# Pinned third-party dependencies. See docs/DEPENDENCIES.md for how to update.
# Only fetched when the platform host is requested; the core library and tests have no
# third-party dependencies.
set(ASCEND_SDL3_TAG    "release-3.4.18" CACHE STRING "SDL3 git tag")
set(ASCEND_SDL3_COMMIT "829a65d769d935c4852f8159e964312c0957260a" CACHE STRING "SDL3 tag commit (verified after fetch)")
set(ASCEND_CGLTF_TAG    "v1.15" CACHE STRING "cgltf git tag")
set(ASCEND_CGLTF_COMMIT "360db1a95480fe102ae9c69b27c5d101167ff5ba" CACHE STRING "cgltf tag commit")
set(ASCEND_STB_COMMIT   "2c980bb59875b0d32144a71867fbdebb2f77cd20" CACHE STRING "stb commit (stb has no tags)")

# cgltf (single header, MIT) is used by engine/assets/glb_loader.cpp. Fetched over git and verified
# against the pinned commit. Set -DASCEND_WITH_GLTF=OFF to build without model loading (tests that need it are skipped).
option(ASCEND_WITH_GLTF "Build the glTF/GLB importer (fetches cgltf over git)" ON)
if(ASCEND_WITH_GLTF)
  include(FetchContent)
  FetchContent_Declare(cgltf
    GIT_REPOSITORY https://github.com/jkuhlmann/cgltf.git
    GIT_TAG ${ASCEND_CGLTF_TAG}
    GIT_SHALLOW TRUE
    SOURCE_SUBDIR ascend_no_cmake)  # header-only: do not add_subdirectory
  FetchContent_MakeAvailable(cgltf)
  execute_process(COMMAND git -C ${cgltf_SOURCE_DIR} rev-parse HEAD
    OUTPUT_VARIABLE ASCEND_CGLTF_ACTUAL OUTPUT_STRIP_TRAILING_WHITESPACE RESULT_VARIABLE _rc)
  if(NOT _rc EQUAL 0 OR NOT ASCEND_CGLTF_ACTUAL STREQUAL ASCEND_CGLTF_COMMIT)
    message(FATAL_ERROR "cgltf ${ASCEND_CGLTF_TAG} resolved to '${ASCEND_CGLTF_ACTUAL}', expected '${ASCEND_CGLTF_COMMIT}'. "
      "Review the new release, then update cmake/Dependencies.cmake (see docs/DEPENDENCIES.md).")
  endif()
endif()
