# Shared warning flags (also used by the Android build).
option(ASCEND_WARNINGS_AS_ERRORS "Treat warnings as errors" ON)

add_library(ascend_warnings INTERFACE)
if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
  target_compile_options(ascend_warnings INTERFACE -Wall -Wextra -Wpedantic -Wshadow -Wconversion)
  if(ASCEND_WARNINGS_AS_ERRORS)
    target_compile_options(ascend_warnings INTERFACE -Werror)
  endif()
endif()
