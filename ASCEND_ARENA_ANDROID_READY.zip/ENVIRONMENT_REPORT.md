# ENVIRONMENT_REPORT

Produced by running real commands in the agent workspace (re-probed 2026-10-11; a clean configure on 2026-10-16 again fetched cgltf over git successfully). Nothing is assumed.
The workspace was reset once during development (see CHANGELOG); docs were regenerated from a fresh probe.

## Host
| Item | Observed |
|---|---|
| OS | Ubuntu 24.04.5 LTS, Linux 6.18.44 x86_64 |
| CPU / RAM | 2 cores, 7.8 GiB RAM |
| Compilers | g++ 13.3.0, clang 18.1.3 |
| Build tools | CMake 3.28.3, Ninja 1.11.1 |
| Other | OpenJDK 21, Gradle 8.14.3, Python 3.13, Node 22 |
| Lint tools | clang-format and clang-tidy present; cppcheck MISSING |

## Android toolchain
`ANDROID_HOME`, `ANDROID_NDK_HOME` empty; `sdkmanager` and `adb` not found. **Android SDK/NDK are NOT installed
and no emulator or device exists in this workspace.**

## Network (egress policy proxy)
| Host | Result (HTTP code from curl) |
|---|---|
| `git ls-remote https://github.com/...` (SDL, stb, cgltf) | works (git over HTTPS) |
| github.com via curl | 400 (not usable for downloads); git is the working route |
| dl.google.com (Android SDK/NDK) | blocked (000 / proxy 403) |
| repo.maven.apache.org, pypi.org | unreachable (000) |

Policy denials are not worked around.

## Consequences
1. No APK can be built or run here. Android build is documented and wired in CI but is **NOT VERIFIED**.
2. Source dependencies can be fetched with git and pinned by commit (SDL3, cgltf, stb).
3. Everything else (gameplay core, UI model, renderer on CPU, tools, tests) builds and runs here.
4. No GPU, display or audio device: rendering is CPU-only and audio output is checked only with SDL's dummy driver.

## Missing for a real Android build
Android SDK platform + build-tools, NDK (pin in CI), JDK 17+, network access to dl.google.com and Google Maven,
and a user-owned signing keystore for release builds.
