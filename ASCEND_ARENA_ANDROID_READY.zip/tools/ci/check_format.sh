#!/usr/bin/env bash
# Fails (exit 1) if any first-party C++ file is not clang-format clean. Run from anywhere.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
command -v clang-format >/dev/null || { echo "ERROR: clang-format not found" >&2; exit 2; }
cd "$ROOT"
git ls-files | grep -E '\.(cpp|h)$' | grep -v '^third_party/' | xargs clang-format --dry-run -Werror --style=file
echo "format OK"
