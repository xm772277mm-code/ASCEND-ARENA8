#!/usr/bin/env bash
# One-command build + test. Needs git access to github.com on first configure (cgltf, and SDL3 for `platform`);
# the fetched sources are verified against the commits pinned in cmake/Dependencies.cmake.
#   tools/ci/build_and_test.sh            -> core library, unit tests, content validation test
#   tools/ci/build_and_test.sh platform   -> also builds the headless SDL3 host and runs its smoke test
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

command -v cmake >/dev/null || { echo "ERROR: cmake not found (need >= 3.22)" >&2; exit 1; }
command -v ninja >/dev/null || { echo "ERROR: ninja not found" >&2; exit 1; }
if ! command -v g++ >/dev/null && ! command -v clang++ >/dev/null; then
  echo "ERROR: no C++ compiler found (need g++ >= 11 or clang++ >= 14)" >&2
  exit 1
fi

BUILD="$ROOT/build"
ARGS=(-DASCEND_BUILD_PLATFORM=OFF)
if [ "${1:-}" = "platform" ]; then
  BUILD="$ROOT/build-platform"
  ARGS=(-DASCEND_BUILD_PLATFORM=ON -DASCEND_SDL_HEADLESS=ON)
fi
cmake -S "$ROOT" -B "$BUILD" -G Ninja "${ARGS[@]}"
cmake --build "$BUILD"
ctest --test-dir "$BUILD" --output-on-failure
