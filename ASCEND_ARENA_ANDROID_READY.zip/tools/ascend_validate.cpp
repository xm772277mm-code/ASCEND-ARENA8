// ascend_validate <content_dir> [--src DIR]...   Exit code: 0 = valid (warnings allowed), 1 = errors, 2 = usage.
#include <cstdio>
#include <cstring>

#include "validator.h"

int main(int argc, char** argv) {
  if (argc < 2) {
    std::fprintf(stderr, "usage: %s <content_dir> [--src DIR]... [--no-catalog]\n", argv[0]);
    return 2;
  }
  ascend::ValidatorOptions opt;
  opt.contentRoot = argv[1];
  for (int i = 2; i < argc; ++i) {
    if (!std::strcmp(argv[i], "--src") && i + 1 < argc)
      opt.sourceRoots.push_back(argv[++i]);
    else if (!std::strcmp(argv[i], "--no-catalog"))
      opt.checkCatalogCsv = false;
    else {
      std::fprintf(stderr, "unknown argument: %s\n", argv[i]);
      return 2;
    }
  }
  const auto rep = ascend::ValidateContent(opt);
  for (const auto& i : rep.issues)
    std::printf("%s: %s: %s\n", i.severity == ascend::ValidationIssue::Severity::Error ? "ERROR" : "WARNING",
                i.where.c_str(), i.message.c_str());
  std::printf("validation: %d error(s), %d warning(s)\n", rep.Errors(), rep.Warnings());
  return rep.Errors() == 0 ? 0 : 1;
}
