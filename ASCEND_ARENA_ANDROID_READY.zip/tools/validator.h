#pragma once
// Content validator: checks everything under content/ that the game loads, plus localization keys used
// by source code. Used by the ascend_validate CLI (exit code != 0 on any error) and by unit tests.
#include <string>
#include <vector>

namespace ascend {

struct ValidationIssue {
  enum class Severity { Error, Warning };
  Severity severity = Severity::Error;
  std::string where;    // file (and section) the problem is in
  std::string message;  // actionable text
};

struct ValidationReport {
  std::vector<ValidationIssue> issues;
  int Errors() const;
  int Warnings() const;
  void Add(ValidationIssue::Severity s, std::string where, std::string msg);
};

struct ValidatorOptions {
  std::string contentRoot;                         // e.g. <repo>/content
  std::vector<std::string> sourceRoots;            // directories scanned for T("key") literals (may be empty)
  std::vector<std::string> languages{"en", "ar"};  // catalogs that must be complete
  bool checkCatalogCsv = true;                     // content/ASSET_CATALOG.csv must list every model/font
};

ValidationReport ValidateContent(const ValidatorOptions& opt);

}  // namespace ascend
