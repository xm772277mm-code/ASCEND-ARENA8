#!/usr/bin/env python3
"""Generates original, rigged, animated humanoid test characters as binary glTF (.glb).

Everything here is authored by this project (no third-party art). The characters are blocky
placeholders with a real 15-joint skeleton, rigid skinning and 7 animation clips
(idle, walk, run, attack, hit, dodge, defeat), so the engine's GLB/skinning/animation pipeline
can be exercised end to end. They are NOT production art.

Usage: make_humanoid_glb.py <out_dir>
Conventions: glTF right-handed, +Y up, character faces +Z (its right hand is at -X).
"""
import json, math, os, struct, sys

# ----------------------------------------------------------------------------- math helpers
def qmul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return (aw*bx + ax*bw + ay*bz - az*by, aw*by - ax*bz + ay*bw + az*bx,
            aw*bz + ax*by - ay*bx + az*bw, aw*bw - ax*bx - ay*by - az*bz)

def qaxis(axis, ang):
    s = math.sin(ang / 2)
    x, y, z = axis
    return (x*s, y*s, z*s, math.cos(ang / 2))

QI = (0.0, 0.0, 0.0, 1.0)
def rx(a): return qaxis((1, 0, 0), a)
def ry(a): return qaxis((0, 1, 0), a)
def rz(a): return qaxis((0, 0, 1), a)

# ----------------------------------------------------------------------------- skeleton
# name, parent, rest translation (local)
JOINTS = [
    ("hips", None, (0, 0.85, 0)),
    ("spine", "hips", (0, 0.15, 0)),
    ("chest", "spine", (0, 0.25, 0)),
    ("head", "chest", (0, 0.30, 0)),
    ("upper_arm_L", "chest", (0.34, 0.12, 0)),   # character's left is +X in glTF
    ("lower_arm_L", "upper_arm_L", (0, -0.28, 0)),
    ("upper_arm_R", "chest", (-0.34, 0.12, 0)),
    ("lower_arm_R", "upper_arm_R", (0, -0.28, 0)),
    ("weapon", "lower_arm_R", (0, -0.28, 0)),
    ("thigh_L", "hips", (0.14, -0.05, 0)),
    ("shin_L", "thigh_L", (0, -0.40, 0)),
    ("foot_L", "shin_L", (0, -0.38, 0)),
    ("thigh_R", "hips", (-0.14, -0.05, 0)),
    ("shin_R", "thigh_R", (0, -0.40, 0)),
    ("foot_R", "shin_R", (0, -0.38, 0)),
]
IDX = {n: i for i, (n, _, _) in enumerate(JOINTS)}

def world_positions():
    pos = {}
    for n, p, t in JOINTS:
        base = pos[p] if p else (0, 0, 0)
        pos[n] = (base[0] + t[0], base[1] + t[1], base[2] + t[2])
    return pos

WORLD = world_positions()

# ----------------------------------------------------------------------------- geometry
def box(cx, cy, cz, sx, sy, sz):
    """Returns (positions, indices) for an axis aligned box with CCW outward faces (glTF)."""
    hx, hy, hz = sx / 2, sy / 2, sz / 2
    faces = [  # normal, 4 corners CCW seen from outside
        ((0, 0, 1),  [(-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]),
        ((0, 0, -1), [(hx, -hy, -hz), (-hx, -hy, -hz), (-hx, hy, -hz), (hx, hy, -hz)]),
        ((1, 0, 0),  [(hx, -hy, hz), (hx, -hy, -hz), (hx, hy, -hz), (hx, hy, hz)]),
        ((-1, 0, 0), [(-hx, -hy, -hz), (-hx, -hy, hz), (-hx, hy, hz), (-hx, hy, -hz)]),
        ((0, 1, 0),  [(-hx, hy, hz), (hx, hy, hz), (hx, hy, -hz), (-hx, hy, -hz)]),
        ((0, -1, 0), [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, -hy, hz), (-hx, -hy, hz)]),
    ]
    pos, idx = [], []
    for _, quad in faces:
        b = len(pos)
        for (x, y, z) in quad:
            pos.append((cx + x, cy + y, cz + z))
        idx += [b, b + 1, b + 2, b, b + 2, b + 3]
    return pos, idx

class Builder:
    """Collects rigidly skinned boxes, grouped by material."""
    def __init__(self):
        self.mats = {}  # material name -> {"color": (r,g,b,a), "pos": [], "joint": [], "idx": []}

    def material(self, name, color):
        self.mats.setdefault(name, {"color": color, "pos": [], "joint": [], "idx": []})

    def add(self, mat, joint, cx, cy, cz, sx, sy, sz):
        m = self.mats[mat]
        pos, idx = box(cx, cy, cz, sx, sy, sz)
        b = len(m["pos"])
        m["pos"] += pos
        m["joint"] += [IDX[joint]] * len(pos)
        m["idx"] += [b + i for i in idx]

def build_character(pal, armored=False, scale=1.0, long_hair=False):
    b = Builder()
    for name, col in pal.items():
        b.material(name, col)
    W = WORLD
    # legs
    for side, sgn in (("L", 1), ("R", -1)):
        b.add("coat", "thigh_" + side, sgn * 0.14, 0.60, 0, 0.19, 0.42, 0.22)
        b.add("coat", "shin_" + side, sgn * 0.14, 0.22, 0, 0.17, 0.40, 0.20)
        b.add("boots", "foot_" + side, sgn * 0.14, 0.07, 0.04, 0.20, 0.14, 0.32)
    # torso
    b.add("coat", "hips", 0, 0.88, 0, 0.46, 0.18, 0.28)
    b.add("accent", "hips", 0, 0.82, 0, 0.48, 0.07, 0.30)       # belt
    b.add("coat", "spine", 0, 1.08, 0, 0.48, 0.25, 0.28)
    b.add("coat", "chest", 0, 1.34, 0, 0.52, 0.30, 0.30)
    b.add("accent", "chest", 0, 1.30, 0.155, 0.12, 0.48, 0.02)  # sash
    if armored:
        b.add("armor", "chest", 0, 1.34, 0.17, 0.46, 0.26, 0.04)  # breastplate
        b.add("armor", "upper_arm_L", 0.38, 1.50, 0, 0.22, 0.12, 0.26)  # pauldrons
        b.add("armor", "upper_arm_R", -0.38, 1.50, 0, 0.22, 0.12, 0.26)
        b.add("armor", "lower_arm_L", 0.34, 1.00, 0, 0.17, 0.16, 0.19)  # gauntlets
        b.add("armor", "lower_arm_R", -0.34, 1.00, 0, 0.17, 0.16, 0.19)
    # head
    b.add("skin", "head", 0, 1.62, 0, 0.26, 0.28, 0.26)
    b.add("hair", "head", 0, 1.76, -0.02, 0.30, 0.12, 0.30)
    b.add("hair", "head", 0, 1.64, -0.15, 0.28, 0.30, 0.08)
    b.add("hair", "head", 0, 1.70, 0.14, 0.26, 0.06, 0.04)       # fringe
    b.add("dark", "head", 0.07, 1.62, 0.135, 0.05, 0.05, 0.02)   # eyes
    b.add("dark", "head", -0.07, 1.62, 0.135, 0.05, 0.05, 0.02)
    if long_hair:
        b.add("hair", "chest", 0, 1.30, -0.20, 0.30, 0.55, 0.08)
    # cape (accent colored, darker) hangs from the chest
    b.add("cape", "chest", 0, 1.15, -0.19, 0.44, 0.62, 0.04)
    # arms
    for side, sgn in (("L", 1), ("R", -1)):
        b.add("coat", "upper_arm_" + side, sgn * 0.34, 1.24, 0, 0.14, 0.30, 0.16)
        b.add("coat", "lower_arm_" + side, sgn * 0.34, 0.96, 0, 0.13, 0.30, 0.15)
        b.add("skin", "lower_arm_" + side, sgn * 0.34, 0.78, 0, 0.11, 0.08, 0.11)
    # weapon in the right hand (blade pointing forward when the arm is raised)
    b.add("dark", "weapon", -0.34, 0.74, 0, 0.07, 0.14, 0.07)
    b.add("accent", "weapon", -0.34, 0.80, 0, 0.20, 0.04, 0.07)
    b.add("blade", "weapon", -0.34, 1.30, 0, 0.05, 1.00, 0.025)
    if scale != 1.0:
        for m in b.mats.values():
            m["pos"] = [(x * scale, y * scale, z * scale) for (x, y, z) in m["pos"]]
    return b

# ----------------------------------------------------------------------------- animation
def lerp(a, b, t): return a + (b - a) * t

def clips(scale=1.0):
    """Returns {name: (duration, {joint: {"t": [(time, vec3)], "r": [(time, quat)]}}, loop)}."""
    C = {}

    def sinwave(f, n=12):
        return [i / n for i in range(n + 1)], f

    def cyc(duration, fn, joints, n=12):
        out = {j: {"r": [], "t": []} for j in joints}
        for i in range(n + 1):
            ph = i / n
            for j in joints:
                r, t = fn(j, ph)
                if r is not None: out[j]["r"].append((ph * duration, r))
                if t is not None: out[j]["t"].append((ph * duration, t))
        return {j: v for j, v in out.items() if v["r"] or v["t"]}

    rest_t = {n: t for n, _, t in JOINTS}

    # idle: gentle breathing, 2 s loop
    def idle(j, ph):
        s = math.sin(ph * 2 * math.pi)
        if j == "chest": return rx(0.03 * s), None
        if j == "head": return rx(-0.02 * s), None
        if j == "hips": return None, (rest_t["hips"][0], rest_t["hips"][1] + 0.01 * s, 0)
        if j == "upper_arm_L": return rz(-0.05 + 0.02 * s), None
        if j == "upper_arm_R": return qmul(rz(0.05 - 0.02 * s), rx(-0.5)), None  # sword hand slightly forward
        return None, None
    C["idle"] = (2.0, cyc(2.0, idle, ["chest", "head", "hips", "upper_arm_L", "upper_arm_R"]), True)

    def gait(amp, lean, bob):
        def f(j, ph):
            s = math.sin(ph * 2 * math.pi)
            c = math.cos(ph * 2 * math.pi)
            if j == "thigh_L": return rx(amp * s), None
            if j == "thigh_R": return rx(-amp * s), None
            if j == "shin_L": return rx(max(0.0, -s) * amp * 1.4), None
            if j == "shin_R": return rx(max(0.0, s) * amp * 1.4), None
            if j == "upper_arm_L": return rx(-amp * 0.8 * s), None
            if j == "upper_arm_R": return qmul(rx(-0.5 + amp * 0.3 * s), QI), None
            if j == "spine": return qmul(rx(lean), ry(0.08 * s)), None
            if j == "hips": return None, (rest_t["hips"][0], rest_t["hips"][1] + bob * abs(c), 0)
            return None, None
        return f
    gj = ["thigh_L", "thigh_R", "shin_L", "shin_R", "upper_arm_L", "upper_arm_R", "spine", "hips"]
    C["walk"] = (1.0, cyc(1.0, gait(0.5, 0.05, 0.03), gj), True)
    C["run"] = (0.6, cyc(0.6, gait(0.95, 0.22, 0.05), gj), True)

    # attack (one shot, 0.5 s): wind up the sword arm, slash forward and down, recover.
    def key(times_vals):
        return times_vals
    attack = {
        "upper_arm_R": {"r": [(0.00, rx(-0.5)), (0.12, rx(-2.6)), (0.22, rx(-2.9)), (0.34, rx(0.2)), (0.50, rx(-0.5))], "t": []},
        "lower_arm_R": {"r": [(0.00, QI), (0.12, rx(-0.4)), (0.22, rx(-0.5)), (0.34, QI), (0.50, QI)], "t": []},
        "spine": {"r": [(0.00, QI), (0.12, ry(0.45)), (0.22, ry(0.5)), (0.34, qmul(rx(0.25), ry(-0.45))), (0.50, QI)], "t": []},
        "hips": {"r": [], "t": [(0.00, rest_t["hips"]), (0.22, (rest_t["hips"][0], rest_t["hips"][1] - 0.05, -0.04)),
                                 (0.34, (rest_t["hips"][0], rest_t["hips"][1] - 0.08, 0.14)), (0.50, rest_t["hips"])]},
        "thigh_L": {"r": [(0.00, QI), (0.34, rx(-0.5)), (0.50, QI)], "t": []},
        "thigh_R": {"r": [(0.00, QI), (0.34, rx(0.4)), (0.50, QI)], "t": []},
    }
    C["attack"] = (0.5, attack, False)

    hit = {
        "spine": {"r": [(0.00, QI), (0.08, rx(-0.45)), (0.35, QI)], "t": []},
        "head": {"r": [(0.00, QI), (0.08, rx(-0.4)), (0.35, QI)], "t": []},
        "hips": {"r": [], "t": [(0.00, rest_t["hips"]), (0.08, (rest_t["hips"][0], rest_t["hips"][1] - 0.04, -0.12)), (0.35, rest_t["hips"])]},
        "upper_arm_R": {"r": [(0.00, rx(-0.5)), (0.08, rx(0.3)), (0.35, rx(-0.5))], "t": []},
    }
    C["hit"] = (0.35, hit, False)

    dodge = {
        "hips": {"r": [], "t": [(0.00, rest_t["hips"]), (0.12, (rest_t["hips"][0], rest_t["hips"][1] - 0.30, 0.1)),
                                 (0.32, (rest_t["hips"][0], rest_t["hips"][1] - 0.25, 0.3)), (0.45, rest_t["hips"])]},
        "spine": {"r": [(0.00, QI), (0.12, rx(0.7)), (0.32, rx(0.6)), (0.45, QI)], "t": []},
        "thigh_L": {"r": [(0.00, QI), (0.12, rx(-1.0)), (0.32, rx(-0.8)), (0.45, QI)], "t": []},
        "thigh_R": {"r": [(0.00, QI), (0.12, rx(-0.6)), (0.32, rx(0.2)), (0.45, QI)], "t": []},
        "shin_L": {"r": [(0.00, QI), (0.12, rx(1.2)), (0.45, QI)], "t": []},
        "shin_R": {"r": [(0.00, QI), (0.12, rx(0.8)), (0.45, QI)], "t": []},
        "upper_arm_R": {"r": [(0.00, rx(-0.5)), (0.12, rx(0.6)), (0.45, rx(-0.5))], "t": []},
    }
    C["dodge"] = (0.45, dodge, False)

    defeat = {
        "hips": {"r": [(0.00, QI), (0.9, rx(-1.45))], "t": [(0.00, rest_t["hips"]), (0.45, (rest_t["hips"][0], rest_t["hips"][1] - 0.35, -0.1)), (0.9, (rest_t["hips"][0], 0.22, -0.35))]},
        "thigh_L": {"r": [(0.00, QI), (0.9, rx(0.8))], "t": []},
        "thigh_R": {"r": [(0.00, QI), (0.9, rx(0.4))], "t": []},
        "shin_L": {"r": [(0.00, QI), (0.9, rx(0.9))], "t": []},
        "upper_arm_L": {"r": [(0.00, QI), (0.9, rz(-0.9))], "t": []},
        "upper_arm_R": {"r": [(0.00, rx(-0.5)), (0.9, rz(0.9))], "t": []},
        "head": {"r": [(0.00, QI), (0.9, rx(0.3))], "t": []},
    }
    C["defeat"] = (0.9, defeat, False)
    return C

# ----------------------------------------------------------------------------- glb writer
class Buf:
    def __init__(self):
        self.data = bytearray()
        self.views = []
        self.accessors = []

    def _pad(self):
        while len(self.data) % 4: self.data.append(0)

    def add(self, raw, target=None):
        self._pad()
        off = len(self.data)
        self.data += raw
        v = {"buffer": 0, "byteOffset": off, "byteLength": len(raw)}
        if target: v["target"] = target
        self.views.append(v)
        return len(self.views) - 1

    def accessor(self, view, ctype, count, atype, mn=None, mx=None):
        a = {"bufferView": view, "componentType": ctype, "count": count, "type": atype}
        if mn is not None: a["min"] = mn
        if mx is not None: a["max"] = mx
        self.accessors.append(a)
        return len(self.accessors) - 1

def write_glb(path, name, builder, scale=1.0):
    buf = Buf()
    nodes, skins, meshes, materials, prims = [], [], [], [], []
    # nodes: 0 = skinned mesh node, then joints
    joint_node = {}
    nodes.append({"name": name + "_mesh", "mesh": 0, "skin": 0})
    for i, (jn, parent, t) in enumerate(JOINTS):
        joint_node[jn] = len(nodes)
        nodes.append({"name": jn, "translation": [t[0] * scale, t[1] * scale, t[2] * scale]})
    for i, (jn, parent, t) in enumerate(JOINTS):
        if parent:
            nodes[joint_node[parent]].setdefault("children", []).append(joint_node[jn])

    # inverse bind matrices (column-major, translation by -world position)
    ibm = bytearray()
    for jn, _, _ in JOINTS:
        w = WORLD[jn]
        m = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -w[0] * scale, -w[1] * scale, -w[2] * scale, 1]
        ibm += struct.pack("<16f", *m)
    ibm_acc = buf.accessor(buf.add(bytes(ibm)), 5126, len(JOINTS), "MAT4")
    skins.append({"joints": [joint_node[j] for j, _, _ in JOINTS], "inverseBindMatrices": ibm_acc,
                  "skeleton": joint_node["hips"]})

    for mi, (mname, m) in enumerate(builder.mats.items()):
        if not m["pos"]:
            continue
        materials.append({"name": mname, "pbrMetallicRoughness": {"baseColorFactor": list(m["color"]),
                          "metallicFactor": 0.0, "roughnessFactor": 0.9}})
        pos = m["pos"]
        mn = [min(p[k] for p in pos) for k in range(3)]
        mx = [max(p[k] for p in pos) for k in range(3)]
        pa = buf.accessor(buf.add(b"".join(struct.pack("<3f", *p) for p in pos), 34962), 5126, len(pos), "VEC3", mn, mx)
        ja = buf.accessor(buf.add(b"".join(struct.pack("<4B", j, 0, 0, 0) for j in m["joint"]), 34962), 5121, len(pos), "VEC4")
        wa = buf.accessor(buf.add(b"".join(struct.pack("<4f", 1, 0, 0, 0) for _ in pos), 34962), 5126, len(pos), "VEC4")
        ia = buf.accessor(buf.add(b"".join(struct.pack("<H", i) for i in m["idx"]), 34963), 5123, len(m["idx"]), "SCALAR")
        prims.append({"attributes": {"POSITION": pa, "JOINTS_0": ja, "WEIGHTS_0": wa}, "indices": ia,
                      "material": len(materials) - 1, "mode": 4})
    meshes.append({"name": name, "primitives": prims})

    anims = []
    for cname, (dur, tracks, loop) in clips(scale).items():
        samplers, channels = [], []
        for jn, tr in tracks.items():
            if tr["r"]:
                times = [t for t, _ in tr["r"]]
                ta = buf.accessor(buf.add(b"".join(struct.pack("<f", t) for t in times)), 5126, len(times), "SCALAR", [min(times)], [max(times)])
                va = buf.accessor(buf.add(b"".join(struct.pack("<4f", *q) for _, q in tr["r"])), 5126, len(times), "VEC4")
                samplers.append({"input": ta, "output": va, "interpolation": "LINEAR"})
                channels.append({"sampler": len(samplers) - 1, "target": {"node": joint_node[jn], "path": "rotation"}})
            if tr["t"]:
                times = [t for t, _ in tr["t"]]
                ta = buf.accessor(buf.add(b"".join(struct.pack("<f", t) for t in times)), 5126, len(times), "SCALAR", [min(times)], [max(times)])
                va = buf.accessor(buf.add(b"".join(struct.pack("<3f", v[0] * scale, v[1] * scale, v[2] * scale) for _, v in tr["t"])), 5126, len(times), "VEC3")
                samplers.append({"input": ta, "output": va, "interpolation": "LINEAR"})
                channels.append({"sampler": len(samplers) - 1, "target": {"node": joint_node[jn], "path": "translation"}})
        anims.append({"name": cname, "samplers": samplers, "channels": channels})

    gltf = {
        "asset": {"version": "2.0", "generator": "ASCEND ARENA tools/asset_gen/make_humanoid_glb.py",
                  "copyright": "ASCEND ARENA project (original, procedurally generated)"},
        "scene": 0, "scenes": [{"nodes": [0, joint_node["hips"]]}],
        "nodes": nodes, "skins": skins, "meshes": meshes, "materials": materials, "animations": anims,
        "buffers": [{"byteLength": len(buf.data)}], "bufferViews": buf.views, "accessors": buf.accessors,
    }
    js = json.dumps(gltf, separators=(",", ":")).encode()
    while len(js) % 4: js += b" "
    binc = bytes(buf.data)
    while len(binc) % 4: binc += b"\0"
    total = 12 + 8 + len(js) + 8 + len(binc)
    with open(path, "wb") as f:
        f.write(struct.pack("<4sII", b"glTF", 2, total))
        f.write(struct.pack("<I4s", len(js), b"JSON")); f.write(js)
        f.write(struct.pack("<I4s", len(binc), b"BIN\0")); f.write(binc)
    return total

# ----------------------------------------------------------------------------- characters
def pal(coat, accent, skin, hair, blade, boots, cape, dark=(0.08, 0.08, 0.12, 1.0), armor=(0.55, 0.58, 0.68, 1.0)):
    return {"coat": coat, "accent": accent, "skin": skin, "hair": hair, "blade": blade, "boots": boots,
            "cape": cape, "dark": dark, "armor": armor}

def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(out, exist_ok=True)
    kael = pal((0.16, 0.19, 0.38, 1), (0.78, 0.22, 0.27, 1), (0.92, 0.78, 0.68, 1), (0.88, 0.89, 0.94, 1),
               (0.66, 0.86, 1.0, 1), (0.12, 0.12, 0.16, 1), (0.50, 0.14, 0.18, 1))
    mira = pal((0.45, 0.20, 0.16, 1), (0.95, 0.70, 0.25, 1), (0.85, 0.62, 0.50, 1), (0.60, 0.18, 0.12, 1),
               (1.0, 0.72, 0.45, 1), (0.20, 0.12, 0.10, 1), (0.85, 0.45, 0.15, 1))
    jobs = [("kael", kael, False, 1.0, False), ("kael_armored", kael, True, 1.0, False), ("mira", mira, False, 0.94, True)]
    for name, p, armored, scale, longhair in jobs:
        b = build_character(p, armored=armored, scale=scale, long_hair=longhair)
        size = write_glb(os.path.join(out, name + ".glb"), name, b, scale=scale)
        print(f"{name}.glb: {size} bytes, {sum(len(m['pos']) for m in b.mats.values())} vertices")

if __name__ == "__main__":
    main()
