// ascend_bench <content_dir> [--frames N] [--enemies N]
// Measures wall-clock cost of simulating + drawing the arena scene with the CPU rasterizer for each quality
// tier. Numbers describe THIS machine only (printed with its CPU model); they say nothing about Android phones.
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#include "../engine/input/viewport.h"
#include "../game/bot.h"
#include "../game/hud.h"
#include "../game/scene_renderer.h"
#include "../game/sysinfo.h"
#include "../gameplay/loadout.h"

using namespace ascend;
using Clock = std::chrono::steady_clock;

namespace {
std::string CpuModel() {
  std::ifstream f("/proc/cpuinfo");
  std::string line;
  while (std::getline(f, line))
    if (line.rfind("model name", 0) == 0) return line.substr(line.find(':') + 2);
  return "unknown CPU";
}
}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    std::fprintf(stderr, "usage: %s <content_dir> [--frames N] [--enemies N]\n", argv[0]);
    return 2;
  }
  int frames = 300, enemies = 10;
  for (int i = 2; i + 1 < argc; i += 2) {
    if (!std::strcmp(argv[i], "--frames"))
      frames = std::atoi(argv[i + 1]);
    else if (!std::strcmp(argv[i], "--enemies"))
      enemies = std::atoi(argv[i + 1]);
  }
  frames = std::clamp(frames, 30, 5000);
  enemies = std::clamp(enemies, 0, kMaxEnemiesAlive);
  ContentDb db;
  const auto errs = db.LoadFromDirectory(argv[1]);
  if (!errs.empty()) {
    for (const auto& e : errs) std::fprintf(stderr, "content error: %s\n", e.c_str());
    return 3;
  }
  std::printf("host: %s\nframes per tier: %d, enemies: %d (software rasterizer, single thread)\n", CpuModel().c_str(),
              frames, enemies);
  std::printf("%-7s %-10s %9s %9s %9s %9s %8s\n", "tier", "resolution", "avg ms", "p95 ms", "max ms", "tris", "RSS MB");
  for (const char* q : {"low", "medium", "high"}) {
    const int H = FbHeightForQuality(q), W = H * 16 / 9;
    World w(&db, 5);
    ArenaDef arena;
    arena.half = 14.f;
    w.SetArena(arena);
    w.SetPlayer(BuildLoadout(db, *db.Character("kael"), 5), {0.f, 0.f, 0.f});
    const char* kinds[] = {"wisp_grunt", "bone_brute", "hollow_archer"};
    for (int i = 0; i < enemies; ++i) {
      const float a = static_cast<float>(i) * 6.2831853f / static_cast<float>(std::max(enemies, 1));
      w.SpawnEnemy(kinds[i % 3], {std::sin(a) * 9.f, 0.f, std::cos(a) * 9.f}, 0, true);
    }
    OrbitCamera cam;
    cam.Snap(w.player().pos);
    SceneRenderer sr;
    sr.SetQuality(std::string(q) == "low" ? Quality::Low
                                          : (std::string(q) == "high" ? Quality::High : Quality::Medium));
    Framebuffer fb(W, H);
    Rasterizer rast;
    ScriptedBot bot;
    const TouchLayout layout =
        TouchLayout::ForScreen(static_cast<float>(W), static_cast<float>(H), static_cast<float>(H) / 70.f);
    HudInfo info;
    HudOptions opt;
    DebugStats dbg;
    std::vector<double> ms;
    int tris = 0;
    for (int f = 0; f < frames; ++f) {
      if (w.AliveEnemyCount() < enemies)
        w.SpawnEnemy("wisp_grunt", {12.f, 0.f, 12.f}, 0, true);  // keep the load constant
      if (!w.player().Alive()) w.SetPlayer(BuildLoadout(db, *db.Character("kael"), 5), {0.f, 0.f, 0.f});
      const auto t0 = Clock::now();
      w.Step(bot.Next(w, cam.yaw()), cam.yaw(), 1.f / 60.f);
      sr.OnEvents(w.TakeEvents(), w, db);
      sr.Update(1.f / 60.f);
      const Camera c = cam.Update(w.player().pos, w.arena(), 1.f / 60.f);
      sr.Draw(fb, rast, w, c);
      sr.DrawTexts(fb, rast);
      DrawHud(fb, rast, w, db, nullptr, layout, info, opt, dbg);
      const auto t1 = Clock::now();
      ms.push_back(std::chrono::duration<double, std::milli>(t1 - t0).count());
      tris = std::max(tris, rast.stats().trianglesDrawn);
    }
    std::sort(ms.begin(), ms.end());
    double sum = 0;
    for (double v : ms) sum += v;
    std::printf("%-7s %4dx%-5d %9.2f %9.2f %9.2f %9d %8ld\n", q, W, H, sum / static_cast<double>(ms.size()),
                ms[ms.size() * 95 / 100], ms.back(), tris, ReadRssKb() / 1024);
  }
  return 0;
}
