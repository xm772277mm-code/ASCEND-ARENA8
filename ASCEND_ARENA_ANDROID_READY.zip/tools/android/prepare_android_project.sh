#!/usr/bin/env bash
# Generates a Gradle Android project in OUT_DIR (default: build/android) from SDL's pinned android-project
# template, wires it to this repository's CMake build and bundles content/ as APK assets.
#
#   tools/android/prepare_android_project.sh [OUT_DIR]
#
# Environment:
#   SDL_SRC        path to an SDL checkout at the pinned tag (otherwise cloned from github.com and verified)
#   ASCEND_APP_ID  Android applicationId   (default com.ascendarena.game)
#   ASCEND_VERSION versionName             (default read from CMakeLists.txt project VERSION)
#   ASCEND_ABIS    comma list of ABIs      (default arm64-v8a)
#   ASCEND_NDK     NDK version string      (default read from this script's pin below)
#   ASCEND_ALLOWED_PERMISSIONS  comma list of Android permissions the manifest may request (default: none)
#
# Nothing here needs the Android SDK; running Gradle on the result does (see docs/ANDROID_BUILD.md).
# Status: this script is exercised in the agent workspace (generation + host-side CMake configure only).
# The Gradle/NDK build itself has NOT been executed anywhere yet.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT="${1:-$ROOT/build/android}"
case "$OUT" in /*) ;; *) OUT="$PWD/$OUT" ;; esac
APP_ID="${ASCEND_APP_ID:-com.ascendarena.game}"
ABIS="${ASCEND_ABIS:-arm64-v8a,armeabi-v7a}"
NDK_VERSION="${ASCEND_NDK:-28.2.13676358}"   # the NDK pinned by SDL's android-project template at release-3.4.18
VERSION="${ASCEND_VERSION:-$(sed -n 's/^project(AscendArena VERSION \([0-9.]*\).*/\1/p' "$ROOT/CMakeLists.txt")}"
[ -n "$VERSION" ] || { echo "ERROR: cannot read project version from CMakeLists.txt" >&2; exit 1; }
case "$APP_ID" in *[!A-Za-z0-9._]*|"") echo "ERROR: invalid ASCEND_APP_ID '$APP_ID'" >&2; exit 1;; esac

TAG="$(sed -n 's/^set(ASCEND_SDL3_TAG *"\([^"]*\)".*/\1/p' "$ROOT/cmake/Dependencies.cmake")"
COMMIT="$(sed -n 's/^set(ASCEND_SDL3_COMMIT *"\([^"]*\)".*/\1/p' "$ROOT/cmake/Dependencies.cmake")"
[ -n "$TAG" ] && [ -n "$COMMIT" ] || { echo "ERROR: SDL pin missing in cmake/Dependencies.cmake" >&2; exit 1; }

SDL="${SDL_SRC:-}"
if [ -z "$SDL" ]; then
  SDL="$ROOT/build/sdl-for-android"
  if [ ! -d "$SDL/.git" ]; then
    command -v git >/dev/null || { echo "ERROR: git not found" >&2; exit 1; }
    git clone --quiet --depth 1 --branch "$TAG" https://github.com/libsdl-org/SDL.git "$SDL"
  fi
fi
ACTUAL="$(git -C "$SDL" rev-parse HEAD)"
[ "$ACTUAL" = "$COMMIT" ] || { echo "ERROR: SDL at $SDL is $ACTUAL, expected $COMMIT ($TAG)" >&2; exit 1; }
[ -d "$SDL/android-project" ] || { echo "ERROR: $SDL/android-project not found" >&2; exit 1; }

rm -rf "$OUT"
mkdir -p "$OUT"
cp -R "$SDL/android-project/." "$OUT/"
rm -f "$OUT/app/jni/src/YourSourceHere.c" "$OUT/app/jni/src/Android.mk" "$OUT/app/jni/src/CMakeLists.txt" "$OUT/app/jni/Android.mk" "$OUT/app/jni/Application.mk"
rmdir "$OUT/app/jni/src" 2>/dev/null || true

# Native build: Gradle -> app/jni/CMakeLists.txt -> this repository (platform host builds libmain.so and SDL3).
cat > "$OUT/app/jni/CMakeLists.txt" <<CMAKE
cmake_minimum_required(VERSION 3.22)
project(AscendArenaAndroid LANGUAGES CXX)
# ASCEND_REPO_DIR is passed by Gradle (see app/build.gradle).
set(ASCEND_BUILD_PLATFORM ON CACHE BOOL "" FORCE)
set(ASCEND_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(ASCEND_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
add_subdirectory(\${ASCEND_REPO_DIR} ascend)
CMAKE

export OUT APP_ID VERSION ABIS NDK_VERSION ROOT ASCEND_ALLOWED_PERMISSIONS
python3 - <<'PY'
import os, re, sys
out, app_id, version, abis, ndk, root = (os.environ[k] for k in ("OUT","APP_ID","VERSION","ABIS","NDK_VERSION","ROOT"))

def patch(path, subs):
    s = open(path, encoding="utf-8").read()
    for pattern, repl in subs:
        s2, n = re.subn(pattern, repl, s, flags=re.M)
        if n == 0:
            sys.exit(f"ERROR: template changed: pattern not found in {path}: {pattern}")
        s = s2
    open(path, "w", encoding="utf-8").write(s)

abi_list = ", ".join(f"'{a.strip()}'" for a in abis.split(",") if a.strip())
# Version code derives from the semantic version: major*10000 + minor*100 + patch.
parts = (version.split(".") + ["0", "0", "0"])[:3]
code = int(parts[0]) * 10000 + int(parts[1]) * 100 + int(parts[2])
patch(f"{out}/app/build.gradle", [
    (r'namespace = "org\.libsdl\.app"', f'namespace = "org.libsdl.app"\n    // applicationId is the package users see; namespace stays org.libsdl.app because SDL\'s Java classes live there.'),
    (r'ndkVersion = "[^"]*"', f'ndkVersion = "{ndk}"'),
    (r'minSdkVersion 21', 'applicationId "%s"\n        minSdkVersion 21' % app_id),
    (r'versionCode 1', f'versionCode {code}'),
    (r'versionName "1\.0"', f'versionName "{version}"'),
    (r'arguments "-DANDROID_PLATFORM=android-21", "-DANDROID_STL=c\+\+_static"',
     f'arguments "-DANDROID_PLATFORM=android-21", "-DANDROID_STL=c++_static", "-DASCEND_REPO_DIR={root}"'),
    (r"(cmake \{\s*arguments[^\n]*\n\s*)// abiFilters[^\n]*\n\s*abiFilters '[^']*'", r"\1abiFilters " + abi_list),
])
patch(f"{out}/app/src/main/AndroidManifest.xml", [
    (r'android:allowBackup="true"', 'android:allowBackup="false"'),
    (r'android:launchMode="singleInstance"', 'android:launchMode="singleInstance"\n            android:screenOrientation="sensorLandscape"'),
])
# Least privilege: the game is offline and uses no haptics, so the template's active VIBRATE permission is removed.
patch(f"{out}/app/src/main/AndroidManifest.xml", [
    (r'^[ \t]*<uses-permission android:name="android\.permission\.VIBRATE" />\n', ''),
])
# Permission gate: parse the manifest (comments are ignored by the parser) and fail on any active permission.
import xml.etree.ElementTree as ET
ns = "{http://schemas.android.com/apk/res/android}name"
perms = [e.get(ns) for e in ET.parse(f"{out}/app/src/main/AndroidManifest.xml").getroot().iter("uses-permission")]
allowed = set(filter(None, os.environ.get("ASCEND_ALLOWED_PERMISSIONS", "").split(",")))
extra = [p for p in perms if p not in allowed]
if extra:
    sys.exit("ERROR: manifest requests permissions not in ASCEND_ALLOWED_PERMISSIONS: " + ", ".join(extra))
print("manifest permissions: " + (", ".join(perms) if perms else "none"))
patch(f"{out}/app/src/main/res/values/strings.xml", [(r"<string name=\"app_name\">[^<]*</string>", '<string name="app_name">ASCEND ARENA</string>')])
PY
# The template builds with ndk-build unless BUILD_WITH_CMAKE is set: make CMake the default.
echo "BUILD_WITH_CMAKE=true" >> "$OUT/gradle.properties"

# Bundle game content as assets + manifest consumed by platform/host.cpp (first-run extraction to private storage).
ASSETS="$OUT/app/src/main/assets/content"
mkdir -p "$ASSETS"
(cd "$ROOT/content" && find . -type f ! -name manifest.txt | sed 's#^\./##' | LC_ALL=C sort) > "$OUT/.files"
while IFS= read -r f; do mkdir -p "$ASSETS/$(dirname "$f")"; cp "$ROOT/content/$f" "$ASSETS/$f"; done < "$OUT/.files"
HASH="$(cd "$ROOT/content" && xargs -a "$OUT/.files" sha256sum | sha256sum | cut -c1-16)"
{ echo "version $HASH"; cat "$OUT/.files"; } > "$ASSETS/manifest.txt"
rm -f "$OUT/.files"

echo "Android project written to: $OUT"
echo "  applicationId: $APP_ID  version: $VERSION  ABIs: $ABIS  NDK: $NDK_VERSION"
echo "  assets: $(wc -l < "$ASSETS/manifest.txt") manifest lines (version $HASH)"
echo "Next (needs Android SDK + NDK, see docs/ANDROID_BUILD.md):  cd $OUT && ./gradlew assembleDebug"
