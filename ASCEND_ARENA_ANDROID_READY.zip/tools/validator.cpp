#include "validator.h"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>

#include "../engine/assets/glb_loader.h"
#include "../engine/assets/ini.h"
#include "../gameplay/content_db.h"
#include "../gameplay/modes/levels.h"

namespace ascend {
namespace fs = std::filesystem;
using Sev = ValidationIssue::Severity;

int ValidationReport::Errors() const {
  return static_cast<int>(
      std::count_if(issues.begin(), issues.end(), [](const ValidationIssue& i) { return i.severity == Sev::Error; }));
}
int ValidationReport::Warnings() const { return static_cast<int>(issues.size()) - Errors(); }
void ValidationReport::Add(Sev s, std::string where, std::string msg) {
  issues.push_back({s, std::move(where), std::move(msg)});
}

namespace {

std::string ReadAll(const fs::path& p, bool& ok) {
  std::ifstream f(p, std::ios::binary);
  ok = static_cast<bool>(f);
  std::ostringstream ss;
  if (ok) ss << f.rdbuf();
  return ss.str();
}

// Counts "{0}", "{1}" ... placeholders so translations cannot drop or invent arguments.
std::set<std::string> Placeholders(const std::string& s) {
  std::set<std::string> out;
  for (std::size_t i = 0; i < s.size(); ++i) {
    if (s[i] != '{') continue;
    const auto e = s.find('}', i);
    if (e == std::string::npos) break;
    out.insert(s.substr(i, e - i + 1));
    i = e;
  }
  return out;
}

// Latin letters outside {placeholders}: values like "x{0}" are language-neutral and not flagged.
int LatinLetters(const std::string& s) {
  int n = 0;
  bool inBrace = false;
  for (char c : s) {
    if (c == '{')
      inBrace = true;
    else if (c == '}')
      inBrace = false;
    else if (!inBrace && std::isalpha(static_cast<unsigned char>(c)))
      ++n;
  }
  return n;
}

bool UnbalancedBraces(const std::string& s) {
  int depth = 0;
  for (char c : s) {
    if (c == '{')
      ++depth;
    else if (c == '}' && --depth < 0)
      return true;
    if (depth > 1) return true;
  }
  return depth != 0;
}

// Minimal RFC-4180 style CSV line split (quotes supported).
std::vector<std::string> SplitCsv(const std::string& line) {
  std::vector<std::string> out;
  std::string cur;
  bool q = false;
  for (std::size_t i = 0; i < line.size(); ++i) {
    const char c = line[i];
    if (q) {
      if (c == '"' && i + 1 < line.size() && line[i + 1] == '"') {
        cur += '"';
        ++i;
      } else if (c == '"')
        q = false;
      else
        cur += c;
    } else if (c == '"')
      q = true;
    else if (c == ',') {
      out.push_back(cur);
      cur.clear();
    } else
      cur += c;
  }
  out.push_back(cur);
  return out;
}

void CollectSourceKeys(const fs::path& root, std::map<std::string, std::string>& keys) {
  std::error_code ec;
  for (fs::recursive_directory_iterator it(root, ec), end; !ec && it != end; it.increment(ec)) {
    if (!it->is_regular_file()) continue;
    const auto ext = it->path().extension().string();
    if (ext != ".cpp" && ext != ".h") continue;
    bool ok = false;
    const std::string text = ReadAll(it->path(), ok);
    if (!ok) continue;
    // T("key") and T("key", ...) with dotted lowercase keys; dynamic keys built at runtime are not scanned.
    for (std::size_t p = text.find("T(\""); p != std::string::npos; p = text.find("T(\"", p + 3)) {
      if (p > 0) {
        const char b = text[p - 1];
        if (std::isalnum(static_cast<unsigned char>(b)) || b == '_') continue;  // e.g. "FormatT(\"" or "KT(\""
      }
      const auto e = text.find('"', p + 3);
      if (e == std::string::npos) continue;
      const std::string k = text.substr(p + 3, e - (p + 3));
      if (k.find('.') != std::string::npos && k.find_first_of(" %{}") == std::string::npos)
        keys.emplace(k, it->path().string());
    }
  }
}

}  // namespace

ValidationReport ValidateContent(const ValidatorOptions& opt) {
  ValidationReport rep;
  const fs::path root(opt.contentRoot);
  std::error_code ec;
  if (!fs::is_directory(root, ec)) {
    rep.Add(Sev::Error, opt.contentRoot, "content directory does not exist");
    return rep;
  }

  // ---- 1. Data files: schema, ranges, duplicates, cross references (reused from the game loader) ----
  ContentDb db;
  for (const auto& e : db.LoadFromDirectory(opt.contentRoot)) rep.Add(Sev::Error, "content data", e);
  LevelsDb levels;
  for (const auto& e : levels.LoadFromDirectory(opt.contentRoot, db)) rep.Add(Sev::Error, "levels/levels.ini", e);

  // ---- 2. Referenced files exist and models actually load ----
  std::set<std::string> assetPaths;  // relative paths that must appear in the asset catalog
  for (const auto& [id, ch] : db.characters()) {
    const std::string where = "character [" + id + "]";
    if (ch.modelPath.rfind("builtin:", 0) != 0) {
      const fs::path mp = root / ch.modelPath;
      assetPaths.insert(ch.modelPath);
      if (!fs::is_regular_file(mp, ec)) {
        rep.Add(Sev::Error, where, "model file missing: " + ch.modelPath + " (expected under " + opt.contentRoot + ")");
      } else {
        auto m = LoadGlbFile(mp.string());
        if (!m) rep.Add(Sev::Error, where, "model does not load: " + m.status.message);
      }
    }
    for (const auto& o : ch.outfits) {
      for (const std::string* p : {&o.meshPath, &o.materialPath}) {
        if (p->empty()) continue;
        assetPaths.insert(*p);
        if (!fs::is_regular_file(root / *p, ec))
          rep.Add(Sev::Error, where + " outfit '" + o.id + "'", "referenced file missing: " + *p);
        else if (p == &o.materialPath) {
          auto d = LoadIniFile((root / *p).string());
          if (!d)
            rep.Add(Sev::Error, where + " outfit '" + o.id + "'", d.status.message);
          else if (!d.value.Find("colors"))
            rep.Add(Sev::Error, where + " outfit '" + o.id + "'", *p + " has no [colors] section");
        }
      }
    }
    if (ch.assetLicense.empty() || ch.assetSource.empty() || ch.assetAuthor.empty())
      rep.Add(Sev::Error, where,
              "license metadata incomplete (asset_source, asset_license, asset_author are required)");
    const std::string lic = ch.assetLicense;
    if (lic.find("TODO") != std::string::npos || lic == "unknown" || lic == "?")
      rep.Add(Sev::Error, where, "asset_license is a placeholder ('" + lic + "')");
  }
  const std::string fontPath = "fonts/DejaVuSans.ttf";
  assetPaths.insert(fontPath);
  if (!fs::is_regular_file(root / fontPath, ec)) rep.Add(Sev::Error, "fonts", "required font missing: " + fontPath);

  // ---- 3. Asset catalog (license records for every shipped asset) ----
  if (opt.checkCatalogCsv) {
    const fs::path csv = root / "ASSET_CATALOG.csv";
    bool ok = false;
    const std::string text = ReadAll(csv, ok);
    if (!ok) {
      rep.Add(Sev::Error, "ASSET_CATALOG.csv", "missing: every shipped asset needs a source/author/license row");
    } else {
      std::istringstream in(text);
      std::string line;
      std::getline(in, line);
      const auto header = SplitCsv(line);
      const std::vector<std::string> need{"path", "source", "author", "license", "modifications"};
      std::map<std::string, std::size_t> col;
      for (std::size_t i = 0; i < header.size(); ++i) col[header[i]] = i;
      bool headerOk = true;
      for (const auto& n : need)
        if (!col.count(n)) {
          rep.Add(Sev::Error, "ASSET_CATALOG.csv", "header lacks column '" + n + "'");
          headerOk = false;
        }
      std::set<std::string> listed;
      int lineNo = 1;
      while (headerOk && std::getline(in, line)) {
        ++lineNo;
        if (line.empty() || line[0] == '#') continue;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        const auto f = SplitCsv(line);
        if (f.size() != header.size()) {
          rep.Add(Sev::Error, "ASSET_CATALOG.csv:" + std::to_string(lineNo),
                  "expected " + std::to_string(header.size()) + " columns, found " + std::to_string(f.size()));
          continue;
        }
        const std::string path = f[col["path"]];
        if (!listed.insert(path).second)
          rep.Add(Sev::Error, "ASSET_CATALOG.csv:" + std::to_string(lineNo), "duplicate row for " + path);
        for (const auto& n : {"source", "author", "license"})
          if (f[col[n]].empty())
            rep.Add(Sev::Error, "ASSET_CATALOG.csv:" + std::to_string(lineNo),
                    std::string("empty ") + n + " for " + path);
        if (!fs::exists(root / path, ec))
          rep.Add(Sev::Warning, "ASSET_CATALOG.csv:" + std::to_string(lineNo),
                  "lists a file that does not exist: " + path);
      }
      if (headerOk)
        for (const auto& p : assetPaths)
          if (!listed.count(p)) rep.Add(Sev::Error, "ASSET_CATALOG.csv", "no license row for shipped asset " + p);
    }
  }

  // ---- 4. Localization ----
  std::map<std::string, std::map<std::string, std::string>> cats;
  for (const auto& lang : opt.languages) {
    const std::string file = "localization/" + lang + ".ini";
    auto d = LoadIniFile((root / file).string());
    if (!d) {
      rep.Add(Sev::Error, file, d.status.message);
      continue;
    }
    const IniSection* s = d.value.Find("strings");
    if (!s) {
      rep.Add(Sev::Error, file, "no [strings] section");
      continue;
    }
    cats[lang] = s->values;
    for (const auto& [k, v] : s->values) {
      if (v.empty()) rep.Add(Sev::Error, file, "key '" + k + "' has an empty value");
      if (UnbalancedBraces(v)) rep.Add(Sev::Error, file, "key '" + k + "' has malformed {placeholders}: " + v);
      if (v.find("TODO") != std::string::npos) rep.Add(Sev::Error, file, "key '" + k + "' contains TODO text");
    }
  }
  const std::string base = opt.languages.empty() ? "en" : opt.languages.front();
  if (cats.count(base)) {
    for (const auto& lang : opt.languages) {
      if (lang == base || !cats.count(lang)) continue;
      for (const auto& [k, v] : cats[base]) {
        auto it = cats[lang].find(k);
        if (it == cats[lang].end()) {
          rep.Add(Sev::Error, "localization/" + lang + ".ini", "missing key '" + k + "' (present in " + base + ")");
          continue;
        }
        if (Placeholders(v) != Placeholders(it->second))
          rep.Add(Sev::Error, "localization/" + lang + ".ini",
                  "key '" + k + "' uses different {placeholders} than " + base);
        if (lang != base && it->second == v && LatinLetters(v) >= 3 && lang == "ar" && k.rfind("app.", 0) != 0)
          rep.Add(Sev::Warning, "localization/" + lang + ".ini",
                  "key '" + k + "' is identical to English (untranslated?)");
      }
      for (const auto& [k, v] : cats[lang])
        if (!cats[base].count(k))
          rep.Add(Sev::Warning, "localization/" + lang + ".ini", "stray key '" + k + "' not in " + base);
    }
    // Keys referenced by content data.
    auto need = [&](const std::string& key, const std::string& where) {
      if (key.empty()) return;
      for (const auto& lang : opt.languages)
        if (cats.count(lang) && !cats[lang].count(key))
          rep.Add(Sev::Error, where, "localization key '" + key + "' missing in " + lang + ".ini");
    };
    for (const auto& [id, s] : db.skills()) need(s.nameKey, "skill [" + id + "]");
    for (const auto& [id, e] : db.enemies()) need(e.nameKey, "enemy [" + id + "]");
    for (const auto& [id, i] : db.items()) need(i.nameKey, "item [" + id + "]");
    for (const auto& [id, c] : db.characters()) {
      need(c.nameKey, "character [" + id + "]");
      for (const auto& o : c.outfits) need(o.nameKey, "character [" + id + "] outfit '" + o.id + "'");
    }
    for (const auto& [id, e] : levels.all()) {
      need(e.nameKey, "encounter [" + id + "]");
      need(e.descKey, "encounter [" + id + "]");
      for (const auto& k : e.introDialogue) need(k, "encounter [" + id + "] intro");
      for (const auto& k : e.outroDialogue) need(k, "encounter [" + id + "] outro");
    }
    // Keys used by UI/game source.
    std::map<std::string, std::string> used;
    for (const auto& s : opt.sourceRoots) CollectSourceKeys(s, used);
    for (const auto& [k, file] : used) need(k, fs::path(file).filename().string() + " (T(\"" + k + "\"))");
  }
  return rep;
}

}  // namespace ascend
