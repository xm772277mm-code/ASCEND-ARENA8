// Headless demo: plays a scripted bot through an arena and dumps frames as PPM images.
//   ascend_render_demo <content_dir> <out_dir> [--frames N] [--every K] [--width W] [--height H] [--seed S]
// Exit code 0 on success; nonzero on content/IO errors. Used to look at the game in CI/sandboxes without a GPU.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <string>

#include "../game/bot.h"
#include "../game/hud.h"
#include "../game/scene_renderer.h"
#include "../game/sysinfo.h"
#include "../gameplay/loadout.h"

using namespace ascend;

int main(int argc, char** argv) {
  if (argc < 3) {
    std::fprintf(
        stderr,
        "usage: %s <content_dir> <out_dir> [--frames N] [--every K] [--width W] [--height H] [--seed S] [--level L]\n",
        argv[0]);
    return 2;
  }
  const std::string content = argv[1], out = argv[2];
  int frames = 600, every = 60, W = 960, H = 540, level = 3;
  std::uint64_t seed = 1;
  for (int i = 3; i + 1 < argc; i += 2) {
    if (!std::strcmp(argv[i], "--frames"))
      frames = std::atoi(argv[i + 1]);
    else if (!std::strcmp(argv[i], "--every"))
      every = std::atoi(argv[i + 1]);
    else if (!std::strcmp(argv[i], "--width"))
      W = std::atoi(argv[i + 1]);
    else if (!std::strcmp(argv[i], "--height"))
      H = std::atoi(argv[i + 1]);
    else if (!std::strcmp(argv[i], "--seed"))
      seed = static_cast<std::uint64_t>(std::atoll(argv[i + 1]));
    else if (!std::strcmp(argv[i], "--level"))
      level = std::atoi(argv[i + 1]);
  }
  ContentDb db;
  const auto errs = db.LoadFromDirectory(content);
  if (!errs.empty()) {
    for (const auto& e : errs) std::fprintf(stderr, "content error: %s\n", e.c_str());
    return 3;
  }
  std::error_code ec;
  std::filesystem::create_directories(out, ec);
  if (ec) {
    std::fprintf(stderr, "cannot create %s: %s\n", out.c_str(), ec.message().c_str());
    return 4;
  }

  World w(&db, seed);
  ArenaDef arena;
  arena.half = 14.f;
  for (int sx : {-1, 1})
    for (int sz : {-1, 1}) {
      const float cx = static_cast<float>(sx) * 7.f, cz = static_cast<float>(sz) * 7.f;
      arena.obstacles.push_back({cx - 0.9f, cz - 0.9f, cx + 0.9f, cz + 0.9f});
    }
  w.SetArena(arena);
  w.SetPlayer(BuildLoadout(db, *db.Character("kael"), level), {0.f, 0.f, -9.f});
  w.SpawnEnemy("wisp_grunt", {-5.f, 0.f, 4.f});
  w.SpawnEnemy("wisp_grunt", {5.f, 0.f, 6.f});
  w.SpawnEnemy("bone_brute", {0.f, 0.f, 10.f});
  w.SpawnEnemy("hollow_archer", {-10.f, 0.f, 10.f});
  w.SpawnEnemy("training_dummy", {10.f, 0.f, -4.f});

  OrbitCamera cam;
  cam.SetYaw(0.f);
  cam.Snap(w.player().pos);
  SceneRenderer sr;
  Framebuffer fb(W, H);
  Rasterizer rast;
  ScriptedBot bot;
  TouchLayout layout =
      TouchLayout::ForScreen(static_cast<float>(W), static_cast<float>(H), static_cast<float>(W) / 150.f);
  HudInfo info;
  info.level = level;
  info.xpToNext = 200;
  info.objective = "DEFEAT ALL ENEMIES";
  DebugStats dbg;
  dbg.fps = 60.f;
  dbg.frameMs = 16.6f;
  dbg.rssKb = ReadRssKb();
  HudOptions opt;
  opt.showDebug = true;

  int written = 0;
  for (int f = 0; f < frames; ++f) {
    const InputFrame in = bot.Next(w, cam.yaw());
    w.Step(in, cam.yaw(), 1.f / 60.f);
    sr.OnEvents(w.TakeEvents(), w, db);
    sr.Update(1.f / 60.f);
    const Camera c = cam.Update(w.player().pos, w.arena(), 1.f / 60.f);
    if (f % every == 0 || f == frames - 1) {
      sr.Draw(fb, rast, w, c);
      sr.DrawTexts(fb, rast);
      dbg.triangles = rast.stats().trianglesDrawn;
      dbg.effects = static_cast<int>(sr.effectCount());
      if (w.AliveEnemyCount() == 0) info.banner = "CLEARED";
      DrawHud(fb, rast, w, db, nullptr, layout, info, opt, dbg);
      char name[512];
      std::snprintf(name, sizeof name, "%s/frame_%04d.ppm", out.c_str(), f);
      if (!fb.SavePpm(name)) {
        std::fprintf(stderr, "failed to write %s\n", name);
        return 5;
      }
      ++written;
    }
  }
  std::printf("frames written: %d, enemies alive: %d, defeated: %d, player hp: %d/%d\n", written, w.AliveEnemyCount(),
              w.TotalDefeated(), w.player().hp.cur, w.player().hp.max);
  return 0;
}
