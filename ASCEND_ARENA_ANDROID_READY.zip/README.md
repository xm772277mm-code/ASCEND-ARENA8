# ASCEND ARENA

An original, offline, Android-first 3D third-person action RPG built on **ASCEND ENGINE**, a game-specific C++20
framework (own gameplay/engine layer on SDL3). Characters, story and sounds are original; no third-party game
assets are used.

**Honest status:** the game logic, UI, localization (English/Arabic), modes, save system and tools are built and
tested on a Linux machine (168 automated tests). **No Android APK has been built yet and nothing has run on a
phone.** See `docs/FEATURE_STATUS.md` and `docs/KNOWN_LIMITATIONS.md`. Online multiplayer does not exist.

## What you can do today (desktop/Linux build)

Move with a virtual joystick, orbit the camera, light combo, heavy attack, dodge, three skills; fight 5 enemy
types in missions, training, a dungeon and a 3-chapter story; earn XP, gold and items; equip gear; switch
character/outfit; change language (EN/AR, RTL); progress is saved.

## Build and test on a computer (Linux/macOS with a C++20 compiler, CMake >= 3.22, Ninja, git)

```
tools/ci/build_and_test.sh              # core library + unit tests + content validation
tools/ci/build_and_test.sh platform     # also the SDL3 desktop host (fetches SDL3 over git)
build-platform/platform/ascend_host     # run the game window (keyboard: see docs/MANUAL_TEST_CHECKLIST.md)
build/tools/ascend_validate content --src ui --src game   # content/licence check, exits non-zero on problems
python3 tools/ci/gen_test_report.py --clean --sanitize    # regenerate docs/TEST_REPORT.md from real runs
```

## Build the Android APK from a phone (cloud route, NOT YET VERIFIED)

You cannot compile a native Android game on an ordinary phone. The repository contains a GitHub Actions
workflow intended to build a debug APK in the cloud for both common ARM Android ABIs (32-bit and 64-bit). It has never been run, so expect to fix first-run
problems.

1. Create a free GitHub account and a new **private** repository; upload this project (GitHub's web upload, or the
   GitHub mobile app, or `git push` from any computer).
2. Open the repository's **Actions** tab, choose the workflow **ci**, press **Run workflow**.
3. If the `android debug APK` job succeeds, open the run page and download the artifact `ascend-arena-debug-apk`.
   Unzip it on the phone, then allow "install unknown apps" for your file manager or browser and open the `.apk`.
4. If the job fails, open the failed step's log and send it to whoever is helping you; that log is the next task.

Steps that still need you: the GitHub account/repository, enabling Actions, and installing the APK. A **release**
(Play Store) build additionally needs your own signing keystore: see `docs/ANDROID_BUILD.md`. No secrets are
stored in this repository.

## Repository map

| Path | Contents |
|---|---|
| `engine/` | core math/loop, input, assets (INI, localization, GLB/OBJ), CPU renderer, skeletal animation, text/Arabic shaping, audio |
| `gameplay/` | world simulation, combat, AI, camera, progression, save, game modes |
| `game/` | scene renderer, HUD, character visuals, scripted bot |
| `ui/` | immediate-mode app: lobby, menus, runs, results |
| `platform/` | SDL3 host (desktop and Android entry) |
| `content/` | data (skills, enemies, items, levels), characters, models, fonts, localization, asset catalog |
| `tools/` | validator, benchmark, render demo, GLB generator, Android project generator, CI scripts |
| `tests/` | unit, integration and monkey tests |
| `android/`, `.github/` | Android notes/CMake wiring and the CI workflow |
| `docs/` | ADR, status, limitations, test report, security, manual test checklist, performance guide |

## Licenses

Code: see the repository owner's choice (no licence file has been added yet: **decide before publishing**).
Third-party: `LICENSES/THIRD_PARTY_NOTICES.md`. Assets: `LICENSES/ASSET_NOTICES.md`, `content/ASSET_CATALOG.csv`.
