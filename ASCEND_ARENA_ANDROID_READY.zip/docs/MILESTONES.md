# Milestones vs. the prompt pack

| Prompt | Milestone | State | What is not done / unverified |
|---|---|---|---|
| 0 | Contract, environment report, ADR, plan | Done | Docs were lost once and rewritten; the plan is this table |
| 1 | Stack, build path, skeleton | Done for desktop | Android build route written but never executed |
| 2 | Playable 3D slice | Done (CPU renderer) | Touch feel, lifecycle and low-end behavior not tested on a device |
| 3 | Combat, AI, progression, save | Done | No navmesh; save is local and unencrypted |
| 4 | Characters, animation, outfits, assets | Pipeline done; art is placeholder | 2 characters, procedural blocky models; no textures |
| 5 | Lobby, UI, localization, modes, story | Done | Only EN/AR; no cutscenes/loading screens/rename |
| 6 | Audio, effects, performance, validator | Done (synthesized audio) | No real audio assets, no phone measurements, no GLES backend |
| 7 | Android build, CI, QA, security audit | Audit and docs done | **No APK; CI never executed; signing not configured; no custom icon** |
| 8 | Online multiplayer | **Not started** (by design) | Requires a stable offline game on devices first, then a real server |

Next recommended step: run the CI workflow (or build on a machine with the Android SDK/NDK), install on a real
phone, work through `docs/MANUAL_TEST_CHECKLIST.md`, and fill in `docs/PERFORMANCE.md`.
