# SECURITY_AND_PRIVACY

Scope: the offline single-player game as built. There is no server, account system or telemetry.

## Data and privacy
- No personal data is collected, no analytics, no ads, no network code. The manifest requests **no permissions**
  (verified by parsing the generated `AndroidManifest.xml`), and `allowBackup` is false.
- The only stored data is the player's profile (name, level, XP, gold, inventory, progress, settings) in one local
  file in the app's private storage (SDL pref path; on Android the app-specific internal directory).
- Nothing leaves the device. If online features are added later they need their own privacy policy, retention and
  deletion plan (Prompt 8).

## Local file handling
- Saves are written atomically (temp file, read-back verification, previous file kept as `.bak`), checked by an
  integrity value, versioned, migrated from older versions and **refused if from a newer version** (never
  overwritten). Corrupt files are kept as `.corrupt` and the player gets a visible notice; the backup is used.
- Loaded data is sanitized (ranges, unknown items/characters removed, inventory limits). Tampering is detected as
  corruption, but the file is not encrypted or signed: players can edit their own offline save with effort.
  This is acceptable for offline play and must not be reused for any server-granted reward.
- Content files, GLB models and the font are parsed with size/count limits and validation; a malformed GLB is
  rejected (a misaligned-accessor case found by sanitizer fuzzing was fixed). Content comes from the app package,
  not from the network.
- Spawn counts, projectiles, audio voices and UI input paths are bounded; a random-input monkey test runs under
  ASan/UBSan without findings.

## Supply chain
- Dependencies are pinned by commit and verified after fetch (SDL3, cgltf); stb_truetype is vendored.
  GitHub Actions in the workflow are pinned to commit hashes. Licenses are listed in `LICENSES/`.
- Android signing keys are never stored in the repository (`docs/ANDROID_BUILD.md`).

## Known gaps
- No third-party security review or fuzzing beyond the unit/monkey/GLB fuzz tests.
- The Android build and runtime behavior are unverified, so Android-specific security settings are only reviewed
  statically.
