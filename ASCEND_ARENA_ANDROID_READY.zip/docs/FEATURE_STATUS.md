# FEATURE_STATUS

Status: IMPLEMENTED (works), PARTIAL, PLACEHOLDER (exists but is not the real thing), NOT IMPLEMENTED.
Verification is separate: **VERIFIED** = executed in the development workspace (see `docs/TEST_REPORT.md`),
**NOT VERIFIED** = written but never run, **Static** = only read/inspected.
"Unit-tested" means an automated test in `tests/` runs it headlessly; it does not mean it was tried on a phone.
Last updated 2026-10-16 (167 unit tests + 1 monkey test = 168 tests).

## Engine and build

| Feature | Status | Verification | Notes |
|---|---|---|---|
| CMake + Ninja build, C++20, warnings as errors | IMPLEMENTED | VERIFIED | `tools/ci/build_and_test.sh`; clear error if cmake/ninja/compiler missing |
| Pinned dependencies with commit check | IMPLEMENTED | VERIFIED | SDL3, cgltf (git), stb_truetype (vendored) |
| Fixed-timestep loop, pause, hitch clamp | IMPLEMENTED | VERIFIED (unit) | |
| Input abstraction: touch router, keyboard, test input | IMPLEMENTED | VERIFIED (unit, synthetic touches) | Real touchscreen not tested |
| CPU 3D rasterizer (culling, depth, lighting, fog, alpha, near clip) | IMPLEMENTED | VERIFIED (unit + screenshots) | Not a GPU renderer |
| OpenGL ES / Vulkan renderer | NOT IMPLEMENTED | - | See ADR-001 |
| Skeletal animation: sampling, blending, CPU skinning | IMPLEMENTED | VERIFIED (unit) | |
| GLB import (cgltf), validation, limits, alignment check | IMPLEMENTED | VERIFIED (unit, fuzz, ASan/UBSan) | Colors only; no textures, no CUBICSPLINE, no morph targets |
| OBJ import | IMPLEMENTED | VERIFIED (unit) | Used for tests/fallbacks |
| Text: UTF-8, TrueType (stb), Arabic shaping + bidi | IMPLEMENTED | VERIFIED (unit + screenshots) | Own shaper; covers common Arabic forms, not every Unicode edge case |
| Audio: synthesized SFX/music, software mixer (caps, rate limits, pause, crossfade) | IMPLEMENTED | VERIFIED (waveform tests) | Audible output on a device NOT VERIFIED |
| Debug overlay (FPS, frame ms, RSS from /proc, triangles) | IMPLEMENTED | VERIFIED on Linux | Toggle in Settings; Android values NOT VERIFIED |
| Viewport/safe-area mapping, UI scaling, quality tiers (low/medium/high) | IMPLEMENTED | VERIFIED (unit) | Notch/cutout on a real device NOT VERIFIED |

## Gameplay

| Feature | Status | Verification | Notes |
|---|---|---|---|
| Player movement (camera-relative), arena/pillar collision | IMPLEMENTED | VERIFIED (unit) | |
| Orbit camera with pitch/distance limits, wall avoidance | IMPLEMENTED | VERIFIED (unit) | |
| Light combo (3 steps), heavy attack, dodge with i-frames + cooldown | IMPLEMENTED | VERIFIED (unit) | Input buffer, aim assist |
| 3 skills per character with mana, cooldown, unlock level | IMPLEMENTED | VERIFIED (unit) | Data-driven (`content/data/skills.ini`, 10 skills) |
| Damage types, resistances, stagger, knockback, crits | IMPLEMENTED | VERIFIED (unit) | |
| No hits through walls | IMPLEMENTED | VERIFIED (unit) | |
| Enemy FSM (idle/patrol/alert/approach/attack/recover/stagger/defeated) | IMPLEMENTED | VERIFIED (unit) | |
| Enemy archetypes: grunt, brute, archer (ranged, kites), boss with enrage, training dummy | IMPLEMENTED | VERIFIED (unit) | Tunable in `enemies.ini` |
| Navigation | PARTIAL | VERIFIED | Simple steering + line of sight, **no navmesh/pathfinding**; enemies can get stuck behind complex obstacles |
| Spawn/projectile limits and cleanup | IMPLEMENTED | VERIFIED (unit + monkey) | 24 enemies, 64 projectiles |
| XP, levels (cap 60), stat growth | IMPLEMENTED | VERIFIED (unit) | XP scaled down for low-level enemies |
| Gold, inventory (40 slots, stacks), equipment slots (weapon/armor/accessory) | IMPLEMENTED | VERIFIED (unit) | 6 items |
| Drops and one-time rewards (no duplication on reload/retry) | IMPLEMENTED | VERIFIED (unit) | |
| Save/load: versioned, atomic, backup, tamper/corruption detection, migration v1, refuses newer versions | IMPLEMENTED | VERIFIED (unit) | Integrity check is for corruption, not anti-cheat; local file is not encrypted |
| Deterministic simulation (seeded RNG) | IMPLEMENTED | VERIFIED (unit) | |

## Content and modes

| Feature | Status | Verification | Notes |
|---|---|---|---|
| Missions | IMPLEMENTED | VERIFIED (unit + UI end to end) | 4 missions: clear, hold/survive with timer, archers, brute |
| Training | IMPLEMENTED | VERIFIED (unit) | Dummies, no rewards, no end condition |
| Dungeon | IMPLEMENTED | VERIFIED (unit) | 1 dungeon: rooms/waves + boss, one-time loot |
| Story | PARTIAL | VERIFIED (unit) | 3 short chapters, ordered unlock, dialogue lines; **no cutscenes**; text is original and brief |
| Characters | PARTIAL | VERIFIED | 2 characters (Kael, Mira, unlock level 3); 1 character has 2 outfits |
| Character art / animation | PLACEHOLDER | VERIFIED (pipeline) | Procedurally generated blocky GLB models with 7 animation clips. **Not production-quality art.** |
| Outfit swap (real mesh swap + real material recolor) | IMPLEMENTED | VERIFIED (unit) | |
| Rigged character animating in the actual game | IMPLEMENTED | VERIFIED headless (screenshots, unit) | On-device NOT VERIFIED |
| Content validator (missing files, duplicates, bad refs, licenses, localization, UI keys) | IMPLEMENTED | VERIFIED | Exits non-zero on errors |
| Asset license catalog | IMPLEMENTED | VERIFIED | `content/ASSET_CATALOG.csv`; all assets are project-original or DejaVu |

## UI and localization

| Feature | Status | Verification | Notes |
|---|---|---|---|
| Lobby with 3D character preview, name/level/power/gold | IMPLEMENTED | VERIFIED (unit + screenshots) | |
| Pages: Play, Characters, Inventory, Story, Profile, Settings, Language | IMPLEMENTED | VERIFIED (unit) | Every drawn button is tapped by the monkey test; main ones have dedicated tests |
| Profile page | PARTIAL | VERIFIED | Read-only; the player name cannot be edited |
| Back navigation, confirm-leave dialog, pause menu, notices | IMPLEMENTED | VERIFIED (unit) | Android back-button semantics tested with a synthetic call |
| Settings: music/SFX volume, sensitivity, invert Y, text scale, graphics quality, debug overlay | IMPLEMENTED | VERIFIED (unit) | Persisted in the save |
| English and Arabic (174 keys each), RTL layout | IMPLEMENTED | VERIFIED (unit + screenshots) | Arabic text reviewed by machine tests only, not by a native speaker |
| Other languages | NOT IMPLEMENTED | - | Fallback-to-English mechanism with visible missing-key markers exists and is tested; no other catalogs ship |
| Accessibility: scalable text, touch targets >= 9 mm | IMPLEMENTED | VERIFIED (unit) | No screen-reader support |
| Loading screens / progress bars | PLACEHOLDER | - | Content loads synchronously at start; no loading UI |

## Android and release

| Feature | Status | Verification | Notes |
|---|---|---|---|
| SDL3 platform host (window, touch, keyboard, audio, lifecycle events) | IMPLEMENTED | VERIFIED on desktop with dummy drivers | No real display/audio/touch tested |
| Android Gradle project generator (package `com.ascendarena.game`, arm64-v8a, minSdk 21, targetSdk 35, no permissions) | IMPLEMENTED | VERIFIED (generation + manifest parse) | |
| Android APK build | NOT VERIFIED | - | Never run: no Android SDK/NDK reachable. **No APK exists.** |
| GitHub Actions workflow | NOT VERIFIED | - | Written, never executed |
| App icon / splash | PLACEHOLDER | Static | Default SDL template icon; no custom icon or splash |
| Release signing | NOT IMPLEMENTED | - | Documented in `docs/ANDROID_BUILD.md`; needs a user-owned keystore |
| Running on a real Android device or emulator | NOT VERIFIED | - | |
| Performance on phones | NOT VERIFIED | - | Only a desktop-CPU benchmark exists (`docs/PERFORMANCE.md`) |

## Not started

| Feature | Status | Notes |
|---|---|---|
| Online multiplayer, rooms, guilds, matchmaking, accounts | NOT IMPLEMENTED | Prompt 8 is deliberately not started; needs a server, auth, anti-cheat and integration tests |
