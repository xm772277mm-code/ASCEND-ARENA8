# PERFORMANCE

**No performance number for an Android device exists yet.** Do not quote any figure below as a phone result.

## Architecture facts that drive performance
- Rendering is a single-threaded CPU rasterizer into a framebuffer, then uploaded via SDL. Internal resolution
  per quality tier: low = 360 px high, medium = 540, high = 720 (`FbHeightForQuality`); the image is scaled to the
  screen.
- Cost scales with resolution, triangles drawn (~1000-1200 in the bundled arenas), effects (capped) and enemies
  (capped at 24 alive, 64 projectiles, bounded audio voices and effect counts).
- Simulation is fixed-step and cheap relative to rendering.

## Measured on the DEVELOPMENT MACHINE only
Command: `build/tools/ascend_bench content --frames 120 --enemies 8` (2026-10-16, Intel Xeon @ 2.80 GHz, 2 cores,
GCC 13 -O2, one thread; the report script re-measures and stores it in `docs/TEST_REPORT.md`):

| Tier | Resolution | avg ms | p95 ms | max ms | triangles | RSS MB |
|---|---|---|---|---|---|---|
| low | 640x360 | 9.08 | 11.69 | 13.46 | 980 | 6 |
| medium | 960x540 | 24.84 | 33.00 | 34.35 | 1124 | 8 |
| high | 1280x720 | 42.58 | 56.38 | 59.46 | 1176 | 11 |

A later run (2026-10-17, same code, a 2.10 GHz Xeon host) gave 7.0 / 15.5 / 26.4 ms avg for low / medium / high, so
the same benchmark varied by up to ~40% between two workspace hosts. See `docs/TEST_REPORT.md` for the latest run.

This is only a relative guide (cost grows with pixel count). A phone core can be faster or slower than this
server core; measure on the device.

## How to profile on Android
1. Install a debug build; enable Settings > debug overlay (FPS, frame ms, memory, triangles, effect count).
2. Play the same scenario each time (Mission 3 "Hold the Gate", 5 minutes) at each quality tier.
3. Note the average and lowest FPS shown, memory growth, and device temperature after 10 minutes.
4. For deeper data: `adb shell dumpsys gfxinfo com.ascendarena.game`, `adb shell dumpsys meminfo com.ascendarena.game`,
   Android Studio Profiler (CPU/memory), `adb shell am start` for a cold-start time, and Perfetto traces.
5. If low-tier frame time exceeds ~16 ms on a target device, options in order: lower internal resolution, fewer
   effects, fewer enemies, multi-threaded rasterization, then a GLES backend (see ADR-001).

## Test matrix (fill in from real runs)

| Class | Example device (fill in) | OS | Tier | Avg FPS | Min FPS | Mem MB | Heat after 10 min | Notes |
|---|---|---|---|---|---|---|---|---|
| Low-end (2-3 GB RAM, older SoC) | | | low | | | | | |
| Mid-range | | | medium | | | | | |
| High-end | | | high | | | | | |

Targets (goals, not results): low tier >= 30 FPS on the low-end class; no crash in a 30 minute session.
