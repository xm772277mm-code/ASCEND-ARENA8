# KNOWN_LIMITATIONS

1. **No APK has been built and nothing has run on Android.** The development workspace has no Android SDK/NDK
   (dl.google.com is blocked), no device and no emulator. The Gradle/NDK route and the CI workflow are untested.
2. **Rendering is a CPU rasterizer.** On the workspace CPU (single thread) it takes 7-9 ms/frame at 640x360 and
   26-43 ms at 1280x720 (varies between hosts) (`docs/PERFORMANCE.md`). Phone speed is unknown and probably lower; the low quality tier
   may be required. A GPU (OpenGL ES) backend does not exist.
3. **Character art is a placeholder**: blocky procedurally generated models, no textures, no hair/face detail.
   This is a pipeline proof (rig, clips, outfits), not shippable art. No third-party art is used.
4. **No audio files**: sound is synthesized and simple. It was verified by waveform tests (not clipping, not silent,
   loops are seamless), never by listening on a device.
5. **Navigation is simple steering with line of sight**, not a navmesh. Enemies can get stuck behind complex geometry.
6. **Content is small**: 2 characters, 10 skills, 5 enemy types, 4 missions, 1 dungeon, 3 story chapters, 5 arenas.
7. **Localization**: English and Arabic only. Arabic was checked by automated tests and screenshots, not by a native
   reader; shaping is a custom implementation and may miss rare cases.
8. **UI**: the profile name cannot be changed; no loading screens; no cutscenes; no screen-reader support.
9. **Save file** is a local text file with an integrity check against corruption. It is not encrypted and is not
   cheat-proof (offline game; nothing is granted by a server).
10. **Android lifecycle, safe-area/cutout handling, touch feel, audio focus and battery use** are implemented against
    SDL's events but were only exercised with synthetic calls.
11. **INI data files** have no inline comments (full-line `#`/`;` only), by design.
12. **CI has never run.** The workflow pins action commits and SDK versions, but no runner has executed it.
13. **No online features.** Rooms, guilds, matchmaking and accounts do not exist (Prompt 8 not started).
14. clang-tidy (bugprone + analyzer) was run; remaining first-party findings are style-level false positives
    (reviewed in CHANGELOG). cppcheck is not installed in the workspace.
