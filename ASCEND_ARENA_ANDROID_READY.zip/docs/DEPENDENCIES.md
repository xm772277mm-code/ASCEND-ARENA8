# Dependencies and how to update them

| Dependency | Pin | License | Where fetched | Used by |
|---|---|---|---|---|
| SDL3 | tag `release-3.4.18`, commit `829a65d769d935c4852f8159e964312c0957260a` | zlib | git (FetchContent) | `platform/` host, Android template |
| cgltf | tag `v1.15`, commit `360db1a95480fe102ae9c69b27c5d101167ff5ba` | MIT | git (FetchContent) | `engine/assets/glb_loader.cpp` |
| stb_truetype.h | stb commit `2c980bb59875b0d32144a71867fbdebb2f77cd20` | MIT or public domain | vendored in `third_party/stb/` | `engine/text` |
| DejaVu Sans | Ubuntu 24.04 `fonts-dejavu-core` | Bitstream Vera + public-domain changes | copied to `content/fonts/` | UI font |
| Android SDK/NDK | NDK `28.2.13676358`, platform 35, build-tools 35.0.0 | Android SDK License Agreement | `sdkmanager` in CI | build only, not shipped |

The core library and unit tests need only cgltf (disable with `-DASCEND_WITH_GLTF=OFF`; character tests then do not
build). Fetched sources are checked against the pinned commit; a mismatch aborts configuration.

## Updating a pin

1. Pick the new tag. `git ls-remote https://github.com/<owner>/<repo>.git <tag>` prints its commit.
2. Read the project's release notes and license file at that tag.
3. Edit `cmake/Dependencies.cmake` (tag and commit together) and `LICENSES/THIRD_PARTY_NOTICES.md`.
4. Run `tools/ci/build_and_test.sh platform` and `tools/ci/gen_test_report.py --clean --sanitize`.
5. For SDL, also re-run `tools/android/prepare_android_project.sh` and read the NDK/SDK versions its template pins.
6. Note the change in `CHANGELOG.md`.
