# Android build (NOT VERIFIED end to end)

Status: the project generator runs and produces a Gradle project whose manifest has no permissions. The Gradle/NDK
build has **never been executed** (the development workspace cannot download the Android SDK/NDK). Treat every step
below as untested until a CI run or a real machine proves it.

## Pinned versions (from `tools/android/prepare_android_project.sh`, CI workflow)

| Item | Value |
|---|---|
| Package ID | `com.ascendarena.game` (override `ASCEND_APP_ID`) |
| Version | name `0.1.0` from `CMakeLists.txt`, code `100` |
| ABIs | `arm64-v8a,armeabi-v7a` (override `ASCEND_ABIS` to build a specific ABI) |
| minSdk / targetSdk / compileSdk | 21 / 35 / 35 (SDL template; re-check the Play Store's current target requirement before publishing) |
| NDK | `28.2.13676358` (the official page lists r30 LTS `30.0.16248370` as newest; upgrade deliberately) |
| Build tools / platform | `build-tools;35.0.0`, `platforms;android-35`, CMake `3.22.1` |
| JDK | 17 (Temurin in CI) |
| Orientation | `sensorLandscape` |
| Permissions | none (the template's INTERNET/CAMERA lines are commented out; checked by parsing the manifest) |
| Backup | `allowBackup=false` |

## Steps (on any Linux machine or the CI runner)

```
# Android SDK installed, ANDROID_HOME set, licences accepted
sdkmanager "platforms;android-35" "build-tools;35.0.0" "ndk;28.2.13676358" "cmake;3.22.1"
tools/android/prepare_android_project.sh build/android     # clones SDL at the pinned tag, checks its commit
cd build/android && ./gradlew --no-daemon assembleDebug
# result: app/build/outputs/apk/debug/*.apk  (only if the build really succeeds)
```

The CI job `android debug APK` in `.github/workflows/ci.yml` does the same. If it fails, the logs are the blocker
report; do not rename any other file to `.apk`.

## Release signing (you must do this; nothing is committed)

1. Create a keystore once and keep it private and backed up:
   `keytool -genkeypair -v -keystore ascend-release.jks -alias ascend -keyalg RSA -keysize 4096 -validity 10000`
2. Store it and its passwords as CI secrets (or in `~/.gradle/gradle.properties`), never in the repository.
3. Add a `signingConfigs.release` block to the generated `app/build.gradle` that reads those values from environment
   variables, then run `./gradlew bundleRelease` (Play Store) or `assembleRelease`.
4. Losing the keystore means you cannot update the app. Consider Play App Signing.

## Not implemented yet for release

Custom launcher icon and splash screen (default SDL template icon is used), release signing config in the
generator, Play Store metadata, crash reporting (none, by design), 32-bit ABI testing.
