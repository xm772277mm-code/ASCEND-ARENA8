# ADR-001: ASCEND ENGINE stack

Status: ACCEPTED. Date: 2026-10-09, rewritten 2026-10-16 after a workspace reset destroyed the original docs
(the decisions below are the ones the code actually implements; verify against `git log`).

## Context

- Target: Android-first, landscape, touch, 3D third-person action RPG, offline single player first.
- The developer works from a phone, so native builds must run in a cloud environment / CI.
- The development workspace has g++/clang/CMake/Ninja/JDK/Gradle but **no Android SDK/NDK, no GPU, no display, no
  audio device**, and the egress policy blocks dl.google.com, Maven and pip; `git` over HTTPS to github.com works
  (see ENVIRONMENT_REPORT.md). Anything needing those cannot be verified here.

## Options compared

| Option | License | For | Against (for this project) |
|---|---|---|---|
| A. SDL3 + own renderer + cgltf + stb_truetype | zlib / MIT / MIT-or-PD | Small, pinned, permissive. SDL covers window, touch, audio output and the Android activity. Gameplay stays renderer-independent. | We write rendering, skinning and UI drawing ourselves. |
| B. Google Filament (+ gltfio) | Apache-2.0 | High-quality PBR, glTF + skinning built in, Android-first. | Large build and tooling, Maven/AAR route that cannot be fetched or checked here. Heavy for a phone-driven workflow. |
| C. SDL3 + bgfx | zlib + BSD-2 | Cross-API renderer incl. Vulkan/GLES. | Extra build tools (shaderc), no glTF/skinning, cannot be verified here. |
| D. raylib | zlib | Very simple API. | Less control over lifecycle/touch; weaker base for a custom engine layer. |
| E. Godot / Unity / Unreal | MIT / proprietary | Mature. | Excluded by the project contract. |

## Decision

**Option A**, with these layers:

| Layer | Code | Notes |
|---|---|---|
| ASCEND ENGINE core | `engine/core`, `engine/input`, `engine/assets`, `engine/render`, `engine/text`, `engine/audio` | Own C++20, no platform calls. Fixed-timestep loop, input model, INI data, localization, CPU rasterizer, skeletal animation, text shaping, software audio mixer. |
| Gameplay | `gameplay/` | World simulation, combat, enemy AI, progression, save, game modes. Deterministic, renderer-independent, fully headless-testable. |
| Game/presentation | `game/`, `ui/` | Scene renderer, HUD, character visuals, immediate-mode UI app (lobby, menus, runs). |
| Platform host | `platform/` | SDL3: window, touch/keyboard events, audio output, lifecycle. |
| Tools | `tools/` | Content validator, benchmark, render demo, GLB generator, Android project generator. |

Dependencies (pinned in `cmake/Dependencies.cmake`, verified by commit hash after fetch): SDL3 `release-3.4.18`,
cgltf `v1.15`, stb_truetype (vendored, `third_party/stb`). See `docs/DEPENDENCIES.md`.

**Renderer: a CPU rasterizer**, presented through SDL's texture API. It was chosen because it is the only renderer
whose output could be produced and *looked at* in the development workspace (frames are dumped and inspected), it
behaves identically on every device SDL supports, and it keeps gameplay independent of any GPU API.
Costs: low internal resolution and a small triangle budget; no PBR; unknown speed on phones (see
`docs/PERFORMANCE.md`). An OpenGL ES backend behind the same interface is **NOT IMPLEMENTED**. If phone
measurements show the CPU path is too slow, Option B (Filament) or a GLES backend is the planned escape hatch;
gameplay code does not depend on the renderer.

**Android build route**: `tools/android/prepare_android_project.sh` copies SDL's pinned `android-project` template,
wires it to this repository's CMake and bundles `content/`; Gradle + the NDK then build the APK. It is run by
`.github/workflows/ci.yml`. This route is **NOT VERIFIED**: the generation step runs here, the Gradle/NDK build has
never been executed anywhere.

NDK: the pin is `28.2.13676358` (the NDK SDL's template pins at this release). The official NDK download page
(fetched 2026-10-10) lists r30 (`30.0.16248370`) as the current LTS, so the pin is older than the newest LTS;
upgrading it is a deliberate, testable change (override with `ASCEND_NDK`).

## Consequences

- Core, gameplay, UI logic, tools and tests build and run anywhere with a C++20 compiler and git.
- The "engine" is a game-specific framework, not a from-scratch GPU/OS abstraction; SDL3 provides that layer.
- Visual quality is limited by the CPU rasterizer and the procedurally generated placeholder characters.
- Everything that needs a phone (touch feel, performance, audio output, lifecycle on a real device) is NOT VERIFIED.
