# Manual test checklist

Automated tests cover logic headlessly; this list is for a **person with a device**. Nothing here has been run on
Android yet. Record device model, Android version, build commit and results in a copy of this file.

Desktop keys (`ascend_host`): WASD/arrows move, J or Z light attack, K or X heavy, Space or L dodge, 1/2/3 skills,
Q potion, P pause, F3 debug overlay, Esc/Back = back. Mouse clicks act as touch.

## 1. Install and launch (Android)
- [ ] APK installs; app opens in landscape; no permission prompt appears.
- [ ] Lobby shows character preview facing the camera; no black bars hide buttons under a notch/cutout.
- [ ] Rotating the phone 180 degrees keeps landscape and the UI intact.

## 2. Touch controls (in a mission)
- [ ] Left-thumb drag anywhere in the left 40% moves the player; releasing stops; dead zone feels right.
- [ ] Dragging on the right/free area orbits the camera; pitch/distance stay within limits; no flipping.
- [ ] Each button (ATK, HVY, DGE, skills 1-3, potion, pause) responds once per tap; skills show cooldown and mana.
- [ ] Moving + attacking + dodging with 3 fingers at once works; a 4th finger does not break anything.
- [ ] Every button is comfortable to hit with a thumb (>= ~9 mm); try a small phone and a large phone.
- [ ] Settings: sensitivity and invert-Y visibly change camera feel.

## 3. Lifecycle
- [ ] Press Home during a run, return after 10 s: run is paused, no stuck joystick, pause overlay shown, resume works.
- [ ] Lock the screen mid-run and unlock: same as above; audio resumes only after resume.
- [ ] Receive a phone call / notification shade pulldown: no crash, no stuck input.
- [ ] Android Back: in a run asks to leave; in menus goes back; in the lobby exits the app.
- [ ] Kill the app from recents during a run and reopen: profile loads, no duplicated rewards.

## 4. Combat and camera
- [ ] Light combo chains 3 steps; heavy is slower and staggers; hits show numbers/sparks.
- [ ] Dodge gives a brief invulnerability: dodge through an enemy strike takes no damage.
- [ ] Archers keep distance and shoot visible projectiles; walls block them and block your hits.
- [ ] Brute resists stagger; boss shows a bar and speeds up below half health.
- [ ] Camera does not pass through pillars or leave the arena walls.
- [ ] Defeat shows the result screen with no reward; retry starts a fresh run.

## 5. Modes (each must return to the lobby cleanly)
- [ ] Missions 1-4: objectives update; victory pays rewards once; replaying pays no first-clear bonus again.
- [ ] Training: dummies never die, no XP/gold, you can leave anytime.
- [ ] Dungeon: rooms advance, boss fight, loot is granted once.
- [ ] Story: chapter 2 and 3 are locked until the previous is cleared; dialogue lines are readable.

## 6. Progression, inventory, characters
- [ ] XP bar fills, level-up heals, stats grow; level shown in lobby/profile matches the run.
- [ ] Equip/unequip changes the Power value and in-run damage/health.
- [ ] Mira is locked until level 3; outfits unlock at their levels and visibly change colors/mesh.

## 7. Language and accessibility
- [ ] Switch to Arabic: all text is Arabic and right-to-left, letters connected, numbers readable; back to English.
- [ ] Text scale up/down: no clipped or overlapping labels on your phone's aspect ratio.
- [ ] Language and settings persist after closing the app.

## 8. Audio
- [ ] Music and SFX play; sliders change volume; mute works; no clicks/pops; many hits do not get louder or stutter.

## 9. Low-end device behavior
- [ ] Set graphics to Low: frame rate is playable; note average FPS from the debug overlay (Settings > debug).
- [ ] 10 minutes of play: no crash, memory (debug overlay) does not grow steadily, the phone does not overheat badly.
- [ ] Record results in `docs/PERFORMANCE.md` test matrix, with the device name.

## 10. Save robustness
- [ ] Turn on airplane mode: nothing changes (the game is offline). Fill storage nearly full: a save failure shows a notice.
