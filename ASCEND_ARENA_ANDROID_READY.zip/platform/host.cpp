// ASCEND ARENA platform host: owns the OS window, converts OS events into App calls and presents the
// CPU-rendered framebuffer. All game logic lives in ui/ (App); this file only talks to SDL.
//
// Options (desktop / CI):
//   --content DIR       content directory (default: <exe dir>/content, ../content, ./content)
//   --extract-to DIR    copy ./content (listed in content/manifest.txt) into DIR/content and use that (tests the
//   Android path)
//   --save PATH         save file (default: SDL pref path / profile.sav)
//   --size WxH          initial window size (default 1280x720)
//   --safe x,y,w,h      override the safe area (simulates a notch)
//   --smoke-frames N    run N frames then exit 0 (works with SDL_VIDEO_DRIVER=dummy SDL_AUDIODRIVER=dummy)
//   --tap a,b,c         execute UI actions one by one during the run (CI / screenshots)
//   --dump-frame PATH   write the last framebuffer as PPM on exit
//   --no-audio          do not open an audio device
// Exit codes: 0 ok, 2 SDL init, 3 window/renderer, 4 content/app init, 5 write error.
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <sstream>
#include <string>
#include <vector>

#include "../engine/input/viewport.h"
#include "../ui/app.h"

namespace fs = std::filesystem;
using namespace ascend;

namespace {

struct Options {
  std::string content, save, dump, extractTo;
  int winW = 1280, winH = 720;
  RectI safeOverride{};
  bool hasSafe = false;
  int smokeFrames = -1;
  std::vector<std::string> taps;
  bool audio = true;
};

std::vector<std::string> Split(const std::string& s, char sep) {
  std::vector<std::string> out;
  std::stringstream ss(s);
  std::string t;
  while (std::getline(ss, t, sep))
    if (!t.empty()) out.push_back(t);
  return out;
}

Options ParseArgs(int argc, char** argv) {
  Options o;
  for (int i = 1; i < argc; ++i) {
    const std::string a = argv[i];
    auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : std::string(); };
    if (a == "--content")
      o.content = next();
    else if (a == "--save")
      o.save = next();
    else if (a == "--dump-frame")
      o.dump = next();
    else if (a == "--extract-to")
      o.extractTo = next();
    else if (a == "--smoke-frames")
      o.smokeFrames = std::atoi(next().c_str());
    else if (a == "--tap")
      o.taps = Split(next(), ',');
    else if (a == "--no-audio")
      o.audio = false;
    else if (a == "--size") {
      int w = 0, h = 0;
      if (std::sscanf(next().c_str(), "%dx%d", &w, &h) == 2 && w >= 160 && h >= 120) {
        o.winW = w;
        o.winH = h;
      }
    } else if (a == "--safe") {
      int x = 0, y = 0, w = 0, h = 0;
      if (std::sscanf(next().c_str(), "%d,%d,%d,%d", &x, &y, &w, &h) == 4) {
        o.safeOverride = {x, y, w, h};
        o.hasSafe = true;
      }
    }
  }
  return o;
}

// ---------------------------------------------------------------------------------- content location

// Android: assets live inside the APK and cannot be opened with std::filesystem. The build writes
// content/manifest.txt ("version <id>" then one relative path per line); on first run (or when the
// version changes) every listed file is copied into the app's private storage and used from there.
// `destRoot` is the app's private directory (Android: SDL_AndroidGetInternalStoragePath()). The same code
// runs on desktop with --extract-to so the logic is testable; only the asset source differs (SDL_LoadFile
// reads Android APK assets there, the working directory here).
std::string ExtractContent(const std::string& destRoot) {
  if (destRoot.empty()) return {};
  const std::string dest = destRoot + "/content";
  size_t msize = 0;
  char* mdata = static_cast<char*>(SDL_LoadFile("content/manifest.txt", &msize));
  if (!mdata) {
    std::fprintf(stderr, "[ascend] ERROR: content/manifest.txt not found in the APK assets: %s\n", SDL_GetError());
    return {};
  }
  const std::string manifest(mdata, msize);
  SDL_free(mdata);
  std::vector<std::string> lines = Split(manifest, '\n');
  const std::string version = lines.empty() ? std::string() : lines[0];
  const std::string stampPath = dest + "/.installed";
  size_t ssize = 0;
  char* sdata = static_cast<char*>(SDL_LoadFile(stampPath.c_str(), &ssize));
  const bool upToDate = sdata && std::string(sdata, ssize) == version;
  if (sdata) SDL_free(sdata);
  if (upToDate) return dest;
  for (std::size_t i = 1; i < lines.size(); ++i) {
    std::string rel = lines[i];
    while (!rel.empty() && (rel.back() == '\r' || rel.back() == ' ')) rel.pop_back();
    if (rel.empty() || rel.find("..") != std::string::npos) continue;  // never write outside the content dir
    size_t sz = 0;
    void* data = SDL_LoadFile(("content/" + rel).c_str(), &sz);
    if (!data) {
      std::fprintf(stderr, "[ascend] ERROR: asset content/%s missing: %s\n", rel.c_str(), SDL_GetError());
      return {};
    }
    const std::string out = dest + "/" + rel;
    SDL_CreateDirectory(out.substr(0, out.find_last_of('/')).c_str());
    const bool ok = SDL_SaveFile(out.c_str(), data, sz);
    SDL_free(data);
    if (!ok) {
      std::fprintf(stderr, "[ascend] ERROR: cannot write %s: %s\n", out.c_str(), SDL_GetError());
      return {};
    }
  }
  SDL_SaveFile(stampPath.c_str(), version.data(), version.size());
  std::printf("[ascend] content installed to %s (%zu files)\n", dest.c_str(), lines.size() - 1);
  return dest;
}

std::string FindContent(const Options& o) {
  if (!o.content.empty()) return o.content;
  if (!o.extractTo.empty()) return ExtractContent(o.extractTo);
#ifdef __ANDROID__
  const char* internal = SDL_AndroidGetInternalStoragePath();
  return ExtractContent(internal ? internal : "");
#else
  std::vector<fs::path> cands;
  if (const char* base = SDL_GetBasePath()) {
    cands.push_back(fs::path(base) / "content");
    cands.push_back(fs::path(base) / ".." / "content");
    cands.push_back(fs::path(base) / ".." / ".." / "content");
  }
  cands.push_back(fs::path("content"));
  for (const auto& c : cands) {
    std::error_code ec;
    if (fs::exists(c / "data" / "skills.ini", ec)) return c.string();
  }
  return {};
#endif
}

std::string SavePath(const Options& o) {
  if (!o.save.empty()) return o.save;
  char* pref = SDL_GetPrefPath("AscendArena", "AscendArena");
  if (!pref) return "profile.sav";
  const std::string p = std::string(pref) + "profile.sav";
  SDL_free(pref);
  return p;
}

// ------------------------------------------------------------------------------------------- host

struct Host {
  SDL_Window* win = nullptr;
  SDL_Renderer* ren = nullptr;
  SDL_Texture* tex = nullptr;
  SDL_AudioStream* audio = nullptr;
  Framebuffer fb;
  Viewport vp;
  float pxPerMm = 6.4f;
  std::string lastQuality;
  int lastWinW = 0, lastWinH = 0;
  RectI lastSafe{};
  bool vsync = false;
};

void Relayout(Host& h, App& app, const Options& o, bool force) {
  int ww = 0, wh = 0;
  SDL_GetWindowSizeInPixels(h.win, &ww, &wh);
  RectI safe{};
  if (o.hasSafe) {
    safe = o.safeOverride;
  } else {
    SDL_Rect r{};
    if (SDL_GetWindowSafeArea(h.win, &r)) {
      // SDL reports points; scale to pixels.
      int pw = 0, ph = 0, w = 0, hh = 0;
      SDL_GetWindowSizeInPixels(h.win, &pw, &ph);
      SDL_GetWindowSize(h.win, &w, &hh);
      const float sx = w > 0 ? static_cast<float>(pw) / static_cast<float>(w) : 1.f;
      const float sy = hh > 0 ? static_cast<float>(ph) / static_cast<float>(hh) : 1.f;
      safe = {static_cast<int>(static_cast<float>(r.x) * sx), static_cast<int>(static_cast<float>(r.y) * sy),
              static_cast<int>(static_cast<float>(r.w) * sx), static_cast<int>(static_cast<float>(r.h) * sy)};
    }
  }
  const std::string quality = app.profile().settings.quality;
  if (!force && ww == h.lastWinW && wh == h.lastWinH && quality == h.lastQuality && safe.x == h.lastSafe.x &&
      safe.y == h.lastSafe.y && safe.w == h.lastSafe.w && safe.h == h.lastSafe.h)
    return;
  h.lastWinW = ww;
  h.lastWinH = wh;
  h.lastQuality = quality;
  h.lastSafe = safe;
  const Viewport nv = ComputeViewport(ww, wh, safe, FbHeightForQuality(quality));
  if (force || nv.fbW != h.vp.fbW || nv.fbH != h.vp.fbH || !h.tex) {
    if (h.tex) SDL_DestroyTexture(h.tex);
    h.tex = SDL_CreateTexture(h.ren, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STREAMING, nv.fbW, nv.fbH);
    if (h.tex) SDL_SetTextureScaleMode(h.tex, SDL_SCALEMODE_LINEAR);
    h.fb.Resize(nv.fbW, nv.fbH);
  }
  h.vp = nv;
  const float scale = SDL_GetWindowDisplayScale(h.win);
  h.pxPerMm = FbPixelsPerMm(h.vp, scale);
  app.SetViewport(h.vp.fbW, h.vp.fbH, h.pxPerMm);
}

constexpr int kMouseTouchId = 1 << 30;

void SendTouch(Host& h, App& app, int id, TouchPhase ph, float wx, float wy) {
  float fx = 0.f, fy = 0.f;
  WindowToFb(h.vp, wx, wy, fx, fy);
  app.OnTouch({id, ph, fx, fy});
}

void PumpAudio(Host& h, App& app) {
  if (!h.audio) return;
  const int bytesPerFrame = 4;                              // 16-bit stereo
  const int targetBytes = kAudioRate / 12 * bytesPerFrame;  // keep ~80 ms queued
  int queued = SDL_GetAudioStreamQueued(h.audio);
  std::int16_t buf[1024 * 2];
  int guard = 0;
  while (queued >= 0 && queued < targetBytes && guard++ < 16) {
    app.audio().Mix(buf, 1024);
    if (!SDL_PutAudioStreamData(h.audio, buf, 1024 * bytesPerFrame)) break;
    queued += 1024 * bytesPerFrame;
  }
}

}  // namespace

int main(int argc, char** argv) {
  const Options opt = ParseArgs(argc, argv);

  SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");  // never turn fingers into mouse clicks (double input)
  SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "0");
  SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");  // the app handles the back button itself
  SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");

  if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | (opt.audio ? SDL_INIT_AUDIO : 0))) {
    // Audio failure must not prevent a silent game from starting.
    std::fprintf(stderr, "[ascend] WARNING: SDL_Init with audio failed (%s); retrying without audio\n", SDL_GetError());
    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS)) {
      std::fprintf(stderr, "[ascend] ERROR: SDL_Init failed: %s\n", SDL_GetError());
      return 2;
    }
  }
  const int ver = SDL_GetVersion();
  std::printf("[ascend] SDL %d.%d.%d, video driver: %s\n", SDL_VERSIONNUM_MAJOR(ver), SDL_VERSIONNUM_MINOR(ver),
              SDL_VERSIONNUM_MICRO(ver), SDL_GetCurrentVideoDriver());

  Host host;
  host.win = SDL_CreateWindow("ASCEND ARENA", opt.winW, opt.winH, SDL_WINDOW_RESIZABLE | SDL_WINDOW_HIGH_PIXEL_DENSITY);
  if (!host.win) {
    std::fprintf(stderr, "[ascend] ERROR: window creation failed: %s\n", SDL_GetError());
    SDL_Quit();
    return 3;
  }
  host.ren = SDL_CreateRenderer(host.win, nullptr);
  if (!host.ren) {
    std::fprintf(stderr, "[ascend] ERROR: renderer creation failed: %s\n", SDL_GetError());
    SDL_DestroyWindow(host.win);
    SDL_Quit();
    return 3;
  }
  host.vsync = SDL_SetRenderVSync(host.ren, 1);
  std::printf("[ascend] renderer: %s, vsync: %s\n", SDL_GetRendererName(host.ren), host.vsync ? "on" : "off");

  const std::string content = FindContent(opt);
  if (content.empty()) {
    const char* msg =
        "Game content was not found. Pass --content <dir> or install the content folder next to the program.";
    std::fprintf(stderr, "[ascend] ERROR: %s\n", msg);
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ASCEND ARENA", msg, host.win);
    SDL_DestroyRenderer(host.ren);
    SDL_DestroyWindow(host.win);
    SDL_Quit();
    return 4;
  }
  App app(AppConfig{content, SavePath(opt), 0xA5CEDull});
  const Status st = app.Init();
  if (!st) {
    std::fprintf(stderr, "[ascend] ERROR: %s\n", st.message.c_str());
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ASCEND ARENA", st.message.c_str(), host.win);
    SDL_DestroyRenderer(host.ren);
    SDL_DestroyWindow(host.win);
    SDL_Quit();
    return 4;
  }
  if (!app.fontError().empty())
    std::printf("[ascend] WARNING: %s (using the built-in ASCII font)\n", app.fontError().c_str());
  std::printf("[ascend] content: %s, save: %s\n", content.c_str(),
              app.loadReport().kind == LoadKind::Fresh ? "new profile" : "loaded");

  if (opt.audio && SDL_WasInit(SDL_INIT_AUDIO)) {
    const SDL_AudioSpec spec{SDL_AUDIO_S16, 2, kAudioRate};
    host.audio = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &spec, nullptr, nullptr);
    if (host.audio)
      SDL_ResumeAudioStreamDevice(host.audio);
    else
      std::printf("[ascend] audio disabled: %s\n", SDL_GetError());
  }

  Relayout(host, app, opt, true);

  bool running = true;
  int frame = 0;
  std::size_t nextTap = 0;
  std::uint64_t prev = SDL_GetPerformanceCounter();
  const double freq = static_cast<double>(SDL_GetPerformanceFrequency());
  bool mouseDown = false;

  while (running) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
      switch (e.type) {
        case SDL_EVENT_QUIT:
          running = false;
          break;
        case SDL_EVENT_TERMINATING:  // Android is killing the process: persist now
          app.OnBackground();
          running = false;
          break;
        case SDL_EVENT_WILL_ENTER_BACKGROUND:
          app.OnBackground();
          break;
        case SDL_EVENT_DID_ENTER_FOREGROUND:
          app.OnForeground();
          prev = SDL_GetPerformanceCounter();  // do not count background time as a frame
          break;
        case SDL_EVENT_LOW_MEMORY:
          std::printf("[ascend] low memory warning\n");
          break;
        case SDL_EVENT_WINDOW_FOCUS_LOST:
          app.OnBackground();
          break;
        case SDL_EVENT_WINDOW_FOCUS_GAINED:
          app.OnForeground();
          prev = SDL_GetPerformanceCounter();
          break;
        case SDL_EVENT_FINGER_DOWN:
        case SDL_EVENT_FINGER_MOTION:
        case SDL_EVENT_FINGER_UP:
        case SDL_EVENT_FINGER_CANCELED: {
          const int id = static_cast<int>(e.tfinger.fingerID & 0x3FFFFFFFu);
          int ww = 0, wh = 0;
          SDL_GetWindowSizeInPixels(host.win, &ww, &wh);
          const TouchPhase ph = e.type == SDL_EVENT_FINGER_DOWN     ? TouchPhase::Down
                                : e.type == SDL_EVENT_FINGER_MOTION ? TouchPhase::Move
                                : e.type == SDL_EVENT_FINGER_UP     ? TouchPhase::Up
                                                                    : TouchPhase::Cancel;
          SendTouch(host, app, id, ph, e.tfinger.x * static_cast<float>(ww), e.tfinger.y * static_cast<float>(wh));
          break;
        }
        case SDL_EVENT_MOUSE_BUTTON_DOWN:
        case SDL_EVENT_MOUSE_BUTTON_UP:
          if (e.button.which == SDL_TOUCH_MOUSEID || e.button.button != SDL_BUTTON_LEFT) break;
          mouseDown = e.type == SDL_EVENT_MOUSE_BUTTON_DOWN;
          {
            const float scale = SDL_GetWindowPixelDensity(host.win);
            SendTouch(host, app, kMouseTouchId, mouseDown ? TouchPhase::Down : TouchPhase::Up, e.button.x * scale,
                      e.button.y * scale);
          }
          break;
        case SDL_EVENT_MOUSE_MOTION:
          if (e.motion.which == SDL_TOUCH_MOUSEID || !mouseDown) break;
          SendTouch(host, app, kMouseTouchId, TouchPhase::Move, e.motion.x * SDL_GetWindowPixelDensity(host.win),
                    e.motion.y * SDL_GetWindowPixelDensity(host.win));
          break;
        case SDL_EVENT_KEY_DOWN:
          if (e.key.repeat) break;
          switch (e.key.scancode) {
            case SDL_SCANCODE_ESCAPE:
            case SDL_SCANCODE_AC_BACK:
              if (!app.BackPressed()) running = false;
              break;
            case SDL_SCANCODE_J:
            case SDL_SCANCODE_Z:
              app.PressKey(KeyAction::Attack);
              break;
            case SDL_SCANCODE_K:
            case SDL_SCANCODE_X:
              app.PressKey(KeyAction::Heavy);
              break;
            case SDL_SCANCODE_SPACE:
            case SDL_SCANCODE_L:
              app.PressKey(KeyAction::Dodge);
              break;
            case SDL_SCANCODE_1:
              app.PressKey(KeyAction::Skill1);
              break;
            case SDL_SCANCODE_2:
              app.PressKey(KeyAction::Skill2);
              break;
            case SDL_SCANCODE_3:
              app.PressKey(KeyAction::Skill3);
              break;
            case SDL_SCANCODE_Q:
              app.PressKey(KeyAction::Potion);
              break;
            case SDL_SCANCODE_P:
              app.PressKey(KeyAction::Pause);
              break;
            case SDL_SCANCODE_F3:
              app.profile().settings.showDebug = !app.profile().settings.showDebug;
              break;
            default:
              break;
          }
          break;
        default:
          break;
      }
    }

    // Keyboard movement (desktop / debug). Touch joystick is handled by the TouchRouter.
    {
      const bool* k = SDL_GetKeyboardState(nullptr);
      Vec2 m{};
      m.x = (k[SDL_SCANCODE_D] || k[SDL_SCANCODE_RIGHT] ? 1.f : 0.f) -
            (k[SDL_SCANCODE_A] || k[SDL_SCANCODE_LEFT] ? 1.f : 0.f);
      m.y = (k[SDL_SCANCODE_W] || k[SDL_SCANCODE_UP] ? 1.f : 0.f) -
            (k[SDL_SCANCODE_S] || k[SDL_SCANCODE_DOWN] ? 1.f : 0.f);
      app.SetKeyMove(m);
    }

    // CI / screenshot taps: one UI action every 3 frames, after the first frame has been drawn.
    if (nextTap < opt.taps.size() && frame > 2 && frame % 3 == 0) {
      if (!app.Tap(opt.taps[nextTap])) {
        std::fprintf(stderr, "[ascend] ERROR: --tap '%s' is not available on this screen\n", opt.taps[nextTap].c_str());
        return 6;
      }
      ++nextTap;
    }

    const std::uint64_t now = SDL_GetPerformanceCounter();
    float dt = static_cast<float>(static_cast<double>(now - prev) / freq);
    prev = now;
    if (opt.smokeFrames >= 0) dt = 1.f / 60.f;  // deterministic stepping for CI
    app.Update(dt);

    Relayout(host, app, opt, false);
    if (host.tex) {
      app.Draw(host.fb);
      SDL_UpdateTexture(host.tex, nullptr, host.fb.pixels(), host.fb.width() * 4);
      SDL_SetRenderDrawColor(host.ren, 0, 0, 0, 255);
      SDL_RenderClear(host.ren);
      const SDL_FRect dst{static_cast<float>(host.vp.dst.x), static_cast<float>(host.vp.dst.y),
                          static_cast<float>(host.vp.dst.w), static_cast<float>(host.vp.dst.h)};
      SDL_RenderTexture(host.ren, host.tex, nullptr, &dst);
      SDL_RenderPresent(host.ren);
    }
    PumpAudio(host, app);
    ++frame;
    if (opt.smokeFrames >= 0 && frame >= opt.smokeFrames)
      running = false;
    else if (!host.vsync)
      SDL_Delay(8);  // without vsync cap at roughly 60-100 fps instead of spinning
  }

  app.Persist();
  int rc = 0;
  if (!opt.dump.empty()) {
    app.Draw(host.fb);
    if (!host.fb.SavePpm(opt.dump)) {
      std::fprintf(stderr, "[ascend] ERROR: cannot write %s\n", opt.dump.c_str());
      rc = 5;
    }
  }
  std::printf("[ascend] shutdown after %d frames (screen %d)\n", frame, static_cast<int>(app.screen()));
  if (host.audio) SDL_DestroyAudioStream(host.audio);
  if (host.tex) SDL_DestroyTexture(host.tex);
  SDL_DestroyRenderer(host.ren);
  SDL_DestroyWindow(host.win);
  SDL_Quit();
  return rc;
}
