// Renderer tests: primitive winding, projection, depth, culling, framebuffer ops, OBJ loading.
#include <cmath>

#include "../engine/assets/mesh_loader.h"
#include "../engine/render/framebuffer.h"
#include "../engine/render/rasterizer.h"
#include "test_framework.h"

using namespace ascend;

namespace {
// Signed volume (divergence theorem). The sign tells whether triangles wind outward or inward.
double SignedVolume(const Mesh& m) {
  double v = 0;
  for (std::size_t t = 0; t + 2 < m.indices.size(); t += 3) {
    const Vec3 a = m.vertices[m.indices[t]].pos, b = m.vertices[m.indices[t + 1]].pos,
               c = m.vertices[m.indices[t + 2]].pos;
    v += static_cast<double>(Dot(a, Cross(b, c))) / 6.0;
  }
  return v;
}
Camera FrontCam() {
  Camera c;
  c.eye = {0.f, 0.f, -5.f};
  c.target = {0.f, 0.f, 0.f};
  return c;
}
}  // namespace

TEST(primitives_wind_consistently_outward) {
  const double box = SignedVolume(MakeBox({2.f, 2.f, 2.f}, {}));
  CHECK(std::fabs(box) > 7.9);  // ~8 m^3
  const double sign = box > 0 ? 1.0 : -1.0;
  CHECK(SignedVolume(MakeCylinder(1.f, 2.f, 24, {})) * sign > 5.5);
  CHECK(SignedVolume(MakeSphere(1.f, 12, 18, {})) * sign > 3.5);
}

TEST(box_renders_when_in_front_and_not_when_behind) {
  Framebuffer fb(64, 64);
  Rasterizer r;
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  r.Begin(&fb, FrontCam(), Lighting{});
  const Mesh box = MakeBox({1.f, 1.f, 1.f}, Color{255, 255, 255, 255});
  r.Draw(box, DrawParams{});
  CHECK(r.stats().trianglesDrawn > 0);
  CHECK(fb.Get(32, 32) != 0xFF000000u);  // center pixel was painted
  CHECK_EQ(fb.Get(2, 2), 0xFF000000u);   // corner untouched
  // Camera looking away: nothing drawn.
  Camera away = FrontCam();
  away.target = {0.f, 0.f, -10.f};
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  r.Begin(&fb, away, Lighting{});
  r.Draw(box, DrawParams{});
  CHECK_EQ(r.stats().trianglesDrawn, 0);
}

TEST(inside_out_mesh_is_culled_and_nearer_surface_wins_depth) {
  Framebuffer fb(64, 64);
  Rasterizer r;
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  r.Begin(&fb, FrontCam(), Lighting{});
  Mesh inv = MakeBox({1.f, 1.f, 1.f}, Color{255, 255, 255, 255});
  for (std::size_t i = 0; i + 2 < inv.indices.size(); i += 3) std::swap(inv.indices[i + 1], inv.indices[i + 2]);
  DrawParams p;
  r.Draw(inv, p);
  // Only far inner faces remain? Culling removes back faces, so inverted box shows its far side faces: still painted.
  const bool painted = fb.Get(32, 32) != 0xFF000000u;
  CHECK(painted);
  // Depth: a red box in front of a blue box must show red at the center regardless of draw order.
  for (int order = 0; order < 2; ++order) {
    fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
    r.Begin(&fb, FrontCam(), Lighting{});
    DrawParams near, far;
    near.model = Mat4::Translation({0.f, 0.f, -1.f});
    far.model = Mat4::Translation({0.f, 0.f, 1.f});
    near.unlit = far.unlit = true;
    const Mesh red = MakeBox({1.f, 1.f, 1.f}, Color{255, 0, 0, 255}),
               blue = MakeBox({1.f, 1.f, 1.f}, Color{0, 0, 255, 255});
    if (order == 0) {
      r.Draw(red, near);
      r.Draw(blue, far);
    } else {
      r.Draw(blue, far);
      r.Draw(red, near);
    }
    const std::uint32_t px = fb.Get(32, 32);
    CHECK((px & 0xFFu) > 200u);         // red channel
    CHECK(((px >> 16) & 0xFFu) < 50u);  // blue channel absent
  }
}

TEST(project_matches_view_and_rejects_behind_camera) {
  Framebuffer fb(100, 100);
  Rasterizer r;
  r.Begin(&fb, FrontCam(), Lighting{});
  float sx = 0, sy = 0;
  CHECK(r.Project({0.f, 0.f, 0.f}, sx, sy));
  CHECK_NEAR(sx, 50.0, 0.5);
  CHECK_NEAR(sy, 50.0, 0.5);
  CHECK(r.Project({1.f, 0.f, 0.f}, sx, sy));
  CHECK(sx > 50.f);  // +x is to the right
  CHECK(r.Project({0.f, 1.f, 0.f}, sx, sy));
  CHECK(sy < 50.f);                             // +y is up on screen
  CHECK(!r.Project({0.f, 0.f, -9.f}, sx, sy));  // behind the camera
}

TEST(triangles_crossing_the_near_plane_do_not_crash) {
  Framebuffer fb(64, 64);
  Rasterizer r;
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  Camera c;
  c.eye = {0.f, 0.5f, 0.f};
  c.target = {0.f, 0.5f, 5.f};
  r.Begin(&fb, c, Lighting{});
  r.Draw(MakeCheckerFloor(20.f, 2.f, {200, 200, 200, 255}, {100, 100, 100, 255}), DrawParams{});
  CHECK(r.stats().trianglesDrawn > 0);
}

TEST(alpha_blend_and_framebuffer_helpers) {
  Framebuffer fb(10, 10);
  CHECK(!fb.Resize(0, 5));
  CHECK(!fb.Resize(100000, 5));
  CHECK_EQ(fb.width(), 10);
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  fb.Blend(1, 1, Color{255, 255, 255, 128});
  const std::uint32_t px = fb.Get(1, 1);
  CHECK((px & 0xFFu) > 120u && (px & 0xFFu) < 135u);
  fb.Blend(-5, 3, Color{255, 0, 0, 255});  // out of range: ignored
  CHECK_EQ(fb.Get(-5, 3), 0u);
  fb.FillCircle(5.f, 5.f, 3.f, Color{0, 255, 0, 255});
  CHECK_EQ(fb.Get(5, 5), (Color{0, 255, 0, 255}).Pack());
  CHECK_EQ(fb.Get(0, 0), 0xFF000000u);
  CHECK(Framebuffer::TextWidth("ABC", 2) == 36.f);
  CHECK(fb.DrawText(0, 0, "A", 1, Color{255, 255, 255, 255}) > 0.f);
}

TEST(obj_loader_validates_input) {
  auto good = ParseObj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n", "tri.obj");
  CHECK(good.ok());
  CHECK_EQ(good.value.TriangleCount(), static_cast<std::size_t>(1));
  auto quad = ParseObj("v 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\nf 1/1/1 2 3 4\n", "q.obj");
  CHECK(quad.ok() && quad.value.TriangleCount() == 2);
  auto neg = ParseObj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf -3 -2 -1\n", "n.obj");
  CHECK(neg.ok());
  CHECK(!ParseObj("v 0 0 0\nf 1 2 3\n", "bad.obj").ok());  // index out of range
  CHECK(!ParseObj("v 0 0\n", "bad.obj").ok());             // wrong coordinate count
  CHECK(!ParseObj("v a b c\n", "bad.obj").ok());           // not numbers
  CHECK(!ParseObj("v nan 0 0\n", "bad.obj").ok());         // non-finite
  CHECK(!ParseObj("# only a comment\n", "empty.obj").ok());
  auto r = ParseObj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 9\n", "ctx.obj");
  CHECK(r.status.message.find("ctx.obj:4") != std::string::npos);
  MeshLoadLimits tiny;
  tiny.maxVertices = 2;
  CHECK(!ParseObj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n", "big.obj", tiny).ok());
  const MeshLoadOutcome fb = LoadMeshOrFallback("/nonexistent/model.obj");
  CHECK(fb.usedFallback && !fb.error.empty() && fb.mesh.TriangleCount() == 12);
}
