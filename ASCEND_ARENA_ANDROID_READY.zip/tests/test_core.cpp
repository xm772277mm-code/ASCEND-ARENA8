// Core engine/gameplay unit tests: timestep, RNG, math, pools, cooldowns, damage, XP, INI, localization.
#include <cmath>

#include "../engine/assets/ini.h"
#include "../engine/assets/localization.h"
#include "../engine/core/amath.h"
#include "../engine/core/fixed_step.h"
#include "../engine/core/rng.h"
#include "../gameplay/combat/combat_types.h"
#include "../gameplay/combat/damage.h"
#include "test_framework.h"

using namespace ascend;

TEST(fixed_step_runs_whole_steps) {
  FixedStepper s(1.f / 60.f, 5);
  CHECK_EQ(s.Advance(0.005f), 0);
  CHECK_EQ(s.Advance(0.0125f), 1);  // 0.0175 accumulated -> one 1/60 step
  CHECK_EQ(s.Advance(1.f / 30.f), 2);
  CHECK(s.Alpha() >= 0.f && s.Alpha() <= 1.f);
}

TEST(fixed_step_clamps_hitch) {
  FixedStepper s(1.f / 60.f, 5);
  CHECK_EQ(s.Advance(10.f), 5);  // never more than the cap
  CHECK_EQ(s.Advance(0.f), 0);   // backlog was dropped, not carried
  CHECK_EQ(s.Advance(-1.f), 0);  // negative time is ignored
}

TEST(fixed_step_pause_does_not_accumulate) {
  FixedStepper s(1.f / 60.f, 5);
  s.SetPaused(true);
  CHECK_EQ(s.Advance(5.f), 0);
  s.SetPaused(false);
  CHECK_EQ(s.Advance(0.f), 0);
}

TEST(rng_is_deterministic) {
  Rng a(123), b(123), c(124);
  bool differs = false;
  for (int i = 0; i < 100; ++i) {
    const auto x = a.NextU64();
    CHECK_EQ(x, b.NextU64());
    differs |= x != c.NextU64();
  }
  CHECK(differs);
  Rng z(0);  // a zero seed must not lock the generator at zero
  CHECK(z.NextU64() != 0u);
}

TEST(rng_int_in_range) {
  Rng r(5);
  bool lo = false, hi = false;
  for (int i = 0; i < 2000; ++i) {
    const int v = r.NextInt(3, 6);
    CHECK(v >= 3 && v <= 6);
    lo |= v == 3;
    hi |= v == 6;
    const float f = r.NextFloat();
    CHECK(f >= 0.f && f < 1.f);
  }
  CHECK(lo && hi);
  CHECK_EQ(r.NextInt(4, 4), 4);
  CHECK_EQ(r.NextInt(9, 2), 9);
}

TEST(math_wrap_angle_and_yaw) {
  CHECK_NEAR(WrapAngle(3.f * kPi), kPi, 1e-4);
  CHECK_NEAR(std::fabs(WrapAngle(-3.f * kPi)), kPi, 1e-4);
  CHECK_NEAR(AngleDelta(kPi * 0.9f, -kPi * 0.9f), kPi * 0.2, 1e-4);
  const Vec3 f = ForwardFromYaw(kPi * 0.5f);
  CHECK_NEAR(f.x, 1.0, 1e-5);
  CHECK_NEAR(YawFromDirection(f), kPi * 0.5, 1e-5);
  CHECK_NEAR(Length(NormalizeXZ({3.f, 9.f, 4.f})), 1.0, 1e-5);
  CHECK_NEAR(NormalizeXZ({0.f, 1.f, 0.f}).x, 0.0, 1e-9);
}

TEST(math_circle_vs_box_pushes_out) {
  const Aabb2 box{0.f, 0.f, 2.f, 2.f};
  const Vec3 out = ResolveCircleVsBox({-0.2f, 0.f, 1.f}, 0.5f, box);
  CHECK_NEAR(out.x, -0.5, 1e-4);
  const Vec3 same = ResolveCircleVsBox({-3.f, 0.f, 1.f}, 0.5f, box);
  CHECK_NEAR(same.x, -3.0, 1e-6);
  const Vec3 inside = ResolveCircleVsBox({0.2f, 0.f, 1.f}, 0.5f, box);
  CHECK_NEAR(inside.x, -0.5, 1e-4);  // nearest face
}

TEST(math_segment_hits_box) {
  const Aabb2 box{1.f, 1.f, 3.f, 3.f};
  CHECK(SegmentHitsBox({0.f, 0.f, 2.f}, {4.f, 0.f, 2.f}, box));
  CHECK(!SegmentHitsBox({0.f, 0.f, 0.f}, {4.f, 0.f, 0.5f}, box));
  CHECK(SegmentHitsBox({2.f, 0.f, 2.f}, {2.5f, 0.f, 2.5f}, box));  // fully inside
  CHECK(!SegmentHitsBox({0.f, 0.f, 0.f}, {0.9f, 0.f, 0.f}, box));  // stops short
}

TEST(pool_bounds) {
  Pool p = Pool::Full(100);
  CHECK_EQ(p.Remove(30), 30);
  CHECK_EQ(p.cur, 70);
  CHECK_EQ(p.Remove(500), 70);
  CHECK(p.Empty());
  CHECK_EQ(p.Remove(-5), 0);  // negative damage cannot heal
  CHECK_EQ(p.Add(40), 40);
  CHECK_EQ(p.Add(1000), 60);  // clamped at max
  CHECK_EQ(p.cur, 100);
  p.SetMax(50, false);
  CHECK_EQ(p.cur, 50);
  p.SetMax(0, true);
  CHECK_EQ(p.max, 1);
}

TEST(cooldown_ticks_and_readies) {
  Cooldown c;
  CHECK(c.Ready());
  c.Start(2.f);
  CHECK(!c.Ready());
  c.Tick(0.5f);
  CHECK_NEAR(c.remaining(), 1.5, 1e-6);
  CHECK_NEAR(c.Fraction(), 0.75, 1e-6);
  c.Tick(5.f);
  CHECK(c.Ready());
  CHECK_NEAR(c.remaining(), 0.0, 1e-9);
  c.Start(-1.f);
  CHECK(c.Ready());
}

TEST(damage_formula) {
  Stats d;
  d.defense = 10;  // physical: -5
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Physical, d), 15);
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Fire, d), 20);  // defense is physical only
  d.resist.fire = 50;
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Fire, d), 10);
  d.resist.fire = 100;
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Fire, d), 0);  // immune
  d.resist.fire = -100;
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Fire, d), 40);  // vulnerable
  Stats tank;
  tank.defense = 1000;
  CHECK_EQ(ComputeDamage(1, 100, DamageType::Physical, tank), 1);             // at least 1
  CHECK_EQ(ComputeDamage(20, 100, DamageType::Physical, Stats{}, true), 27);  // (20-2)=18, crit x1.5
  CHECK_EQ(ComputeDamage(-5, 100, DamageType::Physical, Stats{}), 1);         // corrupt attack value is safe
}

TEST(xp_scaling_prevents_farming) {
  CHECK_EQ(ScaledXpReward(100, 5, 5), 100);
  CHECK_EQ(ScaledXpReward(100, 5, 7), 100);  // 2-level grace gap
  CHECK_EQ(ScaledXpReward(100, 5, 8), 80);
  CHECK_EQ(ScaledXpReward(100, 1, 40), 10);  // floor at 10%
  CHECK_EQ(ScaledXpReward(0, 1, 1), 0);
  CHECK(ScaledXpReward(3, 1, 40) >= 1);
}

TEST(ini_parses_sections_and_types) {
  auto r = ParseIni("# c\n[a]\nx = 5\nf=2.5\nname = Level #5\nlist = a, b ,c\n\n[b]\nk=v\n", "t.ini");
  CHECK(r.ok());
  const IniSection* a = r.value.Find("a");
  CHECK(a != nullptr);
  CHECK_EQ(a->IntOr("x", 0), 5);
  CHECK_NEAR(a->FloatOr("f", 0.f), 2.5, 1e-6);
  CHECK_EQ(a->Str("name"), std::string("Level #5"));  // '#' inside a value is preserved
  CHECK_EQ(a->List("list").size(), static_cast<std::size_t>(3));
  CHECK(!a->Int("name").has_value());
  CHECK(!a->Int("missing").has_value());
  CHECK(r.value.Find("zzz") == nullptr);
}

TEST(ini_rejects_malformed) {
  CHECK(!ParseIni("x = 1\n", "t").ok());          // key outside section
  CHECK(!ParseIni("[a\nx=1\n", "t").ok());        // bad header
  CHECK(!ParseIni("[a]\nnovalue\n", "t").ok());   // no '='
  CHECK(!ParseIni("[a]\nx=1\nx=2\n", "t").ok());  // duplicate key
  CHECK(!ParseIni("[a]\n[a]\n", "t").ok());       // duplicate section
  auto r = ParseIni("[a]\nok=1\nbad line\n", "file.ini");
  CHECK(!r.ok());
  CHECK(r.status.message.find("file.ini:3") != std::string::npos);  // line number reported
  CHECK(!LoadIniFile("/nonexistent/path.ini").ok());
}

TEST(localization_fallback_and_missing_marker) {
  Localization loc;
  auto en = ParseIni("[strings]\nhello = Hello\nonly_en = English only\nfmt = {0} has {1} HP\n", "en");
  auto ar = ParseIni("[strings]\nhello = مرحبا\n", "ar");
  CHECK(en.ok() && ar.ok());
  CHECK(loc.AddCatalog("en", en.value, false).ok);
  CHECK(loc.AddCatalog("ar", ar.value, true).ok);
  CHECK(!loc.AddCatalog("xx", IniDocument{}, false).ok);  // no [strings]
  CHECK(!loc.SetLanguage("fr"));
  CHECK(loc.SetLanguage("ar"));
  CHECK(loc.IsRtl());
  CHECK_EQ(loc.Get("hello"), std::string("مرحبا"));
  CHECK_EQ(loc.Get("only_en"), std::string("English only"));  // falls back to English
  CHECK_EQ(loc.Get("nope"), std::string("!nope!"));           // visible marker
  CHECK_EQ(loc.Format("fmt", {"Kael", "90"}), std::string("Kael has 90 HP"));
  CHECK_EQ(loc.MissingKeys("ar").size(), static_cast<std::size_t>(2));
  CHECK(loc.HasKey("en", "hello") && !loc.HasKey("ar", "only_en"));
}

// ---- viewport / safe area / touch mapping -------------------------------------------------------
#include "../engine/input/viewport.h"

TEST(viewport_quality_tiers_and_defaults) {
  CHECK_EQ(FbHeightForQuality("low"), 360);
  CHECK_EQ(FbHeightForQuality("medium"), 540);
  CHECK_EQ(FbHeightForQuality("high"), 720);
  CHECK_EQ(FbHeightForQuality("???"), 540);
}

TEST(viewport_safe_area_notch_phone) {
  const Viewport vp = ComputeViewport(2400, 1080, RectI{96, 0, 2208, 1080}, 540);
  CHECK_EQ(vp.dst.x, 96);
  CHECK_EQ(vp.dst.w, 2208);
  CHECK_EQ(vp.fbH, 540);
  CHECK_EQ(vp.fbW, 1104);
  float fx = 0, fy = 0;
  CHECK(WindowToFb(vp, 96.f + 1104.f, 540.f, fx, fy));  // centre of the safe area
  CHECK_NEAR(fx, 552.0, 0.01);
  CHECK_NEAR(fy, 270.0, 0.01);
  CHECK(!WindowToFb(vp, 10.f, 540.f, fx, fy));  // finger in the notch strip: outside, clamped
  CHECK_NEAR(fx, 0.0, 1e-6);
  // 440 dpi phone: 17.3 window px/mm, framebuffer is half the window width => ~8.7 px/mm.
  CHECK_NEAR(FbPixelsPerMm(vp, 2.75f), 8.66, 0.05);
}

TEST(viewport_degenerate_inputs_are_safe) {
  Viewport vp = ComputeViewport(0, 0, RectI{-50, -50, 99999, 99999}, 0);
  CHECK(vp.fbW >= 320 && vp.fbH >= 180);
  CHECK(vp.dst.w >= 1 && vp.dst.h >= 1);
  vp = ComputeViewport(800, 600, RectI{}, 100000);
  CHECK(vp.fbH <= 600);
  CHECK_EQ(vp.fbW % 2, 0);
  CHECK(FbPixelsPerMm(vp, 0.f) >= 3.f);
  CHECK(FbPixelsPerMm(vp, std::nanf("")) <= 30.f);
  CHECK(FbPixelsPerMm(vp, 1000.f) <= 30.f);
}
