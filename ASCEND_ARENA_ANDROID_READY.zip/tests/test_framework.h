#pragma once
// Minimal dependency-free unit test framework (no network needed to run tests).
#include <cmath>
#include <functional>
#include <iostream>
#include <string>
#include <vector>

namespace ascend_test {

struct TestCase {
  std::string name;
  std::function<void()> fn;
};

inline std::vector<TestCase>& Registry() {
  static std::vector<TestCase> r;
  return r;
}
inline int& FailureCount() {
  static int n = 0;
  return n;
}
struct Registrar {
  Registrar(const char* name, std::function<void()> fn) { Registry().push_back({name, std::move(fn)}); }
};

}  // namespace ascend_test

#define TEST(name)                                               \
  static void name();                                            \
  static ::ascend_test::Registrar registrar_##name(#name, name); \
  static void name()

#define CHECK(cond)                                                                    \
  do {                                                                                 \
    if (!(cond)) {                                                                     \
      std::cerr << "  FAIL " << __FILE__ << ":" << __LINE__ << "  CHECK(" #cond ")\n"; \
      ++::ascend_test::FailureCount();                                                 \
    }                                                                                  \
  } while (0)

#define CHECK_EQ(a, b)                                                                                            \
  do {                                                                                                            \
    const auto va_ = (a);                                                                                         \
    const auto vb_ = (b);                                                                                         \
    if (!(va_ == vb_)) {                                                                                          \
      std::cerr << "  FAIL " << __FILE__ << ":" << __LINE__ << "  " #a " == " #b << "  (" << va_ << " vs " << vb_ \
                << ")\n";                                                                                         \
      ++::ascend_test::FailureCount();                                                                            \
    }                                                                                                             \
  } while (0)

#define CHECK_NEAR(a, b, eps)                                                                                     \
  do {                                                                                                            \
    const double va_ = static_cast<double>(a), vb_ = static_cast<double>(b);                                      \
    if (std::fabs(va_ - vb_) > (eps)) {                                                                           \
      std::cerr << "  FAIL " << __FILE__ << ":" << __LINE__ << "  " #a " ~= " #b << "  (" << va_ << " vs " << vb_ \
                << ")\n";                                                                                         \
      ++::ascend_test::FailureCount();                                                                            \
    }                                                                                                             \
  } while (0)
