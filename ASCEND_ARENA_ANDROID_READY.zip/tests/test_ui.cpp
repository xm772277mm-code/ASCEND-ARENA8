// Application/UI tests: navigation, every main button, language switching (EN/AR, RTL), settings,
// mode flows through the real UI, lifecycle (background/pause), save recovery and font fallback.
#include <filesystem>
#include <fstream>
#include <set>

#include "../game/bot.h"
#include "../ui/app.h"
#include "test_framework.h"

using namespace ascend;
namespace fs = std::filesystem;

namespace {

constexpr float kDt = 1.f / 60.f;

std::string Content() { return std::string(ASCEND_SOURCE_DIR) + "/content"; }

std::string TempPath(const std::string& n) {
  const fs::path d = fs::temp_directory_path() / "ascend_ui_tests";
  fs::create_directories(d);
  std::error_code ec;
  for (const char* x : {"", ".tmp", ".bak", ".corrupt"}) fs::remove(d / (n + x), ec);
  return (d / n).string();
}

struct Fx {
  App app;
  Framebuffer fb{960, 540};
  explicit Fx(const std::string& save, const std::string& content = Content()) : app(AppConfig{content, save, 1}) {
    const Status s = app.Init();
    if (!s) std::cerr << "  init failed: " << s.message << "\n";
    CHECK(s.ok);
    app.SetViewport(960, 540, 6.4f);
    Draw();
  }
  void Draw() { app.Draw(fb); }
  // Dismisses a startup notice if one is showing.
  void Clear() {
    while (app.overlay() == Overlay::Notice) {
      app.Tap("notice:ok");
      Draw();
    }
  }
  bool Tap(const std::string& a) {
    const bool ok = app.Tap(a);
    Draw();
    return ok;
  }
  void Step(float seconds) {
    const int n = static_cast<int>(seconds / kDt);
    for (int i = 0; i < n; ++i) app.Update(kDt);
    Draw();
  }
};

int DistinctColors(const Framebuffer& fb) {
  std::set<std::uint32_t> s;
  for (int i = 0; i < fb.width() * fb.height(); i += 37) s.insert(fb.pixels()[i]);
  return static_cast<int>(s.size());
}

// Drives the real App with the scripted bot until the result screen (or the time limit).
bool PlayToResult(Fx& f, float maxSeconds, bool immortal) {
  ScriptedBot bot;
  const int n = static_cast<int>(maxSeconds / kDt);
  for (int i = 0; i < n && f.app.screen() == Screen::InGame; ++i) {
    GameSession* s = f.app.session();
    if (!s) break;
    if (s->phase() == RunPhase::IntroDialogue || s->phase() == RunPhase::OutroDialogue) {
      f.app.OnTouch({1, TouchPhase::Up, 5.f, 5.f});
    } else if (s->phase() == RunPhase::Running) {
      if (immortal) s->world().mutablePlayer().hp.cur = s->world().player().hp.max;
      const InputFrame in = bot.Next(s->world(), 0.f);
      f.app.SetKeyMove(in.move);
      if (in.attack) f.app.PressKey(KeyAction::Attack);
      if (in.dodge) f.app.PressKey(KeyAction::Dodge);
      if (in.skill[0]) f.app.PressKey(KeyAction::Skill1);
      if (in.skill[1]) f.app.PressKey(KeyAction::Skill2);
    }
    f.app.Update(kDt);
    if (i % 30 == 0) f.Draw();
  }
  f.app.SetKeyMove({});
  f.Draw();
  return f.app.screen() == Screen::Result;
}

}  // namespace

TEST(ui_init_draws_lobby) {
  Fx f(TempPath("ui1.sav"));
  f.Clear();
  CHECK(f.app.screen() == Screen::Lobby);
  CHECK(f.app.fontError().empty());
  CHECK(DistinctColors(f.fb) > 12);  // a real picture, not a blank clear
  CHECK(f.app.previewVisual() != nullptr);
}

TEST(ui_every_lobby_button_navigates_and_back_returns) {
  Fx f(TempPath("ui2.sav"));
  f.Clear();
  const struct {
    const char* act;
    Screen to;
  } nav[] = {{"nav:play", Screen::Play},           {"nav:characters", Screen::Characters},
             {"nav:inventory", Screen::Inventory}, {"nav:story", Screen::Encounters},
             {"nav:profile", Screen::Profile},     {"nav:settings", Screen::Settings},
             {"nav:language", Screen::Language}};
  for (const auto& n : nav) {
    CHECK(f.app.HasButton(n.act));
    CHECK(f.Tap(n.act));
    CHECK(f.app.screen() == n.to);
    CHECK(DistinctColors(f.fb) > 8);
    CHECK(f.app.HasButton("nav:back"));
    CHECK(f.Tap("nav:back"));
    CHECK(f.app.screen() == Screen::Lobby);
  }
}

TEST(ui_play_page_opens_all_four_modes) {
  Fx f(TempPath("ui3.sav"));
  f.Clear();
  f.Tap("nav:play");
  for (const char* m : {"mode:missions", "mode:training", "mode:dungeons", "mode:story"}) {
    CHECK(f.Tap(m));
    CHECK(f.app.screen() == Screen::Encounters);
    f.Tap("nav:back");
    CHECK(f.app.screen() == Screen::Play);
  }
}

TEST(ui_android_back_button_semantics) {
  Fx f(TempPath("ui4.sav"));
  f.Clear();
  CHECK(!f.app.BackPressed());  // lobby: let the OS leave the app
  f.Tap("nav:settings");
  CHECK(f.app.BackPressed());
  f.Draw();  // the host draws every frame; buttons are rebuilt from what is on screen
  CHECK(f.app.screen() == Screen::Lobby);
  f.Tap("nav:play");
  f.Tap("mode:missions");
  CHECK(f.app.BackPressed());
  f.Draw();
  CHECK(f.app.screen() == Screen::Play);
  CHECK(f.app.BackPressed());
  f.Draw();
  CHECK(f.app.screen() == Screen::Lobby);
}

TEST(ui_arabic_and_english_catalogs_are_complete) {
  Fx f(TempPath("ui5.sav"));
  f.Clear();
  CHECK(f.app.loc().MissingKeys("ar").empty());
  CHECK(f.app.loc().KeyCount("ar") == f.app.loc().KeyCount("en"));
  CHECK(f.app.loc().IsRtl() == false);
  f.app.loc().SetLanguage("ar");
  CHECK(f.app.loc().IsRtl());
  f.app.loc().SetLanguage("en");
}

TEST(ui_language_switch_changes_strings_direction_and_persists) {
  const std::string save = TempPath("ui6.sav");
  {
    Fx f(save);
    f.Clear();
    const std::string en = f.app.loc().Get("ui.play");
    f.Tap("nav:language");
    CHECK(f.app.HasButton("lang:ar"));
    CHECK(f.app.HasButton("lang:en"));
    f.Tap("lang:ar");
    const std::string ar = f.app.loc().Get("ui.play");
    CHECK(ar != en);
    CHECK(f.app.rtl());
    CHECK_EQ(f.app.profile().settings.language, std::string("ar"));
    CHECK(DistinctColors(f.fb) > 8);
    f.Tap("nav:back");
    CHECK(f.app.screen() == Screen::Lobby);
    // In RTL the Play tile sits on the left half (mirrored); in LTR it is on the right half.
    float arX = -1.f;
    for (const auto& b : f.app.buttons())
      if (b.action == "nav:play") arX = b.x + b.w * 0.5f;
    CHECK(arX > 0.f && arX < 960.f * 0.5f);
    f.Tap("nav:language");
    f.Tap("lang:en");
    f.Tap("nav:back");
    float enX = -1.f;
    for (const auto& b : f.app.buttons())
      if (b.action == "nav:play") enX = b.x + b.w * 0.5f;
    CHECK(enX > 960.f * 0.5f);
    f.Tap("nav:language");
    f.Tap("lang:ar");
  }
  Fx g(save);  // a fresh start remembers the language
  g.Clear();
  CHECK_EQ(g.app.loc().language(), std::string("ar"));
  CHECK(g.app.rtl());
}

TEST(ui_arabic_text_is_actually_drawn_with_the_font) {
  Fx f(TempPath("ui7.sav"));
  f.Clear();
  CHECK(f.app.text().HasFont());
  f.Tap("nav:language");
  f.Tap("lang:ar");
  f.Tap("nav:back");
  CHECK(DistinctColors(f.fb) > 12);
  // The shaped Arabic string measures wider than zero and differs from its English counterpart.
  CHECK(f.app.text().Measure(f.app.loc().Get("ui.play"), 30, 1) > 10.f);
}

TEST(ui_settings_apply_and_persist) {
  const std::string save = TempPath("ui8.sav");
  {
    Fx f(save);
    f.Clear();
    f.Tap("nav:settings");
    const int music = f.app.profile().settings.musicVolume;
    CHECK(f.Tap("set:music:+"));
    CHECK_EQ(f.app.profile().settings.musicVolume, music + 10);
    CHECK(f.Tap("set:sens:-"));
    CHECK_EQ(f.app.profile().settings.sensitivity, 90);
    const std::string q = f.app.profile().settings.quality;
    CHECK(f.Tap("set:quality"));
    CHECK(f.app.profile().settings.quality != q);
    CHECK(f.Tap("set:text:+"));
    CHECK(f.app.profile().settings.textScale > 1.05f);
    CHECK(f.Tap("set:invert"));
    CHECK(f.app.profile().settings.invertY);
    for (int i = 0; i < 20; ++i) f.Tap("set:music:+");  // bounded
    CHECK_EQ(f.app.profile().settings.musicVolume, 100);
    for (int i = 0; i < 30; ++i) f.app.Tap("set:text:+");
    CHECK(f.app.profile().settings.textScale <= 1.6f + 1e-4f);
  }
  Fx g(save);
  g.Clear();
  CHECK_EQ(g.app.profile().settings.sensitivity, 90);
  CHECK(g.app.profile().settings.invertY);
}

TEST(ui_large_text_and_odd_viewports_do_not_break_layout) {
  Fx f(TempPath("ui9.sav"));
  f.Clear();
  f.app.profile().settings.textScale = 1.6f;
  const int sizes[][2] = {{320, 180}, {640, 360}, {1280, 720}, {2400, 1080}, {800, 800}, {1080, 2340}};
  for (const auto& s : sizes) {
    Framebuffer fb(s[0], s[1]);
    f.app.SetViewport(s[0], s[1], static_cast<float>(s[0]) / 150.f);
    for (const char* a : {"nav:play", "nav:back", "nav:characters", "nav:back", "nav:inventory", "nav:back",
                          "nav:profile", "nav:back", "nav:settings", "nav:back", "nav:language", "nav:back"}) {
      f.app.Draw(fb);
      f.app.Tap(a);
    }
    f.app.Draw(fb);
    CHECK(DistinctColors(fb) > 4);
    // Every drawn button stays inside the viewport and is large enough to touch (>= 8 mm on its short side
    // is checked at the reference phone size below).
    for (const auto& b : f.app.buttons()) {
      CHECK(b.x >= -1.f && b.y >= -1.f);
      CHECK(b.x + b.w <= static_cast<float>(s[0]) + 1.f);
      CHECK(b.y + b.h <= static_cast<float>(s[1]) + 1.f);
    }
  }
  f.app.SetViewport(960, 540, 6.4f);
  f.app.profile().settings.textScale = 1.0f;
  f.app.Draw(f.fb);
  float minSide = 1e9f;
  for (const auto& b : f.app.buttons()) minSide = std::min(minSide, std::min(b.w, b.h));
  CHECK(minSide / 6.4f >= 7.0f);  // main-screen buttons are at least ~7 mm on the short side
}

TEST(ui_locked_story_chapter_cannot_start) {
  Fx f(TempPath("ui10.sav"));
  f.Clear();
  f.Tap("nav:story");
  CHECK(f.app.HasButton("enc:start:ch1"));
  CHECK(!f.app.HasButton("enc:start:ch2"));
  CHECK(!f.app.Tap("enc:start:ch2"));
  CHECK(f.app.screen() == Screen::Encounters);
}

TEST(ui_mission_end_to_end_through_the_ui_with_rewards_and_save) {
  const std::string save = TempPath("ui11.sav");
  Fx f(save);
  f.Clear();
  f.Tap("nav:play");
  f.Tap("mode:missions");
  CHECK(f.app.HasButton("enc:start:m1_first_blood"));
  const int gold0 = f.app.profile().gold, xp0 = f.app.profile().xp;
  CHECK(f.Tap("enc:start:m1_first_blood"));
  CHECK(f.app.screen() == Screen::InGame);
  CHECK(f.app.session() != nullptr);
  f.Step(1.0f);
  CHECK(PlayToResult(f, 240.f, true));
  CHECK(f.app.session()->summary().outcome == Outcome::Victory);
  CHECK(f.app.HasButton("res:lobby"));
  CHECK(f.app.HasButton("res:retry"));
  CHECK(f.app.profile().completedMissions.count("m1_first_blood") > 0);
  CHECK(f.app.profile().gold > gold0 || f.app.profile().xp > xp0 || f.app.profile().level > 1);
  const int goldAfter = f.app.profile().gold;
  CHECK(f.Tap("res:lobby"));
  CHECK(f.app.screen() == Screen::Lobby);
  CHECK(f.app.session() == nullptr);
  CHECK(fs::exists(save));
  Fx g(save);  // the progress really was saved to disk
  g.Clear();
  CHECK(g.app.profile().completedMissions.count("m1_first_blood") > 0);
  CHECK_EQ(g.app.profile().gold, goldAfter);
}

TEST(ui_retry_starts_a_fresh_run_and_does_not_duplicate_first_clear_reward) {
  Fx f(TempPath("ui12.sav"));
  f.Clear();
  f.Tap("nav:play");
  f.Tap("mode:missions");
  f.Tap("enc:start:m1_first_blood");
  CHECK(PlayToResult(f, 240.f, true));
  const bool first = f.app.session()->summary().firstClear;
  CHECK(first);
  CHECK(f.Tap("res:retry"));
  CHECK(f.app.screen() == Screen::InGame);
  CHECK(PlayToResult(f, 240.f, true));
  CHECK(!f.app.session()->summary().firstClear);  // the one-time bonus is not paid twice
}

TEST(ui_pause_overlay_freezes_simulation_and_resume_continues) {
  Fx f(TempPath("ui13.sav"));
  f.Clear();
  f.Tap("nav:play");
  f.Tap("mode:training");
  CHECK(f.app.HasButton("enc:start:training_basic") || f.app.HasButton("enc:start:basic"));
  const auto list = f.app.levels().OfKind(ModeKind::Training);
  CHECK(!list.empty());
  f.Tap("enc:start:" + list[0]->id);
  CHECK(f.app.screen() == Screen::InGame);
  f.Step(0.5f);
  f.app.PressKey(KeyAction::Pause);
  f.Step(0.2f);
  CHECK(f.app.overlay() == Overlay::Pause);
  const double t = f.app.session()->world().time();
  f.Step(2.0f);
  CHECK_NEAR(f.app.session()->world().time(), t, 1e-6);
  CHECK(f.app.HasButton("run:resume"));
  f.Tap("run:resume");
  CHECK(f.app.overlay() == Overlay::None);
  f.Step(0.5f);
  CHECK(f.app.session()->world().time() > t + 0.3);
}

TEST(ui_background_pauses_run_saves_and_releases_input) {
  const std::string save = TempPath("ui14.sav");
  Fx f(save);
  f.Clear();
  f.Tap("nav:play");
  f.Tap("mode:training");
  const auto list = f.app.levels().OfKind(ModeKind::Training);
  f.Tap("enc:start:" + list[0]->id);
  f.app.OnTouch({1, TouchPhase::Down, 120.f, 420.f});  // finger on the joystick zone
  f.app.OnTouch({1, TouchPhase::Move, 200.f, 380.f});
  f.Step(0.3f);
  f.app.OnBackground();
  CHECK(f.app.overlay() == Overlay::Pause);
  CHECK(fs::exists(save));
  const double t = f.app.session()->world().time();
  f.Step(1.0f);
  CHECK_NEAR(f.app.session()->world().time(), t, 1e-6);
  f.app.OnForeground();
  CHECK(f.app.overlay() == Overlay::Pause);  // stays paused until the player resumes
  f.Tap("run:resume");
  const Vec3 p0 = f.app.session()->world().player().pos;
  f.Step(0.5f);
  const Vec3 p1 = f.app.session()->world().player().pos;
  CHECK(DistanceXZ(p0, p1) < 0.05f);  // the held finger was released: no stuck movement
}

TEST(ui_leave_run_asks_for_confirmation_and_returns_to_lobby) {
  Fx f(TempPath("ui15.sav"));
  f.Clear();
  f.Tap("nav:play");
  f.Tap("mode:training");
  const auto list = f.app.levels().OfKind(ModeKind::Training);
  f.Tap("enc:start:" + list[0]->id);
  f.Step(0.3f);
  f.Tap("run:pause");
  CHECK(f.app.overlay() == Overlay::Pause);
  f.Tap("run:leave");
  CHECK(f.app.overlay() == Overlay::ConfirmLeave);
  f.Tap("run:leave_cancel");
  CHECK(f.app.overlay() == Overlay::Pause);
  f.Tap("run:leave");
  f.Tap("run:leave_confirm");
  CHECK(f.app.screen() == Screen::Lobby);
  CHECK(f.app.overlay() == Overlay::None);
  CHECK(f.app.session() == nullptr);
}

TEST(ui_touch_tap_on_a_button_fires_only_when_released_on_it) {
  Fx f(TempPath("ui16.sav"));
  f.Clear();
  float cx = 0, cy = 0;
  for (const auto& b : f.app.buttons())
    if (b.action == "nav:settings") {
      cx = b.x + b.w * 0.5f;
      cy = b.y + b.h * 0.5f;
    }
  CHECK(cx > 0);
  f.app.OnTouch({1, TouchPhase::Down, cx, cy});
  f.app.OnTouch({1, TouchPhase::Up, 5.f, 5.f});  // released elsewhere: no action
  CHECK(f.app.screen() == Screen::Lobby);
  f.app.OnTouch({2, TouchPhase::Down, cx, cy});
  f.app.OnTouch({2, TouchPhase::Up, cx, cy});
  CHECK(f.app.screen() == Screen::Settings);
}

TEST(ui_character_select_changes_the_real_selected_content) {
  Fx f(TempPath("ui17.sav"));
  f.Clear();
  f.app.profile().level = 6;
  SyncUnlocks(f.app.db(), f.app.profile());
  f.Tap("nav:characters");
  CHECK(f.app.HasButton("char:view:mira"));
  f.Tap("char:view:mira");
  CHECK_EQ(f.app.viewedCharacter(), std::string("mira"));
  CHECK(f.app.previewVisual() != nullptr);
  CHECK(f.app.HasButton("char:select"));
  f.Tap("char:select");
  CHECK_EQ(f.app.profile().characterId, std::string("mira"));
  // Outfit swap (kael has a crimson outfit; unlock level must be reached).
  f.Tap("char:view:kael");
  const CharacterDef* kael = f.app.db().Character("kael");
  CHECK(kael && !kael->outfits.empty());
  const std::string outfit = kael->outfits[0].id;
  f.app.profile().level = std::max(f.app.profile().level, kael->outfits[0].unlockLevel);
  f.Draw();
  CHECK(f.app.HasButton("char:outfit:" + outfit));
  f.Tap("char:outfit:" + outfit);
  CHECK_EQ(f.app.viewedOutfit(), outfit);
  f.Tap("char:select");
  CHECK_EQ(f.app.profile().characterId, std::string("kael"));
  CHECK_EQ(f.app.profile().outfitId, outfit);
}

TEST(ui_locked_character_cannot_be_selected) {
  Fx f(TempPath("ui18.sav"));
  f.Clear();
  f.Tap("nav:characters");
  f.Tap("char:view:mira");  // unlock level 3, profile is level 1
  CHECK(!f.app.HasButton("char:select"));
  f.app.Tap("char:select");
  CHECK_EQ(f.app.profile().characterId, std::string("kael"));
}

TEST(ui_inventory_equip_changes_real_stats) {
  Fx f(TempPath("ui19.sav"));
  f.Clear();
  CHECK_EQ(AddItem(f.app.db(), f.app.profile(), "iron_sword", 1), 1);
  const int atk0 = LoadoutFor(f.app.db(), f.app.profile()).stats.attack;
  f.Tap("nav:inventory");
  int idx = -1;
  for (std::size_t i = 0; i < f.app.profile().inventory.size(); ++i)
    if (f.app.profile().inventory[i].id == "iron_sword") idx = static_cast<int>(i);
  CHECK(idx >= 0);
  CHECK(f.Tap("inv:select:" + std::to_string(idx)));
  CHECK(f.app.HasButton("inv:equip"));
  f.Tap("inv:equip");
  CHECK_EQ(f.app.profile().equipment["weapon"], std::string("iron_sword"));
  CHECK(LoadoutFor(f.app.db(), f.app.profile()).stats.attack > atk0);
  CHECK(f.app.HasButton("inv:unequip:weapon"));
  f.Tap("inv:unequip:weapon");
  CHECK(f.app.profile().equipment.count("weapon") == 0 || f.app.profile().equipment["weapon"].empty());
  CHECK_EQ(CountItem(f.app.profile(), "iron_sword"), 1);
}

TEST(ui_corrupt_save_is_recovered_with_a_visible_notice_and_kept_for_inspection) {
  const std::string save = TempPath("ui20.sav");
  {
    std::ofstream o(save, std::ios::binary);
    o << "this is not a save file\x01\x02\x03";
  }
  Fx f(save);
  CHECK(f.app.overlay() == Overlay::Notice);
  CHECK(!f.app.noticeText().empty());
  CHECK(f.app.loadReport().kind == LoadKind::CorruptReset);
  CHECK(fs::exists(save + ".corrupt"));
  f.Tap("notice:ok");
  CHECK(f.app.overlay() == Overlay::None);
  CHECK_EQ(f.app.profile().level, 1);
}

TEST(ui_missing_font_falls_back_to_ascii_and_reports_it) {
  const fs::path tmp = fs::temp_directory_path() / "ascend_ui_tests" / "content_nofont";
  std::error_code ec;
  fs::remove_all(tmp, ec);
  fs::create_directories(tmp.parent_path());
  fs::copy(Content(), tmp, fs::copy_options::recursive, ec);
  CHECK(!ec);
  fs::remove(tmp / "fonts" / "DejaVuSans.ttf", ec);
  Fx f(TempPath("ui21.sav"), tmp.string());
  f.Clear();
  CHECK(!f.app.fontError().empty());
  CHECK(!f.app.text().HasFont());
  CHECK(DistinctColors(f.fb) > 8);  // still drawn with the built-in font
  f.Tap("nav:language");
  f.Tap("lang:ar");  // Arabic cannot be shown without the font, but nothing may crash
  f.Tap("nav:back");
  CHECK(f.app.screen() == Screen::Lobby);
  fs::remove_all(tmp, ec);
}

TEST(ui_invalid_content_fails_init_with_actionable_message) {
  const fs::path tmp = fs::temp_directory_path() / "ascend_ui_tests" / "content_bad";
  std::error_code ec;
  fs::remove_all(tmp, ec);
  fs::create_directories(tmp.parent_path());
  fs::copy(Content(), tmp, fs::copy_options::recursive, ec);
  {
    std::ofstream o(tmp / "data" / "skills.ini", std::ios::trunc);
    o << "[broken]\nkind = banana\n";
  }
  App app(AppConfig{tmp.string(), TempPath("ui22.sav"), 1});
  const Status s = app.Init();
  CHECK(!s.ok);
  CHECK(s.message.find("content") != std::string::npos);
  CHECK(s.message.find("broken") != std::string::npos);
  fs::remove_all(tmp, ec);
}

TEST(ui_audio_reacts_to_real_gameplay_and_settings) {
  Fx f(TempPath("ui23.sav"));
  f.Clear();
  f.Step(0.1f);
  CHECK(f.app.audio().music() == Music::Menu);
  f.Tap("nav:settings");
  f.app.profile().settings.musicVolume = 40;
  f.Tap("set:sfx:-");  // applies settings to the mixer
  f.Tap("nav:back");
  f.Tap("nav:play");
  f.Tap("mode:missions");
  f.Tap("enc:start:m1_first_blood");
  f.Step(0.5f);
  CHECK(f.app.audio().music() == Music::Battle);
  // Attack until the mixer has really played something for a hit.
  bool heard = false;
  for (int i = 0; i < 600 && !heard; ++i) {
    f.app.session()->world().mutablePlayer().hp.cur = f.app.session()->world().player().hp.max;
    ScriptedBot bot;
    const InputFrame in = bot.Next(f.app.session()->world(), 0.f);
    f.app.SetKeyMove(in.move);
    if (in.attack) f.app.PressKey(KeyAction::Attack);
    f.app.Update(kDt);
    std::int16_t buf[1024];
    f.app.audio().Mix(buf, 512);
    for (auto v : buf) heard |= std::abs(static_cast<int>(v)) > 500;
  }
  CHECK(heard);
  f.app.OnBackground();
  std::int16_t buf[256];
  f.app.audio().Mix(buf, 128);
  bool silent = true;
  for (auto v : buf) silent &= v == 0;
  CHECK(silent);  // paused while in the background
  f.app.OnForeground();
  CHECK(!f.app.audio().paused());
}
