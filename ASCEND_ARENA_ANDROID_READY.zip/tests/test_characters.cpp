// Character pipeline tests: GLB import, skeleton validation, animation sampling/blending, CPU skinning,
// outfits (mesh swap + material recolor), corrupt-file handling and animation selection from game state.
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

#include "../engine/assets/glb_loader.h"
#include "../engine/render/animation.h"
#include "../game/character_visual.h"
#include "test_framework.h"

using namespace ascend;

namespace {

const std::string kRoot = std::string(ASCEND_SOURCE_DIR) + "/content";

const ContentDb& Db() {
  static ContentDb db;
  static bool loaded = false;
  if (!loaded) {
    loaded = true;
    const auto err = db.LoadFromDirectory(kRoot);
    for (const auto& e : err) std::cerr << "  content error: " << e << "\n";
    CHECK(err.empty());
  }
  return db;
}

std::vector<unsigned char> ReadAll(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}

float PoseDistance(const Pose& a, const Pose& b) {
  float d = 0.f;
  for (std::size_t i = 0; i < a.size() && i < b.size(); ++i) {
    d += std::fabs(a[i].t.x - b[i].t.x) + std::fabs(a[i].t.y - b[i].t.y) + std::fabs(a[i].t.z - b[i].t.z);
    d += std::fabs(a[i].r.x - b[i].r.x) + std::fabs(a[i].r.y - b[i].r.y) + std::fabs(a[i].r.z - b[i].r.z) +
         std::fabs(a[i].r.w - b[i].r.w);
  }
  return d;
}

struct Bounds {
  Vec3 mn{1e9f, 1e9f, 1e9f}, mx{-1e9f, -1e9f, -1e9f};
  bool finite = true;
};
Bounds BoundsOf(const Mesh& m) {
  Bounds b;
  for (const auto& v : m.vertices) {
    if (!std::isfinite(v.pos.x) || !std::isfinite(v.pos.y) || !std::isfinite(v.pos.z)) b.finite = false;
    b.mn = {std::min(b.mn.x, v.pos.x), std::min(b.mn.y, v.pos.y), std::min(b.mn.z, v.pos.z)};
    b.mx = {std::max(b.mx.x, v.pos.x), std::max(b.mx.y, v.pos.y), std::max(b.mx.z, v.pos.z)};
  }
  return b;
}

SkinnedModel LoadKael() {
  auto r = LoadGlbFile(kRoot + "/models/kael.glb");
  CHECK(r.ok());
  return r.value;
}

Mesh SkinAt(const SkinnedModel& m, const AnimClip& clip, float t) {
  Pose p;
  SampleClip(m, clip, t, true, p);
  Mesh out;
  SkinToMesh(m, SkinMatrices(m, p), out);
  return out;
}

}  // namespace

TEST(glb_import_gives_a_valid_rigged_model) {
  const SkinnedModel m = LoadKael();
  CHECK_EQ(m.joints.size(), static_cast<std::size_t>(15));
  CHECK(m.vertices.size() > 100);
  CHECK(m.indices.size() % 3 == 0);
  for (const char* clip : {"idle", "walk", "run", "attack", "hit", "dodge", "defeat"}) CHECK(m.FindClip(clip) >= 0);
  const auto problems = ValidateModel(m);
  for (const auto& p : problems) std::cerr << "  model problem: " << p << "\n";
  CHECK(problems.empty());
  // Parents always precede children (required by WorldMatrices).
  for (std::size_t i = 0; i < m.joints.size(); ++i) CHECK(m.joints[i].parent < static_cast<int>(i));
  CHECK(m.FindMaterial("coat") >= 0);
  CHECK(m.FindMaterial("accent") >= 0);
}

TEST(all_shipped_models_import_and_share_the_expected_skeletons) {
  const SkinnedModel kael = LoadKael();
  auto armored = LoadGlbFile(kRoot + "/models/kael_armored.glb");
  auto mira = LoadGlbFile(kRoot + "/models/mira.glb");
  CHECK(armored.ok());
  CHECK(mira.ok());
  CHECK(SameSkeleton(kael, armored.value));  // outfit meshes must fit the character skeleton
  CHECK(ValidateModel(armored.value).empty());
  CHECK(ValidateModel(mira.value).empty());
  CHECK(mira.value.FindClip("attack") >= 0);
}

TEST(skinned_rest_mesh_has_human_scale_and_is_finite) {
  const SkinnedModel m = LoadKael();
  Mesh out;
  SkinToMesh(m, SkinMatrices(m, RestPose(m)), out);
  CHECK_EQ(out.vertices.size(), m.vertices.size());
  const Bounds b = BoundsOf(out);
  CHECK(b.finite);
  const float height = b.mx.y - b.mn.y;
  CHECK(height > 1.4f && height < 2.3f);   // humanoid, in meters
  CHECK(b.mn.y > -0.2f && b.mn.y < 0.2f);  // standing on the ground
}

TEST(animation_sampling_changes_the_pose_over_time_and_loops) {
  const SkinnedModel m = LoadKael();
  const AnimClip& run = m.clips[static_cast<std::size_t>(m.FindClip("run"))];
  CHECK(run.duration > 0.2f);
  Pose p0, p1, pEnd, pWrap, pClamp;
  SampleClip(m, run, 0.f, true, p0);
  SampleClip(m, run, run.duration * 0.25f, true, p1);
  CHECK(PoseDistance(p0, p1) > 0.05f);  // the run cycle really moves joints
  // Looping: t and t + duration give the same pose; clamping holds the last frame.
  SampleClip(m, run, 0.13f, true, pEnd);
  SampleClip(m, run, 0.13f + run.duration, true, pWrap);
  CHECK(PoseDistance(pEnd, pWrap) < 1e-3f);
  Pose pClamp2;
  SampleClip(m, run, run.duration * 5.f, false, pClamp);
  SampleClip(m, run, run.duration * 9.f, false, pClamp2);
  CHECK(PoseDistance(pClamp, pClamp2) < 1e-6f);
  // Skinned geometry follows the pose: an attack frame differs from idle.
  const AnimClip& idle = m.clips[static_cast<std::size_t>(m.FindClip("idle"))];
  const AnimClip& atk = m.clips[static_cast<std::size_t>(m.FindClip("attack"))];
  const Mesh a = SkinAt(m, idle, 0.f), b = SkinAt(m, atk, atk.duration * 0.5f);
  double moved = 0;
  for (std::size_t i = 0; i < a.vertices.size(); ++i)
    moved += std::fabs(a.vertices[i].pos.x - b.vertices[i].pos.x) +
             std::fabs(a.vertices[i].pos.y - b.vertices[i].pos.y) +
             std::fabs(a.vertices[i].pos.z - b.vertices[i].pos.z);
  CHECK(moved > 5.0);
  CHECK(BoundsOf(b).finite);
}

TEST(pose_blend_endpoints_and_quaternion_slerp) {
  const SkinnedModel m = LoadKael();
  Pose a, b;
  SampleClip(m, m.clips[static_cast<std::size_t>(m.FindClip("idle"))], 0.2f, true, a);
  SampleClip(m, m.clips[static_cast<std::size_t>(m.FindClip("attack"))], 0.2f, true, b);
  CHECK(PoseDistance(a, b) > 0.05f);
  CHECK(PoseDistance(BlendPoses(a, b, 0.f), a) < 1e-5f);
  CHECK(PoseDistance(BlendPoses(a, b, 1.f), b) < 1e-4f);
  const Pose mid = BlendPoses(a, b, 0.5f);
  const float dm = PoseDistance(mid, a), db = PoseDistance(mid, b);
  CHECK(dm > 0.f && db > 0.f);
  CHECK(dm < PoseDistance(a, b) && db < PoseDistance(a, b));
  for (const auto& j : mid) {  // blended rotations stay unit length
    const float len = std::sqrt(j.r.x * j.r.x + j.r.y * j.r.y + j.r.z * j.r.z + j.r.w * j.r.w);
    CHECK_NEAR(len, 1.0, 1e-3);
  }
  // Slerp of identical / opposite-sign quaternions stays valid (shortest path).
  const Quat q{0.f, 0.f, 0.f, 1.f}, nq{0.f, 0.f, 0.f, -1.f};
  const Quat s = Slerp(q, nq, 0.5f);
  CHECK_NEAR(std::sqrt(s.x * s.x + s.y * s.y + s.z * s.z + s.w * s.w), 1.0, 1e-4);
}

TEST(animator_crossfades_finishes_one_shots_and_rejects_unknown_clips) {
  const SkinnedModel m = LoadKael();
  Animator an;
  an.SetModel(&m);
  CHECK(an.Play("idle", true, 0.f));
  an.Update(0.f);
  const Pose idlePose = an.pose();
  CHECK(!an.Play("does_not_exist", true));  // keeps the current animation
  CHECK_EQ(an.current(), std::string("idle"));
  CHECK(an.Play("attack", false, 0.2f));
  an.Update(0.05f);  // mid fade: pose is neither pure idle nor pure attack
  const Pose fading = an.pose();
  CHECK(PoseDistance(fading, idlePose) > 1e-4f);
  CHECK(!an.finished());
  const AnimClip& atk = m.clips[static_cast<std::size_t>(m.FindClip("attack"))];
  for (int i = 0; i < 200 && !an.finished(); ++i) an.Update(0.02f);
  CHECK(an.finished());
  CHECK(an.time() >= atk.duration - 1e-4f);
  // Replaying the same clip without restart does not reset it; with restart it does.
  const float t = an.time();
  an.Play("attack", false, 0.f, false);
  CHECK_NEAR(an.time(), t, 1e-6);
  an.Play("attack", false, 0.f, true);
  CHECK(an.time() < t);
}

TEST(character_visual_loads_with_real_model_and_no_warnings) {
  const CharacterDef& kael = *Db().Character("kael");
  auto v = LoadCharacterVisual(kael, "", kRoot);
  CHECK(!v->usedFallback);
  CHECK(v->error.empty());
  for (const auto& w : v->warnings) std::cerr << "  warning: " << w << "\n";
  CHECK(v->warnings.empty());
  CHECK(v->model.joints.size() == 15);
}

TEST(outfit_material_swap_recolors_the_real_material) {
  const CharacterDef& kael = *Db().Character("kael");
  auto base = LoadCharacterVisual(kael, "", kRoot);
  auto crimson = LoadCharacterVisual(kael, "crimson", kRoot);
  CHECK(!crimson->usedFallback);
  const Color a = base->model.materials[static_cast<std::size_t>(base->model.FindMaterial("coat"))].color;
  const Color b = crimson->model.materials[static_cast<std::size_t>(crimson->model.FindMaterial("coat"))].color;
  CHECK(a.r != b.r || a.g != b.g || a.b != b.b);
  CHECK_EQ(static_cast<int>(b.r), 140);
  CHECK_EQ(static_cast<int>(b.g), 30);
  CHECK_EQ(static_cast<int>(b.b), 52);
  CHECK(crimson->warnings.empty());
  // The rendered mesh actually carries the new color.
  base->TickPreview(kael, 0.016f);
  crimson->TickPreview(kael, 0.016f);
  bool found = false;
  for (const auto& vert : crimson->skinned.vertices)
    if (vert.color.r == 140 && vert.color.g == 30 && vert.color.b == 52) found = true;
  CHECK(found);
}

TEST(outfit_mesh_swap_changes_geometry_but_keeps_animations) {
  const CharacterDef& kael = *Db().Character("kael");
  auto base = LoadCharacterVisual(kael, "", kRoot);
  auto armored = LoadCharacterVisual(kael, "armored", kRoot);
  CHECK(!armored->usedFallback);
  for (const auto& w : armored->warnings) std::cerr << "  warning: " << w << "\n";
  CHECK(armored->warnings.empty());
  CHECK(armored->model.vertices.size() != base->model.vertices.size() ||
        armored->model.indices.size() != base->model.indices.size());
  CHECK(armored->model.FindClip("attack") >= 0);  // clips stay with the character
  CHECK(SameSkeleton(base->model, armored->model));
}

TEST(unknown_outfit_and_bad_assets_fail_loudly_not_silently) {
  const CharacterDef& kael = *Db().Character("kael");
  auto bad = LoadCharacterVisual(kael, "no_such_outfit", kRoot);
  CHECK(!bad->usedFallback);
  CHECK(!bad->warnings.empty());  // reported, and the default outfit is used
  CharacterDef missing = kael;
  missing.modelPath = "models/does_not_exist.glb";
  auto v = LoadCharacterVisual(missing, "", kRoot);
  CHECK(v->usedFallback);
  CHECK(!v->placeholderByDesign);
  CHECK(!v->error.empty());
  CharacterDef builtin = kael;
  builtin.modelPath = "builtin:humanoid_placeholder";
  auto p = LoadCharacterVisual(builtin, "", kRoot);
  CHECK(p->usedFallback && p->placeholderByDesign && p->error.empty());
}

TEST(corrupt_glb_files_are_rejected_without_crashing) {
  const std::vector<unsigned char> good = ReadAll(kRoot + "/models/kael.glb");
  CHECK(good.size() > 1000);
  CHECK(ParseGlb(good.data(), good.size(), "good").ok());
  CHECK(!ParseGlb(nullptr, 0, "empty").ok());
  CHECK(!ParseGlb(good.data(), 8, "tiny").ok());
  std::vector<unsigned char> badMagic = good;
  badMagic[0] = 'X';
  CHECK(!ParseGlb(badMagic.data(), badMagic.size(), "magic").ok());
  for (std::size_t cut : {good.size() / 2, good.size() - 1, std::size_t{40}}) {
    const auto r = ParseGlb(good.data(), cut, "truncated");
    CHECK(!r.ok());
    CHECK(!r.status.message.empty());
  }
  // Deterministic byte-flip fuzzing: must never crash or hang; an accepted result must still validate.
  std::uint64_t s = 0x1234567;
  int accepted = 0;
  for (int i = 0; i < 300; ++i) {
    std::vector<unsigned char> d = good;
    for (int k = 0; k < 4; ++k) {
      s = s * 6364136223846793005ull + 1442695040888963407ull;
      d[static_cast<std::size_t>((s >> 33) % d.size())] = static_cast<unsigned char>(s >> 20);
    }
    const auto r = ParseGlb(d.data(), d.size(), "fuzz");
    if (r.ok()) {
      ++accepted;
      CHECK(ValidateModel(r.value).empty());
    }
  }
  CHECK(accepted < 300);  // at least some mutations are caught
}

TEST(glb_limits_are_enforced) {
  const std::vector<unsigned char> good = ReadAll(kRoot + "/models/kael.glb");
  GlbLimits tiny;
  tiny.maxVertices = 10;
  CHECK(!ParseGlb(good.data(), good.size(), "limit", tiny).ok());
  GlbLimits fewJoints;
  fewJoints.maxJoints = 3;
  CHECK(!ParseGlb(good.data(), good.size(), "limit", fewJoints).ok());
  GlbLimits smallFile;
  smallFile.maxFileBytes = 100;
  CHECK(!ParseGlb(good.data(), good.size(), "limit", smallFile).ok());
}

TEST(validate_model_catches_structural_mistakes) {
  SkinnedModel m = LoadKael();
  CHECK(ValidateModel(m).empty());
  SkinnedModel badIndex = m;
  badIndex.indices[0] = static_cast<std::uint32_t>(badIndex.vertices.size() + 5);
  CHECK(!ValidateModel(badIndex).empty());
  SkinnedModel badParent = m;
  badParent.joints[1].parent = 14;  // child before parent
  CHECK(!ValidateModel(badParent).empty());
  SkinnedModel badJoint = m;
  badJoint.vertices[0].joint[0] = 200;
  CHECK(!ValidateModel(badJoint).empty());
  SkinnedModel badTimes = m;
  if (!badTimes.clips.empty() && !badTimes.clips[0].channels.empty() && badTimes.clips[0].channels[0].times.size() > 1)
    std::swap(badTimes.clips[0].channels[0].times[0], badTimes.clips[0].channels[0].times[1]);
  CHECK(!ValidateModel(badTimes).empty());
}

TEST(character_visual_picks_the_clip_for_the_player_state) {
  const CharacterDef& kael = *Db().Character("kael");
  auto v = LoadCharacterVisual(kael, "", kRoot);
  CHECK(!v->usedFallback);
  Player p;
  p.state = PlayerState::Idle;
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("idle"));
  p.state = PlayerState::Run;
  v->Tick(p, kael, 1.0f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("run"));
  v->Tick(p, kael, 0.3f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("walk"));
  p.state = PlayerState::Attack;
  p.stateDuration = 0.4f;
  p.actionSerial += 1;
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("attack"));
  p.state = PlayerState::Dodge;
  p.actionSerial += 1;
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("dodge"));
  p.state = PlayerState::Hurt;
  p.actionSerial += 1;
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("hit"));
  p.state = PlayerState::Dead;
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK_EQ(v->anim.current(), std::string("defeat"));
  CHECK(!v->skinned.vertices.empty());
  CHECK(BoundsOf(v->skinned).finite);
}

TEST(a_new_attack_restarts_the_one_shot_clip) {
  const CharacterDef& kael = *Db().Character("kael");
  auto v = LoadCharacterVisual(kael, "", kRoot);
  Player p;
  p.state = PlayerState::Attack;
  p.stateDuration = 0.35f;
  p.actionSerial = 1;
  for (int i = 0; i < 40; ++i) v->Tick(p, kael, 0.f, 0.02f);  // let the first swing finish
  CHECK(v->anim.finished());
  p.actionSerial = 2;  // next combo step
  v->Tick(p, kael, 0.f, 0.016f);
  CHECK(!v->anim.finished());
  CHECK(v->anim.time() < 0.1f);
}

TEST(misaligned_accessor_data_is_rejected_before_it_is_read) {
  // Regression: a byte-flipped GLB made cgltf load a float from a misaligned address (found by ASan/UBSan).
  // Moving the float position view from offset 960 to 961 must be refused, not read.
  std::vector<unsigned char> d = ReadAll(kRoot + "/models/kael.glb");
  const std::string needle = "\"byteOffset\":960";
  const auto it = std::search(d.begin(), d.end(), needle.begin(), needle.end());
  CHECK(it != d.end());
  if (it == d.end()) return;
  *(it + static_cast<std::ptrdiff_t>(needle.size()) - 1) = '1';  // 961
  const auto r = ParseGlb(d.data(), d.size(), "misaligned");
  CHECK(!r.ok());
  CHECK(r.status.message.find("aligned") != std::string::npos);
}
