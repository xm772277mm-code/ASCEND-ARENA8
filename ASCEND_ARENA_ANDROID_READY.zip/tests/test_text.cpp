// Text pipeline tests: UTF-8, Arabic shaping, bidi order, font loading and drawing.
#include "../engine/text/text_renderer.h"
#include "../engine/text/text_shaping.h"
#include "test_framework.h"

using namespace ascend;

namespace {
CodePoints Shape(const std::string& s) { return ShapeArabic(DecodeUtf8(s)); }
}  // namespace

TEST(utf8_roundtrip_and_invalid_bytes) {
  const std::string s = "A\xD8\xB3\xE2\x82\xAC\xF0\x9F\x98\x80";  // A, Arabic seen, euro, emoji
  const CodePoints c = DecodeUtf8(s);
  CHECK_EQ(c.size(), static_cast<std::size_t>(4));
  CHECK_EQ(c[1], 0x0633u);
  CHECK_EQ(EncodeUtf8(c), s);
  const CodePoints bad = DecodeUtf8(std::string("a\xFF\xC3", 3));  // invalid lead byte, truncated sequence
  CHECK_EQ(bad.size(), static_cast<std::size_t>(3));
  CHECK_EQ(bad[1], 0xFFFDu);
  CHECK_EQ(bad[2], 0xFFFDu);
  CHECK_EQ(DecodeUtf8(std::string("\xC0\x80")).front(), 0xFFFDu);  // overlong encoding rejected
}

TEST(arabic_shaping_joins_letters) {
  // Muhammad: meem(initial) hah(medial) meem(medial) dal(final)
  const CodePoints m = Shape("\xD9\x85\xD8\xAD\xD9\x85\xD8\xAF");
  CHECK_EQ(m.size(), static_cast<std::size_t>(4));
  CHECK_EQ(m[0], 0xFEE3u);
  CHECK_EQ(m[1], 0xFEA4u);
  CHECK_EQ(m[2], 0xFEE4u);
  CHECK_EQ(m[3], 0xFEAAu);
  // Kitab: kaf(initial) teh(medial) alef(final) beh(isolated: alef does not join forward)
  const CodePoints k = Shape("\xD9\x83\xD8\xAA\xD8\xA7\xD8\xA8");
  CHECK_EQ(k[0], 0xFEDBu);
  CHECK_EQ(k[1], 0xFE98u);
  CHECK_EQ(k[2], 0xFE8Eu);
  CHECK_EQ(k[3], 0xFE8Fu);
  // A lone letter is isolated; Latin text is untouched.
  CHECK_EQ(Shape("\xD8\xA8")[0], 0xFE8Fu);
  CHECK(Shape("abc") == DecodeUtf8("abc"));
}

TEST(arabic_lam_alef_ligature) {
  // salam: seen(initial) + lam-alef(final ligature) + meem(isolated)
  const CodePoints s = Shape("\xD8\xB3\xD9\x84\xD8\xA7\xD9\x85");
  CHECK_EQ(s.size(), static_cast<std::size_t>(3));
  CHECK_EQ(s[0], 0xFEB3u);
  CHECK_EQ(s[1], 0xFEFCu);
  CHECK_EQ(s[2], 0xFEE1u);
  // Standalone lam-alef is the isolated ligature.
  CHECK_EQ(Shape("\xD9\x84\xD8\xA7")[0], 0xFEFBu);
}

TEST(arabic_diacritics_do_not_break_joining) {
  // beh + fatha + teh: the mark is transparent so beh is still initial and teh final.
  const CodePoints s = Shape("\xD8\xA8\xD9\x8E\xD8\xAA");
  CHECK_EQ(s.size(), static_cast<std::size_t>(3));
  CHECK_EQ(s[0], 0xFE91u);
  CHECK_EQ(s[1], 0x064Eu);
  CHECK_EQ(s[2], 0xFE96u);
}

TEST(bidi_reverses_rtl_and_keeps_numbers) {
  // Logical "ABC" in an RTL paragraph with Arabic: visual order puts the number to the left.
  const CodePoints v = PrepareForDisplay("\xD8\xA7\xD9\x84 5", 1);  // alef, lam, space, 5 (logical)
  CHECK_EQ(v.size(), static_cast<std::size_t>(4));
  CHECK_EQ(v.front(), static_cast<std::uint32_t>('5'));  // number is drawn on the left
  CHECK_EQ(v[2], 0xFEDDu);                               // then lam
  CHECK_EQ(v.back(), 0xFE8Du);                           // alef is the right-most (first read) letter
  // Pure Latin in an LTR paragraph is unchanged.
  CHECK(ReorderBidi(DecodeUtf8("Level 12"), 0) == DecodeUtf8("Level 12"));
  // Brackets are mirrored inside RTL runs.
  const CodePoints b = ReorderBidi(DecodeUtf8("\xD8\xA8(\xD8\xAA)"), 1);
  CHECK(b.size() == 4);
  // Direction auto-detection.
  CHECK(ContainsRtl("\xD8\xA8"));
  CHECK(!ContainsRtl("hello 123"));
  CHECK(ReorderBidi({}, 1).empty());
}

TEST(font_loads_and_measures_and_draws) {
  TextRenderer tr;
  const Status bad = tr.LoadFont(std::string(ASCEND_SOURCE_DIR) + "/content/fonts/does_not_exist.ttf");
  CHECK(!bad.ok);
  CHECK(!tr.HasFont());
  const Status ok = tr.LoadFont(std::string(ASCEND_SOURCE_DIR) + "/content/fonts/DejaVuSans.ttf");
  CHECK(ok.ok);
  if (!ok.ok) return;
  CHECK(tr.CoversText("Hello World 0123456789"));
  CHECK(tr.CoversText("\xD8\xA7\xD9\x84\xD9\x85\xD8\xB3\xD8\xAA\xD9\x88\xD9\x89"));  // al-mustawa
  CHECK(tr.Measure("WWWW", 24) > tr.Measure("iiii", 24));
  CHECK(tr.Measure("Hello", 48) > tr.Measure("Hello", 24) * 1.8f);
  Framebuffer fb(200, 60);
  fb.ClearGradient({0, 0, 0, 255}, {0, 0, 0, 255});
  const float w = tr.Draw(fb, 10.f, 10.f, "Test", 32, {255, 255, 255, 255});
  CHECK(w > 40.f);
  int lit = 0;
  for (int y = 0; y < 60; ++y)
    for (int x = 0; x < 200; ++x)
      if ((fb.Get(x, y) & 0xFF) > 128) ++lit;
  CHECK(lit > 100);  // glyphs were really rasterized
  // Drawing partly or fully outside the framebuffer must not crash.
  tr.Draw(fb, -500.f, -500.f, "off", 40, {255, 255, 255, 255});
  tr.Draw(fb, 5000.f, 5000.f, "off", 40, {255, 255, 255, 255});
}

TEST(text_wrap_respects_width) {
  TextRenderer tr;
  CHECK(tr.LoadFont(std::string(ASCEND_SOURCE_DIR) + "/content/fonts/DejaVuSans.ttf").ok);
  const auto lines = tr.Wrap("the quick brown fox jumps over the lazy dog", 20, 150.f);
  CHECK(lines.size() >= 3);
  for (const auto& l : lines) CHECK(tr.Measure(l, 20) <= 150.f || l.find(' ') == std::string::npos);
  CHECK_EQ(tr.Wrap("", 20, 100.f).size(), static_cast<std::size_t>(1));
}
