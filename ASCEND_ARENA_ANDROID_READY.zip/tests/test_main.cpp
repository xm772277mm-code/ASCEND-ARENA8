#include <cstring>

#include "test_framework.h"

int main(int argc, char** argv) {
  const char* filter = argc > 1 ? argv[1] : nullptr;
  int run = 0, failed = 0;
  for (const auto& t : ascend_test::Registry()) {
    if (filter && t.name.find(filter) == std::string::npos) continue;
    const int before = ascend_test::FailureCount();
    t.fn();
    ++run;
    if (ascend_test::FailureCount() != before) {
      ++failed;
      std::cout << "[FAIL] " << t.name << "\n";
    } else {
      std::cout << "[ ok ] " << t.name << "\n";
    }
  }
  std::cout << run << " tests run, " << failed << " failed, " << ascend_test::FailureCount() << " check failures\n";
  return failed == 0 ? 0 : 1;
}
