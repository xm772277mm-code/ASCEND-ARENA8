// Validator tests: the shipped content must be valid, and deliberately broken copies must be rejected.
#include <filesystem>
#include <fstream>

#include "../tools/validator.h"
#include "test_framework.h"

using namespace ascend;
namespace fs = std::filesystem;

namespace {

std::string Root() { return std::string(ASCEND_SOURCE_DIR) + "/content"; }

// Copies the real content into a fresh temp directory so a test can break one thing at a time.
fs::path CloneContent(const char* tag) {
  const fs::path dst = fs::temp_directory_path() / (std::string("ascend_validate_") + tag);
  std::error_code ec;
  fs::remove_all(dst, ec);
  fs::copy(Root(), dst, fs::copy_options::recursive, ec);
  CHECK(!ec);
  return dst;
}

void Overwrite(const fs::path& p, const std::string& text) {
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  f << text;
}

std::string Slurp(const fs::path& p) {
  std::ifstream f(p, std::ios::binary);
  return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}

bool HasError(const ValidationReport& r, const std::string& needle) {
  for (const auto& i : r.issues)
    if (i.severity == ValidationIssue::Severity::Error &&
        (i.message.find(needle) != std::string::npos || i.where.find(needle) != std::string::npos))
      return true;
  return false;
}

ValidationReport Run(const fs::path& root) {
  ValidatorOptions o;
  o.contentRoot = root.string();
  o.sourceRoots = {std::string(ASCEND_SOURCE_DIR) + "/ui", std::string(ASCEND_SOURCE_DIR) + "/game"};
  return ValidateContent(o);
}

}  // namespace

TEST(validator_accepts_shipped_content) {
  const auto r = Run(Root());
  for (const auto& i : r.issues) std::cerr << "  issue: " << i.where << ": " << i.message << "\n";
  CHECK_EQ(r.Errors(), 0);
}

TEST(validator_rejects_missing_content_dir) {
  ValidatorOptions o;
  o.contentRoot = "/nonexistent/ascend_content";
  CHECK(ValidateContent(o).Errors() > 0);
}

TEST(validator_flags_missing_model_file) {
  const auto d = CloneContent("model");
  fs::remove(d / "models/mira.glb");
  const auto r = Run(d);
  CHECK(HasError(r, "model file missing"));
}

TEST(validator_flags_corrupt_model) {
  const auto d = CloneContent("corrupt");
  Overwrite(d / "models/mira.glb", "this is not a glb file");
  CHECK(HasError(Run(d), "model does not load"));
}

TEST(validator_flags_missing_license_metadata) {
  const auto d = CloneContent("license");
  std::string t = Slurp(d / "characters/mira.ini");
  const auto p = t.find("asset_license");
  CHECK(p != std::string::npos);
  t.erase(p, t.find('\n', p) - p + 1);
  Overwrite(d / "characters/mira.ini", t);
  CHECK(HasError(Run(d), "asset_license"));
}

TEST(validator_flags_asset_without_catalog_row) {
  const auto d = CloneContent("catalog");
  std::string csv = Slurp(d / "ASSET_CATALOG.csv");
  const auto p = csv.find("models/mira.glb");
  csv.erase(p, csv.find('\n', p) - p + 1);
  Overwrite(d / "ASSET_CATALOG.csv", csv);
  CHECK(HasError(Run(d), "no license row for shipped asset models/mira.glb"));
}

TEST(validator_flags_duplicate_ids_and_bad_references) {
  const auto d = CloneContent("dup");
  std::string items = Slurp(d / "data/items.ini");
  Overwrite(d / "data/items.ini",
            items + "\n[potion_small]\nname_key = item.potion_small\nslot = consumable\nstack = 5\n");
  CHECK(HasError(Run(d), "potion_small"));
  const auto e = CloneContent("ref");
  std::string en = Slurp(e / "data/enemies.ini");
  const auto p = en.find("soul_shard:60");
  CHECK(p != std::string::npos);
  en.replace(p, 13, "ghost_item:60");
  Overwrite(e / "data/enemies.ini", en);
  CHECK(HasError(Run(e), "ghost_item"));
}

TEST(validator_flags_localization_problems) {
  const auto d = CloneContent("loc");
  std::string ar = Slurp(d / "localization/ar.ini");
  const auto p = ar.find("ui.play =");
  CHECK(p != std::string::npos);
  ar.erase(p, ar.find('\n', p) - p + 1);  // missing key
  ar += "\napp.version = الإصدار\n";      // placeholder dropped (also a duplicate key)
  Overwrite(d / "localization/ar.ini", ar);
  const auto r = Run(d);
  CHECK(r.Errors() > 0);  // duplicate key is rejected by the INI parser
  // Missing key only:
  const auto e = CloneContent("loc2");
  std::string ar2 = Slurp(e / "localization/ar.ini");
  const auto q = ar2.find("ui.play =");
  ar2.erase(q, ar2.find('\n', q) - q + 1);
  Overwrite(e / "localization/ar.ini", ar2);
  CHECK(HasError(Run(e), "missing key 'ui.play'"));
  // Changed placeholders:
  const auto f = CloneContent("loc3");
  std::string ar3 = Slurp(f / "localization/ar.ini");
  const auto s = ar3.find("app.version = ");
  ar3.replace(s, ar3.find('\n', s) - s, "app.version = الإصدار {0} {1}");
  Overwrite(f / "localization/ar.ini", ar3);
  CHECK(HasError(Run(f), "different {placeholders}"));
}

TEST(validator_flags_unknown_ui_key_used_in_source) {
  const auto d = CloneContent("uikey");
  std::string en = Slurp(d / "localization/en.ini");
  const auto p = en.find("ui.settings =");
  CHECK(p != std::string::npos);
  en.erase(p, en.find('\n', p) - p + 1);
  Overwrite(d / "localization/en.ini", en);
  std::string ar = Slurp(d / "localization/ar.ini");
  const auto q = ar.find("ui.settings =");
  ar.erase(q, ar.find('\n', q) - q + 1);
  Overwrite(d / "localization/ar.ini", ar);
  CHECK(HasError(Run(d), "localization key 'ui.settings' missing"));
}
