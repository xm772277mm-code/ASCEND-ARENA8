// Progression, inventory, rewards and save/load tests.
#include <filesystem>
#include <fstream>

#include "../gameplay/progression/save.h"
#include "test_framework.h"

using namespace ascend;
namespace fs = std::filesystem;

namespace {
const ContentDb& Db() {
  static ContentDb db;
  static bool loaded = false;
  if (!loaded) {
    loaded = true;
    CHECK(db.LoadFromDirectory(std::string(ASCEND_SOURCE_DIR) + "/content").empty());
  }
  return db;
}
std::string TempPath(const std::string& name) {
  const fs::path dir = fs::temp_directory_path() / "ascend_tests";
  fs::create_directories(dir);
  const fs::path p = dir / name;
  std::error_code ec;
  for (const char* ext : {"", ".tmp", ".bak", ".corrupt"}) fs::remove(p.string() + ext, ec);
  return p.string();
}
void WriteText(const std::string& path, const std::string& t) {
  std::ofstream f(path, std::ios::binary | std::ios::trunc);
  f << t;
}
std::string ReadText(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  return {std::istreambuf_iterator<char>(f), {}};
}
}  // namespace

TEST(xp_curve_increases_and_levels_up) {
  for (int l = 1; l < kMaxLevel; ++l) CHECK(XpToNext(l + 1) > XpToNext(l));
  Profile p;
  CHECK_EQ(AddXp(p, XpToNext(1) - 1), 0);
  CHECK_EQ(p.level, 1);
  CHECK_EQ(AddXp(p, 1), 1);
  CHECK_EQ(p.level, 2);
  CHECK_EQ(p.xp, 0);
}

TEST(xp_multi_level_and_cap) {
  Profile p;
  const int gained = AddXp(p, XpToNext(1) + XpToNext(2) + XpToNext(3) + 5);
  CHECK_EQ(gained, 3);
  CHECK_EQ(p.level, 4);
  CHECK_EQ(p.xp, 5);
  AddXp(p, 2000000000);
  CHECK_EQ(p.level, kMaxLevel);
  CHECK_EQ(p.xp, 0);
  CHECK_EQ(AddXp(p, 100), 0);
  CHECK_EQ(AddXp(p, -50), 0);
}

TEST(gold_is_bounded_and_spend_is_checked) {
  Profile p;
  CHECK_EQ(AddGold(p, kMaxGold + 500), kMaxGold);
  CHECK_EQ(AddGold(p, 10), 0);
  CHECK(!SpendGold(p, kMaxGold + 1));
  CHECK(SpendGold(p, 100));
  CHECK_EQ(p.gold, kMaxGold - 100);
  CHECK(!SpendGold(p, -5));
}

TEST(inventory_stacks_and_slot_limit) {
  Profile p;
  CHECK_EQ(AddItem(Db(), p, "potion_small", 25), 25);  // stack max 20 -> 2 stacks
  CHECK_EQ(p.inventory.size(), static_cast<std::size_t>(2));
  CHECK_EQ(CountItem(p, "potion_small"), 25);
  CHECK_EQ(AddItem(Db(), p, "nope", 1), 0);
  CHECK_EQ(AddItem(Db(), p, "soul_shard", 0), 0);
  Profile q;
  for (int i = 0; i < kInventorySlots; ++i) CHECK_EQ(AddItem(Db(), q, "iron_sword", 1), 1);  // equipment never stacks
  CHECK_EQ(AddItem(Db(), q, "iron_sword", 1), 0);                                            // full
  CHECK_EQ(AddItem(Db(), q, "iron_sword", 1), 0);
  CHECK_EQ(RemoveItem(q, "iron_sword", 3), 3);
  CHECK_EQ(static_cast<int>(q.inventory.size()), kInventorySlots - 3);
  CHECK_EQ(RemoveItem(q, "iron_sword", 1000), kInventorySlots - 3);
  CHECK(q.inventory.empty());
}

TEST(equip_swaps_and_respects_rules) {
  Profile p;
  CHECK(Equip(Db(), p, "iron_sword") == EquipResult::NotOwned);
  AddItem(Db(), p, "iron_sword", 1);
  AddItem(Db(), p, "shadow_blade", 1);
  AddItem(Db(), p, "potion_small", 1);
  CHECK(Equip(Db(), p, "potion_small") == EquipResult::NotEquippable);
  CHECK(Equip(Db(), p, "ghost") == EquipResult::UnknownItem);
  CHECK(Equip(Db(), p, "iron_sword") == EquipResult::Ok);
  CHECK_EQ(p.equipment["weapon"], std::string("iron_sword"));
  CHECK_EQ(CountItem(p, "iron_sword"), 0);
  CHECK(Equip(Db(), p, "shadow_blade") == EquipResult::Ok);  // old weapon returns to the bag
  CHECK_EQ(CountItem(p, "iron_sword"), 1);
  CHECK_EQ(BonusFor(Db(), p).attack, 14);
  CHECK(Unequip(Db(), p, "weapon"));
  CHECK_EQ(BonusFor(Db(), p).attack, 0);
  CHECK(!Unequip(Db(), p, "weapon"));
}

TEST(equipment_bonus_changes_loadout_stats) {
  Profile p;
  const int base = LoadoutFor(Db(), p).stats.attack;
  AddItem(Db(), p, "iron_sword", 1);
  Equip(Db(), p, "iron_sword");
  CHECK_EQ(LoadoutFor(Db(), p).stats.attack, base + 6);
}

TEST(consumable_heals_once_per_item) {
  Profile p;
  AddItem(Db(), p, "potion_small", 1);
  CHECK_EQ(UseConsumable(Db(), p, "potion_small"), 60);
  CHECK_EQ(UseConsumable(Db(), p, "potion_small"), 0);  // none left
  CHECK_EQ(UseConsumable(Db(), p, "soul_shard"), 0);
}

TEST(overflow_items_are_sold_not_lost_silently) {
  Profile p;
  for (int i = 0; i < kInventorySlots; ++i) AddItem(Db(), p, "iron_sword", 1);
  Reward r;
  r.items.push_back({"shadow_blade", 1});
  const GrantResult g = GrantReward(Db(), p, r);
  CHECK(g.itemsGranted.empty());
  CHECK_EQ(g.overflowGold, 400);
  CHECK_EQ(p.gold, 400);
}

TEST(one_time_rewards_cannot_be_claimed_twice) {
  Profile p;
  Reward r;
  r.xp = 50;
  r.gold = 100;
  CHECK(ClaimOnce(Db(), p, "first_clear:m1", r));
  CHECK(!ClaimOnce(Db(), p, "first_clear:m1", r));
  CHECK_EQ(p.gold, 100);
  CHECK_EQ(p.xp, 50);
  CHECK(!ClaimOnce(Db(), p, "", r));
}

TEST(run_result_applies_exactly_once) {
  Profile p;
  Reward r;
  r.gold = 40;
  CHECK(ApplyRun(Db(), p, 1, r));
  CHECK(!ApplyRun(Db(), p, 1, r));
  CHECK(!ApplyRun(Db(), p, 0, r));
  CHECK(ApplyRun(Db(), p, 2, r));
  CHECK_EQ(p.gold, 80);
}

TEST(kill_reward_scales_with_level_gap) {
  GameEvent ev;
  ev.type = EventType::EnemyDefeated;
  ev.refId = "wisp_grunt";
  ev.amount = 18;
  ev.level = 1;
  ev.drops.push_back({"soul_shard", 1});
  Profile low;
  const GrantResult a = ApplyKill(Db(), low, ev);
  CHECK_EQ(low.xp, 18);
  CHECK_EQ(low.gold, 6);
  CHECK_EQ(a.itemsGranted.size(), static_cast<std::size_t>(1));
  Profile high;
  high.level = 20;
  ApplyKill(Db(), high, ev);
  CHECK(high.xp < 18);  // farming low-level enemies is penalized
}

TEST(validate_and_sanitize) {
  Profile p;
  CHECK(Validate(Db(), p).empty());
  p.level = 999;
  p.gold = -5;
  p.characterId = "ghost";
  p.inventory.push_back({"unknown_item", 3});
  p.inventory.push_back({"potion_small", 500});
  p.equipment["weapon"] = "leather_armor";  // wrong slot
  p.settings.sensitivity = 9000;
  CHECK(Validate(Db(), p).size() >= 5);
  const auto changed = Sanitize(Db(), p);
  CHECK(!changed.empty());
  CHECK(Validate(Db(), p).empty());
  CHECK_EQ(p.level, kMaxLevel);
  CHECK_EQ(p.settings.sensitivity, 200);
  CHECK_EQ(p.inventory.size(), static_cast<std::size_t>(1));
  CHECK_EQ(p.inventory[0].count, 20);
}

TEST(save_roundtrip_preserves_everything) {
  Profile p;
  p.name = "Aya";
  p.level = 7;
  p.xp = 33;
  p.gold = 1234;
  p.storyChapter = 3;
  p.dungeonBestRoom = 4;
  p.lastRunId = 9;
  AddItem(Db(), p, "potion_small", 5);
  AddItem(Db(), p, "iron_sword", 1);
  Equip(Db(), p, "iron_sword");
  p.claimedRewards = {"a", "b"};
  p.completedMissions = {"m1"};
  p.missionBestScore["m1"] = 777;
  p.settings.language = "ar";
  p.settings.invertY = true;
  p.settings.textScale = 1.25f;
  const ParseResult r = DeserializeProfile(SerializeProfile(p));
  CHECK(r.ok);
  CHECK_EQ(r.profile.name, std::string("Aya"));
  CHECK_EQ(r.profile.level, 7);
  CHECK_EQ(r.profile.gold, 1234);
  CHECK_EQ(r.profile.inventory.size(), p.inventory.size());
  CHECK_EQ(r.profile.equipment.at("weapon"), std::string("iron_sword"));
  CHECK(r.profile.claimedRewards == p.claimedRewards);
  CHECK_EQ(r.profile.missionBestScore.at("m1"), 777);
  CHECK_EQ(r.profile.settings.language, std::string("ar"));
  CHECK(r.profile.settings.invertY);
  CHECK_NEAR(r.profile.settings.textScale, 1.25, 1e-3);
  CHECK_EQ(r.profile.lastRunId, 9L);
}

TEST(inventory_order_survives_roundtrip_past_ten_stacks) {
  Profile p;
  for (int i = 0; i < 12; ++i) AddItem(Db(), p, i % 2 ? "iron_sword" : "leather_armor", 1);
  AddItem(Db(), p, "soul_shard", 3);
  const ParseResult r = DeserializeProfile(SerializeProfile(p));
  CHECK(r.ok);
  CHECK_EQ(r.profile.inventory.size(), p.inventory.size());
  for (std::size_t i = 0; i < p.inventory.size(); ++i) CHECK_EQ(r.profile.inventory[i].id, p.inventory[i].id);
}

TEST(save_detects_tampering_and_truncation) {
  Profile p;
  p.gold = 10;
  std::string t = SerializeProfile(p);
  std::string cheat = t;
  cheat.replace(cheat.find("gold=10"), 7, "gold=99");
  CHECK(!DeserializeProfile(cheat).ok);
  CHECK(!DeserializeProfile(t.substr(0, t.size() / 2)).ok);
  CHECK(!DeserializeProfile("").ok);
  CHECK(!DeserializeProfile("garbage\nversion=2\n").ok);
  CHECK(!DeserializeProfile("ASCEND_SAVE\nversion=2\nlevel=abc\n").ok);
  CHECK(!DeserializeProfile("ASCEND_SAVE\nversion=2\nlevel=1\nlevel=2\n").ok);
}

TEST(save_migrates_version_1) {
  const std::string v1 =
      "ASCEND_SAVE\nversion=1\nname=Old\ncharacter=kael\nlevel=5\nxp=12\ngold=300\ninv=potion_small:3,soul_shard:9\n";
  const ParseResult r = DeserializeProfile(v1);
  CHECK(r.ok && r.migrated);
  CHECK_EQ(r.profile.version, kSaveVersion);
  CHECK_EQ(r.profile.level, 5);
  CHECK_EQ(CountItem(r.profile, "soul_shard"), 9);
  CHECK_EQ(r.profile.settings.language, std::string("en"));  // new field gets its default
  CHECK(!DeserializeProfile("ASCEND_SAVE\nversion=1\ninv=broken\n").ok);
}

TEST(save_rejects_newer_version) {
  const ParseResult r = DeserializeProfile("ASCEND_SAVE\nversion=99\n");
  CHECK(!r.ok && r.tooNew);
}

TEST(store_save_load_cycle_and_backup) {
  const std::string path = TempPath("cycle.sav");
  SaveStore store(path);
  CHECK(store.Load(Db()).kind == LoadKind::Fresh);
  Profile p;
  p.gold = 50;
  CHECK(store.Save(p));
  CHECK(!fs::exists(path + ".tmp"));  // atomic write leaves no temp file
  p.gold = 75;
  CHECK(store.Save(p));
  CHECK(fs::exists(path + ".bak"));
  const LoadReport rep = store.Load(Db());
  CHECK(rep.kind == LoadKind::Ok);
  CHECK_EQ(rep.profile.gold, 75);
}

TEST(store_recovers_from_corrupt_main_using_backup) {
  const std::string path = TempPath("recover.sav");
  SaveStore store(path);
  Profile p;
  p.gold = 11;
  store.Save(p);
  p.gold = 22;
  store.Save(p);
  WriteText(path, "ASCEND_SAVE\nversion=2\ngold=999999\nchecksum=0000000000000000\n");
  const LoadReport rep = store.Load(Db());
  CHECK(rep.kind == LoadKind::RecoveredFromBackup);
  CHECK_EQ(rep.profile.gold, 11);  // the previous good save
  CHECK(fs::exists(path + ".corrupt"));
}

TEST(store_resets_when_everything_is_corrupt) {
  const std::string path = TempPath("dead.sav");
  WriteText(path, "\x01\x02 not a save");
  SaveStore store(path);
  const LoadReport rep = store.Load(Db());
  CHECK(rep.kind == LoadKind::CorruptReset);
  CHECK_EQ(rep.profile.level, 1);
  CHECK(fs::exists(path + ".corrupt"));
}

TEST(store_never_overwrites_a_newer_save) {
  const std::string path = TempPath("newer.sav");
  WriteText(path, "ASCEND_SAVE\nversion=99\n");
  SaveStore store(path);
  CHECK(store.Load(Db()).kind == LoadKind::TooNew);
  CHECK(!store.Save(Profile{}));
  CHECK_EQ(ReadText(path), std::string("ASCEND_SAVE\nversion=99\n"));
}

TEST(reload_does_not_duplicate_rewards) {
  const std::string path = TempPath("dup.sav");
  SaveStore store(path);
  Profile p;
  Reward r;
  r.gold = 100;
  r.xp = 30;
  CHECK(ApplyRun(Db(), p, 1, r));
  CHECK(ClaimOnce(Db(), p, "first_clear:m1", r));
  CHECK(store.Save(p));
  Profile loaded = store.Load(Db()).profile;  // app restarted
  CHECK(!ApplyRun(Db(), loaded, 1, r));       // same run replayed: ignored
  CHECK(!ClaimOnce(Db(), loaded, "first_clear:m1", r));
  CHECK_EQ(loaded.gold, 200);
}

TEST(loaded_profile_is_sanitized) {
  const std::string path = TempPath("sanitize.sav");
  Profile p;
  p.inventory.push_back({"removed_item", 2});
  p.settings.musicVolume = 5000;
  SaveStore store(path);
  store.Save(p);
  const LoadReport rep = store.Load(Db());
  CHECK(rep.kind == LoadKind::Ok);
  CHECK(!rep.repairs.empty());
  CHECK(Validate(Db(), rep.profile).empty());
}

TEST(characters_unlock_by_level) {
  Profile p;
  CHECK(!p.unlockedCharacters.count("mira"));
  CHECK(SyncUnlocks(Db(), p).empty());  // level 1: nothing new
  p.level = 3;
  const auto added = SyncUnlocks(Db(), p);
  CHECK_EQ(added.size(), static_cast<std::size_t>(1));
  CHECK(p.unlockedCharacters.count("mira") == 1);
  CHECK(SyncUnlocks(Db(), p).empty());  // idempotent
}
