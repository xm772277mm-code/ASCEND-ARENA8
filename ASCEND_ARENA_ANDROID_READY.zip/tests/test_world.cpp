// World simulation tests: movement, collision, combat, cooldowns, dodge, enemy AI, camera, determinism.
#include <cmath>
#include <cstdint>

#include "../gameplay/camera.h"
#include "../gameplay/loadout.h"
#include "../gameplay/world.h"
#include "test_framework.h"

using namespace ascend;

namespace {

const ContentDb& Db() {
  static ContentDb db;
  static bool loaded = false;
  if (!loaded) {
    loaded = true;
    const auto err = db.LoadFromDirectory(std::string(ASCEND_SOURCE_DIR) + "/content");
    for (const auto& e : err) std::cerr << "  content error: " << e << "\n";
    CHECK(err.empty());
  }
  return db;
}

constexpr float kDt = 1.f / 60.f;

struct Fixture {
  World w;
  explicit Fixture(int level = 1, std::uint64_t seed = 7) : w(&Db(), seed) {
    w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), level), {0.f, 0.f, 0.f});
  }
  void Run(float seconds, const InputFrame& in = {}, float camYaw = 0.f) {
    const int n = static_cast<int>(std::lround(seconds / kDt));
    InputFrame held = in;
    for (int i = 0; i < n; ++i) {
      w.Step(held, camYaw, kDt);
      held.attack = held.heavy = held.dodge = held.pause = false;  // presses are one-shot edges
      held.skill = {};
    }
  }
  void Press(InputFrame in) { w.Step(in, 0.f, kDt); }
};

InputFrame Attack() {
  InputFrame f;
  f.attack = true;
  return f;
}

}  // namespace

TEST(content_loads_clean) {
  const ContentDb& db = Db();
  CHECK(db.Character("kael") != nullptr);
  CHECK(db.Skill("shadow_slash") != nullptr);
  CHECK(db.Enemy("wisp_grunt") != nullptr);
  CHECK(db.Enemy("bone_brute")->staggerResist > 0.5f);
  CHECK(db.Enemy("hollow_archer")->ranged);
  CHECK(db.Enemy("training_dummy")->dummy);
  CHECK(db.tuning().dodgeInvuln <= db.tuning().dodgeCooldown);
}

TEST(player_moves_camera_relative) {
  Fixture f;
  InputFrame in;
  in.move = {0.f, 1.f};  // forward
  f.Run(1.0f, in, 0.f);
  CHECK_NEAR(f.w.player().pos.x, 0.0, 0.05);
  CHECK(f.w.player().pos.z > 4.5f);  // ~5.2 m/s for 1 s
  // Camera turned 90 degrees: forward input now moves along +x.
  Fixture g;
  g.Run(1.0f, in, kPi * 0.5f);
  CHECK(g.w.player().pos.x > 4.5f);
  CHECK_NEAR(g.w.player().pos.z, 0.0, 0.1);
}

TEST(player_cannot_leave_arena_or_enter_pillar) {
  Fixture f;
  f.w.SetArena(ArenaDef{10.f, {Aabb2{2.f, 2.f, 4.f, 4.f}}});
  f.w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), 1), {0.f, 0.f, 0.f});
  InputFrame in;
  in.move = {0.f, 1.f};
  f.Run(6.0f, in, 0.f);
  CHECK(f.w.player().pos.z <= 10.f - 0.45f + 1e-3f);
  // Walk diagonally into the pillar from the south-west.
  Fixture g;
  g.w.SetArena(ArenaDef{10.f, {Aabb2{2.f, 2.f, 4.f, 4.f}}});
  g.w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), 1), {3.f, -2.f, 0.f});
  g.Run(3.0f, in, 0.f);
  const Vec3 p = g.w.player().pos;
  const bool inside = p.x > 2.f - 0.44f && p.x < 4.f + 0.44f && p.z > 2.f - 0.44f && p.z < 4.f + 0.44f;
  CHECK(!inside);
}

TEST(light_attack_damages_enemy_in_front_only) {
  Fixture f;
  const int front = f.w.SpawnEnemy("training_dummy", {0.f, 0.f, 1.6f});
  const int behind = f.w.SpawnEnemy("training_dummy", {0.f, 0.f, -1.6f});
  CHECK(front > 0 && behind > 0);
  f.Press(Attack());
  f.Run(0.5f);
  int hpFront = 0, hpBehind = 0;
  for (const auto& e : f.w.enemies()) {
    if (e.uid == front) hpFront = e.hp.cur;
    if (e.uid == behind) hpBehind = e.hp.cur;
  }
  CHECK(hpFront < 500);
  CHECK_EQ(hpBehind, 500);
}

TEST(attack_does_not_hit_through_wall) {
  Fixture f;
  f.w.SetArena(ArenaDef{14.f, {Aabb2{-3.f, 1.f, 3.f, 1.4f}}});  // wall between player and target
  f.w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), 1), {0.f, 0.f, 0.f});
  f.w.SpawnEnemy("training_dummy", {0.f, 0.f, 2.3f});
  f.Press(Attack());
  f.Run(0.5f);
  CHECK_EQ(f.w.enemies()[0].hp.cur, 500);
}

TEST(combo_cycles_and_resets) {
  Fixture f;
  f.w.SpawnEnemy("training_dummy", {0.f, 0.f, 1.5f});
  std::vector<std::string> seen;
  for (int i = 0; i < 4; ++i) {
    f.Press(Attack());
    f.Run(0.7f);
    for (auto& ev : f.w.TakeEvents())
      if (ev.type == EventType::SkillCast) seen.push_back(ev.refId);
  }
  CHECK_EQ(seen.size(), static_cast<std::size_t>(4));
  CHECK_EQ(seen[0], std::string("light_1"));
  CHECK_EQ(seen[1], std::string("light_2"));
  CHECK_EQ(seen[2], std::string("light_3"));
  CHECK_EQ(seen[3], std::string("light_1"));  // wraps
  // Waiting past the combo window restarts at step 1.
  f.Run(2.0f);
  f.w.TakeEvents();
  f.Press(Attack());
  f.Run(0.2f);
  std::string first;
  for (auto& ev : f.w.TakeEvents())
    if (ev.type == EventType::SkillCast) first = ev.refId;
  CHECK_EQ(first, std::string("light_1"));
}

TEST(input_buffer_keeps_press_during_recovery) {
  Fixture f;
  f.Press(Attack());
  f.Run(0.1f);
  f.Press(Attack());  // pressed while the first swing is still locked
  f.Run(0.8f);
  int casts = 0;
  for (auto& ev : f.w.TakeEvents()) casts += ev.type == EventType::SkillCast ? 1 : 0;
  CHECK_EQ(casts, 2);
}

TEST(skill_cooldown_mana_and_unlock_level) {
  Fixture f;  // level 1
  const int mana0 = f.w.player().mana.cur;
  InputFrame in;
  in.skill[0] = true;  // shadow_slash: 12 mana, 4 s cooldown
  f.Press(in);
  f.Run(0.1f);
  CHECK(f.w.player().mana.cur < mana0);
  CHECK(!f.w.player().skillCd[0].Ready());
  const int manaAfter = f.w.player().mana.cur;
  f.Run(0.6f);
  f.Press(in);  // still on cooldown: nothing happens
  CHECK(f.w.player().mana.cur >= manaAfter);
  // Skill 2 (blade_storm) needs level 2.
  InputFrame in2;
  in2.skill[1] = true;
  f.Press(in2);
  f.Run(0.2f);
  CHECK(f.w.player().skillCd[1].Ready());
  // At level 2 it works.
  Fixture g(2);
  g.Press(in2);
  g.Run(0.2f);
  CHECK(!g.w.player().skillCd[1].Ready());
}

TEST(skill_blocked_without_mana) {
  Fixture f;
  f.w.mutablePlayer().mana.cur = 5;
  InputFrame in;
  in.skill[0] = true;
  f.Press(in);
  f.Run(0.2f);
  CHECK(f.w.player().skillCd[0].Ready());
  CHECK(f.w.player().mana.cur >= 5);
}

TEST(mana_regenerates_and_is_bounded) {
  Fixture f;
  f.w.mutablePlayer().mana.cur = 0;
  f.Run(5.f);
  CHECK(f.w.player().mana.cur >= 14 && f.w.player().mana.cur <= 16);
  f.Run(60.f);
  CHECK_EQ(f.w.player().mana.cur, f.w.player().mana.max);
}

TEST(dodge_gives_iframes_and_has_cooldown) {
  Fixture f;
  InputFrame d;
  d.dodge = true;
  f.Press(d);
  CHECK(f.w.player().state == PlayerState::Dodge);
  CHECK(f.w.player().invuln > 0.2f);
  f.Run(0.3f);
  CHECK(f.w.player().pos.z > 3.f);  // dodged forward ~3.6 m
  // Cooldown: pressing again too early does nothing.
  f.Press(d);
  CHECK(f.w.player().state != PlayerState::Dodge);
  f.Run(1.0f);
  f.Press(d);
  CHECK(f.w.player().state == PlayerState::Dodge);
}

TEST(enemy_state_machine_approaches_attacks_recovers) {
  Fixture f;
  f.w.SetArena(ArenaDef{14.f, {}});
  const int id = f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 6.f});
  CHECK(id > 0);
  bool sawAlert = false, sawApproach = false, sawAttack = false, sawRecover = false;
  for (int i = 0; i < 60 * 8; ++i) {
    f.w.Step({}, 0.f, kDt);
    for (const auto& e : f.w.enemies()) {
      sawAlert |= e.state == EnemyState::Alert;
      sawApproach |= e.state == EnemyState::Approach;
      sawAttack |= e.state == EnemyState::Attack;
      sawRecover |= e.state == EnemyState::Recover;
    }
  }
  CHECK(sawAlert && sawApproach && sawAttack && sawRecover);
  CHECK(f.w.player().hp.cur < f.w.player().hp.max);  // it actually hit the player
}

TEST(enemy_ignores_player_out_of_detect_range_and_behind_wall) {
  Fixture f;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 13.f});  // detect range 11, distance 13
  f.Run(1.0f);
  CHECK(f.w.enemies()[0].state != EnemyState::Approach);
  Fixture g;
  g.w.SetArena(ArenaDef{14.f, {Aabb2{-6.f, 4.f, 6.f, 4.5f}}});
  g.w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), 1), {0.f, 0.f, 0.f});
  g.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 8.f});  // within range but wall in between
  g.Run(0.5f);
  CHECK(g.w.enemies()[0].state != EnemyState::Alert && g.w.enemies()[0].state != EnemyState::Approach);
}

TEST(archer_keeps_distance_and_fires_projectile) {
  Fixture f;
  f.w.SpawnEnemy("hollow_archer", {0.f, 0.f, 3.f}, 0, true);  // too close: should back away
  f.Run(1.5f);
  CHECK(DistanceXZ(f.w.enemies()[0].pos, f.w.player().pos) > 3.5f);
  bool fired = false;
  for (int i = 0; i < 60 * 6 && !fired; ++i) {
    f.w.Step({}, 0.f, kDt);
    for (auto& ev : f.w.TakeEvents()) fired |= ev.type == EventType::ProjectileFired;
  }
  CHECK(fired);
}

TEST(projectile_blocked_by_wall_and_dodged) {
  Fixture f;
  f.w.SetArena(ArenaDef{14.f, {Aabb2{-2.f, 4.f, 2.f, 4.5f}}});
  f.w.SetPlayer(BuildLoadout(Db(), *Db().Character("kael"), 1), {0.f, 0.f, 0.f});
  f.w.SpawnEnemy("hollow_archer", {0.f, 0.f, 8.f}, 0, true);
  f.Run(6.f);
  CHECK_EQ(f.w.player().hp.cur, f.w.player().hp.max);  // the wall absorbed everything
}

TEST(enemy_strike_is_avoided_by_dodge) {
  Fixture f;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 2.0f}, 0, true);
  // Dodge sideways (camera yaw 0 => +x) as the windup finishes: no damage may be taken.
  bool windup = false;
  for (int i = 0; i < 60 * 3; ++i) {
    InputFrame in;
    const auto& e = f.w.enemies()[0];
    if (e.state == EnemyState::Attack && e.timer < 0.12f) {
      in.dodge = true;
      in.move = {1.f, 0.f};
      windup = true;
    }
    f.w.Step(in, 0.f, kDt);
    if (windup && f.w.enemies()[0].state == EnemyState::Recover) break;
  }
  CHECK(windup);
  CHECK_EQ(f.w.player().hp.cur, f.w.player().hp.max);
}

TEST(invulnerable_player_ignores_a_landed_strike) {
  Fixture f;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 1.2f}, 0, true);
  bool avoided = false;
  for (int i = 0; i < 60 * 3 && !avoided; ++i) {
    f.w.mutablePlayer().invuln = 1.f;  // forced i-frames while the enemy is in reach
    f.w.Step({}, 0.f, kDt);
    for (auto& ev : f.w.TakeEvents()) avoided |= ev.type == EventType::PlayerDodgedHit;
  }
  CHECK(avoided);
  CHECK_EQ(f.w.player().hp.cur, f.w.player().hp.max);
}

TEST(stagger_and_knockback_respect_resistance) {
  Fixture f;
  const int grunt = f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 1.8f}, 0, true);
  const int brute = f.w.SpawnEnemy("bone_brute", {3.f, 0.f, 1.8f}, 0, true);
  // Put the grunt and the brute both in the heavy attack's reach by using the circle skill (level 2).
  Fixture g(2);
  const int a = g.w.SpawnEnemy("wisp_grunt", {1.8f, 0.f, 0.f}, 0, true);
  const int b = g.w.SpawnEnemy("bone_brute", {-1.9f, 0.f, 0.f}, 0, true);
  InputFrame in;
  in.skill[1] = true;  // blade_storm: circle, stagger 0.6, knockback 1.6
  g.Press(in);
  g.Run(0.35f);
  const Enemy *ea = nullptr, *eb = nullptr;
  for (const auto& e : g.w.enemies()) {
    if (e.uid == a) ea = &e;
    if (e.uid == b) eb = &e;
  }
  CHECK(ea && eb);
  CHECK(ea->state == EnemyState::Stagger);
  CHECK(eb->state != EnemyState::Stagger);              // 70% stagger resist: its stagger already ended
  CHECK(DistanceXZ(ea->pos, g.w.player().pos) > 2.8f);  // pushed away by ~1.6 m
  (void)grunt;
  (void)brute;
}

TEST(enemy_defeat_emits_reward_event_once_and_is_cleaned_up) {
  Fixture f;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 1.6f});
  f.w.mutablePlayer().stats.attack = 500;  // one-hit kill
  f.Press(Attack());
  f.Run(0.3f);
  int defeats = 0, xp = 0;
  for (auto& ev : f.w.TakeEvents())
    if (ev.type == EventType::EnemyDefeated) {
      ++defeats;
      xp = ev.amount;
    }
  CHECK_EQ(defeats, 1);
  CHECK_EQ(xp, 18);
  CHECK_EQ(f.w.AliveEnemyCount(), 0);
  f.Run(2.0f);
  CHECK_EQ(f.w.enemies().size(), static_cast<std::size_t>(0));  // removed after the linger time
  CHECK_EQ(f.w.TotalDefeated(), 1);
}

TEST(training_dummy_never_dies_and_heals) {
  Fixture f;
  f.w.SpawnEnemy("training_dummy", {0.f, 0.f, 1.6f});
  f.w.mutablePlayer().stats.attack = 5000;
  f.Press(Attack());
  f.Run(0.4f);
  CHECK_EQ(f.w.AliveEnemyCount(), 1);
  CHECK_EQ(f.w.TotalDefeated(), 0);
  f.Run(3.5f);
  CHECK_EQ(f.w.enemies()[0].hp.cur, f.w.enemies()[0].hp.max);
}

TEST(spawn_limit_and_unknown_enemy_rejected) {
  Fixture f;
  for (int i = 0; i < kMaxEnemiesAlive; ++i)
    CHECK(f.w.SpawnEnemy("training_dummy",
                         {static_cast<float>(i % 8) - 4.f, 0.f, static_cast<float>(i / 8) * 2.f + 5.f}) > 0);
  CHECK_EQ(f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 9.f}), -1);
  CHECK_EQ(f.w.SpawnEnemy("does_not_exist", {0.f, 0.f, 9.f}), -1);
  int rejected = 0;
  for (auto& ev : f.w.TakeEvents()) rejected += ev.type == EventType::SpawnRejected ? 1 : 0;
  CHECK_EQ(rejected, 2);
}

TEST(boss_enrages_below_threshold) {
  Fixture f;
  const int id = f.w.SpawnEnemy("gate_warden", {0.f, 0.f, 2.2f}, 0, true);
  f.w.mutablePlayer().stats.attack = 200;
  bool enraged = false;
  for (int i = 0; i < 12 && !enraged; ++i) {
    f.Press(Attack());
    f.Run(0.6f);
    for (auto& ev : f.w.TakeEvents()) enraged |= ev.type == EventType::EnemyEnraged && ev.actorId == id;
  }
  CHECK(enraged);
}

TEST(player_death_stops_actions) {
  Fixture f;
  f.w.mutablePlayer().hp.cur = 1;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 1.5f}, 0, true);
  f.Run(4.f);
  CHECK(f.w.player().state == PlayerState::Dead);
  CHECK_EQ(f.w.player().hp.cur, 0);
  const Vec3 p = f.w.player().pos;
  InputFrame in;
  in.move = {0.f, 1.f};
  in.attack = true;
  f.Run(1.f, in);
  CHECK_NEAR(f.w.player().pos.z, p.z, 1e-4);
}

TEST(level_override_scales_enemy) {
  Fixture f;
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 8.f}, 1);
  f.w.SpawnEnemy("wisp_grunt", {3.f, 0.f, 8.f}, 6);
  CHECK(f.w.enemies()[1].stats.maxHp > f.w.enemies()[0].stats.maxHp);
}

TEST(simulation_is_deterministic) {
  auto run = [](std::uint64_t seed) {
    Fixture f(1, seed);
    f.w.SpawnEnemy("wisp_grunt", {3.f, 0.f, 6.f}, 0, true);
    f.w.SpawnEnemy("hollow_archer", {-4.f, 0.f, 8.f}, 0, true);
    f.w.SpawnEnemy("wisp_grunt", {12.f, 0.f, 12.f});  // unaware: patrols using the seeded RNG
    double h = 0;
    for (int i = 0; i < 60 * 10; ++i) {
      InputFrame in;
      in.move = {std::sin(static_cast<float>(i) * 0.05f), 0.5f};
      in.attack = (i % 25) == 0;
      f.w.Step(in, 0.3f, kDt);
      h += static_cast<double>(f.w.player().pos.x) * 3.0 + static_cast<double>(f.w.player().pos.z) +
           f.w.player().hp.cur * 0.001;
      for (const auto& e : f.w.enemies()) h += static_cast<double>(e.pos.x) + e.hp.cur;
    }
    return h;
  };
  CHECK_EQ(run(42), run(42));
  CHECK(run(42) != run(43));
}

TEST(headless_bot_clears_a_wave) {
  // A scripted bot (turn toward nearest enemy, close in, attack) must be able to win against
  // 3 grunts at level 3. This is an end-to-end check of movement + combat + AI + rewards.
  Fixture f(3);
  f.w.SpawnEnemy("wisp_grunt", {-5.f, 0.f, 8.f});
  f.w.SpawnEnemy("wisp_grunt", {0.f, 0.f, 9.f});
  f.w.SpawnEnemy("wisp_grunt", {5.f, 0.f, 8.f});
  int xp = 0;
  for (int i = 0; i < 60 * 60 && f.w.AliveEnemyCount() > 0 && f.w.player().Alive(); ++i) {
    InputFrame in;
    const Enemy* tgt = nullptr;
    float best = 1e9f;
    for (const auto& e : f.w.enemies())
      if (e.Alive() && DistanceXZ(e.pos, f.w.player().pos) < best) {
        best = DistanceXZ(e.pos, f.w.player().pos);
        tgt = &e;
      }
    if (tgt) {
      const Vec3 d = NormalizeXZ(tgt->pos - f.w.player().pos);
      if (best > 1.9f) in.move = {d.x, d.z};  // camera yaw 0: x right, y forward == world x,z
      in.attack = best < 2.3f && (i % 12) == 0;
    }
    f.w.Step(in, 0.f, kDt);
    for (auto& ev : f.w.TakeEvents())
      if (ev.type == EventType::EnemyDefeated) xp += ev.amount;
  }
  CHECK_EQ(f.w.AliveEnemyCount(), 0);
  CHECK(f.w.player().Alive());
  CHECK_EQ(xp, 54);
}

TEST(camera_limits_and_collision) {
  OrbitCamera cam;
  cam.ApplyLook({0.f, 10.f});
  CHECK(cam.pitch() <= cam.config().maxPitch + 1e-6f);
  cam.ApplyLook({0.f, -100.f});
  CHECK(cam.pitch() >= cam.config().minPitch - 1e-6f);
  cam.ApplyLook({1000.f, 0.f});
  CHECK(std::fabs(cam.yaw()) <= kPi + 1e-4f);
  cam.SetDistance(1000.f);
  CHECK_NEAR(cam.distance(), cam.config().maxDistance, 1e-5);
  cam.SetDistance(-5.f);
  CHECK_NEAR(cam.distance(), cam.config().minDistance, 1e-5);
  const float y = cam.yaw();
  cam.ApplyLook({std::nanf(""), 1.f});  // corrupt input must be ignored
  CHECK_EQ(cam.yaw(), y);
  // A pillar directly behind the player pulls the camera in.
  ArenaDef arena{14.f, {Aabb2{-1.f, -2.5f, 1.f, -1.5f}}};
  OrbitCamera c2;
  c2.SetDistance(8.f);
  c2.Snap({0.f, 0.f, 0.f});
  Camera out = c2.Update({0.f, 0.f, 0.f}, arena, 0.016f);
  CHECK(c2.effectiveDistance() < 8.f);
  CHECK(out.eye.y >= c2.config().minEyeHeight - 1e-6f);
}

TEST(camera_stays_inside_arena_walls) {
  ArenaDef arena;
  arena.half = 12.f;
  OrbitCamera cam;
  cam.SetYaw(0.f);  // looking toward +z, boom extends toward -z (the south wall)
  const Vec3 spots[] = {
      {0.f, 0.f, -9.f}, {0.f, 0.f, -11.5f}, {-11.5f, 0.f, -11.5f}, {11.5f, 0.f, 11.5f}, {0.f, 0.f, 0.f}};
  for (float yaw : {0.f, 1.2f, 3.0f, -2.2f}) {
    cam.SetYaw(yaw);
    for (const Vec3& p : spots) {
      cam.Snap(p);
      const Camera c = cam.Update(p, arena, 0.016f);
      CHECK(std::fabs(c.eye.x) <= arena.half - 0.3f + 1e-4f);
      CHECK(std::fabs(c.eye.z) <= arena.half - 0.3f + 1e-4f);
      CHECK(c.eye.y >= cam.config().minEyeHeight - 1e-4f);
      CHECK(DistanceXZ(c.eye, p) <= cam.config().maxDistance);
    }
  }
  // In the open middle the full distance is used.
  cam.SetYaw(0.f);
  cam.Snap({0.f, 0.f, 0.f});
  cam.Update({0.f, 0.f, 0.f}, arena, 0.016f);
  CHECK_NEAR(cam.effectiveDistance(), cam.distance(), 1e-4);
}
