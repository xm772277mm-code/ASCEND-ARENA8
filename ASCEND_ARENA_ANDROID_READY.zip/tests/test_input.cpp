// Touch layout and routing tests (virtual joystick, buttons, look drag, multi-touch, lifecycle release).
#include <cmath>

#include "../engine/input/input.h"
#include "test_framework.h"

using namespace ascend;

namespace {
struct Screen {
  float w, h, ppmm;
};
// Typical landscape phones as framebuffer sizes with their physical scale (pixels per mm).
const Screen kScreens[] = {
    {960.f, 540.f, 6.4f}, {640.f, 360.f, 4.3f}, {1280.f, 720.f, 8.5f}, {780.f, 360.f, 4.8f}, {1000.f, 480.f, 6.7f}};

TouchEvent Ev(int id, TouchPhase ph, float x, float y) {
  TouchEvent e;
  e.id = id;
  e.phase = ph;
  e.x = x;
  e.y = y;
  return e;
}
}  // namespace

TEST(touch_layout_buttons_do_not_overlap_and_fit_screen) {
  for (const auto& s : kScreens) {
    const TouchLayout l = TouchLayout::ForScreen(s.w, s.h, s.ppmm);
    for (std::size_t i = 0; i < l.buttons.size(); ++i) {
      const auto& a = l.buttons[i];
      CHECK(a.cx - a.radius >= 0.f && a.cx + a.radius <= s.w);
      CHECK(a.cy - a.radius >= 0.f && a.cy + a.radius <= s.h);
      for (std::size_t j = i + 1; j < l.buttons.size(); ++j) {
        const auto& b = l.buttons[j];
        const float d = std::hypot(a.cx - b.cx, a.cy - b.cy);
        if (d < a.radius + b.radius + 0.5f * s.ppmm) {
          std::cerr << "  overlap " << static_cast<int>(a.action) << "/" << static_cast<int>(b.action) << " at " << s.w
                    << "x" << s.h << "\n";
          CHECK(false);
        }
      }
    }
  }
}

TEST(touch_layout_meets_minimum_target_size) {
  for (const auto& s : kScreens) {
    const TouchLayout l = TouchLayout::ForScreen(s.w, s.h, s.ppmm);
    CHECK(l.MinButtonDiameterMm(s.ppmm) >= 9.f);  // Android guideline is about 9 mm / 48 dp
    CHECK(l.joystickRadius > 0.f && l.joystickZoneMaxX > 0.f);
  }
}

TEST(touch_layout_buttons_stay_outside_joystick_zone) {
  for (const auto& s : kScreens) {
    const TouchLayout l = TouchLayout::ForScreen(s.w, s.h, s.ppmm);
    for (const auto& b : l.buttons) CHECK(b.cx - b.radius > l.joystickZoneMaxX || b.cy < s.h * 0.4f);
  }
}

TEST(joystick_deadzone_scaling_and_release) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  const float R = r.layout().joystickRadius;
  r.OnTouch(Ev(1, TouchPhase::Down, 100.f, 400.f));
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f + 0.05f * R, 400.f));  // inside the deadzone
  CHECK_NEAR(r.Consume().move.x, 0.0, 1e-6);
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - R));  // full drag up on screen = forward
  InputFrame f = r.Consume();
  CHECK_NEAR(f.move.y, 1.0, 1e-4);
  CHECK_NEAR(f.move.x, 0.0, 1e-4);
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - 5.f * R));  // beyond the radius is clamped
  CHECK(r.Consume().move.y <= 1.0001f);
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f + R * 0.6f, 400.f));  // right
  f = r.Consume();
  CHECK(f.move.x > 0.3f && f.move.x < 1.f);
  r.OnTouch(Ev(1, TouchPhase::Up, 100.f, 400.f));
  f = r.Consume();
  CHECK_NEAR(f.move.x, 0.0, 1e-6);
  CHECK_NEAR(f.move.y, 0.0, 1e-6);
}

TEST(button_press_is_a_single_edge) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  const TouchButton* atk = nullptr;
  for (const auto& b : r.layout().buttons)
    if (b.action == ButtonAction::Attack) atk = &b;
  CHECK(atk != nullptr);
  r.OnTouch(Ev(7, TouchPhase::Down, atk->cx, atk->cy));
  CHECK(r.Consume().attack);
  CHECK(!r.Consume().attack);  // held finger does not repeat
  r.OnTouch(Ev(7, TouchPhase::Up, atk->cx, atk->cy));
  r.OnTouch(Ev(7, TouchPhase::Down, atk->cx, atk->cy));
  CHECK(r.Consume().attack);
}

TEST(each_button_maps_to_its_own_action) {
  const Screen s = kScreens[0];
  for (const auto& b : TouchLayout::ForScreen(s.w, s.h, s.ppmm).buttons) {
    TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
    r.OnTouch(Ev(1, TouchPhase::Down, b.cx, b.cy));
    const InputFrame f = r.Consume();
    switch (b.action) {
      case ButtonAction::Attack:
        CHECK(f.attack && !f.heavy && !f.dodge);
        break;
      case ButtonAction::Heavy:
        CHECK(f.heavy && !f.attack);
        break;
      case ButtonAction::Dodge:
        CHECK(f.dodge && !f.attack);
        break;
      case ButtonAction::Skill1:
        CHECK(f.skill[0] && !f.skill[1] && !f.skill[2]);
        break;
      case ButtonAction::Skill2:
        CHECK(f.skill[1] && !f.skill[0] && !f.skill[2]);
        break;
      case ButtonAction::Skill3:
        CHECK(f.skill[2] && !f.skill[0] && !f.skill[1]);
        break;
      case ButtonAction::Pause:
        CHECK(f.pause);
        break;
      case ButtonAction::Potion:
        CHECK(f.potion);
        break;
    }
  }
}

TEST(multitouch_move_and_attack_and_look) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  const float R = r.layout().joystickRadius;
  const TouchButton* atk = nullptr;
  for (const auto& b : r.layout().buttons)
    if (b.action == ButtonAction::Attack) atk = &b;
  r.OnTouch(Ev(1, TouchPhase::Down, 100.f, 400.f));
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - R));
  r.OnTouch(Ev(2, TouchPhase::Down, atk->cx, atk->cy));
  InputFrame f = r.Consume();
  CHECK(f.attack);
  CHECK(f.move.y > 0.9f);  // the stick keeps working while another finger presses
  // A third finger on the right side (no button) rotates the camera.
  r.OnTouch(Ev(3, TouchPhase::Down, s.w * 0.6f, s.h * 0.3f));
  r.OnTouch(Ev(3, TouchPhase::Move, s.w * 0.6f + 40.f, s.h * 0.3f));
  f = r.Consume();
  CHECK(f.lookDelta.x > 0.f);
  CHECK(r.Consume().lookDelta.x == 0.f);  // look delta is consumed once
}

TEST(second_finger_in_stick_zone_does_not_steal_joystick) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  const float R = r.layout().joystickRadius;
  r.OnTouch(Ev(1, TouchPhase::Down, 100.f, 400.f));
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - R));
  r.OnTouch(Ev(2, TouchPhase::Down, 150.f, 300.f));
  r.OnTouch(Ev(2, TouchPhase::Move, 400.f, 100.f));  // would be a huge stick input if it took over
  CHECK(r.Consume().move.y > 0.9f);
  CHECK_NEAR(r.Consume().move.x, 0.0, 1e-3);
}

TEST(release_all_and_cancel_clear_held_input) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  const float R = r.layout().joystickRadius;
  r.OnTouch(Ev(1, TouchPhase::Down, 100.f, 400.f));
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - R));
  r.ReleaseAll();  // app goes to background
  InputFrame f = r.Consume();
  CHECK_NEAR(f.move.y, 0.0, 1e-6);
  r.OnTouch(Ev(1, TouchPhase::Move, 100.f, 400.f - R));  // late event for a released finger is ignored
  CHECK_NEAR(r.Consume().move.y, 0.0, 1e-6);
  r.OnTouch(Ev(2, TouchPhase::Down, 100.f, 400.f));
  r.OnTouch(Ev(2, TouchPhase::Move, 100.f, 400.f - R));
  r.OnTouch(Ev(2, TouchPhase::Cancel, 0.f, 0.f));
  CHECK_NEAR(r.Consume().move.y, 0.0, 1e-6);
}

TEST(joystick_visual_follows_thumb_and_clamps) {
  const Screen s = kScreens[0];
  TouchRouter r(TouchLayout::ForScreen(s.w, s.h, s.ppmm));
  Vec2 base{}, knob{};
  CHECK(!r.JoystickVisual(base, knob));
  const float R = r.layout().joystickRadius;
  r.OnTouch(Ev(1, TouchPhase::Down, 120.f, 380.f));
  r.OnTouch(Ev(1, TouchPhase::Move, 120.f + 3.f * R, 380.f));
  CHECK(r.JoystickVisual(base, knob));
  CHECK_NEAR(base.x, 120.0, 1e-4);
  CHECK_NEAR(knob.x - base.x, R, 1e-3);
}
