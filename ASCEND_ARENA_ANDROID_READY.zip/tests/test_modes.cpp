// Mode flow tests: missions, training, dungeons, story, rewards, unlocks, saving, and level-data validation.
#include <filesystem>

#include "../game/bot.h"
#include "../gameplay/session.h"
#include "test_framework.h"

using namespace ascend;
namespace fs = std::filesystem;

namespace {
struct Env {
  ContentDb db;
  LevelsDb levels;
  Env() {
    const std::string root = std::string(ASCEND_SOURCE_DIR) + "/content";
    const auto e1 = db.LoadFromDirectory(root);
    for (const auto& e : e1) std::cerr << "  content error: " << e << "\n";
    CHECK(e1.empty());
    const auto e2 = levels.LoadFromDirectory(root, db);
    for (const auto& e : e2) std::cerr << "  levels error: " << e << "\n";
    CHECK(e2.empty());
  }
};
Env& E() {
  static Env e;
  return e;
}

constexpr float kDt = 1.f / 60.f;

// Runs the session with the scripted bot. `immortal` keeps the player alive (for flow tests).
void Play(GameSession& s, float maxSeconds, bool immortal, bool superAttack = false) {
  ScriptedBot bot;
  const int n = static_cast<int>(maxSeconds / kDt);
  for (int i = 0; i < n && s.phase() != RunPhase::Finished && s.phase() != RunPhase::OutroDialogue; ++i) {
    if (immortal) s.world().mutablePlayer().hp.cur = s.world().player().hp.max;
    if (superAttack) s.world().mutablePlayer().stats.attack = 400;
    s.Step(bot.Next(s.world(), 0.f), 0.f, kDt);
  }
}

std::string TempSave(const std::string& n) {
  const fs::path d = fs::temp_directory_path() / "ascend_tests";
  fs::create_directories(d);
  std::error_code ec;
  for (const char* x : {"", ".tmp", ".bak", ".corrupt"}) fs::remove(d / n += x, ec);
  return (d / n).string();
}
}  // namespace

TEST(levels_data_is_valid_and_complete) {
  const LevelsDb& l = E().levels;
  CHECK(l.OfKind(ModeKind::Mission).size() >= 3);
  CHECK(l.OfKind(ModeKind::Training).size() >= 1);
  CHECK(l.OfKind(ModeKind::Dungeon).size() >= 1);
  CHECK(l.OfKind(ModeKind::Story).size() >= 3);
  const auto story = l.OfKind(ModeKind::Story);
  for (std::size_t i = 0; i < story.size(); ++i) CHECK_EQ(story[i]->chapter, static_cast<int>(i) + 1);
  // The dungeon has several rooms and ends with a boss.
  const EncounterDef* d = l.Find("catacombs");
  CHECK(d && d->stages.size() >= 3);
  bool boss = false;
  for (const auto& w : d->stages.back().waves)
    for (const auto& s : w) boss |= E().db.Enemy(s.enemyId)->enrageBelowPercent > 0;
  CHECK(boss);
}

TEST(levels_validator_reports_every_kind_of_mistake) {
  const char* bad =
      "[arena.a]\nhalf = 12\npillars = 1:1\n"
      "[mission.x]\nname_key = k\nstage.1.arena = nowhere\nstage.1.waves = ghost:2 | wisp_grunt:99\nreward_items = "
      "nothing:1\n"
      "[mission.y]\nstage.1.arena = a\nstage.1.waves = wisp_grunt:1\nobjective = fly\n"
      "[training.t]\nname_key = k\ndummies = 3\nstage.1.arena = a\nreward_gold = 5\n"
      "[story.s]\nname_key = k\nchapter = 3\nstage.1.arena = a\nstage.1.waves = wisp_grunt:1\n"
      "[dungeon.d]\nname_key = k\nstage.1.arena = a\nstage.1.waves = wisp_grunt:1\n"
      "[blah.z]\nname_key = k\n";
  auto doc = ParseIni(bad, "test");
  CHECK(doc.ok());
  LevelsDb l;
  const auto err = l.LoadFromDoc(doc.value, E().db);
  std::string all;
  for (const auto& e : err) all += e + "\n";
  CHECK(all.find("bad pillar") != std::string::npos);
  CHECK(all.find("unknown arena") != std::string::npos);
  CHECK(all.find("unknown enemy 'ghost'") != std::string::npos);
  CHECK(all.find("count 1..12") != std::string::npos);
  CHECK(all.find("unknown item 'nothing'") != std::string::npos);
  CHECK(all.find("missing name_key") != std::string::npos);
  CHECK(all.find("unknown objective") != std::string::npos);
  CHECK(all.find("training must not give rewards") != std::string::npos);
  CHECK(all.find("story chapters must be 1..N") != std::string::npos);
  CHECK(all.find("at least 2 rooms") != std::string::npos);
  CHECK(all.find("unknown section kind") != std::string::npos);
}

TEST(unlock_rules_are_enforced) {
  Profile p;
  GameSession s(&E().db, &E().levels, &p, nullptr, 1);
  CHECK(s.LockReason("m1_first_blood").empty());
  CHECK(!s.LockReason("m2_archers_nest").empty());  // needs level 2
  CHECK(!s.LockReason("ch2").empty());              // chapter 2 locked
  CHECK(!s.LockReason("nope").empty());
  CHECK(!s.Start("m2_archers_nest").ok);
  p.level = 4;
  p.storyChapter = 2;
  CHECK(s.LockReason("ch2").empty());
  CHECK(!s.LockReason("ch3").empty());  // chapter 3 still locked
}

TEST(mission_victory_grants_rewards_once_and_saves) {
  const std::string path = TempSave("mission.sav");
  SaveStore store(path);
  Profile p;
  p.level = 3;
  GameSession s(&E().db, &E().levels, &p, &store, 5);
  CHECK(s.Start("m1_first_blood").ok);
  Play(s, 120.f, true);
  CHECK(s.finished());
  CHECK(s.summary().outcome == Outcome::Victory);
  CHECK(s.summary().firstClear);
  CHECK(s.summary().kills == 5);
  CHECK(s.summary().saved);
  CHECK(p.completedMissions.count("m1_first_blood") == 1);
  CHECK(CountItem(p, "iron_sword") >= 1);  // first-clear item
  CHECK(p.gold >= 160);                    // 60 run + 100 first clear (+ kill gold)
  const int goldAfterFirst = p.gold;
  // Replaying: repeat reward only, no first-clear duplicate.
  GameSession s2(&E().db, &E().levels, &p, &store, 6);
  CHECK(s2.Start("m1_first_blood").ok);
  Play(s2, 120.f, true);
  CHECK(s2.summary().outcome == Outcome::Victory);
  CHECK(!s2.summary().firstClear);
  CHECK(p.gold < goldAfterFirst + 100 + 40);  // no extra 100 first-clear gold
  // Reloading the save restores progress without granting anything again.
  Profile loaded = store.Load(E().db).profile;
  CHECK(loaded.completedMissions.count("m1_first_blood") == 1);
  CHECK_EQ(loaded.gold, p.gold);
}

TEST(defeat_gives_no_completion_reward) {
  Profile p;
  GameSession s(&E().db, &E().levels, &p, nullptr, 3);
  CHECK(s.Start("m1_first_blood").ok);
  s.world().mutablePlayer().hp.cur = 1;
  s.world().SpawnEnemy("wisp_grunt", {0.f, 0.f, s.world().player().pos.z + 1.5f}, 0, true);
  // Stand still and get killed.
  for (int i = 0; i < 60 * 60 && !s.finished(); ++i) s.Step({}, 0.f, kDt);
  CHECK(s.finished());
  CHECK(s.summary().outcome == Outcome::Defeat);
  CHECK(!p.completedMissions.count("m1_first_blood"));
  CHECK_EQ(CountItem(p, "iron_sword"), 0);
  CHECK(p.claimedRewards.empty());
}

TEST(kill_xp_applies_live_and_levels_up_the_world_player) {
  Profile p;
  GameSession s(&E().db, &E().levels, &p, nullptr, 9);
  CHECK(s.Start("m1_first_blood").ok);
  const int hp0 = s.world().player().hp.max;
  p.xp = XpToNext(1) - 1;  // next kill levels up
  Play(s, 60.f, true, true);
  CHECK(p.level >= 2);
  CHECK(s.world().player().hp.max > hp0);  // loadout refreshed on level-up
  bool sawLevelUp = false;
  for (auto& ev : s.TakeEvents()) sawLevelUp |= ev.type == EventType::LevelUp;
  // Events are drained by the host each frame; here at least the profile reflects it.
  (void)sawLevelUp;
  CHECK(s.summary().levelsGained >= 1);
}

TEST(training_gives_no_rewards_and_never_ends_by_itself) {
  Profile p;
  GameSession s(&E().db, &E().levels, &p, nullptr, 2);
  CHECK(s.Start("basic").ok);
  CHECK_EQ(s.world().AliveEnemyCount(), 3);
  ScriptedBot bot;
  s.world().mutablePlayer().stats.attack = 9999;
  // Hit dummies manually: walk up and attack for a while.
  for (int i = 0; i < 60 * 20; ++i) {
    InputFrame in;
    in.move = {0.f, 1.f};
    in.attack = i % 20 == 0;
    s.Step(in, 0.f, kDt);
  }
  CHECK(!s.finished());
  CHECK_EQ(p.xp, 0);
  CHECK_EQ(p.gold, 0);
  CHECK_EQ(s.world().AliveEnemyCount(), 3);  // dummies cannot die
  // Skills can be tested freely: mana is always full.
  CHECK_EQ(s.world().player().mana.cur, s.world().player().mana.max);
  s.Abandon();
  CHECK(s.summary().outcome == Outcome::Abandoned);
  CHECK(p.completedMissions.empty());
}

TEST(survive_objective_wins_on_timer) {
  Profile p;
  p.level = 5;
  GameSession s(&E().db, &E().levels, &p, nullptr, 4);
  CHECK(s.Start("m3_hold_the_gate").ok);
  Play(s, 90.f, true);
  CHECK(s.finished());
  CHECK(s.summary().outcome == Outcome::Victory);
  CHECK(s.summary().seconds >= 45.f - 0.1f);
  CHECK(s.world().AliveEnemyCount() <= kMaxEnemiesAlive);
}

TEST(time_limit_fails_the_mission) {
  Profile p;
  p.level = 2;
  GameSession s(&E().db, &E().levels, &p, nullptr, 4);
  CHECK(s.Start("m2_archers_nest").ok);
  // Do nothing but stay alive: the 150 s limit must trigger TimeUp.
  for (int i = 0; i < 60 * 170 && !s.finished(); ++i) {
    s.world().mutablePlayer().hp.cur = s.world().player().hp.max;
    s.Step({}, 0.f, kDt);
  }
  CHECK(s.finished());
  CHECK(s.summary().outcome == Outcome::TimeUp);
  CHECK(!p.completedMissions.count("m2_archers_nest"));
}

TEST(dungeon_has_rooms_boss_and_one_time_loot) {
  Profile p;
  p.level = 6;
  GameSession s(&E().db, &E().levels, &p, nullptr, 8);
  CHECK(s.Start("catacombs").ok);
  CHECK_EQ(s.status().stages, 3);
  int maxStage = 0;
  ScriptedBot bot;
  for (int i = 0; i < 60 * 600 && !s.finished() && s.phase() != RunPhase::OutroDialogue; ++i) {
    s.world().mutablePlayer().hp.cur = s.world().player().hp.max;
    s.world().mutablePlayer().stats.attack = 300;
    s.Step(bot.Next(s.world(), 0.f), 0.f, kDt);
    maxStage = std::max(maxStage, s.status().stage);
  }
  CHECK(s.finished());
  CHECK_EQ(maxStage, 3);
  CHECK(s.summary().outcome == Outcome::Victory);
  CHECK_EQ(s.summary().roomsCleared, 3);
  CHECK_EQ(p.dungeonBestRoom, 3);
  CHECK(CountItem(p, "shadow_blade") >= 1);
}

TEST(story_chapters_unlock_in_order_with_dialogue) {
  Profile p;
  p.level = 6;
  GameSession s(&E().db, &E().levels, &p, nullptr, 11);
  CHECK(s.Start("ch1").ok);
  CHECK(s.phase() == RunPhase::IntroDialogue);
  CHECK_EQ(s.dialogueKey(), std::string("story.c1.l1"));
  // The world is frozen during dialogue.
  const double t0 = s.world().time();
  s.Step({}, 0.f, kDt);
  CHECK_EQ(s.world().time(), t0);
  s.AdvanceDialogue();
  s.AdvanceDialogue();
  CHECK(s.phase() == RunPhase::IntroDialogue);
  s.AdvanceDialogue();
  CHECK(s.phase() == RunPhase::Running);
  Play(s, 120.f, true, true);
  CHECK(s.phase() == RunPhase::OutroDialogue);
  CHECK_EQ(s.dialogueKey(), std::string("story.c1.o1"));
  s.AdvanceDialogue();
  CHECK(s.finished());
  CHECK_EQ(p.storyChaptersCleared, 1);
  CHECK_EQ(p.storyChapter, 2);
  GameSession s2(&E().db, &E().levels, &p, nullptr, 12);
  CHECK(s2.Start("ch2").ok);  // now unlocked
  GameSession s3(&E().db, &E().levels, &p, nullptr, 13);
  CHECK(!s3.Start("ch3").ok);  // still locked
}

TEST(pause_freezes_the_run) {
  Profile p;
  GameSession s(&E().db, &E().levels, &p, nullptr, 1);
  CHECK(s.Start("m1_first_blood").ok);
  s.Step({}, 0.f, kDt);
  const double t = s.world().time();
  s.SetPaused(true);
  for (int i = 0; i < 120; ++i) s.Step({}, 0.f, kDt);
  CHECK_EQ(s.world().time(), t);
  s.SetPaused(false);
  s.Step({}, 0.f, kDt);
  CHECK(s.world().time() > t);
}

TEST(result_cannot_be_applied_twice) {
  Profile p;
  p.level = 3;
  GameSession s(&E().db, &E().levels, &p, nullptr, 5);
  CHECK(s.Start("m1_first_blood").ok);
  Play(s, 120.f, true);
  CHECK(s.finished());
  const int gold = p.gold;
  s.Abandon();  // finishing again must be a no-op
  for (int i = 0; i < 100; ++i) s.Step({}, 0.f, kDt);
  CHECK_EQ(p.gold, gold);
  CHECK(s.summary().outcome == Outcome::Victory);
}

TEST(enemy_count_never_exceeds_limit_in_survive) {
  Profile p;
  p.level = 8;
  GameSession s(&E().db, &E().levels, &p, nullptr, 21);
  CHECK(s.Start("m3_hold_the_gate").ok);
  int peak = 0;
  for (int i = 0; i < 60 * 50 && !s.finished(); ++i) {
    s.world().mutablePlayer().hp.cur = s.world().player().hp.max;
    s.Step({}, 0.f, kDt);  // never kills anything
    peak = std::max(peak, s.world().AliveEnemyCount());
  }
  CHECK(peak <= kMaxEnemiesAlive);
}
