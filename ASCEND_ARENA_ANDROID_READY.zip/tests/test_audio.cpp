// Audio tests: synthesized clips (not silent, not clipping, no clicks, deterministic) and the mixer
// (volumes, voice cap, rate limiting, pause, crossfade, limiter, bad input).
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <vector>

#include "../engine/audio/audio.h"
#include "test_framework.h"

using namespace ascend;

namespace {
int Peak(const std::vector<std::int16_t>& s) {
  int p = 0;
  for (auto v : s) p = std::max(p, std::abs(static_cast<int>(v)));
  return p;
}
std::uint64_t Hash(const std::vector<std::int16_t>& s) {
  std::uint64_t h = 1469598103934665603ull;
  for (auto v : s) h = (h ^ static_cast<std::uint16_t>(v)) * 1099511628211ull;
  return h;
}
int StereoPeak(const std::vector<std::int16_t>& s) { return Peak(s); }
std::vector<std::int16_t> MixFrames(Mixer& m, int frames) {
  std::vector<std::int16_t> b(static_cast<std::size_t>(frames) * 2);
  m.Mix(b.data(), frames);
  return b;
}
}  // namespace

TEST(audio_every_sfx_is_audible_unclipped_and_click_free) {
  for (int i = 0; i < static_cast<int>(Sfx::Count); ++i) {
    const Sfx s = static_cast<Sfx>(i);
    const PcmClip& c = SfxClip(s);
    CHECK(c.samples.size() > static_cast<std::size_t>(kAudioRate / 30));  // longer than ~33 ms
    CHECK(c.samples.size() < static_cast<std::size_t>(kAudioRate));       // shorter than 1 s
    const int pk = Peak(c.samples);
    CHECK(pk > 3000);    // audible
    CHECK(pk <= 32000);  // below full scale
    CHECK(std::abs(static_cast<int>(c.samples.front())) < pk / 20 + 1);
    CHECK(std::abs(static_cast<int>(c.samples.back())) < pk / 20 + 1);
    CHECK(std::string(SfxName(s)) != "?");
  }
}

TEST(audio_synthesis_is_deterministic) {
  for (int i = 0; i < static_cast<int>(Sfx::Count); ++i) {
    const PcmClip a = SfxClip(static_cast<Sfx>(i));
    CHECK(Hash(a.samples) == Hash(SfxClip(static_cast<Sfx>(i)).samples));
  }
  CHECK(Hash(SfxClip(Sfx::Hit).samples) != Hash(SfxClip(Sfx::Heavy).samples));
}

TEST(audio_music_loops_are_seamless_quiet_enough_and_distinct) {
  std::uint64_t hashes[3];
  for (int i = 1; i < static_cast<int>(Music::Count); ++i) {
    const PcmClip& c = MusicClip(static_cast<Music>(i));
    CHECK(c.samples.size() > static_cast<std::size_t>(kAudioRate * 10));
    const int pk = Peak(c.samples);
    CHECK(pk > 2000 && pk < 30000);
    // Loop seam: the jump from the last to the first sample is tiny compared with the signal.
    const int jump = std::abs(static_cast<int>(c.samples.back()) - static_cast<int>(c.samples.front()));
    CHECK(jump < 400);
    hashes[i - 1] = Hash(c.samples);
  }
  CHECK(hashes[0] != hashes[1] && hashes[1] != hashes[2]);
  CHECK(MusicClip(Music::None).samples.empty());
}

TEST(mixer_plays_then_goes_silent) {
  Mixer m;
  CHECK(m.Play(Sfx::Hit));
  auto b = MixFrames(m, 512);
  CHECK(StereoPeak(b) > 1000);
  b = MixFrames(m, kAudioRate);  // the clip is shorter than 1 s
  b = MixFrames(m, 512);
  CHECK_EQ(StereoPeak(b), 0);
  CHECK_EQ(m.stats().activeVoices, 0);
}

TEST(mixer_volume_scales_and_zero_is_silent) {
  Mixer a, b;
  a.SetVolumes(0, 100);
  b.SetVolumes(0, 50);
  a.Play(Sfx::Heavy);
  b.Play(Sfx::Heavy);
  const int pa = StereoPeak(MixFrames(a, 2000)), pb = StereoPeak(MixFrames(b, 2000));
  CHECK(pa > 0 && pb > 0);
  CHECK(pb < pa * 0.65 && pb > pa * 0.3);
  Mixer z;
  z.SetVolumes(0, 0);
  z.Play(Sfx::Hit);
  z.SetMusic(Music::Battle);
  CHECK_EQ(StereoPeak(MixFrames(z, 4000)), 0);
  z.SetVolumes(-50, 500);  // clamped, must not blow up
  z.Play(Sfx::Crit);
  CHECK(StereoPeak(MixFrames(z, 2000)) <= 32767);
}

TEST(mixer_rate_limits_and_caps_identical_sounds) {
  Mixer m;
  int accepted = 0;
  for (int i = 0; i < 20; ++i) accepted += m.Play(Sfx::Hit) ? 1 : 0;  // area attack: 20 hits in one instant
  CHECK_EQ(accepted, 1);
  CHECK(m.stats().droppedPlays >= 19);
  MixFrames(m, 800);  // > 30 ms later
  CHECK(m.Play(Sfx::Hit));
  MixFrames(m, 800);
  CHECK(m.Play(Sfx::Hit));
  MixFrames(m, 800);
  CHECK(!m.Play(Sfx::Hit));  // per-sound cap (3 overlapping) reached
}

TEST(mixer_voice_cap_and_priority) {
  Mixer m(4);
  for (int i = 0; i < static_cast<int>(Sfx::Count); ++i) {
    m.Play(static_cast<Sfx>(i));
    MixFrames(m, 1200);
  }
  CHECK(m.stats().activeVoices <= 4);
  Mixer p(2);
  p.Play(Sfx::LevelUp);
  p.Play(Sfx::Victory);
  MixFrames(p, 1200);
  CHECK(!p.Play(Sfx::UiClick));  // low priority cannot steal important jingles
  CHECK(p.stats().activeVoices == 2);
}

TEST(mixer_pause_freezes_output_and_position) {
  Mixer m;
  m.Play(Sfx::Heavy);
  MixFrames(m, 600);
  const auto clockBefore = m.clock();
  m.SetPaused(true);
  CHECK_EQ(StereoPeak(MixFrames(m, 4000)), 0);
  CHECK_EQ(m.clock(), clockBefore);
  m.SetPaused(false);
  CHECK(StereoPeak(MixFrames(m, 600)) > 100);  // the sound continues where it stopped
}

TEST(mixer_music_crossfade_and_stop) {
  Mixer m;
  m.SetMusic(Music::Menu);
  CHECK(StereoPeak(MixFrames(m, kAudioRate)) > 500);
  m.SetMusic(Music::Battle);
  CHECK(StereoPeak(MixFrames(m, kAudioRate / 4)) > 500);
  m.SetMusic(Music::None);
  MixFrames(m, kAudioRate);  // fade out takes 0.6 s
  CHECK_EQ(StereoPeak(MixFrames(m, 1000)), 0);
  CHECK(m.music() == Music::None);
}

TEST(mixer_limiter_never_wraps_with_many_loud_voices) {
  // Heavy load: soft limiting keeps nearly every sample below full scale (no hard clipping storm).
  Mixer m(32);
  m.SetVolumes(100, 100);
  m.SetMusic(Music::Boss);
  std::size_t total = 0, hot = 0;
  for (int k = 0; k < 20; ++k) {
    for (int i = 0; i < 6; ++i) m.Play(static_cast<Sfx>((k + i) % static_cast<int>(Sfx::Count)), 2.f);
    for (auto v : MixFrames(m, 1024)) {
      ++total;
      hot += std::abs(static_cast<int>(v)) >= 32760 ? 1u : 0u;
    }
  }
  CHECK(hot * 50 < total);
  // Two loud tonal sounds on top of each other: a wrap-around would show as a jump of ~65000 between samples.
  Mixer t;
  t.SetVolumes(0, 100);
  t.Play(Sfx::UiClick, 2.f);
  t.Play(Sfx::UiBack, 2.f);
  const auto b = MixFrames(t, 1500);
  int maxStep = 0;
  for (std::size_t i = 2; i < b.size(); i += 2)
    maxStep = std::max(maxStep, std::abs(static_cast<int>(b[i]) - static_cast<int>(b[i - 2])));
  CHECK(maxStep < 25000);  // legit tonal steps reach ~17000; a wrap would be > 50000
}

TEST(mixer_handles_bad_input) {
  Mixer m;
  CHECK(!m.Play(Sfx::Hit, std::nanf("")));
  CHECK(!m.Play(static_cast<Sfx>(999)));
  m.Mix(nullptr, 100);
  std::int16_t one[2] = {7, 7};
  m.Mix(one, 0);
  m.Mix(one, -5);
  CHECK_EQ(one[0], 7);
  CHECK(m.Play(Sfx::Skill, 1.f, 100.f));  // pitch clamped to 2x
  MixFrames(m, 4000);
  m.StopAll();
  CHECK_EQ(StereoPeak(MixFrames(m, 500)), 0);
}
