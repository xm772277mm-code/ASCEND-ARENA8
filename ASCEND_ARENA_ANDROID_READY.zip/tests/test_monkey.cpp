// Monkey test: random taps on whatever buttons are drawn, random touches, key presses, lifecycle events and
// odd viewport sizes, across all screens and modes. After every step the profile must stay valid, the world
// must respect its spawn limit, and the saved file must reload to an equivalent valid profile.
#include <filesystem>
#include <set>
#include <string>
#include <vector>

#include "../ui/app.h"
#include "test_framework.h"

using namespace ascend;
namespace fs = std::filesystem;

namespace {

struct Lcg {
  std::uint64_t s;
  std::uint32_t Next() {
    s = s * 6364136223846793005ull + 1442695040888963407ull;
    return static_cast<std::uint32_t>(s >> 33);
  }
  int Range(int n) { return n <= 0 ? 0 : static_cast<int>(Next() % static_cast<std::uint32_t>(n)); }
  float Unit() { return static_cast<float>(Next() % 10000) / 10000.f; }
};

std::string SavePath(const std::string& n) {
  const fs::path d = fs::temp_directory_path() / "ascend_monkey";
  fs::create_directories(d);
  std::error_code ec;
  for (const char* x : {"", ".tmp", ".bak", ".corrupt"}) fs::remove(d / (n + x), ec);
  return (d / n).string();
}

void CheckInvariants(App& app) {
  const auto problems = Validate(app.db(), app.profile());
  if (!problems.empty()) {
    for (const auto& p : problems) std::cerr << "  invalid profile: " << p << "\n";
    CHECK(problems.empty());
  }
  if (GameSession* s = app.session()) {
    CHECK(s->world().AliveEnemyCount() <= kMaxEnemiesAlive);
    CHECK(s->world().player().hp.cur >= 0);
    CHECK(s->world().player().hp.cur <= s->world().player().hp.max);
  }
}

}  // namespace

TEST(monkey_random_ui_use_never_breaks_state_or_crashes) {
  const std::string save = SavePath("monkey.sav");
  App app(AppConfig{std::string(ASCEND_SOURCE_DIR) + "/content", save, 7});
  CHECK(app.Init().ok);
  Framebuffer fb(960, 540);
  app.SetViewport(960, 540, 6.4f);
  Lcg rng{0xC0FFEE};
  std::set<std::string> actionsSeen;
  std::set<int> screensSeen;
  int taps = 0, runsStarted = 0;
  int touchId = 1;
  for (int step = 0; step < 1200; ++step) {
    app.Draw(fb);
    screensSeen.insert(static_cast<int>(app.screen()));
    const int kind = rng.Range(100);
    if (kind < 40) {  // tap a random enabled drawn button through its action
      std::vector<std::string> enabled;
      for (const auto& b : app.buttons())
        if (b.enabled) enabled.push_back(b.action);
      if (!enabled.empty()) {
        const std::string a = enabled[static_cast<std::size_t>(rng.Range(static_cast<int>(enabled.size())))];
        actionsSeen.insert(a);
        const bool wasRun = app.screen() == Screen::InGame;
        app.Tap(a);
        ++taps;
        if (!wasRun && app.screen() == Screen::InGame) ++runsStarted;
      }
    } else if (kind < 55) {  // real touch gesture at a random point (down, a few moves, up)
      const float x = rng.Unit() * 960.f, y = rng.Unit() * 540.f;
      const int id = touchId++;
      app.OnTouch({id, TouchPhase::Down, x, y});
      for (int m = 0; m < 3; ++m)
        app.OnTouch({id, TouchPhase::Move, x + rng.Unit() * 120.f - 60.f, y + rng.Unit() * 120.f - 60.f});
      app.OnTouch({id, rng.Range(10) == 0 ? TouchPhase::Cancel : TouchPhase::Up, x, y});
    } else if (kind < 70) {  // keys (only meaningful in a run, must be harmless elsewhere)
      app.PressKey(static_cast<KeyAction>(rng.Range(8)));
      app.SetKeyMove({rng.Unit() * 2.f - 1.f, rng.Unit() * 2.f - 1.f});
    } else if (kind < 75) {
      app.BackPressed();
    } else if (kind < 78) {
      app.OnBackground();
      app.OnForeground();
    } else if (kind < 80) {  // odd viewports, including tiny and extreme aspect ratios
      static const int sizes[][2] = {{320, 180}, {640, 360}, {2400, 1080}, {800, 800}, {1280, 400}, {960, 540}};
      const auto& sz = sizes[rng.Range(6)];
      fb.Resize(sz[0], sz[1]);
      app.SetViewport(sz[0], sz[1], 2.f + rng.Unit() * 12.f);
    }
    const int updates = 1 + rng.Range(20);
    for (int u = 0; u < updates; ++u) app.Update(1.f / 60.f);
    if ((step % 50) == 0) CheckInvariants(app);
    if (app.overlay() == Overlay::Notice && rng.Range(3) == 0) app.Tap("notice:ok");
  }
  CheckInvariants(app);
  // The sweep must actually have exercised the app: many screens, many distinct actions, real runs.
  CHECK(screensSeen.size() >= 7);
  CHECK(actionsSeen.size() >= 30);
  CHECK(runsStarted >= 5);
  CHECK(taps > 300);
  // The persisted profile reloads and is valid.
  app.Persist();
  SaveStore store(save);
  const LoadReport rep = store.Load(app.db());
  CHECK(Validate(app.db(), rep.profile).empty());
}
