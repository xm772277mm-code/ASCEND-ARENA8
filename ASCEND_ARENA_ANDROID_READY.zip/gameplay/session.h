#pragma once
// GameSession: one play-through of an encounter (mission, training, dungeon, story chapter).
// Connects the World to the Profile (XP, loot, rewards, save). Headless and fully testable.
#include <memory>
#include <string>
#include <vector>

#include "modes/levels.h"
#include "progression/save.h"
#include "world.h"

namespace ascend {

enum class RunPhase { Idle, IntroDialogue, Running, Transition, OutroDialogue, Finished };
enum class Outcome { None, Victory, Defeat, TimeUp, Abandoned };

struct RunSummary {
  Outcome outcome = Outcome::None;
  int kills = 0;
  float seconds = 0.f;
  int score = 0;
  int roomsCleared = 0;
  bool firstClear = false;
  GrantResult grant;       // completion reward
  GrantResult firstGrant;  // first-clear bonus
  int levelsGained = 0;    // total during the run (kills + rewards)
  bool saved = false;
  std::string saveError;
};

// Live numbers for the HUD (the UI layer turns them into localized text).
struct RunStatus {
  int enemiesAlive = 0;
  int wave = 0, waves = 0;
  int stage = 0, stages = 0;
  float timeLeft = -1.f;  // < 0: no limit
  bool survive = false;
};

class GameSession {
 public:
  GameSession(const ContentDb* db, const LevelsDb* levels, Profile* profile, SaveStore* store, std::uint64_t seed);

  // Why an encounter cannot start (empty string == can start).
  std::string LockReason(const std::string& encounterId) const;
  Status Start(const std::string& encounterId);

  void AdvanceDialogue();  // next line; after the last line the phase changes
  void Step(const InputFrame& in, float cameraYaw, float dt);
  void SetPaused(bool p) { paused_ = p; }
  bool paused() const { return paused_; }
  void Abandon();  // leave the run (back to the lobby); keeps kill rewards, saves

  RunPhase phase() const { return phase_; }
  bool finished() const { return phase_ == RunPhase::Finished; }
  const RunSummary& summary() const { return summary_; }
  RunStatus status() const;
  const std::string& dialogueKey() const;  // current line while in a dialogue phase
  const EncounterDef* encounter() const { return enc_; }
  World& world() { return *world_; }
  const World& world() const { return *world_; }
  Profile& profile() { return *profile_; }
  // Events produced by the last Step (world events + LevelUp), for effects/audio.
  std::vector<GameEvent> TakeEvents();

 private:
  void BuildStage(int index, int carryHp);
  void SpawnWave(int waveIdx, bool aware);
  void Finish(Outcome o);
  void Handle(const GameEvent& ev);
  Vec3 SpawnPoint(int i, int wave) const;

  const ContentDb* db_;
  const LevelsDb* levels_;
  Profile* profile_;
  SaveStore* store_;
  std::uint64_t seed_;
  std::unique_ptr<World> world_;
  const EncounterDef* enc_ = nullptr;
  RunPhase phase_ = RunPhase::Idle;
  RunSummary summary_;
  std::vector<GameEvent> events_;
  bool paused_ = false;
  int stage_ = 0;
  int nextWave_ = 0;       // next wave to spawn in this stage
  float waveTimer_ = 0.f;  // delay before the next wave / survive spawn clock
  float time_ = 0.f;
  float transitionTimer_ = 0.f;
  float endTimer_ = 0.f;
  Outcome pendingOutcome_ = Outcome::None;
  std::size_t dialogueIdx_ = 0;
  long runId_ = 0;
  int startLevel_ = 1;
  bool applied_ = false;
};

}  // namespace ascend
