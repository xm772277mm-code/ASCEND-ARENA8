#include "session.h"

#include <algorithm>
#include <cmath>

namespace ascend {
namespace {
constexpr float kWaveDelay = 1.2f;
constexpr float kTransitionSeconds = 2.0f;
constexpr float kEndDelay = 1.6f;
constexpr int kMaxSurviveAlive = 10;
const std::string kEmpty;
}  // namespace

GameSession::GameSession(const ContentDb* db, const LevelsDb* levels, Profile* profile, SaveStore* store,
                         std::uint64_t seed)
    : db_(db), levels_(levels), profile_(profile), store_(store), seed_(seed) {
  world_ = std::make_unique<World>(db_, seed_);
}

std::string GameSession::LockReason(const std::string& id) const {
  const EncounterDef* e = levels_->Find(id);
  if (!e) return "unknown encounter";
  if (profile_->level < e->unlockLevel) return "requires level " + std::to_string(e->unlockLevel);
  if (e->kind == ModeKind::Story && e->chapter > profile_->storyChapter)
    return "complete chapter " + std::to_string(e->chapter - 1) + " first";
  return "";
}

Status GameSession::Start(const std::string& id) {
  if (phase_ == RunPhase::Running || phase_ == RunPhase::Transition) return Status::Error("a run is already active");
  const std::string why = LockReason(id);
  if (!why.empty()) return Status::Error(why);
  enc_ = levels_->Find(id);
  summary_ = {};
  events_.clear();
  paused_ = false;
  time_ = 0.f;
  applied_ = false;
  stage_ = 0;
  startLevel_ = profile_->level;
  runId_ = profile_->lastRunId + 1;
  BuildStage(0, -1);
  dialogueIdx_ = 0;
  phase_ = enc_->introDialogue.empty() ? RunPhase::Running : RunPhase::IntroDialogue;
  return Status::Ok();
}

void GameSession::BuildStage(int index, int carryHp) {
  const StageDef& st = enc_->stages[static_cast<std::size_t>(index)];
  const ArenaSpec* ar = levels_->Arena(st.arenaId);
  world_ = std::make_unique<World>(db_, seed_ + static_cast<std::uint64_t>(index) * 7919u);
  if (ar) world_->SetArena(ar->arena);
  const float half = world_->arena().half;
  world_->SetPlayer(LoadoutFor(*db_, *profile_), {0.f, 0.f, -half * 0.7f});
  if (carryHp > 0) world_->mutablePlayer().hp.cur = std::min(carryHp, world_->player().hp.max);
  stage_ = index;
  nextWave_ = 0;
  waveTimer_ = kWaveDelay;
  if (enc_->kind == ModeKind::Training) {
    for (int i = 0; i < enc_->trainingDummies; ++i) {
      const float x = (static_cast<float>(i) - static_cast<float>(enc_->trainingDummies - 1) * 0.5f) * 3.5f;
      world_->SpawnEnemy("training_dummy", {x, 0.f, half * 0.3f});
    }
  }
}

Vec3 GameSession::SpawnPoint(int i, int wave) const {
  const float half = world_->arena().half;
  const float ang = static_cast<float>(i) * 2.399963f + static_cast<float>(wave) * 0.9f + 0.5f;
  Vec3 p{std::sin(ang) * half * 0.62f, 0.f, std::cos(ang) * half * 0.62f};
  if (DistanceXZ(p, world_->player().pos) < 6.f) p = {-p.x, 0.f, -p.z};  // never spawn on top of the player
  return p;
}

void GameSession::SpawnWave(int waveIdx, bool aware) {
  const StageDef& st = enc_->stages[static_cast<std::size_t>(stage_)];
  const WaveDef& w = st.waves[static_cast<std::size_t>(waveIdx) % st.waves.size()];
  int n = 0;
  for (const auto& sp : w)
    for (int k = 0; k < sp.count; ++k)
      world_->SpawnEnemy(sp.enemyId, SpawnPoint(n++, waveIdx), enc_->enemyLevel, aware);
}

void GameSession::AdvanceDialogue() {
  if (phase_ != RunPhase::IntroDialogue && phase_ != RunPhase::OutroDialogue) return;
  const auto& lines = phase_ == RunPhase::IntroDialogue ? enc_->introDialogue : enc_->outroDialogue;
  ++dialogueIdx_;
  if (dialogueIdx_ >= lines.size()) {
    dialogueIdx_ = 0;
    phase_ = phase_ == RunPhase::IntroDialogue ? RunPhase::Running : RunPhase::Finished;
  }
}

const std::string& GameSession::dialogueKey() const {
  if (!enc_) return kEmpty;
  const auto& lines = phase_ == RunPhase::IntroDialogue ? enc_->introDialogue : enc_->outroDialogue;
  if ((phase_ != RunPhase::IntroDialogue && phase_ != RunPhase::OutroDialogue) || dialogueIdx_ >= lines.size())
    return kEmpty;
  return lines[dialogueIdx_];
}

RunStatus GameSession::status() const {
  RunStatus s;
  if (!enc_) return s;
  s.enemiesAlive = 0;
  for (const auto& e : world_->enemies())
    if (e.Alive() && !e.def->dummy) ++s.enemiesAlive;
  const StageDef& st = enc_->stages[static_cast<std::size_t>(stage_)];
  s.waves = static_cast<int>(st.waves.size());
  s.wave = std::min(nextWave_, s.waves);
  s.stage = stage_ + 1;
  s.stages = static_cast<int>(enc_->stages.size());
  s.survive = enc_->objective == Objective::Survive;
  if (s.survive)
    s.timeLeft = std::max(0.f, enc_->surviveSeconds - time_);
  else if (enc_->timeLimit > 0.f)
    s.timeLeft = std::max(0.f, enc_->timeLimit - time_);
  return s;
}

std::vector<GameEvent> GameSession::TakeEvents() {
  std::vector<GameEvent> out;
  out.swap(events_);
  return out;
}

void GameSession::Handle(const GameEvent& ev) {
  if (ev.type != EventType::EnemyDefeated) return;
  ++summary_.kills;
  if (enc_->kind == ModeKind::Training) return;  // no rewards from practice
  const GrantResult g = ApplyKill(*db_, *profile_, ev);
  if (g.levelsGained > 0) {
    summary_.levelsGained += g.levelsGained;
    world_->UpdatePlayerLoadout(LoadoutFor(*db_, *profile_), false);
    GameEvent lv;
    lv.type = EventType::LevelUp;
    lv.amount = profile_->level;
    lv.pos = world_->player().pos;
    events_.push_back(lv);
  }
}

void GameSession::Step(const InputFrame& in, float cameraYaw, float dt) {
  if (!enc_ || paused_) return;
  if (phase_ == RunPhase::Transition) {
    transitionTimer_ -= dt;
    if (transitionTimer_ <= 0.f) {
      const int hp = world_->player().hp.cur;
      const int heal = world_->player().hp.max * 30 / 100;
      BuildStage(stage_ + 1, std::min(world_->player().hp.max, hp + heal));
      world_->mutablePlayer().mana.cur = world_->player().mana.max;
      phase_ = RunPhase::Running;
    }
    return;
  }
  if (phase_ != RunPhase::Running) return;

  time_ += dt;
  world_->Step(in, cameraYaw, dt);
  for (auto& ev : world_->TakeEvents()) {
    Handle(ev);
    events_.push_back(std::move(ev));
  }
  if (enc_->kind == ModeKind::Training) {
    world_->mutablePlayer().mana.cur = world_->player().mana.max;  // free skill testing, no rewards
    return;
  }

  if (pendingOutcome_ != Outcome::None) {  // short beat before the result screen
    endTimer_ -= dt;
    if (endTimer_ <= 0.f) Finish(pendingOutcome_);
    return;
  }
  if (!world_->player().Alive()) {
    pendingOutcome_ = Outcome::Defeat;
    endTimer_ = kEndDelay;
    return;
  }
  if (enc_->timeLimit > 0.f && time_ >= enc_->timeLimit && enc_->objective == Objective::KillAll) {
    pendingOutcome_ = Outcome::TimeUp;
    endTimer_ = 0.5f;
    return;
  }

  const StageDef& st = enc_->stages[static_cast<std::size_t>(stage_)];
  const int alive = world_->AliveEnemyCount();
  if (enc_->objective == Objective::Survive) {
    if (time_ >= enc_->surviveSeconds) {
      pendingOutcome_ = Outcome::Victory;
      endTimer_ = kEndDelay;
      return;
    }
    waveTimer_ -= dt;
    if (waveTimer_ <= 0.f && alive < kMaxSurviveAlive) {
      SpawnWave(nextWave_, true);
      ++nextWave_;
      waveTimer_ = enc_->spawnInterval;
    }
    return;
  }
  // Kill-all: spawn the next wave once the field is clear.
  if (nextWave_ < static_cast<int>(st.waves.size())) {
    if (alive == 0) {
      waveTimer_ -= dt;
      if (waveTimer_ <= 0.f) {
        SpawnWave(nextWave_, nextWave_ > 0);
        ++nextWave_;
        waveTimer_ = kWaveDelay;
      }
    }
    return;
  }
  if (alive == 0) {
    ++summary_.roomsCleared;
    if (stage_ + 1 < static_cast<int>(enc_->stages.size())) {
      phase_ = RunPhase::Transition;
      transitionTimer_ = kTransitionSeconds;
    } else {
      pendingOutcome_ = Outcome::Victory;
      endTimer_ = kEndDelay;
    }
  }
}

void GameSession::Abandon() {
  if (!enc_ || phase_ == RunPhase::Finished || phase_ == RunPhase::Idle) return;
  Finish(Outcome::Abandoned);
}

void GameSession::Finish(Outcome o) {
  if (applied_) return;  // never apply a result twice
  applied_ = true;
  pendingOutcome_ = Outcome::None;
  summary_.outcome = o;
  summary_.seconds = time_;
  const Player& p = world_->player();
  summary_.score = o == Outcome::Victory
                       ? summary_.kills * 100 + p.hp.cur * 2 + std::max(0, static_cast<int>(180.f - time_)) * 3
                       : summary_.kills * 100;
  if (enc_->kind == ModeKind::Dungeon)
    profile_->dungeonBestRoom = std::max(profile_->dungeonBestRoom, summary_.roomsCleared);
  if (o == Outcome::Victory && enc_->kind != ModeKind::Training) {
    ApplyRun(*db_, *profile_, runId_, enc_->reward, &summary_.grant);
    summary_.firstClear = ClaimOnce(*db_, *profile_, "first_clear:" + enc_->id, enc_->firstClear, &summary_.firstGrant);
    summary_.levelsGained += summary_.grant.levelsGained + summary_.firstGrant.levelsGained;
    if (enc_->kind == ModeKind::Mission) {
      profile_->completedMissions.insert(enc_->id);
      int& best = profile_->missionBestScore[enc_->id];
      best = std::max(best, summary_.score);
    } else if (enc_->kind == ModeKind::Story) {
      profile_->storyChaptersCleared = std::max(profile_->storyChaptersCleared, enc_->chapter);
      profile_->storyChapter = std::max(profile_->storyChapter, enc_->chapter + 1);
    } else if (enc_->kind == ModeKind::Dungeon) {
      profile_->completedMissions.insert("dungeon:" + enc_->id);
    }
  } else {
    profile_->lastRunId = std::max(profile_->lastRunId, runId_);  // a failed run still consumes its id
  }
  if (store_) {
    const Status s = store_->Save(*profile_);
    summary_.saved = s.ok;
    summary_.saveError = s.message;
  }
  const bool outro = o == Outcome::Victory && !enc_->outroDialogue.empty();
  dialogueIdx_ = 0;
  phase_ = outro ? RunPhase::OutroDialogue : RunPhase::Finished;
}

}  // namespace ascend
