#include "world.h"

#include <algorithm>
#include <cmath>

#include "combat/damage.h"

namespace ascend {
namespace {

constexpr float kPlayerTurnRate = 16.f;
constexpr float kEnemyTurnRate = 8.f;
constexpr float kInputBufferSeconds = 0.25f;
constexpr float kPostHitInvuln = 0.4f;
constexpr float kDefeatedLinger = 1.2f;
constexpr float kAlertTime = 0.4f;
constexpr float kAimAssistRange = 3.6f;
constexpr float kAimAssistHalfAngle = 1.05f;  // ~60 degrees each side

float TurnToward(float cur, float target, float maxStep) {
  const float d = Clamp(AngleDelta(cur, target), -maxStep, maxStep);
  return WrapAngle(cur + d);
}

// Distance from point p to segment a-b on the ground plane.
float DistToSegmentXZ(Vec3 p, Vec3 a, Vec3 b) {
  const float abx = b.x - a.x, abz = b.z - a.z;
  const float l2 = abx * abx + abz * abz;
  float t = 0.f;
  if (l2 > 1e-8f) t = Clamp(((p.x - a.x) * abx + (p.z - a.z) * abz) / l2, 0.f, 1.f);
  const float cx = a.x + abx * t, cz = a.z + abz * t;
  return std::sqrt((p.x - cx) * (p.x - cx) + (p.z - cz) * (p.z - cz));
}

float DegToRad(float d) { return d * kPi / 180.f; }

enum Action { kLight = 0, kHeavy = 1, kDodge = 2, kSkill0 = 3 };

}  // namespace

const char* EnemyStateName(EnemyState s) {
  switch (s) {
    case EnemyState::Idle:
      return "idle";
    case EnemyState::Patrol:
      return "patrol";
    case EnemyState::Alert:
      return "alert";
    case EnemyState::Approach:
      return "approach";
    case EnemyState::Attack:
      return "attack";
    case EnemyState::Recover:
      return "recover";
    case EnemyState::Stagger:
      return "stagger";
    case EnemyState::Defeated:
      return "defeated";
  }
  return "?";
}

const char* PlayerStateName(PlayerState s) {
  switch (s) {
    case PlayerState::Idle:
      return "idle";
    case PlayerState::Run:
      return "run";
    case PlayerState::Attack:
      return "attack";
    case PlayerState::Dodge:
      return "dodge";
    case PlayerState::Hurt:
      return "hurt";
    case PlayerState::Dead:
      return "dead";
  }
  return "?";
}

// ---------------------------------------------------------------- arena

Vec3 ArenaDef::ResolveCircle(Vec3 p, float r) const {
  for (int it = 0; it < 2; ++it) {
    p.x = Clamp(p.x, -half + r, half - r);
    p.z = Clamp(p.z, -half + r, half - r);
    for (const auto& o : obstacles) p = ResolveCircleVsBox(p, r, o);
  }
  p.x = Clamp(p.x, -half + r, half - r);
  p.z = Clamp(p.z, -half + r, half - r);
  p.y = 0.f;
  return p;
}

bool ArenaDef::Blocked(Vec3 a, Vec3 b) const {
  for (const auto& o : obstacles)
    if (SegmentHitsBox(a, b, o)) return true;
  return false;
}

// ---------------------------------------------------------------- setup

World::World(const ContentDb* db, std::uint64_t seed) : db_(db), rng_(seed) {}

void World::SetPlayer(const PlayerLoadout& l, Vec3 pos) {
  loadout_ = l;
  player_ = Player{};
  player_.stats = l.stats;
  player_.level = l.level;
  player_.hp = Pool::Full(l.stats.maxHp);
  player_.mana = Pool::Full(l.stats.maxMana);
  player_.pos = arena_.ResolveCircle(pos, tuning().playerRadius);
}

void World::UpdatePlayerLoadout(const PlayerLoadout& l, bool healFull) {
  loadout_ = l;
  const int oldHp = player_.hp.max, oldMana = player_.mana.max;
  player_.stats = l.stats;
  player_.level = l.level;
  player_.hp.max = std::max(1, l.stats.maxHp);
  player_.mana.max = std::max(0, l.stats.maxMana);
  if (healFull) {
    player_.hp.cur = player_.hp.max;
    player_.mana.cur = player_.mana.max;
  } else {
    player_.hp.cur = std::min(player_.hp.max, player_.hp.cur + std::max(0, player_.hp.max - oldHp));
    player_.mana.cur = std::min(player_.mana.max, player_.mana.cur + std::max(0, player_.mana.max - oldMana));
  }
}

int World::AliveEnemyCount() const {
  int n = 0;
  for (const auto& e : enemies_) n += e.Alive() ? 1 : 0;
  return n;
}

Enemy* World::FindEnemy(int uid) {
  for (auto& e : enemies_)
    if (e.uid == uid) return &e;
  return nullptr;
}

int World::SpawnEnemy(const std::string& defId, Vec3 pos, int levelOverride, bool aware) {
  const EnemyDef* def = db_->Enemy(defId);
  if (!def) {
    GameEvent ev;
    ev.type = EventType::SpawnRejected;
    ev.refId = "unknown enemy '" + defId + "'";
    Emit(ev);
    return -1;
  }
  if (AliveEnemyCount() >= kMaxEnemiesAlive || enemies_.size() >= static_cast<std::size_t>(kMaxEnemiesAlive) * 2) {
    GameEvent ev;
    ev.type = EventType::SpawnRejected;
    ev.refId = "enemy limit reached";
    Emit(ev);
    return -1;
  }
  Enemy e;
  e.uid = nextUid_++;
  e.def = def;
  e.level = levelOverride > 0 ? levelOverride : def->level;
  e.stats = def->stats;
  const float scale = std::max(0.4f, 1.f + 0.12f * static_cast<float>(e.level - def->level));
  e.stats.maxHp = std::max(1, static_cast<int>(std::lround(static_cast<float>(def->stats.maxHp) * scale)));
  e.stats.attack = std::max(0, static_cast<int>(std::lround(static_cast<float>(def->stats.attack) * scale)));
  e.hp = Pool::Full(e.stats.maxHp);
  e.pos = arena_.ResolveCircle(pos, def->radius);
  e.home = e.pos;
  e.yaw = YawFromDirection(NormalizeXZ(player_.pos - e.pos));
  e.aware = aware;
  e.state = aware ? EnemyState::Approach : EnemyState::Idle;
  e.timer = 0.5f + rng_.NextFloat() * 1.5f;
  enemies_.push_back(e);
  return e.uid;
}

std::vector<GameEvent> World::TakeEvents() {
  std::vector<GameEvent> out;
  out.swap(events_);
  return out;
}

const Enemy* World::NearestEnemyInCone(float range, float halfAngle) const {
  const Enemy* best = nullptr;
  float bestD = 1e9f;
  for (const auto& e : enemies_) {
    if (!e.Alive()) continue;
    const float d = DistanceXZ(player_.pos, e.pos);
    if (d > range + e.def->radius) continue;
    if (d > 0.01f) {
      const float a = std::fabs(AngleDelta(player_.yaw, YawFromDirection(NormalizeXZ(e.pos - player_.pos))));
      if (a > halfAngle) continue;
    }
    if (arena_.Blocked(player_.pos, e.pos)) continue;
    if (d < bestD) {
      bestD = d;
      best = &e;
    }
  }
  return best;
}

// ---------------------------------------------------------------- step

void World::Step(const InputFrame& in, float cameraYaw, float dt) {
  time_ += static_cast<double>(dt);
  StepPlayer(in, cameraYaw, dt);
  StepEnemies(dt);
  StepProjectiles(dt);
  Separate();
}

bool World::CanAct() const {
  const Player& p = player_;
  if (!p.Alive()) return false;
  if (p.state == PlayerState::Idle || p.state == PlayerState::Run) return true;
  return false;
}

void World::StepPlayer(const InputFrame& in, float cameraYaw, float dt) {
  Player& p = player_;
  p.animTime += dt;
  p.dodgeCd.Tick(dt);
  for (auto& c : p.skillCd) c.Tick(dt);
  p.invuln = std::max(0.f, p.invuln - dt);
  p.flash = std::max(0.f, p.flash - dt * 4.f);
  p.comboTimer = std::max(0.f, p.comboTimer - dt);
  if (!p.Alive()) return;

  p.manaAcc += tuning().manaRegenPerSec * dt;
  const int whole = static_cast<int>(p.manaAcc);
  if (whole > 0) {
    p.mana.Add(whole);
    p.manaAcc -= static_cast<float>(whole);
  }

  if (p.stateTimer > 0.f) p.stateTimer -= dt;
  if (p.pendingSkill) {
    p.pendingTimer -= dt;
    if (p.pendingTimer <= 0.f) {
      const SkillDef* s = p.pendingSkill;
      p.pendingSkill = nullptr;
      ResolvePlayerSkill(*s);
    }
  }
  if (p.state == PlayerState::Dodge) {
    const float speed = tuning().dodgeDistance / tuning().dodgeTime;
    p.pos = arena_.ResolveCircle(p.pos + p.dodgeDir * (speed * dt), tuning().playerRadius);
    if (p.stateTimer <= 0.f) p.state = PlayerState::Idle;
  } else if ((p.state == PlayerState::Attack || p.state == PlayerState::Hurt) && p.stateTimer <= 0.f &&
             !p.pendingSkill) {
    p.state = PlayerState::Idle;
  }

  // Movement direction in world space (camera relative).
  const Vec3 fwd = ForwardFromYaw(cameraYaw);
  const Vec3 right{std::cos(cameraYaw), 0.f, -std::sin(cameraYaw)};
  Vec3 dir = fwd * in.move.y + right * in.move.x;
  float mag = std::sqrt(dir.x * dir.x + dir.z * dir.z);
  if (mag > 1.f) {
    dir = dir * (1.f / mag);
    mag = 1.f;
  }

  // Input -> buffered action (latest press wins; priority dodge > skill > heavy > light).
  int action = -1;
  if (in.attack) action = kLight;
  if (in.heavy) action = kHeavy;
  for (int i = 0; i < kMaxSkills; ++i)
    if (in.skill[static_cast<std::size_t>(i)]) action = kSkill0 + i;
  if (in.dodge) action = kDodge;
  if (action >= 0) {
    bufferedAction_ = action;
    bufferTimer_ = kInputBufferSeconds;
  }
  bufferTimer_ -= dt;
  if (bufferTimer_ <= 0.f) bufferedAction_ = -1;

  if (bufferedAction_ >= 0) {
    const int a = bufferedAction_;
    const bool recovering = p.state == PlayerState::Attack && !p.pendingSkill;
    bool consumed = false;
    if (a == kDodge && (CanAct() || recovering)) {
      consumed = true;
      if (p.dodgeCd.Ready()) {
        p.dodgeDir = mag > 0.2f ? NormalizeXZ(dir) : ForwardFromYaw(p.yaw);
        p.yaw = YawFromDirection(p.dodgeDir);
        p.state = PlayerState::Dodge;
        ++p.actionSerial;
        p.stateTimer = tuning().dodgeTime;
        p.stateDuration = p.stateTimer;
        p.invuln = std::max(p.invuln, tuning().dodgeInvuln);
        p.dodgeCd.Start(tuning().dodgeCooldown);
        p.pendingSkill = nullptr;
        GameEvent ev;
        ev.type = EventType::DodgeStarted;
        ev.pos = p.pos;
        Emit(ev);
      }
    } else if (a != kDodge && CanAct()) {
      consumed = true;
      if (a == kLight && !loadout_.lightCombo.empty()) {
        if (p.comboTimer <= 0.f) p.comboIndex = 0;
        const SkillDef* s = loadout_.lightCombo[static_cast<std::size_t>(p.comboIndex) % loadout_.lightCombo.size()];
        p.comboIndex = (p.comboIndex + 1) % static_cast<int>(loadout_.lightCombo.size());
        BeginAttack(s, -1);
      } else if (a == kHeavy && loadout_.heavy) {
        BeginAttack(loadout_.heavy, -1);
      } else if (a >= kSkill0 && a < kSkill0 + kMaxSkills) {
        const std::size_t slot = static_cast<std::size_t>(a - kSkill0);
        const SkillDef* s = loadout_.skills[slot];
        if (s && p.level >= s->unlockLevel && p.skillCd[slot].Ready() && p.mana.cur >= s->manaCost) {
          p.mana.Remove(s->manaCost);
          p.skillCd[slot].Start(s->cooldown);
          BeginAttack(s, static_cast<int>(slot));
        }
      }
    }
    if (consumed) bufferedAction_ = -1;
  }

  // Locomotion.
  if (p.state == PlayerState::Idle || p.state == PlayerState::Run) {
    if (mag > 0.05f) {
      const Vec3 d = NormalizeXZ(dir);
      p.yaw = TurnToward(p.yaw, YawFromDirection(d), kPlayerTurnRate * dt);
      p.pos = arena_.ResolveCircle(p.pos + d * (p.stats.moveSpeed * mag * dt), tuning().playerRadius);
      p.state = PlayerState::Run;
    } else {
      p.state = PlayerState::Idle;
    }
  }
}

void World::BeginAttack(const SkillDef* s, int slot) {
  Player& p = player_;
  // Aim assist: snap toward the nearest enemy in front so touch players do not miss.
  if (s->kind != SkillKind::Circle) {
    if (const Enemy* t = NearestEnemyInCone(kAimAssistRange, kAimAssistHalfAngle))
      p.yaw = YawFromDirection(NormalizeXZ(t->pos - p.pos));
  }
  p.state = PlayerState::Attack;
  ++p.actionSerial;
  const bool basic = slot < 0;
  p.stateTimer = basic ? s->cooldown : Clamp(s->cooldown * 0.15f, 0.35f, 0.6f);
  if (s->kind == SkillKind::Dash) p.stateTimer = 0.3f;
  p.stateDuration = p.stateTimer;
  p.pendingSkill = s;
  p.pendingTimer = (s->kind == SkillKind::Dash) ? 0.f : tuning().hitDelay;
  p.lastSkill = s;
  if (basic) p.comboTimer = p.stateTimer + tuning().comboWindow;
  GameEvent ev;
  ev.type = EventType::SkillCast;
  ev.refId = s->id;
  ev.pos = p.pos;
  Emit(ev);
}

void World::ResolvePlayerSkill(const SkillDef& s) {
  if (s.kind == SkillKind::Dash) {
    DoDash(s);
    return;
  }
  const Player& p = player_;
  const float halfArc = DegToRad(s.arcDegrees) * 0.5f;
  for (auto& e : enemies_) {
    if (!e.Alive()) continue;
    const float d = DistanceXZ(p.pos, e.pos);
    if (d > s.range + e.def->radius) continue;
    if (s.kind == SkillKind::Arc && d > e.def->radius) {
      const float a = std::fabs(AngleDelta(p.yaw, YawFromDirection(NormalizeXZ(e.pos - p.pos))));
      const float slack = std::atan2(e.def->radius, std::max(d, 0.1f));  // wide targets are easier to clip
      if (a > halfArc + slack) continue;
    }
    if (arena_.Blocked(p.pos, e.pos)) continue;  // no hits through walls
    HitEnemy(e, s);
  }
}

void World::DoDash(const SkillDef& s) {
  Player& p = player_;
  const Vec3 start = p.pos;
  const Vec3 dir = ForwardFromYaw(p.yaw);
  Vec3 cur = start;
  const float step = 0.2f;
  const int steps = static_cast<int>(s.range / step + 1e-4f);  // integer counter: no float accumulation error
  for (int n = 1; n <= steps; ++n) {
    const Vec3 cand = start + dir * (static_cast<float>(n) * step);
    const Vec3 res = arena_.ResolveCircle(cand, tuning().playerRadius);
    if (DistanceXZ(cand, res) > 0.05f) break;  // blocked by wall/obstacle
    cur = res;
  }
  p.pos = cur;
  p.invuln = std::max(p.invuln, 0.25f);
  for (auto& e : enemies_) {
    if (!e.Alive()) continue;
    if (DistToSegmentXZ(e.pos, start, cur) <= e.def->radius + 0.9f) HitEnemy(e, s);
  }
}

void World::HitEnemy(Enemy& e, const SkillDef& s) {
  const bool crit = rng_.NextInt(1, 100) <= tuning().critChancePercent;
  const int dmg = ComputeDamage(player_.stats.attack, s.powerPercent, s.type, e.stats, crit);
  e.sinceHit = 0.f;
  e.flash = 1.f;
  e.aware = true;
  e.hp.Remove(dmg);
  GameEvent ev;
  ev.type = EventType::EnemyHit;
  ev.actorId = e.uid;
  ev.amount = dmg;
  ev.crit = crit;
  ev.pos = e.pos;
  ev.refId = s.id;
  Emit(ev);

  if (e.def->dummy) {
    if (e.hp.Empty()) e.hp.cur = e.hp.max;  // dummies cannot die
    return;
  }
  if (e.hp.Empty()) {
    Defeat(e);
    return;
  }
  const float stagger = s.stagger * (1.f - e.def->staggerResist);
  if (stagger >= 0.08f) {
    e.state = EnemyState::Stagger;
    e.timer = stagger;
  }
  const float kb = s.knockback * (1.f - e.def->knockbackResist);
  if (kb > 0.01f) {
    e.knockTimer = 0.15f;
    e.knockVel = NormalizeXZ(e.pos - player_.pos) * (kb / 0.15f);
  }
  if (e.def->enrageBelowPercent > 0 && !e.enraged && e.hp.cur * 100 < e.hp.max * e.def->enrageBelowPercent) {
    e.enraged = true;
    GameEvent en;
    en.type = EventType::EnemyEnraged;
    en.actorId = e.uid;
    en.pos = e.pos;
    Emit(en);
  }
}

void World::Defeat(Enemy& e) {
  e.state = EnemyState::Defeated;
  e.timer = kDefeatedLinger;
  e.knockTimer = 0.f;
  ++defeated_;
  GameEvent ev;
  ev.type = EventType::EnemyDefeated;
  ev.actorId = e.uid;
  ev.amount = e.def->xp;
  ev.level = e.level;
  ev.pos = e.pos;
  ev.refId = e.def->id;
  for (const auto& d : e.def->drops)
    if (rng_.NextInt(1, 100) <= d.chancePercent) ev.drops.push_back({d.itemId, d.count});
  Emit(std::move(ev));
}

// ---------------------------------------------------------------- enemies

void World::StepEnemies(float dt) {
  for (auto& e : enemies_) StepEnemy(e, dt);
  enemies_.erase(std::remove_if(enemies_.begin(), enemies_.end(),
                                [](const Enemy& e) { return e.state == EnemyState::Defeated && e.timer <= 0.f; }),
                 enemies_.end());
}

void World::StepEnemy(Enemy& e, float dt) {
  const EnemyDef& d = *e.def;
  e.animTime += dt;
  e.flash = std::max(0.f, e.flash - dt * 4.f);
  e.sinceHit += dt;
  if (e.knockTimer > 0.f) {
    e.knockTimer -= dt;
    e.pos = arena_.ResolveCircle(e.pos + e.knockVel * dt, d.radius);
  }
  if (e.state == EnemyState::Defeated) {
    e.timer -= dt;
    return;
  }
  if (d.dummy) {
    if (e.sinceHit > 3.f) e.hp.cur = e.hp.max;
    return;
  }
  if (e.state == EnemyState::Stagger) {
    e.timer -= dt;
    if (e.timer <= 0.f) e.state = EnemyState::Approach;
    return;
  }

  const Player& p = player_;
  const bool playerAlive = p.Alive();
  const float dist = DistanceXZ(e.pos, p.pos);
  const Vec3 toPlayer = NormalizeXZ(p.pos - e.pos);
  const float speedMul = e.enraged ? d.enrageSpeedMult : 1.f;
  const float speed = e.stats.moveSpeed * speedMul;
  auto moveDir = [&](Vec3 dir, float s) { e.pos = arena_.ResolveCircle(e.pos + dir * (s * dt), d.radius); };
  auto faceTo = [&](Vec3 dir) {
    if (dir.x != 0.f || dir.z != 0.f) e.yaw = TurnToward(e.yaw, YawFromDirection(dir), kEnemyTurnRate * dt);
  };
  auto sees = [&]() { return playerAlive && dist <= d.detectRange && !arena_.Blocked(e.pos, p.pos); };

  if (!playerAlive && e.state != EnemyState::Idle && e.state != EnemyState::Patrol) {
    e.state = EnemyState::Idle;
    e.aware = false;
    e.timer = 1.f;
  }

  switch (e.state) {
    case EnemyState::Idle:
      e.timer -= dt;
      if (e.aware || sees()) {
        e.aware = true;
        e.state = EnemyState::Alert;
        e.timer = kAlertTime;
      } else if (e.timer <= 0.f && d.patrolRadius > 0.5f) {
        const float ang = rng_.NextFloat() * 2.f * kPi;
        const float r = d.patrolRadius * (0.4f + 0.6f * rng_.NextFloat());
        e.patrolTarget =
            arena_.ResolveCircle({e.home.x + std::sin(ang) * r, 0.f, e.home.z + std::cos(ang) * r}, d.radius);
        e.state = EnemyState::Patrol;
        e.timer = 6.f;  // give up if the target is unreachable
      }
      break;
    case EnemyState::Patrol: {
      e.timer -= dt;
      const Vec3 to = NormalizeXZ(e.patrolTarget - e.pos);
      faceTo(to);
      moveDir(to, speed * 0.5f);
      if (sees()) {
        e.aware = true;
        e.state = EnemyState::Alert;
        e.timer = kAlertTime;
      } else if (DistanceXZ(e.pos, e.patrolTarget) < 0.3f || e.timer <= 0.f) {
        e.state = EnemyState::Idle;
        e.timer = 1.f + rng_.NextFloat() * 2.f;
      }
      break;
    }
    case EnemyState::Alert:
      faceTo(toPlayer);
      e.timer -= dt;
      if (e.timer <= 0.f) e.state = EnemyState::Approach;
      break;
    case EnemyState::Approach: {
      if (dist > d.loseRange) {  // gave up: walk home
        e.aware = false;
        e.state = EnemyState::Idle;
        e.timer = 1.f;
        break;
      }
      faceTo(toPlayer);
      const bool los = !arena_.Blocked(e.pos, p.pos);
      if (d.ranged) {
        if (los && dist <= d.attackRange) {
          if (dist < d.attackRange * 0.4f) {
            moveDir(toPlayer * -1.f, speed);  // kite: back away from the player
            break;
          }
          e.state = EnemyState::Attack;
          e.timer = d.windup * (e.enraged ? 0.75f : 1.f);
          e.strikeDone = false;
          GameEvent ev;
          ev.type = EventType::EnemyWindup;
          ev.actorId = e.uid;
          ev.pos = e.pos;
          Emit(ev);
        } else {
          moveDir(toPlayer, speed);
        }
      } else if (dist <= d.attackRange * 0.85f && los) {
        e.state = EnemyState::Attack;
        e.timer = d.windup * (e.enraged ? 0.75f : 1.f);
        e.strikeDone = false;
        GameEvent ev;
        ev.type = EventType::EnemyWindup;
        ev.actorId = e.uid;
        ev.pos = e.pos;
        Emit(ev);
      } else {
        // Simple steering (not a navmesh): head for the player; if an obstacle blocks the line,
        // slide around it by trying a rotated heading.
        Vec3 dir = toPlayer;
        if (!los) {
          const float side = (e.uid % 2 == 0) ? 1.f : -1.f;
          const float a = YawFromDirection(toPlayer) + side * 0.9f;
          dir = ForwardFromYaw(a);
        }
        moveDir(dir, speed);
      }
      break;
    }
    case EnemyState::Attack:
      e.timer -= dt;
      if (e.timer > d.windup * 0.3f) faceTo(toPlayer);  // aim locks late so a dodge can beat it
      if (e.timer <= 0.f && !e.strikeDone) {
        e.strikeDone = true;
        EnemyStrike(e);
        e.state = EnemyState::Recover;
        e.timer = d.recover;
      }
      break;
    case EnemyState::Recover:
      e.timer -= dt;
      if (e.timer <= 0.f) e.state = EnemyState::Approach;
      break;
    case EnemyState::Stagger:
    case EnemyState::Defeated:
      break;
  }
}

void World::EnemyStrike(Enemy& e) {
  const EnemyDef& d = *e.def;
  const Player& p = player_;
  if (!p.Alive()) return;
  if (d.ranged) {
    if (projectiles_.size() >= static_cast<std::size_t>(kMaxProjectiles)) return;
    Projectile pr;
    const Vec3 dir = NormalizeXZ(p.pos - e.pos);
    pr.pos = e.pos + dir * 0.6f;
    pr.pos.y = 1.0f;
    pr.vel = dir * tuning().projectileSpeed;
    pr.life = 3.f;
    pr.attack = e.stats.attack;
    pr.power = d.damagePercent;
    pr.type = d.damageType;
    projectiles_.push_back(pr);
    GameEvent ev;
    ev.type = EventType::ProjectileFired;
    ev.actorId = e.uid;
    ev.pos = e.pos;
    Emit(ev);
    return;
  }
  const float dist = DistanceXZ(e.pos, p.pos);
  if (dist > d.attackRange + tuning().playerRadius) return;
  const float a = std::fabs(AngleDelta(e.yaw, YawFromDirection(NormalizeXZ(p.pos - e.pos))));
  if (a > 0.9f) return;
  if (arena_.Blocked(e.pos, p.pos)) return;
  DamagePlayer(e.stats.attack, d.damagePercent, d.damageType, e.pos, true);
}

void World::DamagePlayer(int attack, int power, DamageType type, Vec3 from, bool melee) {
  (void)from;
  (void)melee;
  Player& p = player_;
  if (!p.Alive()) return;
  if (p.invuln > 0.f) {
    GameEvent ev;
    ev.type = EventType::PlayerDodgedHit;
    ev.pos = p.pos;
    Emit(ev);
    return;
  }
  const int dmg = ComputeDamage(attack, power, type, p.stats);
  p.hp.Remove(dmg);
  p.flash = 1.f;
  GameEvent ev;
  ev.type = EventType::PlayerHit;
  ev.amount = dmg;
  ev.pos = p.pos;
  Emit(ev);
  if (p.hp.Empty()) {
    p.state = PlayerState::Dead;
    p.pendingSkill = nullptr;
    GameEvent dead;
    dead.type = EventType::PlayerDefeated;
    dead.pos = p.pos;
    Emit(dead);
    return;
  }
  p.invuln = kPostHitInvuln;
  if (p.state != PlayerState::Dodge) {
    p.state = PlayerState::Hurt;
    ++p.actionSerial;
    p.stateTimer = tuning().hurtStagger;
    p.stateDuration = p.stateTimer;
    p.pendingSkill = nullptr;
  }
}

void World::StepProjectiles(float dt) {
  for (auto& pr : projectiles_) {
    const Vec3 next = pr.pos + pr.vel * dt;
    pr.life -= dt;
    Vec3 a = pr.pos, b = next;
    a.y = b.y = 0.f;
    if (arena_.Blocked(a, b) || std::fabs(next.x) > arena_.half || std::fabs(next.z) > arena_.half) {
      pr.life = 0.f;
      continue;
    }
    pr.pos = next;
    const Player& p = player_;
    if (p.Alive() && p.invuln <= 0.f && DistanceXZ(pr.pos, p.pos) <= tuning().playerRadius + 0.25f) {
      DamagePlayer(pr.attack, pr.power, pr.type, pr.pos, false);
      pr.life = 0.f;
    }
  }
  projectiles_.erase(
      std::remove_if(projectiles_.begin(), projectiles_.end(), [](const Projectile& p) { return p.life <= 0.f; }),
      projectiles_.end());
}

void World::Separate() {
  for (std::size_t i = 0; i < enemies_.size(); ++i) {
    Enemy& a = enemies_[i];
    if (!a.Alive()) continue;
    for (std::size_t j = i + 1; j < enemies_.size(); ++j) {
      Enemy& b = enemies_[j];
      if (!b.Alive()) continue;
      const float min = a.def->radius + b.def->radius;
      const float d = DistanceXZ(a.pos, b.pos);
      if (d >= min) continue;
      Vec3 n = d > 1e-4f ? NormalizeXZ(a.pos - b.pos) : Vec3{1.f, 0.f, 0.f};
      const float push = (min - d) * 0.5f;
      a.pos = arena_.ResolveCircle(a.pos + n * push, a.def->radius);
      b.pos = arena_.ResolveCircle(b.pos - n * push, b.def->radius);
    }
    if (player_.Alive()) {
      const float min = a.def->radius + tuning().playerRadius;
      const float d = DistanceXZ(a.pos, player_.pos);
      if (d < min) {
        const Vec3 n = d > 1e-4f ? NormalizeXZ(a.pos - player_.pos) : Vec3{1.f, 0.f, 0.f};
        a.pos = arena_.ResolveCircle(player_.pos + n * min, a.def->radius);
      }
    }
  }
}

}  // namespace ascend
