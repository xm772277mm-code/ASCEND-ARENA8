#pragma once
// Player profile: everything that is saved. Pure data + rules, no I/O (see save.h for persistence).
#include <map>
#include <set>
#include <string>
#include <vector>

#include "../content_db.h"
#include "../loadout.h"
#include "../world.h"

namespace ascend {

constexpr int kSaveVersion = 2;
constexpr int kInventorySlots = 40;
constexpr int kMaxGold = 99999999;

struct ItemStack {
  std::string id;
  int count = 0;
};

struct Settings {
  std::string language = "en";
  int musicVolume = 70;            // 0..100
  int sfxVolume = 80;              // 0..100
  int sensitivity = 100;           // percent, 50..200
  std::string quality = "medium";  // low | medium | high
  bool invertY = false;
  bool showDebug = false;
  float textScale = 1.0f;  // accessibility, 0.8..1.6
};

struct Profile {
  int version = kSaveVersion;
  std::string name = "Hunter";
  std::string characterId = "kael";
  std::string outfitId;  // empty = default outfit
  int level = 1;
  int xp = 0;
  int gold = 0;
  std::vector<ItemStack> inventory;              // at most kInventorySlots stacks
  std::map<std::string, std::string> equipment;  // slot name (weapon|armor|accessory) -> item id
  std::set<std::string> unlockedCharacters{"kael"};
  std::set<std::string> claimedRewards;  // one-time reward ids (first clears, chapters)
  std::set<std::string> completedMissions;
  std::map<std::string, int> missionBestScore;
  int storyChapter = 1;  // highest unlocked chapter (1-based)
  int storyChaptersCleared = 0;
  int dungeonBestRoom = 0;
  long lastRunId = 0;  // highest run result already applied (anti-duplication)
  Settings settings;
};

// ---- progression rules --------------------------------------------------------------------

// XP needed to advance from `level` to level+1 (strictly increasing).
int XpToNext(int level);

// Adds XP, handles multiple level-ups, stops at kMaxLevel (xp stays 0 there). Returns levels gained.
int AddXp(Profile& p, int amount);
// Adds gold clamped to [0, kMaxGold]; returns the amount actually added.
int AddGold(Profile& p, int amount);
// Tries to spend gold; false (and no change) when not enough.
bool SpendGold(Profile& p, int amount);

// ---- inventory & equipment ------------------------------------------------------------------

// Adds items respecting stack limits and the slot limit. Returns how many were added.
int AddItem(const ContentDb& db, Profile& p, const std::string& id, int count);
// Removes up to `count`; returns how many were removed.
int RemoveItem(Profile& p, const std::string& id, int count);
int CountItem(const Profile& p, const std::string& id);
const char* SlotName(ItemSlot s);

enum class EquipResult { Ok, UnknownItem, NotOwned, NotEquippable, InventoryFull };
// Moves one item from the inventory into its slot; the previous occupant returns to the inventory.
EquipResult Equip(const ContentDb& db, Profile& p, const std::string& itemId);
bool Unequip(const ContentDb& db, Profile& p, const std::string& slot);
EquipmentBonus BonusFor(const ContentDb& db, const Profile& p);

// Uses one consumable; returns the heal amount (0 when not usable / not owned).
int UseConsumable(const ContentDb& db, Profile& p, const std::string& itemId);

// ---- rewards ----------------------------------------------------------------------------------

struct Reward {
  int xp = 0;
  int gold = 0;
  std::vector<ItemStack> items;
};
struct GrantResult {
  int levelsGained = 0;
  int goldGranted = 0;
  int overflowGold = 0;  // items that did not fit are sold for their value
  std::vector<ItemStack> itemsGranted;
};
GrantResult GrantReward(const ContentDb& db, Profile& p, const Reward& r);
// One-time rewards: returns false (and grants nothing) if `rewardId` was already claimed.
bool ClaimOnce(const ContentDb& db, Profile& p, const std::string& rewardId, const Reward& r,
               GrantResult* out = nullptr);
// Reward for a defeated enemy (XP scaled by level gap, gold, rolled drops from the world event).
GrantResult ApplyKill(const ContentDb& db, Profile& p, const GameEvent& defeatedEvent);
// Applies a finished run exactly once: a run id <= lastRunId is rejected (reload / retry safe).
bool ApplyRun(const ContentDb& db, Profile& p, long runId, const Reward& r, GrantResult* out = nullptr);

// ---- validation ---------------------------------------------------------------------------------

// Returns human-readable problems; empty means valid. Does not modify the profile.
std::vector<std::string> Validate(const ContentDb& db, const Profile& p);
// Repairs what can be repaired safely (clamps numbers, drops unknown items). Returns what it changed.
std::vector<std::string> Sanitize(const ContentDb& db, Profile& p);

// Unlocks every character whose unlock level has been reached. Returns the ids newly unlocked.
std::vector<std::string> SyncUnlocks(const ContentDb& db, Profile& p);

PlayerLoadout LoadoutFor(const ContentDb& db, const Profile& p);

}  // namespace ascend
