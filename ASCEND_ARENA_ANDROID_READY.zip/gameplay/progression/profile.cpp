#include "profile.h"

#include <algorithm>

#include "../combat/damage.h"

namespace ascend {

int XpToNext(int level) {
  level = ClampInt(level, 1, kMaxLevel);
  const int l = level - 1;
  return 100 + 50 * l + 10 * l * l;
}

int AddXp(Profile& p, int amount) {
  if (amount <= 0 || p.level >= kMaxLevel) return 0;
  long xp = static_cast<long>(p.xp) + amount;
  int gained = 0;
  while (p.level < kMaxLevel && xp >= XpToNext(p.level)) {
    xp -= XpToNext(p.level);
    ++p.level;
    ++gained;
  }
  p.xp = p.level >= kMaxLevel ? 0 : static_cast<int>(xp);
  return gained;
}

int AddGold(Profile& p, int amount) {
  if (amount <= 0) return 0;
  const int room = kMaxGold - p.gold;
  const int add = std::min(amount, std::max(0, room));
  p.gold += add;
  return add;
}

bool SpendGold(Profile& p, int amount) {
  if (amount < 0 || p.gold < amount) return false;
  p.gold -= amount;
  return true;
}

const char* SlotName(ItemSlot s) {
  switch (s) {
    case ItemSlot::Weapon:
      return "weapon";
    case ItemSlot::Armor:
      return "armor";
    case ItemSlot::Accessory:
      return "accessory";
    case ItemSlot::Consumable:
      return "consumable";
    case ItemSlot::Material:
      return "material";
  }
  return "material";
}

int AddItem(const ContentDb& db, Profile& p, const std::string& id, int count) {
  const ItemDef* def = db.Item(id);
  if (!def || count <= 0) return 0;
  int left = count;
  for (auto& st : p.inventory) {
    if (st.id != id || st.count >= def->stackMax) continue;
    const int add = std::min(left, def->stackMax - st.count);
    st.count += add;
    left -= add;
    if (left == 0) break;
  }
  while (left > 0 && static_cast<int>(p.inventory.size()) < kInventorySlots) {
    const int add = std::min(left, def->stackMax);
    p.inventory.push_back({id, add});
    left -= add;
  }
  return count - left;
}

int RemoveItem(Profile& p, const std::string& id, int count) {
  int left = std::max(0, count);
  for (auto it = p.inventory.rbegin(); it != p.inventory.rend() && left > 0; ++it) {
    if (it->id != id) continue;
    const int take = std::min(left, it->count);
    it->count -= take;
    left -= take;
  }
  p.inventory.erase(
      std::remove_if(p.inventory.begin(), p.inventory.end(), [](const ItemStack& s) { return s.count <= 0; }),
      p.inventory.end());
  return count - left > 0 ? count - left : 0;
}

int CountItem(const Profile& p, const std::string& id) {
  int n = 0;
  for (const auto& s : p.inventory)
    if (s.id == id) n += s.count;
  return n;
}

EquipResult Equip(const ContentDb& db, Profile& p, const std::string& itemId) {
  const ItemDef* def = db.Item(itemId);
  if (!def) return EquipResult::UnknownItem;
  if (def->slot != ItemSlot::Weapon && def->slot != ItemSlot::Armor && def->slot != ItemSlot::Accessory)
    return EquipResult::NotEquippable;
  if (CountItem(p, itemId) < 1) return EquipResult::NotOwned;
  RemoveItem(p, itemId, 1);  // frees a slot first so the swap below always fits
  const std::string slot = SlotName(def->slot);
  auto it = p.equipment.find(slot);
  if (it != p.equipment.end() && !it->second.empty()) {
    if (AddItem(db, p, it->second, 1) != 1) {
      AddItem(db, p, itemId, 1);  // roll back
      return EquipResult::InventoryFull;
    }
  }
  p.equipment[slot] = itemId;
  return EquipResult::Ok;
}

bool Unequip(const ContentDb& db, Profile& p, const std::string& slot) {
  auto it = p.equipment.find(slot);
  if (it == p.equipment.end() || it->second.empty()) return false;
  if (AddItem(db, p, it->second, 1) != 1) return false;  // no room: keep it equipped
  p.equipment.erase(it);
  return true;
}

EquipmentBonus BonusFor(const ContentDb& db, const Profile& p) {
  EquipmentBonus b;
  for (const auto& [slot, id] : p.equipment) {
    (void)slot;
    if (const ItemDef* d = db.Item(id)) {
      b.attack += d->bonusAttack;
      b.defense += d->bonusDefense;
      b.hp += d->bonusHp;
    }
  }
  return b;
}

int UseConsumable(const ContentDb& db, Profile& p, const std::string& itemId) {
  const ItemDef* d = db.Item(itemId);
  if (!d || d->slot != ItemSlot::Consumable || d->healAmount <= 0) return 0;
  if (RemoveItem(p, itemId, 1) != 1) return 0;
  return d->healAmount;
}

GrantResult GrantReward(const ContentDb& db, Profile& p, const Reward& r) {
  GrantResult g;
  g.levelsGained = AddXp(p, r.xp);
  g.goldGranted = AddGold(p, r.gold);
  for (const auto& it : r.items) {
    const int added = AddItem(db, p, it.id, it.count);
    if (added > 0) g.itemsGranted.push_back({it.id, added});
    if (added < it.count) {
      const ItemDef* d = db.Item(it.id);
      const int sold = (it.count - added) * (d ? d->value : 0);
      g.overflowGold += AddGold(p, sold);
    }
  }
  return g;
}

bool ClaimOnce(const ContentDb& db, Profile& p, const std::string& rewardId, const Reward& r, GrantResult* out) {
  if (rewardId.empty() || p.claimedRewards.count(rewardId)) return false;
  p.claimedRewards.insert(rewardId);
  const GrantResult g = GrantReward(db, p, r);
  if (out) *out = g;
  return true;
}

GrantResult ApplyKill(const ContentDb& db, Profile& p, const GameEvent& ev) {
  Reward r;
  const EnemyDef* d = db.Enemy(ev.refId);
  r.xp = ScaledXpReward(ev.amount, ev.level, p.level);
  r.gold = d ? d->gold : 0;
  for (const auto& dr : ev.drops) r.items.push_back({dr.itemId, dr.count});
  return GrantReward(db, p, r);
}

bool ApplyRun(const ContentDb& db, Profile& p, long runId, const Reward& r, GrantResult* out) {
  if (runId <= p.lastRunId) return false;
  p.lastRunId = runId;
  const GrantResult g = GrantReward(db, p, r);
  if (out) *out = g;
  return true;
}

std::vector<std::string> Validate(const ContentDb& db, const Profile& p) {
  std::vector<std::string> e;
  if (p.level < 1 || p.level > kMaxLevel) e.push_back("level out of range: " + std::to_string(p.level));
  if (p.xp < 0 || (p.level < kMaxLevel && p.xp >= XpToNext(p.level))) e.push_back("xp out of range for level");
  if (p.gold < 0 || p.gold > kMaxGold) e.push_back("gold out of range");
  if (!db.Character(p.characterId)) e.push_back("unknown character '" + p.characterId + "'");
  if (!p.unlockedCharacters.count(p.characterId)) e.push_back("selected character is not unlocked");
  if (static_cast<int>(p.inventory.size()) > kInventorySlots) e.push_back("too many inventory slots");
  for (const auto& s : p.inventory) {
    const ItemDef* d = db.Item(s.id);
    if (!d)
      e.push_back("unknown inventory item '" + s.id + "'");
    else if (s.count < 1 || s.count > d->stackMax)
      e.push_back("bad stack count for '" + s.id + "'");
  }
  for (const auto& [slot, id] : p.equipment) {
    const ItemDef* d = db.Item(id);
    if (!d)
      e.push_back("unknown equipped item '" + id + "'");
    else if (slot != SlotName(d->slot))
      e.push_back("item '" + id + "' in wrong slot '" + slot + "'");
  }
  if (p.storyChapter < 1) e.push_back("story chapter < 1");
  return e;
}

std::vector<std::string> SyncUnlocks(const ContentDb& db, Profile& p) {
  std::vector<std::string> added;
  for (const auto& [id, ch] : db.characters())
    if (ch.unlockLevel <= p.level && p.unlockedCharacters.insert(id).second) added.push_back(id);
  return added;
}

std::vector<std::string> Sanitize(const ContentDb& db, Profile& p) {
  std::vector<std::string> changed;
  const int lv = ClampInt(p.level, 1, kMaxLevel);
  if (lv != p.level) {
    changed.push_back("level clamped");
    p.level = lv;
  }
  if (p.xp < 0) {
    p.xp = 0;
    changed.push_back("xp clamped");
  }
  if (p.level < kMaxLevel && p.xp >= XpToNext(p.level)) {
    p.xp = XpToNext(p.level) - 1;
    changed.push_back("xp clamped");
  }
  if (p.gold < 0 || p.gold > kMaxGold) {
    p.gold = ClampInt(p.gold, 0, kMaxGold);
    changed.push_back("gold clamped");
  }
  if (!db.Character(p.characterId)) {
    p.characterId = "kael";
    changed.push_back("character reset");
  }
  p.unlockedCharacters.insert(p.characterId);
  std::vector<ItemStack> keep;
  for (auto s : p.inventory) {
    const ItemDef* d = db.Item(s.id);
    if (!d || s.count < 1) {
      changed.push_back("dropped item '" + s.id + "'");
      continue;
    }
    s.count = std::min(s.count, d->stackMax);
    if (static_cast<int>(keep.size()) >= kInventorySlots) {
      changed.push_back("dropped overflow stack");
      continue;
    }
    keep.push_back(s);
  }
  p.inventory = keep;
  for (auto it = p.equipment.begin(); it != p.equipment.end();) {
    const ItemDef* d = db.Item(it->second);
    if (!d || it->first != SlotName(d->slot)) {
      changed.push_back("removed bad equipment '" + it->second + "'");
      it = p.equipment.erase(it);
    } else {
      ++it;
    }
  }
  const Settings def;
  Settings& s = p.settings;
  s.musicVolume = ClampInt(s.musicVolume, 0, 100);
  s.sfxVolume = ClampInt(s.sfxVolume, 0, 100);
  s.sensitivity = ClampInt(s.sensitivity, 50, 200);
  s.textScale = Clamp(s.textScale, 0.8f, 1.6f);
  if (s.quality != "low" && s.quality != "medium" && s.quality != "high") s.quality = def.quality;
  if (s.language.empty()) s.language = def.language;
  p.storyChapter = std::max(1, p.storyChapter);
  return changed;
}

PlayerLoadout LoadoutFor(const ContentDb& db, const Profile& p) {
  const CharacterDef* ch = db.Character(p.characterId);
  if (!ch) ch = db.Character("kael");
  return BuildLoadout(db, *ch, p.level, BonusFor(db, p));
}

}  // namespace ascend
