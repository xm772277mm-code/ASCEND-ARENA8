#pragma once
// Versioned, checksummed save files with migration, backup and corruption recovery.
// Format: text "key=value" lines, first line "ASCEND_SAVE", last line "checksum=<fnv1a64 hex>".
#include <string>
#include <vector>

#include "profile.h"

namespace ascend {

std::string SerializeProfile(const Profile& p);

enum class LoadKind {
  Fresh,  // no save existed: a new default profile
  Ok,
  Migrated,             // an older version was upgraded in memory
  RecoveredFromBackup,  // main file corrupt, .bak used
  CorruptReset,         // main and backup unusable: default profile, bad file kept as .corrupt
  TooNew                // written by a newer game: not loaded, never overwritten
};

struct LoadReport {
  LoadKind kind = LoadKind::Fresh;
  Profile profile;
  std::string message;
  std::vector<std::string> repairs;  // what Sanitize changed
};

// Parses text (no I/O). On failure `ok` is false and `error` explains why.
struct ParseResult {
  bool ok = false;
  bool tooNew = false;
  bool migrated = false;
  Profile profile;
  std::string error;
};
ParseResult DeserializeProfile(const std::string& text);

class SaveStore {
 public:
  explicit SaveStore(std::string path) : path_(std::move(path)) {}
  // Atomic: writes <path>.tmp, verifies it by reading back, keeps the previous file as <path>.bak, renames.
  Status Save(const Profile& p);
  LoadReport Load(const ContentDb& db);
  const std::string& path() const { return path_; }

 private:
  std::string path_;
  bool blocked_ = false;  // a newer save exists: refuse to overwrite it
};

}  // namespace ascend
