#include "save.h"

#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>

namespace ascend {
namespace {

namespace fs = std::filesystem;

std::uint64_t Fnv1a(const std::string& s) {
  std::uint64_t h = 1469598103934665603ull;
  for (unsigned char c : s) {
    h ^= c;
    h *= 1099511628211ull;
  }
  return h;
}

std::string Hex(std::uint64_t v) {
  static const char* d = "0123456789abcdef";
  std::string s(16, '0');
  for (int i = 15; i >= 0; --i) {
    s[static_cast<std::size_t>(i)] = d[v & 0xF];
    v >>= 4;
  }
  return s;
}

std::string Clean(std::string s, std::size_t maxLen) {
  std::string out;
  for (char c : s)
    if (c != '\n' && c != '\r') out += c;
  if (out.size() > maxLen) out.resize(maxLen);
  return out;
}

std::vector<std::string> Split(const std::string& s, char sep) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == sep) {
      if (!cur.empty()) out.push_back(cur);
      cur.clear();
    } else {
      cur += c;
    }
  }
  if (!cur.empty()) out.push_back(cur);
  return out;
}

std::string Join(const std::set<std::string>& v) {
  std::string s;
  for (const auto& x : v) s += (s.empty() ? "" : ",") + x;
  return s;
}

bool ToInt(const std::string& s, long& out) {
  if (s.empty() || s.size() > 12) return false;
  std::size_t i = (s[0] == '-') ? 1 : 0;
  if (i == s.size()) return false;
  for (std::size_t k = i; k < s.size(); ++k)
    if (s[k] < '0' || s[k] > '9') return false;
  out = std::stol(s);
  return true;
}

bool ReadFile(const std::string& path, std::string& out) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return false;
  std::ostringstream ss;
  ss << f.rdbuf();
  out = ss.str();
  return true;
}

}  // namespace

std::string SerializeProfile(const Profile& p) {
  std::ostringstream o;
  o << "ASCEND_SAVE\n";
  o << "version=" << kSaveVersion << "\n";
  o << "name=" << Clean(p.name, 24) << "\n";
  o << "character=" << p.characterId << "\n";
  o << "outfit=" << p.outfitId << "\n";
  o << "level=" << p.level << "\nxp=" << p.xp << "\ngold=" << p.gold << "\n";
  o << "chapter=" << p.storyChapter << "\nchapters_cleared=" << p.storyChaptersCleared << "\n";
  o << "dungeon_best=" << p.dungeonBestRoom << "\nlast_run=" << p.lastRunId << "\n";
  for (std::size_t i = 0; i < p.inventory.size(); ++i)
    o << "inv." << i << "=" << p.inventory[i].id << ":" << p.inventory[i].count << "\n";
  for (const auto& [slot, id] : p.equipment) o << "eq." << slot << "=" << id << "\n";
  o << "unlocked=" << Join(p.unlockedCharacters) << "\n";
  o << "claimed=" << Join(p.claimedRewards) << "\n";
  o << "missions=" << Join(p.completedMissions) << "\n";
  for (const auto& [id, s] : p.missionBestScore) o << "best." << id << "=" << s << "\n";
  const Settings& s = p.settings;
  o << "set.language=" << s.language << "\nset.music=" << s.musicVolume << "\nset.sfx=" << s.sfxVolume
    << "\nset.sensitivity=" << s.sensitivity << "\nset.quality=" << s.quality
    << "\nset.invert_y=" << (s.invertY ? 1 : 0) << "\nset.debug=" << (s.showDebug ? 1 : 0)
    << "\nset.text_scale=" << std::lround(s.textScale * 100.f) << "\n";
  std::string body = o.str();
  return body + "checksum=" + Hex(Fnv1a(body)) + "\n";
}

ParseResult DeserializeProfile(const std::string& text) {
  ParseResult r;
  std::istringstream in(text);
  std::string line;
  if (!std::getline(in, line) || line != "ASCEND_SAVE") {
    r.error = "missing ASCEND_SAVE header";
    return r;
  }
  std::map<std::string, std::string> kv;
  std::string body = "ASCEND_SAVE\n";
  while (std::getline(in, line)) {
    if (line.empty()) continue;
    const auto eq = line.find('=');
    if (eq == std::string::npos || eq == 0) {
      r.error = "malformed line: '" + line.substr(0, 40) + "'";
      return r;
    }
    const std::string k = line.substr(0, eq), v = line.substr(eq + 1);
    if (kv.count(k)) {
      r.error = "duplicate key '" + k + "'";
      return r;
    }
    kv[k] = v;
    if (k != "checksum") body += line + "\n";
  }
  long version = 0;
  if (!kv.count("version") || !ToInt(kv["version"], version) || version < 1) {
    r.error = "missing or invalid version";
    return r;
  }
  if (version > kSaveVersion) {
    r.tooNew = true;
    r.error =
        "save version " + std::to_string(version) + " is newer than this game (" + std::to_string(kSaveVersion) + ")";
    return r;
  }
  if (version >= 2) {
    if (!kv.count("checksum") || kv["checksum"] != Hex(Fnv1a(body))) {
      r.error = "checksum mismatch (file damaged or edited)";
      return r;
    }
  }
  Profile p;
  auto num = [&](const char* key, int& dst) -> bool {
    if (!kv.count(key)) return true;  // optional: keep default
    long v = 0;
    if (!ToInt(kv[key], v) || v < -1000000000L || v > 1000000000L) {
      r.error = std::string("invalid number for '") + key + "'";
      return false;
    }
    dst = static_cast<int>(v);
    return true;
  };
  if (kv.count("name")) p.name = Clean(kv["name"], 24);
  if (kv.count("character")) p.characterId = kv["character"];
  if (kv.count("outfit")) p.outfitId = kv["outfit"];
  if (!num("level", p.level) || !num("xp", p.xp) || !num("gold", p.gold)) return r;
  if (version >= 2) {
    if (!num("chapter", p.storyChapter) || !num("chapters_cleared", p.storyChaptersCleared) ||
        !num("dungeon_best", p.dungeonBestRoom))
      return r;
    if (kv.count("last_run")) {
      long v = 0;
      if (!ToInt(kv["last_run"], v)) {
        r.error = "invalid last_run";
        return r;
      }
      p.lastRunId = v;
    }
    for (const auto& [k, v] : kv) {
      if (k.rfind("inv.", 0) == 0) {
        const auto c = v.find(':');
        long n = 0;
        if (c == std::string::npos || !ToInt(v.substr(c + 1), n)) {
          r.error = "bad inventory entry '" + k + "'";
          return r;
        }
        p.inventory.push_back({v.substr(0, c), static_cast<int>(n)});
      } else if (k.rfind("eq.", 0) == 0) {
        p.equipment[k.substr(3)] = v;
      } else if (k.rfind("best.", 0) == 0) {
        long n = 0;
        if (!ToInt(v, n)) {
          r.error = "bad score '" + k + "'";
          return r;
        }
        p.missionBestScore[k.substr(5)] = static_cast<int>(n);
      }
    }
    // Inventory order: numeric suffix order (map order would sort "inv.10" before "inv.2").
    std::vector<ItemStack> ordered;
    for (std::size_t i = 0;; ++i) {
      const auto it = kv.find("inv." + std::to_string(i));
      if (it == kv.end()) break;
      const auto c = it->second.find(':');
      long n = 0;
      ToInt(it->second.substr(c + 1), n);
      ordered.push_back({it->second.substr(0, c), static_cast<int>(n)});
    }
    p.inventory = ordered;
    if (kv.count("unlocked")) {
      p.unlockedCharacters.clear();
      for (auto& x : Split(kv["unlocked"], ',')) p.unlockedCharacters.insert(x);
    }
    for (auto& x : Split(kv.count("claimed") ? kv["claimed"] : "", ',')) p.claimedRewards.insert(x);
    for (auto& x : Split(kv.count("missions") ? kv["missions"] : "", ',')) p.completedMissions.insert(x);
    Settings& s = p.settings;
    if (kv.count("set.language")) s.language = kv["set.language"];
    if (kv.count("set.quality")) s.quality = kv["set.quality"];
    int ts = 100;
    if (!num("set.music", s.musicVolume) || !num("set.sfx", s.sfxVolume) || !num("set.sensitivity", s.sensitivity) ||
        !num("set.text_scale", ts))
      return r;
    s.textScale = static_cast<float>(ts) / 100.f;
    int b = 0;
    if (!num("set.invert_y", b)) return r;
    s.invertY = b != 0;
    b = 0;
    if (!num("set.debug", b)) return r;
    s.showDebug = b != 0;
  } else {
    // v1 (legacy): single-line inventory "id:count,id:count", no equipment/settings/checksum.
    for (auto& tok : Split(kv.count("inv") ? kv["inv"] : "", ',')) {
      const auto c = tok.find(':');
      long n = 0;
      if (c == std::string::npos || !ToInt(tok.substr(c + 1), n)) {
        r.error = "bad legacy inventory entry '" + tok + "'";
        return r;
      }
      p.inventory.push_back({tok.substr(0, c), static_cast<int>(n)});
    }
    r.migrated = true;
  }
  p.version = kSaveVersion;
  if (p.unlockedCharacters.empty()) p.unlockedCharacters.insert(p.characterId);
  r.profile = p;
  r.ok = true;
  return r;
}

Status SaveStore::Save(const Profile& p) {
  if (blocked_) return Status::Error("refusing to overwrite a save written by a newer game version");
  const std::string text = SerializeProfile(p);
  const fs::path main(path_), tmp(path_ + ".tmp"), bak(path_ + ".bak");
  std::error_code ec;
  if (main.has_parent_path()) fs::create_directories(main.parent_path(), ec);
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return Status::Error("cannot open " + tmp.string() + " for writing");
    f.write(text.data(), static_cast<std::streamsize>(text.size()));
    f.flush();
    if (!f) return Status::Error("write failed (disk full?) for " + tmp.string());
  }
  std::string back;
  if (!ReadFile(tmp.string(), back) || back != text) {
    fs::remove(tmp, ec);
    return Status::Error("verification of the written save failed");
  }
  if (fs::exists(main, ec)) fs::copy_file(main, bak, fs::copy_options::overwrite_existing, ec);
  fs::rename(tmp, main, ec);
  if (ec) return Status::Error("rename failed: " + ec.message());
  return Status::Ok();
}

LoadReport SaveStore::Load(const ContentDb& db) {
  LoadReport rep;
  std::error_code ec;
  const fs::path main(path_), bak(path_ + ".bak");
  auto finish = [&](ParseResult pr, LoadKind kind, std::string msg) {
    rep.profile = pr.profile;
    rep.repairs = Sanitize(db, rep.profile);
    rep.kind = pr.migrated && kind == LoadKind::Ok ? LoadKind::Migrated : kind;
    rep.message = std::move(msg);
    return rep;
  };
  std::string text;
  const bool haveMain = fs::exists(main, ec) && ReadFile(path_, text);
  if (!haveMain && !fs::exists(bak, ec)) {
    rep.kind = LoadKind::Fresh;
    rep.message = "no save found; starting a new profile";
    return rep;
  }
  std::string problem = "save file unreadable";
  if (haveMain) {
    ParseResult pr = DeserializeProfile(text);
    if (pr.ok) return finish(pr, LoadKind::Ok, "loaded");
    if (pr.tooNew) {
      blocked_ = true;
      rep.kind = LoadKind::TooNew;
      rep.message = pr.error;
      return rep;
    }
    problem = pr.error;
    fs::copy_file(main, path_ + ".corrupt", fs::copy_options::overwrite_existing, ec);  // keep evidence
  }
  std::string btext;
  if (ReadFile(bak.string(), btext)) {
    ParseResult pr = DeserializeProfile(btext);
    if (pr.ok) return finish(pr, LoadKind::RecoveredFromBackup, "main save damaged (" + problem + "); restored backup");
  }
  rep.kind = LoadKind::CorruptReset;
  rep.message = "save damaged (" + problem + ") and no usable backup; started a new profile";
  return rep;
}

}  // namespace ascend
