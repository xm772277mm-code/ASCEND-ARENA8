#pragma once
// Third-person orbit/follow camera with safe pitch/distance limits and wall avoidance.
#include "../engine/render/math3d.h"
#include "world.h"

namespace ascend {

struct OrbitCameraConfig {
  float minPitch = -0.10f;  // radians; slightly below horizontal at most
  float maxPitch = 1.20f;   // ~69 degrees looking down
  float minDistance = 3.0f;
  float maxDistance = 12.0f;
  float defaultDistance = 7.5f;
  float defaultPitch = 0.45f;
  float targetHeight = 1.4f;  // look at the player's upper body
  float followSharpness = 14.f;
  float minEyeHeight = 0.4f;
  float obstacleMargin = 0.35f;
};

class OrbitCamera {
 public:
  explicit OrbitCamera(OrbitCameraConfig cfg = {});

  // Applies a look delta (radians). Yaw wraps; pitch and distance are clamped to the config limits.
  void ApplyLook(Vec2 delta, float sensitivity = 1.f, bool invertY = false);
  void SetDistance(float d);
  void SetYaw(float yaw) { yaw_ = WrapAngle(yaw); }
  // Advances smoothing and builds the render camera. `world` supplies obstacles for collision.
  Camera Update(Vec3 target, const ArenaDef& arena, float dt);
  // Snaps instantly (scene start / teleport).
  void Snap(Vec3 target);

  float yaw() const { return yaw_; }
  float pitch() const { return pitch_; }
  float distance() const { return distance_; }
  float effectiveDistance() const { return effective_; }
  const OrbitCameraConfig& config() const { return cfg_; }

 private:
  OrbitCameraConfig cfg_;
  float yaw_ = 0.f, pitch_, distance_, effective_;
  Vec3 smoothTarget_{};
  bool snapped_ = false;
};

}  // namespace ascend
