#pragma once
#include <string>

#include "../../engine/core/amath.h"

namespace ascend {

enum class DamageType { Physical, Fire, Shadow, Holy };

inline const char* DamageTypeName(DamageType t) {
  switch (t) {
    case DamageType::Physical:
      return "physical";
    case DamageType::Fire:
      return "fire";
    case DamageType::Shadow:
      return "shadow";
    case DamageType::Holy:
      return "holy";
  }
  return "physical";
}

// Resistances in percent (-100..90). 25 means 25% less damage of that type.
struct Resistances {
  int physical = 0, fire = 0, shadow = 0, holy = 0;
  int For(DamageType t) const {
    switch (t) {
      case DamageType::Physical:
        return physical;
      case DamageType::Fire:
        return fire;
      case DamageType::Shadow:
        return shadow;
      case DamageType::Holy:
        return holy;
    }
    return 0;
  }
};

// Core combat stats shared by player and enemies.
struct Stats {
  int maxHp = 100;
  int maxMana = 50;
  int attack = 10;
  int defense = 5;
  float moveSpeed = 5.f;  // meters / second
  Resistances resist;
};

// Simple bounded resource (health, mana).
struct Pool {
  int cur = 0, max = 0;

  static Pool Full(int m) { return {m, m}; }
  bool Empty() const { return cur <= 0; }
  // Applies damage, clamps at 0, returns the amount actually removed.
  int Remove(int n) {
    if (n < 0) n = 0;
    const int taken = n < cur ? n : cur;
    cur -= taken;
    return taken;
  }
  // Adds, clamps at max, returns the amount actually added.
  int Add(int n) {
    if (n < 0) n = 0;
    const int room = max - cur;
    const int added = n < room ? n : room;
    cur += added;
    return added;
  }
  void SetMax(int m, bool refill) {
    max = m < 1 ? 1 : m;
    cur = refill ? max : (cur > max ? max : cur);
  }
  float Fraction() const { return max > 0 ? static_cast<float>(cur) / static_cast<float>(max) : 0.f; }
};

class Cooldown {
 public:
  bool Ready() const { return remaining_ <= 0.f; }
  void Start(float seconds) {
    remaining_ = seconds > 0.f ? seconds : 0.f;
    total_ = remaining_;
  }
  void Tick(float dt) {
    if (remaining_ > 0.f) {
      remaining_ -= dt;
      if (remaining_ < 0.f) remaining_ = 0.f;
    }
  }
  float remaining() const { return remaining_; }
  float Fraction() const { return total_ > 0.f ? remaining_ / total_ : 0.f; }  // 1 = just started
  void Reset() {
    remaining_ = 0.f;
    total_ = 0.f;
  }

 private:
  float remaining_ = 0.f, total_ = 0.f;
};

}  // namespace ascend
