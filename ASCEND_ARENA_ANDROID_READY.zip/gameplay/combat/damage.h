#pragma once
#include "combat_types.h"

namespace ascend {

// Integer damage formula (deterministic across platforms):
//   raw   = attack * powerPercent / 100
//   after = raw - defense / 2           (defense only applies to physical)
//   final = after * (100 - resist) / 100
// The result is always at least 1 unless resist >= 100 (immune => 0).
// `crit` multiplies the final damage by 1.5.
int ComputeDamage(int attackerAttack, int powerPercent, DamageType type, const Stats& defender, bool crit = false);

// Experience value of a defeated enemy, scaled down when the player out-levels it
// so low-level enemies cannot be farmed for the full reward.
int ScaledXpReward(int baseXp, int enemyLevel, int playerLevel);

}  // namespace ascend
