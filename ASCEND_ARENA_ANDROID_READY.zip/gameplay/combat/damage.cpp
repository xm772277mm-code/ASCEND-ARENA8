#include "damage.h"

namespace ascend {

int ComputeDamage(int attackerAttack, int powerPercent, DamageType type, const Stats& defender, bool crit) {
  if (attackerAttack < 0) attackerAttack = 0;
  if (powerPercent < 0) powerPercent = 0;
  int resist = defender.resist.For(type);
  resist = ClampInt(resist, -100, 100);
  if (resist >= 100) return 0;  // immune

  long raw = static_cast<long>(attackerAttack) * powerPercent / 100;
  if (type == DamageType::Physical) raw -= defender.defense / 2;
  long after = raw * (100 - resist) / 100;
  if (crit) after = after * 3 / 2;
  if (after < 1) after = 1;
  if (after > 999999) after = 999999;
  return static_cast<int>(after);
}

int ScaledXpReward(int baseXp, int enemyLevel, int playerLevel) {
  if (baseXp <= 0) return 0;
  const int gap = playerLevel - enemyLevel;
  if (gap <= 2) return baseXp;
  // 20% less per level beyond a 2-level grace gap, never below 10%.
  int pct = 100 - (gap - 2) * 20;
  if (pct < 10) pct = 10;
  const int v = baseXp * pct / 100;
  return v < 1 ? 1 : v;
}

}  // namespace ascend
