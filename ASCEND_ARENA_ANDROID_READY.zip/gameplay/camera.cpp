#include "camera.h"

#include <cmath>

namespace ascend {

OrbitCamera::OrbitCamera(OrbitCameraConfig cfg)
    : cfg_(cfg), pitch_(cfg.defaultPitch), distance_(cfg.defaultDistance), effective_(cfg.defaultDistance) {}

void OrbitCamera::ApplyLook(Vec2 d, float sensitivity, bool invertY) {
  if (!std::isfinite(d.x) || !std::isfinite(d.y)) return;  // ignore corrupt input
  sensitivity = Clamp(sensitivity, 0.1f, 4.f);
  yaw_ = WrapAngle(yaw_ + d.x * sensitivity);
  pitch_ = Clamp(pitch_ + (invertY ? -d.y : d.y) * sensitivity, cfg_.minPitch, cfg_.maxPitch);
}

void OrbitCamera::SetDistance(float d) { distance_ = Clamp(d, cfg_.minDistance, cfg_.maxDistance); }

void OrbitCamera::Snap(Vec3 target) {
  smoothTarget_ = target;
  snapped_ = true;
}

Camera OrbitCamera::Update(Vec3 target, const ArenaDef& arena, float dt) {
  if (!snapped_) Snap(target);
  const float k = 1.f - std::exp(-cfg_.followSharpness * Clamp(dt, 0.f, 0.25f));
  smoothTarget_.x = Lerp(smoothTarget_.x, target.x, k);
  smoothTarget_.z = Lerp(smoothTarget_.z, target.z, k);
  const Vec3 look{smoothTarget_.x, cfg_.targetHeight, smoothTarget_.z};

  const Vec3 fwd = ForwardFromYaw(yaw_);
  const float cp = std::cos(pitch_), sp = std::sin(pitch_);
  auto eyeAt = [&](float dist) {
    return Vec3{look.x - fwd.x * cp * dist, look.y + sp * dist, look.z - fwd.z * cp * dist};
  };

  // Pull the camera in when an obstacle is between it and the player (binary search along the boom).
  float dist = distance_;
  // Obstacles are treated as 3.2 m tall: the boom is blocked only where it is below that height.
  constexpr float kObstacleHeight = 3.2f;
  // The arena border counts as an obstacle too: an eye outside the walls would look at their back faces and
  // hide the floor (visible at every mission start, when the player spawns near a wall).
  const float inside = arena.half - 0.4f;
  auto blocked = [&](float dd) {
    const Vec3 e = eyeAt(dd);
    if (std::fabs(e.x) > inside || std::fabs(e.z) > inside) return true;
    for (const auto& o : arena.obstacles) {
      const Aabb2 g{o.minX - cfg_.obstacleMargin, o.minZ - cfg_.obstacleMargin, o.maxX + cfg_.obstacleMargin,
                    o.maxZ + cfg_.obstacleMargin};
      for (int i = 1; i <= 24; ++i) {
        const float t = static_cast<float>(i) / 24.f;
        const float x = Lerp(look.x, e.x, t), z = Lerp(look.z, e.z, t), y = Lerp(look.y, e.y, t);
        if (x >= g.minX && x <= g.maxX && z >= g.minZ && z <= g.maxZ && y < kObstacleHeight) return true;
      }
    }
    return false;
  };
  if (blocked(dist)) {
    float lo = cfg_.minDistance * 0.5f, hi = dist;
    for (int i = 0; i < 8; ++i) {
      const float mid = 0.5f * (lo + hi);
      if (blocked(mid))
        hi = mid;
      else
        lo = mid;
    }
    dist = std::max(lo, 1.0f);
  }
  effective_ = dist;
  Vec3 eye = eyeAt(dist);
  eye.y = std::max(eye.y, cfg_.minEyeHeight);
  eye.x = Clamp(eye.x, -inside, inside);  // final safety: never outside the walls, even with the player hugging one
  eye.z = Clamp(eye.z, -inside, inside);
  Camera c;
  c.eye = eye;
  c.target = look;
  return c;
}

}  // namespace ascend
