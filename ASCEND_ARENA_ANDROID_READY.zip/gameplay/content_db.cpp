#include "content_db.h"

#include <algorithm>
#include <filesystem>
#include <set>

#include "../engine/input/input.h"

namespace ascend {
namespace {

struct Ctx {
  std::string file;
  const IniSection* sec;
  std::vector<std::string>* err;

  void Err(const std::string& m) const { err->push_back(file + " [" + sec->name + "]: " + m); }
  std::string Req(const std::string& k) const {
    if (!sec->Has(k) || sec->Str(k).empty()) {
      Err("missing required key '" + k + "'");
      return "";
    }
    return sec->Str(k);
  }
  int IntIn(const std::string& k, int lo, int hi, int def, bool required = false) const {
    if (!sec->Has(k)) {
      if (required) Err("missing required key '" + k + "'");
      return def;
    }
    auto v = sec->Int(k);
    if (!v) {
      Err("key '" + k + "' is not an integer: '" + sec->Str(k) + "'");
      return def;
    }
    if (*v < lo || *v > hi) {
      Err("key '" + k + "' = " + std::to_string(*v) + " out of range [" + std::to_string(lo) + "," +
          std::to_string(hi) + "]");
      return def;
    }
    return *v;
  }
  float FloatIn(const std::string& k, float lo, float hi, float def, bool required = false) const {
    if (!sec->Has(k)) {
      if (required) Err("missing required key '" + k + "'");
      return def;
    }
    auto v = sec->Float(k);
    if (!v) {
      Err("key '" + k + "' is not a number: '" + sec->Str(k) + "'");
      return def;
    }
    if (*v < lo || *v > hi) {
      Err("key '" + k + "' = " + sec->Str(k) + " out of range [" + std::to_string(lo) + "," + std::to_string(hi) + "]");
      return def;
    }
    return *v;
  }
};

}  // namespace

bool ParseDamageType(const std::string& s, DamageType& out) {
  if (s == "physical")
    out = DamageType::Physical;
  else if (s == "fire")
    out = DamageType::Fire;
  else if (s == "shadow")
    out = DamageType::Shadow;
  else if (s == "holy")
    out = DamageType::Holy;
  else
    return false;
  return true;
}

void ContentDb::ParseTuning(const IniDocument& d, std::vector<std::string>& err) {
  const IniSection* t = d.Find("tuning");
  if (!t) {
    err.push_back("combat.ini: missing [tuning] section");
    return;
  }
  Ctx c{"combat.ini", t, &err};
  tuning_.playerRadius = c.FloatIn("player_radius", 0.2f, 1.5f, tuning_.playerRadius);
  tuning_.hitDelay = c.FloatIn("hit_delay", 0.f, 1.f, tuning_.hitDelay);
  tuning_.comboWindow = c.FloatIn("combo_window", 0.1f, 3.f, tuning_.comboWindow);
  tuning_.dodgeDistance = c.FloatIn("dodge_distance", 0.5f, 12.f, tuning_.dodgeDistance);
  tuning_.dodgeTime = c.FloatIn("dodge_time", 0.05f, 2.f, tuning_.dodgeTime);
  tuning_.dodgeInvuln = c.FloatIn("dodge_invuln", 0.f, 2.f, tuning_.dodgeInvuln);
  tuning_.dodgeCooldown = c.FloatIn("dodge_cooldown", 0.1f, 20.f, tuning_.dodgeCooldown);
  tuning_.manaRegenPerSec = c.FloatIn("mana_regen", 0.f, 100.f, tuning_.manaRegenPerSec);
  tuning_.hurtStagger = c.FloatIn("hurt_stagger", 0.f, 2.f, tuning_.hurtStagger);
  tuning_.critChancePercent = c.IntIn("crit_chance", 0, 100, tuning_.critChancePercent);
  tuning_.projectileSpeed = c.FloatIn("projectile_speed", 1.f, 40.f, tuning_.projectileSpeed);
  if (tuning_.dodgeInvuln > tuning_.dodgeCooldown)
    c.Err("dodge_invuln must not exceed dodge_cooldown (permanent invulnerability)");
}

void ContentDb::ParseSkills(const IniDocument& d, std::vector<std::string>& err) {
  for (const auto& s : d.sections) {
    Ctx c{"skills.ini", &s, &err};
    SkillDef k;
    k.id = s.name;
    k.nameKey = c.Req("name_key");
    const std::string kind = c.Req("kind");
    if (kind == "arc")
      k.kind = SkillKind::Arc;
    else if (kind == "circle")
      k.kind = SkillKind::Circle;
    else if (kind == "dash")
      k.kind = SkillKind::Dash;
    else if (!kind.empty())
      c.Err("unknown kind '" + kind + "' (arc|circle|dash)");
    const std::string type = s.Str("type", "physical");
    if (!ParseDamageType(type, k.type)) c.Err("unknown damage type '" + type + "'");
    k.powerPercent = c.IntIn("power", 1, 2000, 100, true);
    k.cooldown = c.FloatIn("cooldown", 0.f, 120.f, 1.f, true);
    k.manaCost = c.IntIn("mana", 0, 1000, 0);
    k.range = c.FloatIn("range", 0.5f, 30.f, 2.f, true);
    k.arcDegrees = c.FloatIn("arc", 10.f, 360.f, 90.f);
    k.knockback = c.FloatIn("knockback", 0.f, 10.f, 0.f);
    k.stagger = c.FloatIn("stagger", 0.f, 5.f, 0.f);
    k.unlockLevel = c.IntIn("unlock_level", 1, 100, 1);
    if (!skills_.emplace(k.id, k).second) c.Err("duplicate skill id across files");
  }
}

void ContentDb::ParseEnemies(const IniDocument& d, std::vector<std::string>& err) {
  for (const auto& s : d.sections) {
    Ctx c{"enemies.ini", &s, &err};
    EnemyDef e;
    e.id = s.name;
    e.nameKey = c.Req("name_key");
    e.level = c.IntIn("level", 1, 100, 1, true);
    e.stats.maxHp = c.IntIn("hp", 1, 1000000, 50, true);
    e.stats.attack = c.IntIn("attack", 0, 100000, 5, true);
    e.stats.defense = c.IntIn("defense", 0, 100000, 0);
    e.stats.moveSpeed = c.FloatIn("speed", 0.f, 20.f, 3.f, true);
    e.radius = c.FloatIn("radius", 0.2f, 3.f, 0.5f);
    e.detectRange = c.FloatIn("detect_range", 1.f, 60.f, 10.f);
    e.loseRange = c.FloatIn("lose_range", 1.f, 100.f, 16.f);
    e.attackRange = c.FloatIn("attack_range", 0.5f, 40.f, 1.8f);
    e.windup = c.FloatIn("windup", 0.1f, 5.f, 0.6f);
    e.recover = c.FloatIn("recover", 0.1f, 10.f, 0.8f);
    e.damagePercent = c.IntIn("damage_percent", 1, 1000, 100);
    const std::string dt = s.Str("damage_type", "physical");
    if (!ParseDamageType(dt, e.damageType)) c.Err("unknown damage type '" + dt + "'");
    e.ranged = s.IntOr("ranged", 0) != 0;
    e.xp = c.IntIn("xp", 0, 1000000, 10);
    e.gold = c.IntIn("gold", 0, 1000000, 0);
    e.staggerResist = c.FloatIn("stagger_resist", 0.f, 1.f, 0.f);
    e.knockbackResist = c.FloatIn("knockback_resist", 0.f, 1.f, 0.f);
    e.patrolRadius = c.FloatIn("patrol_radius", 0.f, 30.f, 3.f);
    e.dummy = s.IntOr("dummy", 0) != 0;
    e.enrageBelowPercent = c.IntIn("enrage_below_percent", 0, 99, 0);
    e.enrageSpeedMult = c.FloatIn("enrage_speed_mult", 1.f, 3.f, 1.3f);
    e.stats.resist.physical = c.IntIn("resist_physical", -100, 90, 0);
    e.stats.resist.fire = c.IntIn("resist_fire", -100, 90, 0);
    e.stats.resist.shadow = c.IntIn("resist_shadow", -100, 90, 0);
    e.stats.resist.holy = c.IntIn("resist_holy", -100, 90, 0);
    if (e.loseRange < e.detectRange) c.Err("lose_range must be >= detect_range");
    // drops = item:chance[:count], item:chance ...
    for (const auto& tok : s.List("drops")) {
      DropDef dd;
      const auto a = tok.find(':');
      if (a == std::string::npos) {
        c.Err("malformed drop '" + tok + "' (expected item:chance[:count])");
        continue;
      }
      dd.itemId = tok.substr(0, a);
      std::string rest = tok.substr(a + 1);
      const auto b = rest.find(':');
      try {
        dd.chancePercent = std::stoi(b == std::string::npos ? rest : rest.substr(0, b));
        if (b != std::string::npos) dd.count = std::stoi(rest.substr(b + 1));
      } catch (...) {
        c.Err("malformed drop numbers in '" + tok + "'");
        continue;
      }
      if (dd.chancePercent < 0 || dd.chancePercent > 100 || dd.count < 1 || dd.count > 99)
        c.Err("drop '" + tok + "' has chance/count out of range");
      e.drops.push_back(dd);
    }
    if (!enemies_.emplace(e.id, e).second) c.Err("duplicate enemy id across files");
  }
}

void ContentDb::ParseItems(const IniDocument& d, std::vector<std::string>& err) {
  for (const auto& s : d.sections) {
    Ctx c{"items.ini", &s, &err};
    ItemDef it;
    it.id = s.name;
    it.nameKey = c.Req("name_key");
    const std::string slot = c.Req("slot");
    if (slot == "weapon")
      it.slot = ItemSlot::Weapon;
    else if (slot == "armor")
      it.slot = ItemSlot::Armor;
    else if (slot == "accessory")
      it.slot = ItemSlot::Accessory;
    else if (slot == "consumable")
      it.slot = ItemSlot::Consumable;
    else if (slot == "material")
      it.slot = ItemSlot::Material;
    else if (!slot.empty())
      c.Err("unknown slot '" + slot + "'");
    it.stackMax = c.IntIn("stack", 1, 999, 1);
    it.bonusAttack = c.IntIn("bonus_attack", 0, 100000, 0);
    it.bonusDefense = c.IntIn("bonus_defense", 0, 100000, 0);
    it.bonusHp = c.IntIn("bonus_hp", 0, 100000, 0);
    it.healAmount = c.IntIn("heal", 0, 100000, 0);
    it.value = c.IntIn("value", 0, 10000000, 0);
    const bool equip = it.slot == ItemSlot::Weapon || it.slot == ItemSlot::Armor || it.slot == ItemSlot::Accessory;
    if (equip && it.stackMax != 1) c.Err("equipment must have stack = 1");
    if (!items_.emplace(it.id, it).second) c.Err("duplicate item id across files");
  }
}

void ContentDb::ParseCharacters(const IniDocument& d, std::vector<std::string>& err) {
  for (const auto& s : d.sections) {
    Ctx c{"characters", &s, &err};
    CharacterDef ch;
    ch.id = s.name;
    ch.nameKey = c.Req("name_key");
    ch.rarity = c.IntIn("rarity", 1, 5, 1, true);
    ch.baseStats.maxHp = c.IntIn("hp", 1, 100000, 100, true);
    ch.baseStats.maxMana = c.IntIn("mana", 0, 100000, 50, true);
    ch.baseStats.attack = c.IntIn("attack", 0, 100000, 10, true);
    ch.baseStats.defense = c.IntIn("defense", 0, 100000, 5, true);
    ch.baseStats.moveSpeed = c.FloatIn("speed", 1.f, 15.f, 5.f, true);
    ch.hpPerLevel = c.IntIn("hp_per_level", 0, 1000, 12);
    ch.attackPerLevel = c.IntIn("attack_per_level", 0, 1000, 2);
    ch.defensePerLevel = c.IntIn("defense_per_level", 0, 1000, 1);
    ch.manaPerLevel = c.IntIn("mana_per_level", 0, 1000, 4);
    ch.skills = s.List("skills");
    ch.lightCombo = s.List("light_combo");
    if (ch.lightCombo.empty() || ch.lightCombo.size() > 4) c.Err("light_combo needs 1..4 skill ids");
    ch.heavySkill = c.Req("heavy");
    if (static_cast<int>(ch.skills.size()) != kMaxSkills)
      c.Err("needs exactly " + std::to_string(kMaxSkills) + " skills, found " + std::to_string(ch.skills.size()));
    ch.modelPath = c.Req("model");
    ch.animationSet = s.Str("animation_set", "");
    ch.unlockLevel = c.IntIn("unlock_level", 1, 100, 1);
    for (const auto& [k, v] : s.values)
      if (k.rfind("anim.", 0) == 0) ch.animMap[k.substr(5)] = v;
    ch.assetSource = c.Req("asset_source");
    ch.assetLicense = c.Req("asset_license");
    ch.assetAuthor = c.Req("asset_author");
    for (const auto& oid : s.List("outfits")) {
      OutfitDef o;
      o.id = oid;
      o.nameKey = s.Str("outfit." + oid + ".name_key");
      o.meshPath = s.Str("outfit." + oid + ".mesh");
      o.materialPath = s.Str("outfit." + oid + ".material");
      o.unlockLevel = s.IntOr("outfit." + oid + ".unlock_level", 1);
      if (o.nameKey.empty()) c.Err("outfit '" + oid + "' missing outfit." + oid + ".name_key");
      if (o.meshPath.empty() && o.materialPath.empty())
        c.Err("outfit '" + oid + "' must override a mesh or a material");
      ch.outfits.push_back(o);
    }
    if (!characters_.emplace(ch.id, ch).second) c.Err("duplicate character id across files");
  }
}

void ContentDb::CrossValidate(std::vector<std::string>& err) {
  for (const auto& [id, ch] : characters_) {
    for (const auto& sk : ch.skills)
      if (!skills_.count(sk)) err.push_back("character [" + id + "]: unknown skill '" + sk + "'");
    for (const auto& sk : ch.lightCombo)
      if (!skills_.count(sk)) err.push_back("character [" + id + "]: unknown light_combo skill '" + sk + "'");
    if (!ch.heavySkill.empty() && !skills_.count(ch.heavySkill))
      err.push_back("character [" + id + "]: unknown heavy skill '" + ch.heavySkill + "'");
  }
  for (const auto& [id, e] : enemies_)
    for (const auto& d : e.drops)
      if (!items_.count(d.itemId)) err.push_back("enemy [" + id + "]: drop references unknown item '" + d.itemId + "'");
}

std::vector<std::string> ContentDb::LoadFromDocs(const IniDocument* skills, const IniDocument* enemies,
                                                 const IniDocument* items, const std::vector<IniDocument>& characters,
                                                 const IniDocument* combat) {
  std::vector<std::string> err;
  if (combat) ParseTuning(*combat, err);
  if (skills) ParseSkills(*skills, err);
  if (items) ParseItems(*items, err);
  if (enemies) ParseEnemies(*enemies, err);
  for (const auto& c : characters) ParseCharacters(c, err);
  CrossValidate(err);
  return err;
}

std::vector<std::string> ContentDb::LoadFromDirectory(const std::string& root) {
  namespace fs = std::filesystem;
  std::vector<std::string> err;
  auto load = [&](const std::string& rel, IniDocument& out) {
    auto r = LoadIniFile((fs::path(root) / rel).string());
    if (!r) {
      err.push_back(r.status.message);
      return false;
    }
    out = std::move(r.value);
    return true;
  };
  IniDocument sk, en, it, cb;
  const bool d0 = load("data/combat.ini", cb);
  const bool a = load("data/skills.ini", sk);
  const bool b = load("data/enemies.ini", en);
  const bool c = load("data/items.ini", it);
  std::vector<IniDocument> chars;
  const fs::path cdir = fs::path(root) / "characters";
  std::error_code ec;
  std::vector<std::string> files;
  for (const auto& e : fs::directory_iterator(cdir, ec))
    if (e.path().extension() == ".ini") files.push_back(e.path().string());
  if (ec) err.push_back(cdir.string() + ": cannot list directory (" + ec.message() + ")");
  std::sort(files.begin(), files.end());  // deterministic order
  for (const auto& f : files) {
    auto r = LoadIniFile(f);
    if (!r)
      err.push_back(r.status.message);
    else
      chars.push_back(std::move(r.value));
  }
  auto more = LoadFromDocs(a ? &sk : nullptr, b ? &en : nullptr, c ? &it : nullptr, chars, d0 ? &cb : nullptr);
  err.insert(err.end(), more.begin(), more.end());
  return err;
}

const SkillDef* ContentDb::Skill(const std::string& id) const {
  auto i = skills_.find(id);
  return i == skills_.end() ? nullptr : &i->second;
}
const EnemyDef* ContentDb::Enemy(const std::string& id) const {
  auto i = enemies_.find(id);
  return i == enemies_.end() ? nullptr : &i->second;
}
const ItemDef* ContentDb::Item(const std::string& id) const {
  auto i = items_.find(id);
  return i == items_.end() ? nullptr : &i->second;
}
const CharacterDef* ContentDb::Character(const std::string& id) const {
  auto i = characters_.find(id);
  return i == characters_.end() ? nullptr : &i->second;
}

}  // namespace ascend
