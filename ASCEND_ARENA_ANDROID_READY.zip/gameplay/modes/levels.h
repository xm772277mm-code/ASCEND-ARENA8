#pragma once
// Data-driven game modes: Missions, Training, Dungeons, Story. Loaded from content/levels/levels.ini.
#include <map>
#include <string>
#include <vector>

#include "../content_db.h"
#include "../progression/profile.h"

namespace ascend {

enum class ModeKind { Mission, Training, Dungeon, Story };
enum class Objective { KillAll, Survive };

struct SpawnDef {
  std::string enemyId;
  int count = 1;
};
using WaveDef = std::vector<SpawnDef>;

struct ArenaSpec {
  std::string id;
  ArenaDef arena;
};

struct StageDef {
  std::string arenaId;
  std::vector<WaveDef> waves;
};

struct EncounterDef {
  std::string id;
  ModeKind kind = ModeKind::Mission;
  std::string nameKey, descKey;
  Objective objective = Objective::KillAll;
  int enemyLevel = 0;  // 0 = use each enemy's own level
  int unlockLevel = 1;
  int chapter = 0;               // story only (1-based)
  std::vector<StageDef> stages;  // missions/story: 1, dungeons: several rooms
  float surviveSeconds = 0.f;
  float spawnInterval = 8.f;  // survive mode: seconds between waves
  float timeLimit = 0.f;      // 0 = none
  int trainingDummies = 0;
  Reward reward;                                          // every successful clear
  Reward firstClear;                                      // once per profile
  std::vector<std::string> introDialogue, outroDialogue;  // localization keys
};

class LevelsDb {
 public:
  // Reads <root>/levels/levels.ini. Returns all errors (empty == valid).
  std::vector<std::string> LoadFromDirectory(const std::string& root, const ContentDb& db);
  std::vector<std::string> LoadFromDoc(const IniDocument& doc, const ContentDb& db);

  const EncounterDef* Find(const std::string& id) const;
  const ArenaSpec* Arena(const std::string& id) const;
  std::vector<const EncounterDef*> OfKind(ModeKind k) const;  // sorted by id (chapter for story)
  const std::map<std::string, EncounterDef>& all() const { return encounters_; }
  const std::map<std::string, ArenaSpec>& arenas() const { return arenas_; }

 private:
  std::map<std::string, EncounterDef> encounters_;
  std::map<std::string, ArenaSpec> arenas_;
};

const char* ModeKindName(ModeKind k);

}  // namespace ascend
