#include "levels.h"

#include <algorithm>
#include <cmath>
#include <filesystem>

namespace ascend {
namespace {

std::string Trim(const std::string& s) {
  const auto a = s.find_first_not_of(" \t");
  if (a == std::string::npos) return "";
  return s.substr(a, s.find_last_not_of(" \t") - a + 1);
}

std::vector<std::string> SplitOn(const std::string& s, char sep) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == sep) {
      out.push_back(Trim(cur));
      cur.clear();
    } else {
      cur += c;
    }
  }
  out.push_back(Trim(cur));
  return out;
}

bool ParseInt(const std::string& s, int& out) {
  try {
    std::size_t n = 0;
    out = std::stoi(s, &n);
    return n == s.size();
  } catch (...) {
    return false;
  }
}

bool ParseFloat(const std::string& s, float& out) {
  try {
    std::size_t n = 0;
    out = std::stof(s, &n);
    return n == s.size();
  } catch (...) {
    return false;
  }
}

}  // namespace

const char* ModeKindName(ModeKind k) {
  switch (k) {
    case ModeKind::Mission:
      return "mission";
    case ModeKind::Training:
      return "training";
    case ModeKind::Dungeon:
      return "dungeon";
    case ModeKind::Story:
      return "story";
  }
  return "mission";
}

std::vector<std::string> LevelsDb::LoadFromDirectory(const std::string& root, const ContentDb& db) {
  auto r = LoadIniFile((std::filesystem::path(root) / "levels" / "levels.ini").string());
  if (!r) return {r.status.message};
  return LoadFromDoc(r.value, db);
}

std::vector<std::string> LevelsDb::LoadFromDoc(const IniDocument& doc, const ContentDb& db) {
  std::vector<std::string> err;
  auto E = [&](const IniSection& s, const std::string& m) { err.push_back("levels.ini [" + s.name + "]: " + m); };

  // Arenas first.
  for (const auto& s : doc.sections) {
    if (s.name.rfind("arena.", 0) != 0) continue;
    ArenaSpec a;
    a.id = s.name.substr(6);
    float half = 12.f;
    if (s.Has("half") && (!ParseFloat(s.Str("half"), half) || half < 6.f || half > 40.f)) E(s, "half must be 6..40");
    a.arena.half = half;
    for (const auto& tok : SplitOn(s.Str("pillars"), ',')) {
      if (tok.empty()) continue;
      const auto p = SplitOn(tok, ':');
      float x = 0.f, z = 0.f, sz = 0.f;
      if (p.size() != 3 || !ParseFloat(p[0], x) || !ParseFloat(p[1], z) || !ParseFloat(p[2], sz) || sz < 0.5f ||
          sz > 8.f) {
        E(s, "bad pillar '" + tok + "' (expected x:z:size)");
        continue;
      }
      if (std::fabs(x) + sz * 0.5f >= half - 1.f || std::fabs(z) + sz * 0.5f >= half - 1.f) {
        E(s, "pillar '" + tok + "' too close to the border");
        continue;
      }
      a.arena.obstacles.push_back({x - sz * 0.5f, z - sz * 0.5f, x + sz * 0.5f, z + sz * 0.5f});
    }
    if (!arenas_.emplace(a.id, a).second) E(s, "duplicate arena id");
  }

  auto parseReward = [&](const IniSection& s, const std::string& prefix, Reward& r) {
    int v = 0;
    if (s.Has(prefix + "xp")) {
      if (!ParseInt(s.Str(prefix + "xp"), v) || v < 0 || v > 1000000)
        E(s, prefix + "xp invalid");
      else
        r.xp = v;
    }
    if (s.Has(prefix + "gold")) {
      if (!ParseInt(s.Str(prefix + "gold"), v) || v < 0 || v > 1000000)
        E(s, prefix + "gold invalid");
      else
        r.gold = v;
    }
    for (const auto& tok : SplitOn(s.Str(prefix + "items"), ',')) {
      if (tok.empty()) continue;
      const auto p = SplitOn(tok, ':');
      int n = 0;
      if (p.size() != 2 || !ParseInt(p[1], n) || n < 1 || n > 99) {
        E(s, prefix + "items: bad entry '" + tok + "'");
        continue;
      }
      if (!db.Item(p[0])) {
        E(s, prefix + "items: unknown item '" + p[0] + "'");
        continue;
      }
      r.items.push_back({p[0], n});
    }
  };

  for (const auto& s : doc.sections) {
    const auto dot = s.name.find('.');
    if (dot == std::string::npos) {
      E(s, "section name must be <kind>.<id>");
      continue;
    }
    const std::string kindStr = s.name.substr(0, dot), id = s.name.substr(dot + 1);
    if (kindStr == "arena") continue;
    EncounterDef d;
    d.id = id;
    if (kindStr == "mission")
      d.kind = ModeKind::Mission;
    else if (kindStr == "training")
      d.kind = ModeKind::Training;
    else if (kindStr == "dungeon")
      d.kind = ModeKind::Dungeon;
    else if (kindStr == "story")
      d.kind = ModeKind::Story;
    else {
      E(s, "unknown section kind '" + kindStr + "'");
      continue;
    }
    d.nameKey = s.Str("name_key");
    d.descKey = s.Str("desc_key");
    if (d.nameKey.empty()) E(s, "missing name_key");
    const std::string obj = s.Str("objective", "kill_all");
    if (obj == "kill_all")
      d.objective = Objective::KillAll;
    else if (obj == "survive")
      d.objective = Objective::Survive;
    else
      E(s, "unknown objective '" + obj + "'");
    int iv = 0;
    float fv = 0.f;
    if (s.Has("level") && (!ParseInt(s.Str("level"), iv) || iv < 0 || iv > 100))
      E(s, "level invalid");
    else if (s.Has("level"))
      d.enemyLevel = iv;
    if (s.Has("unlock_level") && (!ParseInt(s.Str("unlock_level"), iv) || iv < 1 || iv > kMaxLevel))
      E(s, "unlock_level invalid");
    else if (s.Has("unlock_level"))
      d.unlockLevel = iv;
    if (s.Has("chapter") && (!ParseInt(s.Str("chapter"), iv) || iv < 1 || iv > 99))
      E(s, "chapter invalid");
    else if (s.Has("chapter"))
      d.chapter = iv;
    if (d.kind == ModeKind::Story && d.chapter < 1) E(s, "story needs chapter >= 1");
    if (s.Has("survive_seconds") && (!ParseFloat(s.Str("survive_seconds"), fv) || fv < 5.f || fv > 3600.f))
      E(s, "survive_seconds invalid");
    else if (s.Has("survive_seconds"))
      d.surviveSeconds = fv;
    if (s.Has("spawn_interval") && (!ParseFloat(s.Str("spawn_interval"), fv) || fv < 1.f || fv > 120.f))
      E(s, "spawn_interval invalid");
    else if (s.Has("spawn_interval"))
      d.spawnInterval = fv;
    if (s.Has("time_limit") && (!ParseFloat(s.Str("time_limit"), fv) || fv < 0.f || fv > 3600.f))
      E(s, "time_limit invalid");
    else if (s.Has("time_limit"))
      d.timeLimit = fv;
    if (d.objective == Objective::Survive && d.surviveSeconds <= 0.f) E(s, "survive objective needs survive_seconds");
    if (s.Has("dummies") && (!ParseInt(s.Str("dummies"), iv) || iv < 1 || iv > 8))
      E(s, "dummies must be 1..8");
    else if (s.Has("dummies"))
      d.trainingDummies = iv;
    parseReward(s, "reward_", d.reward);
    parseReward(s, "first_clear_", d.firstClear);
    if (d.kind == ModeKind::Training && (d.reward.xp || d.reward.gold || !d.reward.items.empty()))
      E(s, "training must not give rewards");
    d.introDialogue = SplitOn(s.Str("intro_dialogue"), ',');
    d.outroDialogue = SplitOn(s.Str("outro_dialogue"), ',');
    d.introDialogue.erase(std::remove(d.introDialogue.begin(), d.introDialogue.end(), ""), d.introDialogue.end());
    d.outroDialogue.erase(std::remove(d.outroDialogue.begin(), d.outroDialogue.end(), ""), d.outroDialogue.end());

    for (int n = 1; n <= 12; ++n) {
      const std::string pre = "stage." + std::to_string(n) + ".";
      if (!s.Has(pre + "arena")) break;
      StageDef st;
      st.arenaId = s.Str(pre + "arena");
      if (!arenas_.count(st.arenaId)) E(s, "unknown arena '" + st.arenaId + "'");
      for (const auto& wv : SplitOn(s.Str(pre + "waves"), '|')) {
        if (wv.empty()) continue;
        WaveDef w;
        for (const auto& tok : SplitOn(wv, ',')) {
          const auto p = SplitOn(tok, ':');
          int cnt = 0;
          if (p.size() != 2 || !ParseInt(p[1], cnt) || cnt < 1 || cnt > 12) {
            E(s, "bad spawn '" + tok + "' (expected enemy:count, count 1..12)");
            continue;
          }
          if (!db.Enemy(p[0])) {
            E(s, "unknown enemy '" + p[0] + "'");
            continue;
          }
          w.push_back({p[0], cnt});
        }
        if (!w.empty()) st.waves.push_back(w);
      }
      if (st.waves.empty() && d.kind != ModeKind::Training) E(s, pre + "waves is empty");
      d.stages.push_back(st);
    }
    if (d.stages.empty()) E(s, "needs at least one stage (stage.1.arena)");
    if (d.kind != ModeKind::Dungeon && d.stages.size() > 1) E(s, "only dungeons may have several stages");
    if (d.kind == ModeKind::Dungeon && d.stages.size() < 2) E(s, "a dungeon needs at least 2 rooms");
    if (!encounters_.emplace(d.id, d).second) E(s, "duplicate encounter id '" + d.id + "'");
  }

  // Story chapters must be contiguous 1..N and each chapter unique.
  std::vector<int> chapters;
  for (const auto& [id, e] : encounters_) {
    (void)id;
    if (e.kind == ModeKind::Story) chapters.push_back(e.chapter);
  }
  std::sort(chapters.begin(), chapters.end());
  for (std::size_t i = 0; i < chapters.size(); ++i)
    if (chapters[i] != static_cast<int>(i) + 1) {
      err.push_back("levels.ini: story chapters must be 1..N without gaps or duplicates");
      break;
    }
  return err;
}

const EncounterDef* LevelsDb::Find(const std::string& id) const {
  auto it = encounters_.find(id);
  return it == encounters_.end() ? nullptr : &it->second;
}

const ArenaSpec* LevelsDb::Arena(const std::string& id) const {
  auto it = arenas_.find(id);
  return it == arenas_.end() ? nullptr : &it->second;
}

std::vector<const EncounterDef*> LevelsDb::OfKind(ModeKind k) const {
  std::vector<const EncounterDef*> v;
  for (const auto& [id, e] : encounters_) {
    (void)id;
    if (e.kind == k) v.push_back(&e);
  }
  if (k == ModeKind::Story)
    std::sort(v.begin(), v.end(), [](const EncounterDef* a, const EncounterDef* b) { return a->chapter < b->chapter; });
  return v;
}

}  // namespace ascend
