#pragma once
// Builds the player's combat loadout (stats + skills) from character data, level and equipment.
#include "content_db.h"
#include "world.h"

namespace ascend {

struct EquipmentBonus {
  int attack = 0, defense = 0, hp = 0;
};

// Level is clamped to [1, kMaxLevel]. Skills that do not exist in the database stay null
// (the validator reports them at load time; the world treats a null skill slot as empty).
PlayerLoadout BuildLoadout(const ContentDb& db, const CharacterDef& ch, int level, const EquipmentBonus& bonus = {});

constexpr int kMaxLevel = 60;

}  // namespace ascend
