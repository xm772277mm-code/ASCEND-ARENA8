#pragma once
// Data-driven game content: skills, enemies, items, characters. Loaded from INI files and
// validated; every problem is reported with file/section context rather than ignored.
#include <map>
#include <string>
#include <vector>

#include "../engine/assets/ini.h"
#include "combat/combat_types.h"

namespace ascend {

enum class SkillKind { Arc, Circle, Dash };
enum class ItemSlot { Weapon, Armor, Accessory, Consumable, Material };

struct SkillDef {
  std::string id;
  std::string nameKey;
  SkillKind kind = SkillKind::Arc;
  DamageType type = DamageType::Physical;
  int powerPercent = 100;
  float cooldown = 1.f;
  int manaCost = 0;
  float range = 2.f;        // arc/circle reach; dash distance for Dash
  float arcDegrees = 90.f;  // full cone width for Arc
  float knockback = 0.f;    // meters
  float stagger = 0.f;      // seconds the target is stunned
  int unlockLevel = 1;
};

struct DropDef {
  std::string itemId;
  int chancePercent = 0;
  int count = 1;
};

struct EnemyDef {
  std::string id;
  std::string nameKey;
  int level = 1;
  Stats stats;
  float radius = 0.5f;
  float detectRange = 10.f;
  float loseRange = 16.f;  // gives up chasing beyond this distance
  float attackRange = 1.8f;
  float windup = 0.6f;   // telegraph time before the strike lands
  float recover = 0.8f;  // vulnerable time after striking
  int damagePercent = 100;
  DamageType damageType = DamageType::Physical;
  bool ranged = false;
  int xp = 10;
  int gold = 5;
  float staggerResist = 0.f;  // 0..1 fraction of stagger duration ignored
  float knockbackResist = 0.f;
  float patrolRadius = 3.f;
  bool dummy = false;          // training dummy: never acts, heals when left alone, gives no rewards
  int enrageBelowPercent = 0;  // 0 = never; otherwise below this hp% the enemy is faster and winds up quicker
  float enrageSpeedMult = 1.3f;
  std::vector<DropDef> drops;
};

// Global combat numbers (content/data/combat.ini [tuning]); every field has a validated range.
struct CombatTuning {
  float playerRadius = 0.45f;
  float hitDelay = 0.10f;     // seconds between pressing attack and the hit landing
  float comboWindow = 0.80f;  // seconds after an attack ends in which the next combo step continues
  float dodgeDistance = 3.6f;
  float dodgeTime = 0.22f;
  float dodgeInvuln = 0.30f;
  float dodgeCooldown = 0.9f;
  float manaRegenPerSec = 3.f;
  float hurtStagger = 0.25f;  // player cannot act this long after taking a hit
  int critChancePercent = 8;
  float projectileSpeed = 9.f;
};

struct ItemDef {
  std::string id;
  std::string nameKey;
  ItemSlot slot = ItemSlot::Material;
  int stackMax = 1;
  int bonusAttack = 0, bonusDefense = 0, bonusHp = 0;
  int healAmount = 0;
  int value = 0;
};

struct OutfitDef {
  std::string id;
  std::string nameKey;
  std::string meshPath;      // optional mesh override (relative to content root)
  std::string materialPath;  // optional material/texture override
  int unlockLevel = 1;
};

struct CharacterDef {
  std::string id;
  std::string nameKey;
  int rarity = 1;  // 1..5
  Stats baseStats;
  int hpPerLevel = 12, attackPerLevel = 2, defensePerLevel = 1, manaPerLevel = 4;
  std::vector<std::string> skills;      // exactly kMaxSkills ids
  std::vector<std::string> lightCombo;  // 1..4 skill ids used by the light attack button, in order
  std::string heavySkill;               // skill id used by the heavy attack button
  std::string modelPath;
  std::string animationSet;
  std::map<std::string, std::string>
      animMap;  // logical key (idle/walk/run/attack/hit/dodge/defeat) -> clip name; missing = same name
  std::vector<OutfitDef> outfits;
  int unlockLevel = 1;
  // License / source metadata (required by the validator).
  std::string assetSource;
  std::string assetLicense;
  std::string assetAuthor;
};

class ContentDb {
 public:
  // Loads content/data/{skills,enemies,items}.ini and content/characters/*.ini under `root`.
  // Returns all errors found (empty vector == valid).
  std::vector<std::string> LoadFromDirectory(const std::string& root);
  // Loads from already-parsed documents (used by tests).
  std::vector<std::string> LoadFromDocs(const IniDocument* skills, const IniDocument* enemies, const IniDocument* items,
                                        const std::vector<IniDocument>& characters,
                                        const IniDocument* combat = nullptr);

  const SkillDef* Skill(const std::string& id) const;
  const EnemyDef* Enemy(const std::string& id) const;
  const ItemDef* Item(const std::string& id) const;
  const CharacterDef* Character(const std::string& id) const;

  const CombatTuning& tuning() const { return tuning_; }
  const std::map<std::string, SkillDef>& skills() const { return skills_; }
  const std::map<std::string, EnemyDef>& enemies() const { return enemies_; }
  const std::map<std::string, ItemDef>& items() const { return items_; }
  const std::map<std::string, CharacterDef>& characters() const { return characters_; }

 private:
  void ParseTuning(const IniDocument& d, std::vector<std::string>& err);
  void ParseSkills(const IniDocument& d, std::vector<std::string>& err);
  void ParseEnemies(const IniDocument& d, std::vector<std::string>& err);
  void ParseItems(const IniDocument& d, std::vector<std::string>& err);
  void ParseCharacters(const IniDocument& d, std::vector<std::string>& err);
  void CrossValidate(std::vector<std::string>& err);

  CombatTuning tuning_;
  std::map<std::string, SkillDef> skills_;
  std::map<std::string, EnemyDef> enemies_;
  std::map<std::string, ItemDef> items_;
  std::map<std::string, CharacterDef> characters_;
};

bool ParseDamageType(const std::string& s, DamageType& out);

}  // namespace ascend
