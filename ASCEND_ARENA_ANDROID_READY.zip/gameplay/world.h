#pragma once
// ASCEND ENGINE gameplay world: deterministic, renderer-independent simulation of one arena.
// Everything here runs headless (unit tests, bots, CI). Rendering and UI only read this state.
#include <array>
#include <string>
#include <vector>

#include "../engine/core/amath.h"
#include "../engine/core/rng.h"
#include "../engine/input/input.h"
#include "combat/combat_types.h"
#include "content_db.h"

namespace ascend {

constexpr int kMaxEnemiesAlive = 24;  // hard spawn limit (performance + safety)
constexpr int kMaxProjectiles = 64;

struct ArenaDef {
  float half = 14.f;             // playable square is [-half, half] on x and z
  std::vector<Aabb2> obstacles;  // pillars / interior walls

  // Pushes a circle out of the arena border and all obstacles.
  Vec3 ResolveCircle(Vec3 p, float r) const;
  // True if a straight line between a and b passes through an obstacle (line of sight blocked).
  bool Blocked(Vec3 a, Vec3 b) const;
};

enum class PlayerState { Idle, Run, Attack, Dodge, Hurt, Dead };
enum class EnemyState { Idle, Patrol, Alert, Approach, Attack, Recover, Stagger, Defeated };

const char* EnemyStateName(EnemyState s);
const char* PlayerStateName(PlayerState s);

// What the progression layer hands to the world when the player is created or levels up.
struct PlayerLoadout {
  Stats stats;
  int level = 1;
  std::vector<const SkillDef*> lightCombo;
  const SkillDef* heavy = nullptr;
  std::array<const SkillDef*, kMaxSkills> skills{};
};

struct Player {
  Vec3 pos;
  float yaw = 0.f;
  Pool hp, mana;
  Stats stats;
  int level = 1;
  PlayerState state = PlayerState::Idle;
  float stateTimer = 0.f;     // remaining time of Attack/Dodge/Hurt
  float stateDuration = 0.f;  // total time of the current Attack/Dodge/Hurt (animation progress)
  float invuln = 0.f;         // remaining invulnerability seconds
  float flash = 0.f;          // hit feedback 0..1
  float animTime = 0.f;
  Vec3 dodgeDir;
  int actionSerial = 0;    // increments on every attack/dodge/hurt so animation can restart
  int comboIndex = 0;      // next light attack step
  float comboTimer = 0.f;  // time left to continue the combo
  std::array<Cooldown, kMaxSkills> skillCd;
  Cooldown dodgeCd;
  const SkillDef* pendingSkill = nullptr;  // hit that lands when pendingTimer reaches 0
  float pendingTimer = 0.f;
  float manaAcc = 0.f;
  const SkillDef* lastSkill = nullptr;  // for animation selection
  bool Alive() const { return state != PlayerState::Dead; }
};

struct Enemy {
  int uid = 0;
  const EnemyDef* def = nullptr;
  Stats stats;  // level-scaled copy
  int level = 1;
  Pool hp;
  Vec3 pos, home, patrolTarget;
  float yaw = 0.f;
  EnemyState state = EnemyState::Idle;
  float timer = 0.f;  // state timer
  float flash = 0.f;
  bool aware = false;
  bool enraged = false;
  bool strikeDone = false;
  float knockTimer = 0.f;
  Vec3 knockVel;
  float sinceHit = 0.f;  // seconds since last damage (training dummy regeneration)
  float animTime = 0.f;
  bool Alive() const { return state != EnemyState::Defeated; }
};

struct Projectile {
  Vec3 pos, vel;
  float life = 0.f;
  int attack = 0, power = 100;
  DamageType type = DamageType::Physical;
};

enum class EventType {
  PlayerHit,        // amount = damage
  PlayerDodgedHit,  // an attack was avoided by i-frames
  EnemyHit,         // actorId = enemy uid
  EnemyDefeated,    // refId = def id, drops filled
  EnemyEnraged,
  EnemyWindup,
  PlayerDefeated,
  SkillCast,  // refId = skill id
  DodgeStarted,
  ProjectileFired,
  SpawnRejected,  // refId = reason
  LevelUp         // amount = new level (emitted by the session, not the world)
};

struct DropResult {
  std::string itemId;
  int count = 1;
};

struct GameEvent {
  EventType type = EventType::PlayerHit;
  int actorId = 0;
  int amount = 0;
  int level = 1;
  bool crit = false;
  Vec3 pos;
  std::string refId;
  std::vector<DropResult> drops;
};

class World {
 public:
  World(const ContentDb* db, std::uint64_t seed);

  void SetArena(ArenaDef a) { arena_ = std::move(a); }
  const ArenaDef& arena() const { return arena_; }

  // Creates/replaces the player. Hp and mana start full.
  void SetPlayer(const PlayerLoadout& loadout, Vec3 pos);
  // Level-up / equipment change: new stats and skills; `healFull` refills hp+mana.
  void UpdatePlayerLoadout(const PlayerLoadout& loadout, bool healFull);

  // Returns the new enemy's uid, or -1 (and a SpawnRejected event) if unknown / over the limit / blocked.
  int SpawnEnemy(const std::string& defId, Vec3 pos, int levelOverride = 0, bool aware = false);

  // Advances the simulation by one fixed step. cameraYaw makes movement camera-relative.
  void Step(const InputFrame& in, float cameraYaw, float dt);

  const Player& player() const { return player_; }
  Player& mutablePlayer() { return player_; }
  const std::vector<Enemy>& enemies() const { return enemies_; }
  const std::vector<Projectile>& projectiles() const { return projectiles_; }
  int AliveEnemyCount() const;
  int TotalDefeated() const { return defeated_; }
  double time() const { return time_; }
  const CombatTuning& tuning() const { return db_->tuning(); }

  std::vector<GameEvent> TakeEvents();
  const PlayerLoadout& loadout() const { return loadout_; }

  // Nearest living enemy inside a cone in front of the player (aim assist and HUD target).
  const Enemy* NearestEnemyInCone(float range, float halfAngle) const;

 private:
  void StepPlayer(const InputFrame& in, float cameraYaw, float dt);
  bool CanAct() const;
  void BeginAttack(const SkillDef* skill, int slot);
  void ResolvePlayerSkill(const SkillDef& skill);
  void DoDash(const SkillDef& skill);
  void HitEnemy(Enemy& e, const SkillDef& skill);
  void StepEnemies(float dt);
  void StepEnemy(Enemy& e, float dt);
  void EnemyStrike(Enemy& e);
  void DamagePlayer(int attack, int power, DamageType type, Vec3 from, bool melee);
  void StepProjectiles(float dt);
  void Separate();
  void Defeat(Enemy& e);
  void Emit(GameEvent ev) { events_.push_back(std::move(ev)); }
  Enemy* FindEnemy(int uid);

  const ContentDb* db_;
  Rng rng_;
  ArenaDef arena_;
  Player player_;
  PlayerLoadout loadout_;
  std::vector<Enemy> enemies_;
  std::vector<Projectile> projectiles_;
  std::vector<GameEvent> events_;
  double time_ = 0.0;
  int bufferedAction_ = -1;  // input buffer so a press during recovery is not lost
  float bufferTimer_ = 0.f;
  int nextUid_ = 1;
  int defeated_ = 0;
};

}  // namespace ascend
