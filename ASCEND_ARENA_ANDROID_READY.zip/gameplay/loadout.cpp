#include "loadout.h"

namespace ascend {

PlayerLoadout BuildLoadout(const ContentDb& db, const CharacterDef& ch, int level, const EquipmentBonus& bonus) {
  level = ClampInt(level, 1, kMaxLevel);
  const int lv = level - 1;
  PlayerLoadout l;
  l.level = level;
  l.stats = ch.baseStats;
  l.stats.maxHp += ch.hpPerLevel * lv + bonus.hp;
  l.stats.maxMana += ch.manaPerLevel * lv;
  l.stats.attack += ch.attackPerLevel * lv + bonus.attack;
  l.stats.defense += ch.defensePerLevel * lv + bonus.defense;
  for (const auto& id : ch.lightCombo)
    if (const SkillDef* s = db.Skill(id)) l.lightCombo.push_back(s);
  l.heavy = db.Skill(ch.heavySkill);
  for (std::size_t i = 0; i < ch.skills.size() && i < l.skills.size(); ++i) l.skills[i] = db.Skill(ch.skills[i]);
  return l;
}

}  // namespace ascend
