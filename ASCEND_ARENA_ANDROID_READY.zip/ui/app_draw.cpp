#include <algorithm>
#include <cmath>

#include "app.h"
#include "ui_ctx.h"

namespace ascend {
namespace {

const Color kWhite{255, 255, 255, 255};
const Color kDim{175, 185, 220, 255};
const Color kGold{255, 215, 110, 255};
const Color kRed{255, 120, 120, 255};
const Color kGreen{140, 230, 160, 255};

float BtnH(UiCtx& c) { return std::max(9.f * c.mm, LineH(c, c.px) * 1.55f); }

bool IsCleared(const Profile& p, const EncounterDef& e) {
  switch (e.kind) {
    case ModeKind::Mission:
      return p.completedMissions.count(e.id) > 0;
    case ModeKind::Dungeon:
      return p.completedMissions.count("dungeon:" + e.id) > 0;
    case ModeKind::Story:
      return p.storyChaptersCleared >= e.chapter;
    case ModeKind::Training:
      return false;
  }
  return false;
}

}  // namespace

// --------------------------------------------------------------------------------- background

void App::DrawBackground(Framebuffer& fb, bool preview) {
  if (preview) {
    DrawPreview(fb);
  } else {
    fb.ClearGradient(Color{14, 16, 38, 255}, Color{40, 30, 66, 255});
  }
}

void App::DrawPreview(Framebuffer& fb) {
  fb.ClearGradient(Color{18, 20, 48, 255}, Color{70, 52, 96, 255});
  Camera cam;
  cam.fovY = 38.f * kPi / 180.f;
  cam.eye = {0.f, 1.45f, -4.6f};
  const float shift = rtl() ? -1.35f : 1.35f;  // model sits on the side opposite the menu
  cam.target = {shift, 1.0f, 0.f};
  Lighting light;
  light.fog = Color{70, 52, 96, 255};
  light.fogNear = 30.f;
  light.fogFar = 80.f;
  rast_.Begin(&fb, cam, light);
  static const Mesh disc = MakeDisc(1.35f, 32, Color{70, 74, 110, 255});
  static const Mesh ring = MakeDisc(1.5f, 32, Color{34, 36, 70, 255});
  DrawParams fp;
  fp.model = Mat4::Translation({0.f, 0.f, 0.f});
  fp.cull = false;
  rast_.Draw(ring, fp);
  fp.model = Mat4::Translation({0.f, 0.01f, 0.f});
  rast_.Draw(disc, fp);
  DrawParams dp;
  dp.model =
      Mat4::RotationY(kPi - 0.35f + std::sin(previewTime_ * 0.6f) * 0.35f);  // face the camera (it looks along +z)
  if (preview_ && !preview_->usedFallback) {
    rast_.Draw(preview_->skinned, dp);
  } else {
    static const HumanoidModel h = BuildHumanoid({});
    for (const Mesh* m : {&h.legL, &h.legR, &h.torso, &h.head, &h.armL, &h.armR, &h.weapon, &h.cape})
      rast_.Draw(*m, dp);
  }
}

// -------------------------------------------------------------------------------------- Draw

void App::Draw(Framebuffer& fb) {
  buttons_.clear();
  UiCtx c;
  c.fb = &fb;
  c.text = &text_;
  c.buttons = &buttons_;
  c.W = static_cast<float>(fb.width());
  c.H = static_cast<float>(fb.height());
  vw_ = fb.width();
  vh_ = fb.height();
  c.mm = pxPerMm_;
  c.margin = 3.f * pxPerMm_;
  const float ts = inited_ ? profile_.settings.textScale : 1.f;
  c.px = ClampInt(static_cast<int>(std::lround(4.1f * pxPerMm_ * ts)), 11, 64);
  c.pxBig = ClampInt(static_cast<int>(std::lround(static_cast<float>(c.px) * 1.5f)), 16, 96);
  c.pxSmall = ClampInt(static_cast<int>(std::lround(static_cast<float>(c.px) * 0.78f)), 10, 48);
  c.rtl = inited_ && loc_.IsRtl();

  if (!inited_) {
    fb.ClearGradient(Color{10, 10, 20, 255}, Color{30, 20, 40, 255});
    Put(c, c.W * 0.5f, c.H * 0.45f, "ASCEND ARENA", c.pxBig, kWhite, TextAlign::Center);
    return;
  }

  switch (screen_) {
    case Screen::InGame:
      DrawInGame(c);
      break;
    case Screen::Result:
      DrawBackground(fb, false);
      DrawResult(c);
      break;
    case Screen::Lobby:
      DrawBackground(fb, true);
      DrawLobby(c);
      break;
    case Screen::Characters:
      DrawBackground(fb, true);
      DrawCharacters(c);
      break;
    case Screen::Play:
      DrawBackground(fb, false);
      DrawPlay(c);
      break;
    case Screen::Encounters:
      DrawBackground(fb, false);
      DrawEncounters(c);
      break;
    case Screen::Inventory:
      DrawBackground(fb, false);
      DrawInventory(c);
      break;
    case Screen::Profile:
      DrawBackground(fb, false);
      DrawProfile(c);
      break;
    case Screen::Settings:
      DrawBackground(fb, false);
      DrawSettings(c);
      break;
    case Screen::Language:
      DrawBackground(fb, false);
      DrawLanguage(c);
      break;
  }
  if (overlay_ != Overlay::None) DrawOverlay(c);
}

// ------------------------------------------------------------------------------------ helpers

namespace {

// Back button (always the first button, at the start edge) + title text. Returns content top y.
float Header(UiCtx& c, const std::string& back, const std::string& title, const std::string& right) {
  const float bh = std::max(9.f * c.mm, LineH(c, c.px) * 1.55f);
  Btn(c, c.margin, c.margin, 20.f * c.mm, bh, "nav:back", back);
  const float tx = c.margin + 22.f * c.mm;
  PutStart(c, tx, c.margin + (bh - LineH(c, c.pxBig)) * 0.5f, c.W - tx - c.margin - 40.f * c.mm, title, c.pxBig,
           kWhite);
  if (!right.empty())
    PutEnd(c, c.W * 0.5f, c.margin + (bh - LineH(c, c.px)) * 0.5f, c.W * 0.5f - c.margin, right, c.px, kGold);
  return c.margin * 2.f + bh;
}

}  // namespace

// ------------------------------------------------------------------------------------- Lobby

void App::DrawLobby(UiCtx& c) {
  const CharacterDef* ch = db_.Character(profile_.characterId);
  // Character info card (under the preview).
  const float cw = c.W * 0.44f, chh = 4.2f * LineH(c, c.px);
  const float cy = c.H - c.margin - chh;
  Panel(c, c.margin, cy, cw, chh);
  PutStart(c, c.margin + c.margin * 0.5f, cy + c.margin * 0.4f, cw - c.margin,
           ch ? T(ch->nameKey) : profile_.characterId, c.pxBig, kWhite);
  const std::string stats =
      T("ui.level_short", {std::to_string(profile_.level)}) + "   " + T("ui.power", {std::to_string(Power())});
  PutStart(c, c.margin + c.margin * 0.5f, cy + c.margin * 0.4f + LineH(c, c.pxBig) * 1.1f, cw - c.margin, stats, c.px,
           kDim);
  PutStart(c, c.margin + c.margin * 0.5f, cy + c.margin * 0.4f + LineH(c, c.pxBig) * 1.1f + LineH(c, c.px) * 1.1f,
           cw - c.margin, T("ui.gold") + ": " + std::to_string(profile_.gold), c.px, kGold);

  // Navigation (opposite side of the preview).
  const float nx = c.W * 0.52f, nw = c.W * 0.48f - c.margin;
  PutStart(c, nx, c.margin, nw, T("app.title"), c.pxBig, kWhite);
  float y = c.margin + LineH(c, c.pxBig) * 1.5f;
  const float gap = c.margin * 0.6f;
  const float tw = (nw - gap) * 0.5f, th = std::max(11.f * c.mm, LineH(c, c.px) * 1.9f);
  struct Tile {
    const char* key;
    const char* act;
  };
  const Tile tiles[] = {{"ui.play", "nav:play"},           {"ui.characters", "nav:characters"},
                        {"ui.inventory", "nav:inventory"}, {"ui.story", "nav:story"},
                        {"ui.profile", "nav:profile"},     {"ui.settings", "nav:settings"},
                        {"ui.language", "nav:language"}};
  for (std::size_t i = 0; i < 7; ++i) {
    const float x = nx + static_cast<float>(i % 2) * (tw + gap);
    const float yy = y + static_cast<float>(i / 2) * (th + gap);
    Btn(c, x, yy, i == 0 ? nw : tw, th, tiles[i].act, T(tiles[i].key), true, i == 0, i == 0 ? c.pxBig : c.px);
    if (i == 0) {  // Play spans the full row
      y += th + gap;
      // shift remaining tiles up: recompute with an offset by using new loop index below
      break;
    }
  }
  // Remaining 6 tiles in a 2-column grid under Play.
  for (std::size_t i = 1; i < 7; ++i) {
    const std::size_t k = i - 1;
    const float x = nx + static_cast<float>(k % 2) * (tw + gap);
    const float yy = y + static_cast<float>(k / 2) * (th + gap);
    Btn(c, x, yy, tw, th, tiles[i].act, T(tiles[i].key));
  }
  const float noteY = y + 3.f * (th + gap) + gap;
  PutWrapped(c, nx, noteY, nw, T("ui.online_unavailable"), c.pxSmall, kDim, 3);
  PutEnd(c, c.margin, c.H - c.margin - LineH(c, c.pxSmall), c.W - 2.f * c.margin, T("app.version", {"0.1.0"}),
         c.pxSmall, kDim);
}

// --------------------------------------------------------------------------------------- Play

void App::DrawPlay(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.play"), T("ui.gold") + ": " + std::to_string(profile_.gold));
  const float gap = c.margin;
  const float cw = (c.W - 3.f * c.margin) * 0.5f;
  const float chh = (c.H - top - 2.f * c.margin - gap) * 0.5f;
  struct M {
    const char* name;
    const char* desc;
    const char* act;
  };
  const M modes[] = {{"ui.mode.missions", "ui.mode.missions.desc", "mode:missions"},
                     {"ui.mode.training", "ui.mode.training.desc", "mode:training"},
                     {"ui.mode.dungeons", "ui.mode.dungeons.desc", "mode:dungeons"},
                     {"ui.mode.story", "ui.mode.story.desc", "mode:story"}};
  for (int i = 0; i < 4; ++i) {
    const float x = c.margin + static_cast<float>(i % 2) * (cw + gap);
    const float y = top + c.margin * 0.5f + static_cast<float>(i / 2) * (chh + gap);
    Btn(c, x, y, cw, chh, modes[i].act, "", true, false);
    PutStart(c, x + c.margin * 0.6f, y + c.margin * 0.6f, cw - c.margin * 1.2f, T(modes[i].name), c.pxBig, kWhite);
    PutWrapped(c, x + c.margin * 0.6f, y + c.margin * 0.6f + LineH(c, c.pxBig) * 1.3f, cw - c.margin * 1.2f,
               T(modes[i].desc), c.px, kDim, 3);
  }
}

// ---------------------------------------------------------------------------------- Encounters

void App::DrawEncounters(UiCtx& c) {
  const char* modeKey = encKind_ == ModeKind::Mission    ? "ui.mode.missions"
                        : encKind_ == ModeKind::Training ? "ui.mode.training"
                        : encKind_ == ModeKind::Dungeon  ? "ui.mode.dungeons"
                                                         : "ui.mode.story";
  const float top = Header(c, T("ui.back"), T(modeKey), T("ui.level_short", {std::to_string(profile_.level)}));
  const auto list = levels_.OfKind(encKind_);
  const int perPage = 3;
  const int pages = std::max(1, (static_cast<int>(list.size()) + perPage - 1) / perPage);
  page_ = ClampInt(page_, 0, pages - 1);
  const float rowH =
      (c.H - top - c.margin * 2.f - (pages > 1 ? BtnH(c) + c.margin : 0.f)) / static_cast<float>(perPage) -
      c.margin * 0.5f;
  float y = top + c.margin * 0.3f;
  for (int i = page_ * perPage; i < std::min(static_cast<int>(list.size()), (page_ + 1) * perPage); ++i) {
    const EncounterDef& e = *list[static_cast<std::size_t>(i)];
    const float w = c.W - 2.f * c.margin;
    Panel(c, c.margin, y, w, rowH);
    const float bw = 26.f * c.mm;
    const float textW = w - bw - c.margin * 2.5f;
    std::string title = T(e.nameKey);
    PutStart(c, c.margin * 1.5f, y + c.margin * 0.4f, textW, title, c.pxBig * 3 / 4 + c.px / 4, kWhite);
    PutWrapped(c, c.margin * 1.5f, y + c.margin * 0.4f + LineH(c, c.pxBig) * 1.0f, textW, T(e.descKey), c.pxSmall + 1,
               kDim, 2);
    // Status / action on the end side.
    const std::string lock = menuSession_->LockReason(e.id);
    const float bx = c.W - c.margin * 1.5f - bw;
    const float bh = std::min(rowH - c.margin, BtnH(c));
    const float by = y + (rowH - bh) * 0.5f - (lock.empty() ? 0.f : bh * 0.35f);
    // Logical x for the end side: mirror of bx.
    const float lx = rtl() ? c.margin * 1.5f : bx;
    if (lock.empty()) {
      Btn(c, rtl() ? c.margin * 1.5f : bx, by, bw, bh, "enc:start:" + e.id, T("ui.start"), true, true);
      if (IsCleared(profile_, e))
        PutCenter(c, rtl() ? c.margin * 1.5f : bx, by + bh + 2.f, bw, T("ui.cleared"), c.pxSmall, kGreen);
    } else {
      Btn(c, lx, by, bw, bh, "enc:locked:" + e.id, T("ui.locked"), false);
      std::string why = e.unlockLevel > profile_.level ? T("ui.requires_level", {std::to_string(e.unlockLevel)})
                                                       : T("ui.requires_chapter");
      PutWrapped(c, lx - c.margin * 0.5f, by + bh + 2.f, bw + c.margin, why, c.pxSmall - 1 > 9 ? c.pxSmall - 1 : 9,
                 kRed, 2);
    }
    y += rowH + c.margin * 0.5f;
  }
  if (encKind_ == ModeKind::Dungeon)
    PutStart(c, c.margin, c.H - c.margin - LineH(c, c.px), c.W * 0.5f,
             T("ui.best_room", {std::to_string(profile_.dungeonBestRoom)}), c.px, kDim);
  if (pages > 1) {
    const float bh = BtnH(c), by = c.H - c.margin - bh;
    Btn(c, c.W * 0.5f - 12.f * c.mm - c.margin * 0.5f - 8.f * c.mm, by, 12.f * c.mm, bh, "page:-", rtl() ? ">" : "<",
        page_ > 0);
    PutCenter(c, c.W * 0.5f - 12.f * c.mm, by + (bh - LineH(c, c.px)) * 0.5f, 24.f * c.mm,
              T("ui.inventory.page", {std::to_string(page_ + 1), std::to_string(pages)}), c.px, kDim);
    Btn(c, c.W * 0.5f + 12.f * c.mm + c.margin * 0.5f - 4.f * c.mm, by, 12.f * c.mm, bh, "page:+", rtl() ? "<" : ">",
        page_ + 1 < pages);
  }
}

// ------------------------------------------------------------------------------- Characters

void App::DrawCharacters(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.characters"), "");
  const CharacterDef* view = db_.Character(viewedChar_);
  if (!view) return;
  const float nx = c.W * 0.5f, nw = c.W * 0.5f - c.margin;
  float y = top;
  // Character cards.
  const float ch = std::max(10.f * c.mm, LineH(c, c.px) * 1.6f);
  for (const auto& [id, def] : db_.characters()) {
    const bool unlocked = profile_.unlockedCharacters.count(id) > 0;
    std::string label = T(def.nameKey);
    Btn(c, nx, y, nw, ch, "char:view:" + id, "", true, id == viewedChar_);
    PutStart(c, nx + c.margin * 0.5f, y + (ch - LineH(c, c.px)) * 0.5f, nw * 0.6f, label, c.px,
             unlocked ? kWhite : kDim);
    PutEnd(c, nx, y + (ch - LineH(c, c.pxSmall)) * 0.5f, nw - c.margin * 0.5f,
           unlocked ? Stars(def.rarity) : T("ui.char.unlock", {std::to_string(def.unlockLevel)}), c.pxSmall,
           unlocked ? kGold : kRed);
    y += ch + c.margin * 0.4f;
  }
  // Stats at the current level.
  const PlayerLoadout l = BuildLoadout(db_, *view, profile_.level);
  y += c.margin * 0.3f;
  const float sw = (nw - c.margin) * 0.5f;
  struct S {
    const char* key;
    int v;
  };
  const S stats[] = {{"ui.stat.hp", l.stats.maxHp},
                     {"ui.stat.mana", l.stats.maxMana},
                     {"ui.stat.attack", l.stats.attack},
                     {"ui.stat.defense", l.stats.defense}};
  for (int i = 0; i < 4; ++i) {
    const float x = nx + static_cast<float>(i % 2) * (sw + c.margin);
    const float yy = y + static_cast<float>(i / 2) * LineH(c, c.px) * 1.2f;
    PutStart(c, x, yy, sw * 0.6f, T(stats[i].key), c.px, kDim);
    PutEnd(c, x, yy, sw, std::to_string(stats[i].v), c.px, kWhite);
  }
  y += 2.f * LineH(c, c.px) * 1.2f + c.margin * 0.4f;
  // Outfits (real mesh/material swaps; locked ones are disabled).
  PutStart(c, nx, y, nw, T("ui.outfit"), c.pxSmall, kDim);
  y += LineH(c, c.pxSmall) * 1.15f;
  const float ow = std::min(nw / 3.f - c.margin * 0.4f, 30.f * c.mm),
              oh = std::max(8.f * c.mm, LineH(c, c.pxSmall) * 1.6f);
  float ox = nx;
  Btn(c, ox, y, ow, oh, "char:outfit:default", T("ui.outfit.default"), true, viewedOutfit_.empty(), c.pxSmall);
  ox += ow + c.margin * 0.4f;
  for (const auto& o : view->outfits) {
    const bool ok = o.unlockLevel <= profile_.level;
    Btn(c, ox, y, ow, oh, "char:outfit:" + o.id,
        ok ? T(o.nameKey) : T("ui.level_short", {std::to_string(o.unlockLevel)}), ok, viewedOutfit_ == o.id, c.pxSmall);
    ox += ow + c.margin * 0.4f;
    if (ox + ow > nx + nw) break;
  }
  y += oh + c.margin * 0.5f;
  if (preview_ && preview_->usedFallback && !preview_->placeholderByDesign)
    PutWrapped(c, nx, y, nw, T("ui.char.model_fallback", {preview_->error}), c.pxSmall, kRed, 2);
  // Select.
  const bool unlocked = profile_.unlockedCharacters.count(view->id) > 0;
  const bool same = profile_.characterId == view->id && profile_.outfitId == viewedOutfit_;
  const float bh = BtnH(c);
  Btn(c, nx, c.H - c.margin - bh, nw, bh, "char:select", same ? T("ui.selected") : T("ui.select"), unlocked && !same,
      !same && unlocked);
  // Preview caption.
  Panel(c, c.margin, c.H - c.margin - 2.2f * LineH(c, c.px), c.W * 0.44f, 2.2f * LineH(c, c.px));
  PutStart(c, c.margin * 1.5f, c.H - c.margin - 2.1f * LineH(c, c.px), c.W * 0.44f - c.margin, T(view->nameKey),
           c.pxBig * 3 / 4 + c.px / 4, kWhite);
}

// -------------------------------------------------------------------------------- Inventory

void App::DrawInventory(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.inventory"), T("ui.gold") + ": " + std::to_string(profile_.gold));
  const float lw = c.W * 0.40f - c.margin;
  float y = top;
  // Equipment slots.
  const float rh = std::max(11.f * c.mm, LineH(c, c.px) * 2.1f);
  for (const char* slot : {"weapon", "armor", "accessory"}) {
    Panel(c, c.margin, y, lw, rh);
    PutStart(c, c.margin * 1.4f, y + c.margin * 0.3f, lw - c.margin, T(std::string("ui.slot.") + slot), c.pxSmall,
             kDim);
    auto it = profile_.equipment.find(slot);
    const ItemDef* d = it == profile_.equipment.end() ? nullptr : db_.Item(it->second);
    PutStart(c, c.margin * 1.4f, y + c.margin * 0.3f + LineH(c, c.pxSmall) * 1.1f,
             lw - c.margin * 5.f * 1.f - 8.f * c.mm, d ? T(d->nameKey) : T("ui.empty"), c.px, d ? kWhite : kDim);
    if (d) {
      const float uw = 6.f * c.mm + 8.f * c.mm;
      Btn(c, c.margin + lw - uw - c.margin * 0.4f, y + (rh - 8.f * c.mm) * 0.5f, uw, 8.f * c.mm,
          std::string("inv:unequip:") + slot, T("ui.unequip"), true, false, c.pxSmall);
    }
    y += rh + c.margin * 0.4f;
  }
  // Detail of the selected item.
  const float dh = c.H - y - c.margin;
  Panel(c, c.margin, y, lw, dh);
  if (invSel_ >= 0 && invSel_ < static_cast<int>(profile_.inventory.size())) {
    const ItemStack& st = profile_.inventory[static_cast<std::size_t>(invSel_)];
    const ItemDef* d = db_.Item(st.id);
    if (d) {
      float yy = y + c.margin * 0.4f;
      PutStart(c, c.margin * 1.4f, yy, lw - c.margin, T(d->nameKey), c.px, kWhite);
      yy += LineH(c, c.px) * 1.2f;
      if (d->slot == ItemSlot::Consumable)
        PutStart(c, c.margin * 1.4f, yy, lw - c.margin, T("ui.item.heal", {std::to_string(d->healAmount)}), c.pxSmall,
                 kGreen);
      else if (d->slot == ItemSlot::Material)
        PutStart(c, c.margin * 1.4f, yy, lw - c.margin, T("ui.item.count", {std::to_string(st.count)}), c.pxSmall,
                 kDim);
      else
        PutWrapped(c, c.margin * 1.4f, yy, lw - c.margin,
                   T("ui.item.bonus",
                     {std::to_string(d->bonusAttack), std::to_string(d->bonusDefense), std::to_string(d->bonusHp)}),
                   c.pxSmall, kGreen, 2);
      const bool equippable =
          d->slot == ItemSlot::Weapon || d->slot == ItemSlot::Armor || d->slot == ItemSlot::Accessory;
      if (equippable)
        Btn(c, c.margin * 1.4f, y + dh - BtnH(c) - c.margin * 0.4f, lw - c.margin * 1.6f, BtnH(c), "inv:equip",
            T("ui.equip"), true, true);
    }
  }
  // Item grid.
  const float gx = c.W * 0.40f + c.margin * 0.2f, gw = c.W - gx - c.margin;
  const int perPage = 8;
  const int pages = std::max(1, (static_cast<int>(profile_.inventory.size()) + perPage - 1) / perPage);
  page_ = ClampInt(page_, 0, pages - 1);
  const float cw = (gw - c.margin * 0.5f) * 0.5f;
  const float chh = std::max(9.f * c.mm, LineH(c, c.px) * 1.6f);
  const float gy = top;
  if (profile_.inventory.empty()) PutStart(c, gx, gy, gw, T("ui.empty"), c.px, kDim);
  for (int i = page_ * perPage; i < std::min(static_cast<int>(profile_.inventory.size()), (page_ + 1) * perPage); ++i) {
    const int k = i - page_ * perPage;
    const float x = gx + static_cast<float>(k % 2) * (cw + c.margin * 0.5f);
    const float yy = gy + static_cast<float>(k / 2) * (chh + c.margin * 0.4f);
    const ItemStack& st = profile_.inventory[static_cast<std::size_t>(i)];
    const ItemDef* d = db_.Item(st.id);
    Btn(c, x, yy, cw, chh, "inv:select:" + std::to_string(i), "", true, i == invSel_);
    PutStart(c, x + c.margin * 0.4f, yy + (chh - LineH(c, c.pxSmall)) * 0.5f, cw * 0.7f, d ? T(d->nameKey) : st.id,
             c.pxSmall, kWhite);
    PutEnd(c, x, yy + (chh - LineH(c, c.pxSmall)) * 0.5f, cw - c.margin * 0.4f, "x" + std::to_string(st.count),
           c.pxSmall, kDim);
  }
  if (pages > 1) {
    const float bh = BtnH(c), by = c.H - c.margin - bh;
    Btn(c, gx, by, 12.f * c.mm, bh, "page:-", rtl() ? ">" : "<", page_ > 0);
    PutCenter(c, gx + 12.f * c.mm, by + (bh - LineH(c, c.px)) * 0.5f, gw - 24.f * c.mm,
              T("ui.inventory.page", {std::to_string(page_ + 1), std::to_string(pages)}), c.px, kDim);
    Btn(c, gx + gw - 12.f * c.mm, by, 12.f * c.mm, bh, "page:+", rtl() ? "<" : ">", page_ + 1 < pages);
  }
}

// ----------------------------------------------------------------------------------- Profile

void App::DrawProfile(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.profile"), T("ui.gold") + ": " + std::to_string(profile_.gold));
  const float w = c.W - 2.f * c.margin;
  Panel(c, c.margin, top, w, c.H - top - c.margin);
  float y = top + c.margin;
  const float x = c.margin * 2.f, iw = w - c.margin * 2.f;
  const CharacterDef* ch = db_.Character(profile_.characterId);
  PutStart(c, x, y, iw, T("ui.profile.name") + ": " + profile_.name, c.pxBig * 3 / 4 + c.px / 4, kWhite);
  y += LineH(c, c.pxBig) * 1.15f;
  PutStart(
      c, x, y, iw,
      T("ui.profile.level") + ": " + std::to_string(profile_.level) + "    " + T("ui.power", {std::to_string(Power())}),
      c.px, kDim);
  y += LineH(c, c.px) * 1.3f;
  // XP bar.
  const int need = profile_.level >= kMaxLevel ? 1 : XpToNext(profile_.level);
  const float frac = profile_.level >= kMaxLevel ? 1.f : static_cast<float>(profile_.xp) / static_cast<float>(need);
  const float bx = c.X(x, iw), bh = std::max(3.f * c.mm, 8.f);
  c.fb->FillRect(bx, y, iw, bh, Color{50, 44, 20, 255});
  const float fw = iw * Clamp(frac, 0.f, 1.f);
  c.fb->FillRect(c.rtl ? bx + iw - fw : bx, y, fw, bh, Color{240, 200, 70, 255});
  y += bh + c.margin * 0.3f;
  PutStart(c, x, y, iw, T("ui.profile.xp", {std::to_string(profile_.xp), std::to_string(need)}), c.pxSmall, kDim);
  y += LineH(c, c.pxSmall) * 1.6f;
  if (ch) {
    PutStart(c, x, y, iw, T("ui.characters") + ": " + T(ch->nameKey), c.px, kWhite);
    y += LineH(c, c.px) * 1.3f;
  }
  PutStart(c, x, y, iw, T("ui.profile.missions_cleared", {std::to_string(profile_.completedMissions.size())}), c.px,
           kWhite);
  y += LineH(c, c.px) * 1.3f;
  PutStart(c, x, y, iw, T("ui.profile.chapters_cleared", {std::to_string(profile_.storyChaptersCleared)}), c.px,
           kWhite);
  y += LineH(c, c.px) * 1.3f;
  PutStart(c, x, y, iw, T("ui.best_room", {std::to_string(profile_.dungeonBestRoom)}), c.px, kWhite);
}

// ---------------------------------------------------------------------------------- Settings

void App::DrawSettings(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.settings"), "");
  const Settings& s = profile_.settings;
  const float colW = (c.W - 3.f * c.margin) * 0.5f;
  const float rowH = std::max(10.f * c.mm, LineH(c, c.px) * 1.8f);
  struct Row {
    std::string label, value, minus, plus;
  };
  const std::string qkey = "ui.settings.quality." + s.quality;
  const Row left[] = {
      {T("ui.settings.music"), std::to_string(s.musicVolume) + "%", "set:music:-", "set:music:+"},
      {T("ui.settings.sfx"), std::to_string(s.sfxVolume) + "%", "set:sfx:-", "set:sfx:+"},
      {T("ui.settings.sensitivity"), std::to_string(s.sensitivity) + "%", "set:sens:-", "set:sens:+"},
      {T("ui.settings.text_size"), std::to_string(static_cast<int>(std::lround(s.textScale * 100.f))) + "%",
       "set:text:-", "set:text:+"}};
  float y = top;
  for (const auto& r : left) {
    Panel(c, c.margin, y, colW, rowH);
    PutStart(c, c.margin * 1.4f, y + (rowH - LineH(c, c.pxSmall)) * 0.5f - 1.f, colW * 0.42f, r.label, c.pxSmall + 1,
             kWhite);
    const float bw = 9.f * c.mm;
    const float vx = c.margin + colW - c.margin * 0.4f - bw * 2.f - 12.f * c.mm;
    Btn(c, c.margin + colW - c.margin * 0.4f - bw * 2.f - 12.f * c.mm - bw * 0.f, y + (rowH - 8.f * c.mm) * 0.5f, bw,
        8.f * c.mm, r.minus, "-", true, false);
    PutCenter(c, vx + bw, y + (rowH - LineH(c, c.pxSmall)) * 0.5f, 12.f * c.mm, r.value, c.pxSmall + 1, kGold);
    Btn(c, c.margin + colW - c.margin * 0.4f - bw, y + (rowH - 8.f * c.mm) * 0.5f, bw, 8.f * c.mm, r.plus, "+", true,
        false);
    y += rowH + c.margin * 0.4f;
  }
  // Right column: toggles.
  const float rx = c.margin * 2.f + colW;
  struct Tog {
    std::string label, value, act;
  };
  const Tog right[] = {
      {T("ui.settings.quality"), T(qkey), "set:quality"},
      {T("ui.settings.invert_y"), s.invertY ? T("ui.settings.on") : T("ui.settings.off"), "set:invert"},
      {T("ui.settings.debug"), s.showDebug ? T("ui.settings.on") : T("ui.settings.off"), "set:debug"}};
  y = top;
  for (const auto& r : right) {
    Panel(c, rx, y, colW, rowH);
    PutStart(c, rx + c.margin * 0.8f, y + (rowH - LineH(c, c.pxSmall)) * 0.5f - 1.f, colW * 0.5f, r.label,
             c.pxSmall + 1, kWhite);
    Btn(c, rx + colW - 24.f * c.mm - c.margin * 0.4f, y + (rowH - 8.f * c.mm) * 0.5f, 24.f * c.mm, 8.f * c.mm, r.act,
        r.value, true, false, c.pxSmall + 1);
    y += rowH + c.margin * 0.4f;
  }
}

// ----------------------------------------------------------------------------------- Language

void App::DrawLanguage(UiCtx& c) {
  const float top = Header(c, T("ui.back"), T("ui.language"), "");
  const std::size_t total = loc_.KeyCount("en");
  float y = top;
  const float rh = std::max(13.f * c.mm, LineH(c, c.px) * 2.3f);
  for (const std::string& code : loc_.Languages()) {
    const std::size_t have = loc_.KeyCount(code) - loc_.MissingKeys(code).size() > 0 ? loc_.KeyCount(code) - 0 : 0;
    const std::size_t translated = total >= loc_.MissingKeys(code).size() ? total - loc_.MissingKeys(code).size() : 0;
    (void)have;
    const std::string nameKey = "ui.language.name." + code;
    std::string name = loc_.HasKey("en", nameKey) ? loc_.Get(nameKey) : code;
    // Always show the language in its own catalog's wording when available.
    Btn(c, c.margin, y, c.W - 2.f * c.margin, rh, "lang:" + code, "", true, code == loc_.language());
    PutStart(c, c.margin * 1.6f, y + c.margin * 0.4f, c.W - 6.f * c.margin, name, c.px, kWhite);
    PutStart(c, c.margin * 1.6f, y + c.margin * 0.4f + LineH(c, c.px) * 1.1f, c.W - 6.f * c.margin,
             T("ui.language.coverage", {std::to_string(translated), std::to_string(total)}), c.pxSmall, kDim);
    y += rh + c.margin * 0.4f;
  }
  PutWrapped(c, c.margin, c.H - c.margin - LineH(c, c.pxSmall) * 2.4f, c.W - 2.f * c.margin, T("ui.language.note"),
             c.pxSmall, kDim, 2);
}

// ------------------------------------------------------------------------------------- InGame

void App::DrawInGame(UiCtx& c) {
  if (!session_) return;
  GameSession& s = *session_;
  scene_.Draw(*c.fb, rast_, s.world(), camera_);
  scene_.DrawTexts(*c.fb, rast_);
  HudInfo info;
  const Profile& p = profile_;
  info.level = p.level;
  info.xp = p.xp;
  info.xpToNext = p.level >= kMaxLevel ? 1 : XpToNext(p.level);
  info.gold = p.gold;
  info.potions = CountItem(p, "potion_small");
  info.levelText = T("ui.level_short", {std::to_string(p.level)});
  info.goldText = T("ui.gold") + " " + std::to_string(p.gold);
  info.attackLabel = T("ui.hud.attack");
  info.heavyLabel = T("ui.hud.heavy");
  info.dodgeLabel = T("ui.hud.dodge");
  info.pausedText = T("ui.paused");
  info.text = &text_;
  info.textScale = p.settings.textScale;
  const RunStatus st = s.status();
  std::string obj;
  if (s.encounter() && s.encounter()->kind == ModeKind::Training) {
    obj = T("ui.training.hint");
  } else {
    obj = T("ui.enemies_left", {std::to_string(st.enemiesAlive)});
    if (st.waves > 1) obj += "   " + T("ui.wave", {std::to_string(st.wave), std::to_string(st.waves)});
    if (st.stages > 1) obj += "   " + T("ui.room", {std::to_string(st.stage), std::to_string(st.stages)});
    if (st.timeLeft >= 0.f)
      obj += "   " + T("ui.time_left", {std::to_string(static_cast<int>(std::ceil(st.timeLeft)))});
  }
  info.objective = obj;
  const RunPhase ph = s.phase();
  if (ph == RunPhase::IntroDialogue || ph == RunPhase::OutroDialogue) {
    info.dialogue = T(s.dialogueKey());
    info.dialogueHint = T("ui.tap_continue");
  }
  HudOptions opt;
  opt.showDebug = p.settings.showDebug;
  dbg_.triangles = rast_.stats().trianglesDrawn;
  dbg_.effects = static_cast<int>(scene_.effectCount());
  const TouchLayout& lay = router_.layout();
  if (ph == RunPhase::Running || ph == RunPhase::Transition)
    DrawHud(*c.fb, rast_, s.world(), db_, &router_, lay, info, opt, dbg_);
  else {
    TouchLayout none = lay;
    none.buttons.clear();
    DrawHud(*c.fb, rast_, s.world(), db_, nullptr, none, info, opt, dbg_);
  }
  // Pause button as a real UI button too, so mouse/touch-less hosts and tests can use it.
  if (overlay_ == Overlay::None && ph == RunPhase::Running) {
    for (const auto& b : lay.buttons)
      if (b.action == ButtonAction::Pause)
        buttons_.push_back({b.cx - b.radius, b.cy - b.radius, b.radius * 2.f, b.radius * 2.f, "run:pause", "II", true});
  }
}

// ------------------------------------------------------------------------------------- Result

void App::DrawResult(UiCtx& c) {
  if (!session_) return;
  const RunSummary& r = session_->summary();
  const EncounterDef* e = session_->encounter();
  const char* key = r.outcome == Outcome::Victory     ? "ui.victory"
                    : r.outcome == Outcome::TimeUp    ? "ui.time_up"
                    : r.outcome == Outcome::Abandoned ? "ui.abandoned"
                                                      : "ui.defeat";
  const float pw = c.W * 0.7f, px0 = (c.W - pw) * 0.5f;
  Panel(c, px0, c.margin, pw, c.H - 2.f * c.margin);
  float y = c.margin * 1.6f;
  PutCenter(c, px0, y, pw, T(key), c.pxBig * 3 / 2, r.outcome == Outcome::Victory ? kGold : kRed);
  y += LineH(c, c.pxBig) * 1.9f;
  if (e) {
    PutCenter(c, px0, y, pw, T(e->nameKey), c.px, kDim);
    y += LineH(c, c.px) * 1.5f;
  }
  const float x = px0 + c.margin, w = pw - 2.f * c.margin;
  auto line = [&](const std::string& s, Color col) {
    PutStart(c, x, y, w, s, c.px, col);
    y += LineH(c, c.px) * 1.2f;
  };
  line(T("ui.kills", {std::to_string(r.kills)}), kWhite);
  line(T("ui.time", {std::to_string(static_cast<int>(r.seconds))}), kWhite);
  if (e && e->kind == ModeKind::Dungeon) line(T("ui.rooms_cleared", {std::to_string(r.roomsCleared)}), kWhite);
  if (r.outcome == Outcome::Victory && e && e->kind != ModeKind::Training) {
    const int xp = r.grant.levelsGained >= 0 ? e->reward.xp + (r.firstClear ? e->firstClear.xp : 0) : 0;
    const int gold = r.grant.goldGranted + r.firstGrant.goldGranted;
    PutStart(c, x, y, w, T("ui.rewards"), c.px, kGold);
    y += LineH(c, c.px) * 1.2f;
    line("  " + T("ui.xp_gained", {std::to_string(xp)}), kGreen);
    line("  " + T("ui.gold_gained", {std::to_string(gold)}), kGold);
    if (r.firstClear) line("  " + T("ui.first_clear"), kGold);
  }
  if (r.levelsGained > 0) line(T("ui.level_up", {std::to_string(profile_.level)}), kGreen);
  const float bh = BtnH(c);
  const float bw = (pw - 3.f * c.margin) * 0.5f;
  const float by = c.H - c.margin * 1.6f - bh;
  const bool canRetry = menuSession_ && menuSession_->LockReason(runEncounter_).empty();
  Btn(c, px0 + c.margin, by, bw, bh, "res:retry", T("ui.retry"), canRetry);
  Btn(c, px0 + c.margin * 2.f + bw, by, bw, bh, "res:lobby", T("ui.return_lobby"), true, true);
}

// ------------------------------------------------------------------------------------ Overlay

void App::DrawOverlay(UiCtx& c) {
  c.fb->FillRect(0, 0, c.W, c.H, Color{0, 0, 0, 165});
  // Overlay buttons replace the screen's buttons: nothing underneath may be tapped.
  buttons_.clear();
  const float pw = std::min(c.W * 0.62f, 130.f * c.mm), px0 = (c.W - pw) * 0.5f;
  const float bh = BtnH(c);
  if (overlay_ == Overlay::Pause) {
    const float ph = LineH(c, c.pxBig) * 1.6f + 2.f * bh + c.margin * 4.f;
    const float py = (c.H - ph) * 0.5f;
    Panel(c, px0, py, pw, ph);
    PutCenter(c, px0, py + c.margin, pw, T("ui.paused"), c.pxBig, kWhite);
    float y = py + c.margin * 1.4f + LineH(c, c.pxBig) * 1.3f;
    Btn(c, px0 + c.margin, y, pw - 2.f * c.margin, bh, "run:resume", T("ui.resume"), true, true);
    y += bh + c.margin;
    Btn(c, px0 + c.margin, y, pw - 2.f * c.margin, bh, "run:leave", T("ui.quit_run"));
  } else if (overlay_ == Overlay::ConfirmLeave) {
    const float ph = LineH(c, c.pxBig) * 1.6f + LineH(c, c.px) * 2.6f + bh + c.margin * 4.f;
    const float py = (c.H - ph) * 0.5f;
    Panel(c, px0, py, pw, ph);
    PutCenter(c, px0, py + c.margin, pw, T("ui.quit_confirm.title"), c.pxBig * 3 / 4 + c.px / 4, kWhite);
    PutWrapped(c, px0 + c.margin, py + c.margin * 1.4f + LineH(c, c.pxBig) * 1.2f, pw - 2.f * c.margin,
               T("ui.quit_confirm.body"), c.px, kDim, 3);
    const float by = py + ph - c.margin - bh;
    const float bw = (pw - 3.f * c.margin) * 0.5f;
    Btn(c, px0 + c.margin, by, bw, bh, "run:leave_confirm", T("ui.yes"));
    Btn(c, px0 + c.margin * 2.f + bw, by, bw, bh, "run:leave_cancel", T("ui.no"), true, true);
  } else if (overlay_ == Overlay::Notice) {
    const float textH = LineH(c, c.px) * 4.2f;
    const float ph = LineH(c, c.pxBig) * 1.2f + textH + bh + c.margin * 4.f;
    const float py = (c.H - ph) * 0.5f;
    Panel(c, px0, py, pw, ph);
    PutCenter(c, px0, py + c.margin, pw, T("ui.error_title"), c.pxBig * 3 / 4 + c.px / 4, kGold);
    PutWrapped(c, px0 + c.margin, py + c.margin * 1.4f + LineH(c, c.pxBig) * 1.1f, pw - 2.f * c.margin, noticeText_,
               c.px, kWhite, 5);
    Btn(c, px0 + c.margin, py + ph - c.margin - bh, pw - 2.f * c.margin, bh, "notice:ok", T("ui.ok"), true, true);
  }
}

}  // namespace ascend
