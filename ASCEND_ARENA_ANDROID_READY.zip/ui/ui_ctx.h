#pragma once
// Drawing helpers shared by the UI screens (internal to the ui library).
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

#include "app.h"

namespace ascend {

struct UiCtx {
  Framebuffer* fb = nullptr;
  TextRenderer* text = nullptr;
  std::vector<UiButton>* buttons = nullptr;
  float W = 0, H = 0, mm = 6.4f, margin = 19.f;
  int px = 20, pxBig = 30, pxSmall = 15;
  bool rtl = false;
  // Mirrors a logical (start-edge based) x coordinate for right-to-left languages.
  float X(float x, float w) const { return rtl ? W - x - w : x; }
};

inline float MeasureText(UiCtx& c, const std::string& s, int px) {
  return c.text->HasFont() ? c.text->Measure(s, px, c.rtl ? 1 : 0) : Framebuffer::TextWidth(s, std::max(1, px / 9));
}

inline float LineH(UiCtx& c, int px) {
  return c.text->HasFont() ? c.text->LineHeight(px) : static_cast<float>(px) * 1.2f;
}

// Draws at an exact pixel x (alignment relative to that x).
inline float Put(UiCtx& c, float x, float y, const std::string& s, int px, Color col, TextAlign al = TextAlign::Left) {
  if (c.text->HasFont()) return c.text->Draw(*c.fb, x, y, s, px, col, al, c.rtl ? 1 : 0);
  const int scale = std::max(1, px / 9);
  const float w = Framebuffer::TextWidth(s, scale);
  float xx = x;
  if (al == TextAlign::Center)
    xx = x - w * 0.5f;
  else if (al == TextAlign::Right)
    xx = x - w;
  return c.fb->DrawText(xx, y, s, scale, col);
}

// Text aligned to the START edge of a logical region [x, x+w] (left for LTR, right for RTL).
inline float PutStart(UiCtx& c, float x, float y, float w, const std::string& s, int px, Color col) {
  const float rx = c.X(x, w);
  return c.rtl ? Put(c, rx + w, y, s, px, col, TextAlign::Right) : Put(c, rx, y, s, px, col, TextAlign::Left);
}

// Text aligned to the END edge of a logical region.
inline float PutEnd(UiCtx& c, float x, float y, float w, const std::string& s, int px, Color col) {
  const float rx = c.X(x, w);
  return c.rtl ? Put(c, rx, y, s, px, col, TextAlign::Left) : Put(c, rx + w, y, s, px, col, TextAlign::Right);
}

inline void PutCenter(UiCtx& c, float x, float y, float w, const std::string& s, int px, Color col) {
  Put(c, c.X(x, w) + w * 0.5f, y, s, px, col, TextAlign::Center);
}

// Word-wrapped paragraph in a logical region. Returns the height used. Stops after maxLines (adds "..." if cut).
inline float PutWrapped(UiCtx& c, float x, float y, float w, const std::string& s, int px, Color col,
                        int maxLines = 99) {
  std::vector<std::string> lines;
  if (c.text->HasFont())
    lines = c.text->Wrap(s, px, w);
  else
    lines = {s};
  float yy = y;
  for (std::size_t i = 0; i < lines.size() && static_cast<int>(i) < maxLines; ++i) {
    std::string l = lines[i];
    if (static_cast<int>(i) == maxLines - 1 && i + 1 < lines.size()) l += "...";
    PutStart(c, x, yy, w, l, px, col);
    yy += LineH(c, px) * 1.05f;
  }
  return yy - y;
}

inline void Outline(Framebuffer& fb, float x, float y, float w, float h, Color col, float t = 1.5f) {
  fb.FillRect(x, y, w, t, col);
  fb.FillRect(x, y + h - t, w, t, col);
  fb.FillRect(x, y, t, h, col);
  fb.FillRect(x + w - t, y, t, h, col);
}

// Logical-coordinate panel.
inline void Panel(UiCtx& c, float x, float y, float w, float h, Color fill = {16, 20, 44, 215},
                  Color border = {70, 84, 140, 255}) {
  const float rx = c.X(x, w);
  c.fb->FillRect(rx, y, w, h, fill);
  Outline(*c.fb, rx, y, w, h, border);
}

inline void Btn(UiCtx& c, float x, float y, float w, float h, const std::string& action, const std::string& label,
                bool enabled = true, bool selected = false, int px = 0) {
  const float rx = c.X(x, w);
  Color fill = selected ? Color{60, 80, 160, 235} : Color{30, 38, 78, 225};
  Color border = selected ? Color{190, 210, 255, 255} : Color{110, 126, 190, 255};
  Color tc = {255, 255, 255, 255};
  if (!enabled) {
    fill = {22, 24, 38, 200};
    border = {60, 64, 90, 255};
    tc = {130, 134, 160, 255};
  }
  c.fb->FillRect(rx, y, w, h, fill);
  Outline(*c.fb, rx, y, w, h, border, selected ? 2.5f : 1.5f);
  int p = px > 0 ? px : c.px;
  while (p > 10 && MeasureText(c, label, p) > w - 8.f) --p;
  const float ty = y + (h - LineH(c, p)) * 0.5f;
  Put(c, rx + w * 0.5f, ty, label, p, tc, TextAlign::Center);
  c.buttons->push_back({rx, y, w, h, action, label, enabled});
}

inline std::string Stars(int n) {
  std::string s;
  for (int i = 0; i < n; ++i) s += "\xE2\x98\x85";  // black star
  return s;
}

}  // namespace ascend
