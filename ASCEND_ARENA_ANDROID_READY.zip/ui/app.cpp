#include "app.h"

#include <algorithm>
#include <cmath>
#include <filesystem>

#include "../game/sysinfo.h"

namespace ascend {
namespace fs = std::filesystem;

namespace {

bool StartsWith(const std::string& s, const char* p) { return s.rfind(p, 0) == 0; }

bool IsRtlLanguage(const std::string& code) { return code == "ar" || code == "he" || code == "fa" || code == "ur"; }

Quality QualityFrom(const std::string& s) {
  if (s == "low") return Quality::Low;
  if (s == "high") return Quality::High;
  return Quality::Medium;
}

}  // namespace

App::App(AppConfig cfg) : cfg_(std::move(cfg)), store_(cfg_.savePath) {}

// ---------------------------------------------------------------------------------------- init

Status App::Init() {
  inited_ = false;
  const auto errs = db_.LoadFromDirectory(cfg_.contentRoot);
  if (!errs.empty()) {
    std::string m = "content is invalid:";
    for (std::size_t i = 0; i < errs.size() && i < 5; ++i) m += "\n  " + errs[i];
    return Status::Error(m);
  }
  const auto lerrs = levels_.LoadFromDirectory(cfg_.contentRoot, db_);
  if (!lerrs.empty()) {
    std::string m = "levels are invalid:";
    for (std::size_t i = 0; i < lerrs.size() && i < 5; ++i) m += "\n  " + lerrs[i];
    return Status::Error(m);
  }
  // Localization: every content/localization/<code>.ini is a catalog. English is required (fallback language).
  const fs::path ldir = fs::path(cfg_.contentRoot) / "localization";
  std::error_code ec;
  std::vector<fs::path> files;
  for (const auto& e : fs::directory_iterator(ldir, ec))
    if (e.path().extension() == ".ini") files.push_back(e.path());
  std::sort(files.begin(), files.end());
  for (const auto& f : files) {
    auto doc = LoadIniFile(f.string());
    if (!doc) return Status::Error("localization " + f.string() + ": " + doc.status.message);
    const std::string code = f.stem().string();
    const Status st = loc_.AddCatalog(code, doc.value, IsRtlLanguage(code));
    if (!st) return Status::Error("localization " + f.string() + ": " + st.message);
  }
  if (loc_.KeyCount("en") == 0)
    return Status::Error("English localization catalog is missing (content/localization/en.ini)");

  const Status font = text_.LoadFont((fs::path(cfg_.contentRoot) / "fonts" / "DejaVuSans.ttf").string());
  if (!font) fontError_ = font.message;  // not fatal: the 5x7 ASCII font is used (Arabic cannot be shown then)

  loadReport_ = store_.Load(db_);
  profile_ = loadReport_.profile;
  SyncUnlocks(db_, profile_);
  if (!loc_.SetLanguage(profile_.settings.language)) {
    profile_.settings.language = "en";
    loc_.SetLanguage("en");
  }
  menuSession_ = std::make_unique<GameSession>(&db_, &levels_, &profile_, &store_, cfg_.seed);
  viewedChar_ = profile_.characterId;
  viewedOutfit_ = profile_.outfitId;
  inited_ = true;
  ApplySettings();
  RefreshPreview();
  switch (loadReport_.kind) {
    case LoadKind::RecoveredFromBackup:
      pendingNotices_.push_back(T("ui.save.recovered"));
      break;
    case LoadKind::CorruptReset:
      pendingNotices_.push_back(T("ui.save.reset"));
      break;
    case LoadKind::TooNew:
      pendingNotices_.push_back(T("ui.save.too_new"));
      break;
    case LoadKind::Migrated:
      pendingNotices_.push_back(T("ui.save.migrated"));
      break;
    default:
      break;
  }
  if (!pendingNotices_.empty()) {
    ShowNotice(pendingNotices_.front());
    pendingNotices_.erase(pendingNotices_.begin());
  }
  return Status::Ok();
}

void App::SetViewport(int w, int h, float pxPerMm) {
  if (w > 0) vw_ = w;
  if (h > 0) vh_ = h;
  if (pxPerMm > 0.5f) pxPerMm_ = pxPerMm;
  router_ = TouchRouter(TouchLayout::ForScreen(static_cast<float>(vw_), static_cast<float>(vh_), pxPerMm_));
}

void App::ApplySettings() {
  const Settings& s = profile_.settings;
  scene_.SetQuality(QualityFrom(s.quality));
  loc_.SetLanguage(s.language);
  audio_.SetVolumes(s.musicVolume, s.sfxVolume);
}

void App::RefreshPreview() {
  if (!inited_) return;
  const CharacterDef* def = db_.Character(viewedChar_);
  if (!def) def = db_.Character(profile_.characterId);
  if (!def) return;
  preview_ = LoadCharacterVisual(*def, viewedOutfit_, cfg_.contentRoot);
}

int App::Power() const {
  const CharacterDef* ch = db_.Character(profile_.characterId);
  if (!ch) return 0;
  const PlayerLoadout l = LoadoutFor(db_, profile_);
  // Documented formula: a single comparable number, not used by combat itself.
  return l.stats.maxHp / 10 + l.stats.attack * 3 + l.stats.defense * 2 + l.stats.maxMana / 5;
}

void App::Persist() {
  const Status s = store_.Save(profile_);
  if (!s) ShowNotice(T("ui.save.failed", {s.message}));
}

void App::ShowNotice(const std::string& text) {
  if (overlay_ == Overlay::Notice) {
    pendingNotices_.push_back(text);
    return;
  }
  noticeText_ = text;
  overlay_ = Overlay::Notice;
}

// ------------------------------------------------------------------------------------- navigation

void App::Go(Screen s) {
  if (s == Screen::Lobby)
    stack_.clear();
  else if (screen_ != Screen::InGame && screen_ != Screen::Result)
    stack_.push_back(screen_);
  screen_ = s;
  page_ = 0;
  invSel_ = -1;
  if (s == Screen::Characters) {
    viewedChar_ = profile_.characterId;
    viewedOutfit_ = profile_.outfitId;
    RefreshPreview();
  }
  if (s == Screen::Lobby) {
    viewedChar_ = profile_.characterId;
    viewedOutfit_ = profile_.outfitId;
    RefreshPreview();
  }
}

void App::Back() {
  if (stack_.empty()) {
    screen_ = Screen::Lobby;
  } else {
    screen_ = stack_.back();
    stack_.pop_back();
  }
  page_ = 0;
  invSel_ = -1;
  if (screen_ == Screen::Lobby) {
    viewedChar_ = profile_.characterId;
    viewedOutfit_ = profile_.outfitId;
    RefreshPreview();
  }
}

bool App::BackPressed() {
  if (overlay_ == Overlay::Notice) {
    Execute("notice:ok");
    return true;
  }
  if (overlay_ == Overlay::ConfirmLeave) {
    overlay_ = Overlay::Pause;
    return true;
  }
  if (overlay_ == Overlay::Pause) {
    Execute("run:resume");
    return true;
  }
  if (screen_ == Screen::InGame) {
    if (session_ && (session_->phase() == RunPhase::Running)) overlay_ = Overlay::Pause;
    return true;
  }
  if (screen_ == Screen::Result) {
    Execute("res:lobby");
    return true;
  }
  if (screen_ == Screen::Lobby) return false;
  Back();
  return true;
}

void App::OnBackground() {
  if (!inited_) return;
  router_.ReleaseAll();
  keyMove_ = {};
  keyFrame_ = {};
  if (screen_ == Screen::InGame && overlay_ == Overlay::None && session_ && session_->phase() == RunPhase::Running)
    overlay_ = Overlay::Pause;
  stepper_.SetPaused(true);
  audio_.SetPaused(true);
  Persist();
}

void App::OnForeground() {
  stepper_.SetPaused(false);
  audio_.SetPaused(false);
}

// ------------------------------------------------------------------------------------------ input

void App::PressKey(KeyAction a) {
  switch (a) {
    case KeyAction::Attack:
      keyFrame_.attack = true;
      break;
    case KeyAction::Heavy:
      keyFrame_.heavy = true;
      break;
    case KeyAction::Dodge:
      keyFrame_.dodge = true;
      break;
    case KeyAction::Skill1:
      keyFrame_.skill[0] = true;
      break;
    case KeyAction::Skill2:
      keyFrame_.skill[1] = true;
      break;
    case KeyAction::Skill3:
      keyFrame_.skill[2] = true;
      break;
    case KeyAction::Pause:
      keyFrame_.pause = true;
      break;
    case KeyAction::Potion:
      keyFrame_.potion = true;
      break;
  }
}

bool App::HasButton(const std::string& action) const {
  for (const auto& b : buttons_)
    if (b.action == action && b.enabled) return true;
  return false;
}

bool App::Tap(const std::string& action) {
  if (!HasButton(action)) return false;
  Execute(action);
  return true;
}

void App::OnTouch(const TouchEvent& e) {
  if (!inited_) return;
  const bool inRun = screen_ == Screen::InGame && overlay_ == Overlay::None && session_;
  if (inRun) {
    const RunPhase ph = session_->phase();
    if (ph == RunPhase::IntroDialogue || ph == RunPhase::OutroDialogue) {
      if (e.phase == TouchPhase::Up) session_->AdvanceDialogue();
      return;
    }
    router_.OnTouch(e);
    return;
  }
  // Menu / overlay: a button fires when the finger is released on the button it was pressed on.
  const UiButton* hit = nullptr;
  for (auto it = buttons_.rbegin(); it != buttons_.rend(); ++it)
    if (it->enabled && it->Contains(e.x, e.y)) {
      hit = &*it;
      break;
    }
  if (e.phase == TouchPhase::Down) {
    pressedAction_ = hit ? hit->action : std::string();
  } else if (e.phase == TouchPhase::Up) {
    if (hit && hit->action == pressedAction_) Execute(hit->action);
    pressedAction_.clear();
  } else if (e.phase == TouchPhase::Cancel) {
    pressedAction_.clear();
  }
}

// --------------------------------------------------------------------------------------- actions

void App::Execute(const std::string& a) {
  audio_.Play(a == "nav:back" || a == "run:leave_cancel" || a == "run:resume" ? Sfx::UiBack : Sfx::UiClick);
  if (a == "notice:ok") {
    overlay_ = Overlay::None;
    noticeText_.clear();
    if (!pendingNotices_.empty()) {
      const std::string n = pendingNotices_.front();
      pendingNotices_.erase(pendingNotices_.begin());
      ShowNotice(n);
    }
    return;
  }
  if (a == "nav:back") return Back();
  if (a == "nav:lobby") return Go(Screen::Lobby);
  if (a == "nav:play") return Go(Screen::Play);
  if (a == "nav:characters") return Go(Screen::Characters);
  if (a == "nav:inventory") return Go(Screen::Inventory);
  if (a == "nav:profile") return Go(Screen::Profile);
  if (a == "nav:settings") return Go(Screen::Settings);
  if (a == "nav:language") return Go(Screen::Language);
  if (a == "nav:story" || a == "mode:story") {
    encKind_ = ModeKind::Story;
    return Go(Screen::Encounters);
  }
  if (StartsWith(a, "mode:")) {
    const std::string m = a.substr(5);
    encKind_ = m == "training" ? ModeKind::Training : (m == "dungeons" ? ModeKind::Dungeon : ModeKind::Mission);
    return Go(Screen::Encounters);
  }
  if (a == "page:+") {
    ++page_;
    return;
  }
  if (a == "page:-") {
    page_ = std::max(0, page_ - 1);
    return;
  }
  if (StartsWith(a, "enc:start:")) return StartRun(a.substr(10));

  // ---- characters
  if (StartsWith(a, "char:view:")) {
    const std::string id = a.substr(10);
    if (db_.Character(id)) {
      viewedChar_ = id;
      viewedOutfit_ = id == profile_.characterId ? profile_.outfitId : std::string();
      RefreshPreview();
    }
    return;
  }
  if (StartsWith(a, "char:outfit:")) {
    const std::string o = a.substr(12);
    viewedOutfit_ = o == "default" ? std::string() : o;
    RefreshPreview();
    return;
  }
  if (a == "char:select") {
    const CharacterDef* def = db_.Character(viewedChar_);
    if (def && profile_.unlockedCharacters.count(def->id)) {
      bool outfitOk = viewedOutfit_.empty();
      for (const auto& o : def->outfits)
        if (o.id == viewedOutfit_ && o.unlockLevel <= profile_.level) outfitOk = true;
      profile_.characterId = def->id;
      profile_.outfitId = outfitOk ? viewedOutfit_ : std::string();
      Persist();
    }
    return;
  }

  // ---- inventory
  if (StartsWith(a, "inv:select:")) {
    invSel_ = std::atoi(a.c_str() + 11);
    return;
  }
  if (a == "inv:equip") {
    if (invSel_ >= 0 && invSel_ < static_cast<int>(profile_.inventory.size())) {
      const std::string id = profile_.inventory[static_cast<std::size_t>(invSel_)].id;
      const EquipResult r = Equip(db_, profile_, id);
      if (r == EquipResult::InventoryFull)
        ShowNotice(T("ui.inventory.full"));
      else if (r == EquipResult::Ok)
        Persist();
      invSel_ = -1;
    }
    return;
  }
  if (StartsWith(a, "inv:unequip:")) {
    if (Unequip(db_, profile_, a.substr(12)))
      Persist();
    else
      ShowNotice(T("ui.inventory.full"));
    return;
  }

  // ---- settings
  if (StartsWith(a, "set:")) {
    Settings& s = profile_.settings;
    if (a == "set:music:+")
      s.musicVolume = ClampInt(s.musicVolume + 10, 0, 100);
    else if (a == "set:music:-")
      s.musicVolume = ClampInt(s.musicVolume - 10, 0, 100);
    else if (a == "set:sfx:+")
      s.sfxVolume = ClampInt(s.sfxVolume + 10, 0, 100);
    else if (a == "set:sfx:-")
      s.sfxVolume = ClampInt(s.sfxVolume - 10, 0, 100);
    else if (a == "set:sens:+")
      s.sensitivity = ClampInt(s.sensitivity + 10, 50, 200);
    else if (a == "set:sens:-")
      s.sensitivity = ClampInt(s.sensitivity - 10, 50, 200);
    else if (a == "set:text:+")
      s.textScale = Clamp(std::round((s.textScale + 0.1f) * 10.f) / 10.f, 0.8f, 1.6f);
    else if (a == "set:text:-")
      s.textScale = Clamp(std::round((s.textScale - 0.1f) * 10.f) / 10.f, 0.8f, 1.6f);
    else if (a == "set:invert")
      s.invertY = !s.invertY;
    else if (a == "set:debug")
      s.showDebug = !s.showDebug;
    else if (a == "set:quality")
      s.quality = s.quality == "low" ? "medium" : (s.quality == "medium" ? "high" : "low");
    ApplySettings();
    Persist();
    return;
  }
  if (StartsWith(a, "lang:")) {
    const std::string code = a.substr(5);
    if (loc_.SetLanguage(code)) {
      profile_.settings.language = code;
      Persist();
    }
    return;
  }

  // ---- run control
  if (a == "run:pause") {
    if (screen_ == Screen::InGame && session_ && session_->phase() == RunPhase::Running) overlay_ = Overlay::Pause;
    return;
  }
  if (a == "run:resume") {
    overlay_ = Overlay::None;
    router_.ReleaseAll();
    return;
  }
  if (a == "run:leave") {
    overlay_ = Overlay::ConfirmLeave;
    return;
  }
  if (a == "run:leave_cancel") {
    overlay_ = Overlay::Pause;
    return;
  }
  if (a == "run:leave_confirm") {
    overlay_ = Overlay::None;
    if (session_) session_->Abandon();  // keeps kill rewards and saves
    SyncUnlocks(db_, profile_);
    session_.reset();
    playerVisual_.reset();
    scene_.SetPlayerVisual(nullptr);
    scene_.ClearEffects();
    Go(Screen::Lobby);
    return;
  }
  if (a == "res:lobby") {
    session_.reset();
    playerVisual_.reset();
    scene_.SetPlayerVisual(nullptr);
    scene_.ClearEffects();
    resultShown_ = false;
    Go(Screen::Lobby);
    return;
  }
  if (a == "res:retry") {
    const std::string id = runEncounter_;
    session_.reset();
    resultShown_ = false;
    StartRun(id);
    return;
  }
}

void App::StartRun(const std::string& id) {
  const EncounterDef* enc = levels_.Find(id);
  if (!enc) {
    ShowNotice(T("ui.error_title") + ": " + id);
    return;
  }
  // The lock check is shown in the UI, but it is enforced here too so a stale button cannot bypass it.
  auto s = std::make_unique<GameSession>(&db_, &levels_, &profile_, &store_,
                                         cfg_.seed + static_cast<std::uint64_t>(profile_.lastRunId));
  const Status st = s->Start(id);
  if (!st) {
    ShowNotice(T("ui.error_title") + ": " + st.message);
    return;
  }
  session_ = std::move(s);
  runEncounter_ = id;
  resultShown_ = false;
  overlay_ = Overlay::None;
  const CharacterDef* def = db_.Character(profile_.characterId);
  if (def) {
    playerVisual_ = LoadCharacterVisual(*def, profile_.outfitId, cfg_.contentRoot);
    scene_.SetPlayerVisual(playerVisual_.get());
  }
  scene_.ClearEffects();
  router_ = TouchRouter(TouchLayout::ForScreen(static_cast<float>(vw_), static_cast<float>(vh_), pxPerMm_));
  cam_ = OrbitCamera();
  cam_.Snap(session_->world().player().pos);
  stepper_ = FixedStepper(1.f / 60.f, 5);
  camera_ = cam_.Update(session_->world().player().pos, session_->world().arena(), 0.f);
  // Go() would push the menu screen on the stack; a run replaces the screen without history.
  stack_.clear();
  screen_ = Screen::InGame;
}

void App::PlayEventSounds(const std::vector<GameEvent>& events) {
  for (const auto& ev : events) {
    switch (ev.type) {
      case EventType::EnemyHit:
        audio_.Play(ev.crit ? Sfx::Crit : Sfx::Hit);
        break;
      case EventType::SkillCast: {
        const SkillDef* k = db_.Skill(ev.refId);
        if (!k) break;
        if (k->kind == SkillKind::Dash)
          audio_.Play(Sfx::Dash);
        else if (ev.refId.rfind("light_", 0) == 0)
          audio_.Play(Sfx::Swing);
        else if (ev.refId.rfind("heavy", 0) == 0)
          audio_.Play(Sfx::Heavy);
        else
          audio_.Play(Sfx::Skill);
        break;
      }
      case EventType::DodgeStarted:
        audio_.Play(Sfx::Dodge);
        break;
      case EventType::PlayerHit:
        audio_.Play(Sfx::PlayerHurt);
        break;
      case EventType::EnemyWindup:
        audio_.Play(Sfx::EnemyWindup, 0.7f);
        break;
      case EventType::EnemyDefeated:
        audio_.Play(Sfx::EnemyDefeat);
        if (!ev.drops.empty()) audio_.Play(Sfx::Pickup, 0.8f);
        break;
      case EventType::LevelUp:
        audio_.Play(Sfx::LevelUp);
        break;
      default:
        break;
    }
  }
}

void App::UpdateMusic() {
  Music m = Music::Menu;
  if (screen_ == Screen::InGame && session_ && session_->phase() == RunPhase::Running) {
    m = Music::Battle;
    for (const auto& e : session_->world().enemies())
      if (e.Alive() && e.def->enrageBelowPercent > 0 && e.aware) m = Music::Boss;
  }
  audio_.SetMusic(m);
}

void App::FinishRunScreen() {
  audio_.Play(session_ && session_->summary().outcome == Outcome::Victory ? Sfx::Victory : Sfx::Defeat);
  resultShown_ = true;
  SyncUnlocks(db_, profile_);
  if (session_ && !session_->summary().saved && !session_->summary().saveError.empty())
    ShowNotice(T("ui.save.failed", {session_->summary().saveError}));
  screen_ = Screen::Result;
  stack_.clear();
}

// ----------------------------------------------------------------------------------------- update

void App::StepRun(float dt) {
  GameSession& s = *session_;
  const RunPhase ph = s.phase();
  InputFrame in = router_.Consume();
  // Merge desktop/debug keys (edges are applied once, then cleared).
  in.attack |= keyFrame_.attack;
  in.heavy |= keyFrame_.heavy;
  in.dodge |= keyFrame_.dodge;
  in.pause |= keyFrame_.pause;
  in.potion |= keyFrame_.potion;
  for (std::size_t i = 0; i < in.skill.size(); ++i) in.skill[i] = in.skill[i] || keyFrame_.skill[i];
  keyFrame_ = {};
  if (std::fabs(keyMove_.x) > 0.01f || std::fabs(keyMove_.y) > 0.01f) in.move = keyMove_;

  if (ph == RunPhase::Running && in.pause) {
    overlay_ = Overlay::Pause;
    return;
  }
  if (ph == RunPhase::Running && in.potion) {
    const int heal = UseConsumable(db_, profile_, "potion_small");
    if (heal > 0) s.world().mutablePlayer().hp.Add(heal);
  }
  const Settings& set = profile_.settings;
  cam_.ApplyLook(in.lookDelta, static_cast<float>(set.sensitivity) / 100.f, set.invertY);
  lastMoveMag_ = Length(in.move);

  const int n = stepper_.Advance(dt);
  InputFrame first = in;
  for (int i = 0; i < n; ++i) {
    s.Step(first, cam_.yaw(), stepper_.step());
    first.attack = first.heavy = first.dodge = first.potion = first.pause = false;
    first.skill = {};
    first.lookDelta = {};
    if (s.finished()) break;
  }
  const auto events = s.TakeEvents();
  PlayEventSounds(events);
  scene_.OnEvents(events, s.world(), db_);
  scene_.Update(dt);
  if (playerVisual_) {
    const CharacterDef* def = db_.Character(profile_.characterId);
    if (def && !playerVisual_->usedFallback) playerVisual_->Tick(s.world().player(), *def, lastMoveMag_, dt);
  }
  camera_ = cam_.Update(s.world().player().pos, s.world().arena(), dt);
}

void App::Update(float dt) {
  if (!inited_) return;
  if (!(dt >= 0.f) || dt > 1.f) dt = dt > 1.f ? 1.f : 0.f;  // clamp hitches and NaN
  previewTime_ += dt;
  UpdateMusic();
  // Measured frame rate (average over half a second).
  fpsAcc_ += dt;
  ++fpsFrames_;
  if (fpsAcc_ >= 0.5f) {
    dbg_.fps = static_cast<float>(fpsFrames_) / fpsAcc_;
    dbg_.frameMs = 1000.f * fpsAcc_ / static_cast<float>(fpsFrames_);
    dbg_.rssKb = ReadRssKb();
    fpsAcc_ = 0.f;
    fpsFrames_ = 0;
  }
  if ((screen_ == Screen::Lobby || screen_ == Screen::Characters) && preview_ && !preview_->usedFallback) {
    const CharacterDef* def = db_.Character(viewedChar_);
    if (def) preview_->TickPreview(*def, dt);
  }
  if (screen_ == Screen::InGame && session_ && overlay_ == Overlay::None) {
    StepRun(dt);
    if (session_->finished() && !resultShown_) FinishRunScreen();
  }
}

}  // namespace ascend
