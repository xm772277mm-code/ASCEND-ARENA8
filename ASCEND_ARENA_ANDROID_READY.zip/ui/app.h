#pragma once
// ASCEND ARENA application layer: lobby, menus, settings, language, mode selection, in-game run and
// result flow. Everything is driven by real game state (Profile, GameSession, SaveStore, Localization).
// UI is immediate-mode: Draw() lays widgets out and records them as buttons, so a tap is resolved
// against exactly what was drawn. The same code runs in the SDL host and in headless tests.
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "../engine/assets/localization.h"
#include "../engine/audio/audio.h"
#include "../engine/core/fixed_step.h"
#include "../engine/input/input.h"
#include "../engine/render/rasterizer.h"
#include "../engine/text/text_renderer.h"
#include "../game/character_visual.h"
#include "../game/hud.h"
#include "../game/scene_renderer.h"
#include "../gameplay/camera.h"
#include "../gameplay/session.h"

namespace ascend {

struct AppConfig {
  std::string contentRoot;
  std::string savePath;
  std::uint64_t seed = 1;
};

enum class Screen { Lobby, Play, Encounters, Characters, Inventory, Profile, Settings, Language, InGame, Result };
enum class Overlay { None, Pause, ConfirmLeave, Notice };

struct UiButton {
  float x = 0, y = 0, w = 0, h = 0;
  std::string action;
  std::string label;
  bool enabled = true;
  bool Contains(float px, float py) const { return px >= x && px <= x + w && py >= y && py <= y + h; }
};

// A keyboard-style debug/desktop control (the SDL host maps keys to this; touch is the real input).
enum class KeyAction { Attack, Heavy, Dodge, Skill1, Skill2, Skill3, Pause, Potion };

struct UiCtx;

class App {
 public:
  explicit App(AppConfig cfg);

  // Loads content, localization, font and the save. Returns an error only for problems the app cannot
  // run with (missing/invalid content). A missing font or a damaged save is recovered and reported.
  Status Init();

  void SetViewport(int w, int h, float pixelsPerMm);
  void OnTouch(const TouchEvent& e);
  void SetKeyMove(Vec2 m) { keyMove_ = m; }
  void PressKey(KeyAction a);
  void Update(float realDt);
  void Draw(Framebuffer& fb);
  void OnBackground();  // pauses a run and saves
  void OnForeground();
  bool BackPressed();  // Android back / Escape: returns false when the app should exit

  // ---- inspection (tests, host) ----
  Screen screen() const { return screen_; }
  Overlay overlay() const { return overlay_; }
  const std::vector<UiButton>& buttons() const { return buttons_; }
  // Executes the action of a currently drawn, enabled button. Returns false if there is none.
  bool Tap(const std::string& action);
  bool HasButton(const std::string& action) const;
  Profile& profile() { return profile_; }
  const Profile& profile() const { return profile_; }
  Localization& loc() { return loc_; }
  ContentDb& db() { return db_; }
  LevelsDb& levels() { return levels_; }
  GameSession* session() { return session_.get(); }
  const std::string& noticeText() const { return noticeText_; }
  bool rtl() const { return loc_.IsRtl(); }
  const LoadReport& loadReport() const { return loadReport_; }
  const std::string& fontError() const { return fontError_; }
  const std::string& viewedCharacter() const { return viewedChar_; }
  const std::string& viewedOutfit() const { return viewedOutfit_; }
  const CharacterVisual* previewVisual() const { return preview_.get(); }
  TextRenderer& text() { return text_; }
  Mixer& audio() { return audio_; }
  DebugStats& debugStats() { return dbg_; }
  void Persist();  // saves the profile; reports failures through a notice

 private:
  void Execute(const std::string& action);
  void Go(Screen s);
  void Back();
  void ShowNotice(const std::string& text);
  void StartRun(const std::string& encounterId);
  void FinishRunScreen();
  void ApplySettings();
  void RefreshPreview();
  void StepRun(float dt);
  void PlayEventSounds(const std::vector<GameEvent>& events);
  void UpdateMusic();
  std::string T(const std::string& key) const { return loc_.Get(key); }
  std::string T(const std::string& key, const std::vector<std::string>& a) const { return loc_.Format(key, a); }
  int Power() const;

  void DrawBackground(Framebuffer& fb, bool preview);
  void DrawPreview(Framebuffer& fb);
  void DrawLobby(UiCtx& c);
  void DrawPlay(UiCtx& c);
  void DrawEncounters(UiCtx& c);
  void DrawCharacters(UiCtx& c);
  void DrawInventory(UiCtx& c);
  void DrawProfile(UiCtx& c);
  void DrawSettings(UiCtx& c);
  void DrawLanguage(UiCtx& c);
  void DrawInGame(UiCtx& c);
  void DrawResult(UiCtx& c);
  void DrawOverlay(UiCtx& c);

  AppConfig cfg_;
  ContentDb db_;
  LevelsDb levels_;
  Localization loc_;
  TextRenderer text_;
  Mixer audio_;
  Profile profile_;
  SaveStore store_;
  LoadReport loadReport_;
  std::string fontError_;
  bool inited_ = false;

  int vw_ = 960, vh_ = 540;
  float pxPerMm_ = 6.4f;

  Screen screen_ = Screen::Lobby;
  std::vector<Screen> stack_;
  Overlay overlay_ = Overlay::None;
  std::string noticeText_;
  std::vector<std::string> pendingNotices_;
  std::vector<UiButton> buttons_;
  std::string pressedAction_;
  bool quit_ = false;

  ModeKind encKind_ = ModeKind::Mission;
  int page_ = 0;
  int invSel_ = -1;
  std::string viewedChar_, viewedOutfit_;
  std::unique_ptr<CharacterVisual> preview_;
  float previewTime_ = 0.f;

  // run state
  std::unique_ptr<GameSession> menuSession_;  // used for lock checks while no run is active
  std::unique_ptr<GameSession> session_;
  std::string runEncounter_;
  TouchRouter router_{TouchLayout{}};
  OrbitCamera cam_;
  Camera camera_;
  SceneRenderer scene_;
  Rasterizer rast_;
  FixedStepper stepper_{1.f / 60.f, 5};
  std::unique_ptr<CharacterVisual> playerVisual_;
  Vec2 keyMove_{};
  InputFrame keyFrame_;
  float lastMoveMag_ = 0.f;
  DebugStats dbg_;
  float fpsAcc_ = 0.f;
  int fpsFrames_ = 0;
  bool resultShown_ = false;
  std::string lastLanguageApplied_;
};

}  // namespace ascend
