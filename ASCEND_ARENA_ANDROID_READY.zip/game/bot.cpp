#include "bot.h"

#include <cmath>

namespace ascend {

InputFrame ScriptedBot::Next(const World& w, float cameraYaw) {
  InputFrame in;
  ++tick_;
  if (attackCooldownTicks_ > 0) --attackCooldownTicks_;
  const Player& p = w.player();
  if (!p.Alive()) return in;

  const Enemy* tgt = nullptr;
  float best = 1e9f;
  for (const auto& e : w.enemies()) {
    if (!e.Alive() || e.def->dummy) continue;
    const float d = DistanceXZ(e.pos, p.pos);
    if (d < best) {
      best = d;
      tgt = &e;
    }
  }
  if (!tgt) return in;

  // Convert the world-space direction to camera-relative stick input.
  const Vec3 d = NormalizeXZ(tgt->pos - p.pos);
  const Vec3 fwd = ForwardFromYaw(cameraYaw);
  const Vec3 right{std::cos(cameraYaw), 0.f, -std::sin(cameraYaw)};
  const float f = Dot(d, fwd), r = Dot(d, right);

  const bool windupSoon = tgt->state == EnemyState::Attack && tgt->timer < 0.14f && best < tgt->def->attackRange + 1.f;
  if (windupSoon && p.dodgeCd.Ready()) {
    in.dodge = true;
    in.move = {-r, -f};  // roll away from the strike
    return in;
  }
  if (best > 1.9f && p.state != PlayerState::Attack) in.move = {r, f};

  if (best < 2.3f && attackCooldownTicks_ == 0) {
    in.attack = true;
    attackCooldownTicks_ = 12;
  }
  // Use skills opportunistically (the world validates cooldown, mana and level).
  if (best < 3.2f && (tick_ % 97) == 0) in.skill[0] = true;
  if (best < 3.0f && (tick_ % 211) == 0) in.skill[1] = true;
  return in;
}

}  // namespace ascend
