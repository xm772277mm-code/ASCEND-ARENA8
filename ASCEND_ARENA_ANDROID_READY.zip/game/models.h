#pragma once
// Procedural placeholder models (primitives). Used for enemies and as the fallback character until
// real glTF characters are loaded (Prompt 4). All are original shapes created in code.
#include <string>

#include "../engine/render/mesh.h"

namespace ascend {

struct HumanoidPalette {
  Color coat{40, 48, 90, 255};
  Color accent{200, 60, 70, 255};
  Color skin{235, 200, 175, 255};
  Color hair{225, 228, 240, 255};
  Color blade{170, 220, 255, 255};
  Color boots{30, 30, 40, 255};
};

struct HumanoidModel {
  Mesh legL, legR, torso, head, armL, armR, weapon, cape;
  Vec3 hipPivot{0.f, 0.8f, 0.f};
  Vec3 shoulderL{-0.36f, 1.4f, 0.f}, shoulderR{0.36f, 1.4f, 0.f};
};
HumanoidModel BuildHumanoid(const HumanoidPalette& pal);

struct EnemyModel {
  Mesh body;
  Mesh weapon;  // optional, animated on windup/strike
  Vec3 weaponPivot{0.f, 1.2f, 0.f};
  float height = 1.6f;  // for health bar placement
  bool hasWeapon = false;
  Color telegraph{255, 90, 60, 255};
};
EnemyModel BuildEnemyModel(const std::string& enemyId);

// Flat fan covering an arc (degrees) of the given radius in the XZ plane at y=0, centered facing +z.
Mesh MakeArcSector(float radius, float arcDegrees, int segments, Color c);
// Flat ring in the XZ plane.
Mesh MakeRing(float outer, float inner, int segments, Color c);

}  // namespace ascend
