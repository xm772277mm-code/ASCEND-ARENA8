#include "hud.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace ascend {
namespace {

void Bar(Framebuffer& fb, float x, float y, float w, float h, float frac, Color fill, Color back) {
  fb.FillRect(x - 1.f, y - 1.f, w + 2.f, h + 2.f, Color{0, 0, 0, 170});
  fb.FillRect(x, y, w, h, back);
  fb.FillRect(x, y, w * Clamp(frac, 0.f, 1.f), h, fill);
}

// Draws text with the TrueType renderer when available, otherwise with the built-in 5x7 font.
float Txt(Framebuffer& fb, const HudInfo& info, float x, float y, const std::string& s, int px, Color c,
          TextAlign al = TextAlign::Left) {
  if (info.text && info.text->HasFont()) {
    // Soft shadow for readability on busy backgrounds.
    info.text->Draw(fb, x + 1.f, y + 1.f, s, px, Color{0, 0, 0, static_cast<std::uint8_t>(c.a / 2)}, al);
    return info.text->Draw(fb, x, y, s, px, c, al);
  }
  const int scale = std::max(1, px / 9);
  const float w = Framebuffer::TextWidth(s, scale);
  float xx = x;
  if (al == TextAlign::Center)
    xx = x - w * 0.5f;
  else if (al == TextAlign::Right)
    xx = x - w;
  return fb.DrawText(xx, y, s, scale, c);
}

float Width(const HudInfo& info, const std::string& s, int px) {
  if (info.text && info.text->HasFont()) return info.text->Measure(s, px);
  return Framebuffer::TextWidth(s, std::max(1, px / 9));
}

}  // namespace

int HudTextPx(int fbHeight, float textScale) {
  const float s = Clamp(textScale, 0.8f, 1.6f);
  return ClampInt(static_cast<int>(std::lround(static_cast<float>(fbHeight) / 26.f * s)), 10, 64);
}

void DrawHud(Framebuffer& fb, const Rasterizer& rast, const World& w, const ContentDb& db, const TouchRouter* router,
             const TouchLayout& layout, const HudInfo& info, const HudOptions& opt, const DebugStats& dbg) {
  (void)db;
  const float W = static_cast<float>(fb.width()), H = static_cast<float>(fb.height());
  const int px = HudTextPx(fb.height(), info.textScale);
  const float u = static_cast<float>(px) / 8.f;  // layout unit that scales with the text size
  const Player& p = w.player();

  // Enemy health bars above heads (only enemies that have noticed the player or are hurt).
  for (const auto& e : w.enemies()) {
    if (!e.Alive()) continue;
    if (!e.aware && e.hp.cur == e.hp.max) continue;
    float sx = 0.f, sy = 0.f;
    if (!rast.Project({e.pos.x, e.def->radius * 2.f + 1.5f, e.pos.z}, sx, sy)) continue;
    const float bw = (e.def->enrageBelowPercent > 0 ? 34.f : 22.f) * u, bh = 2.f * u;
    Bar(fb, sx - bw * 0.5f, sy, bw, bh, e.hp.Fraction(), e.enraged ? Color{255, 120, 40, 255} : Color{220, 60, 70, 255},
        Color{60, 20, 30, 255});
  }

  // Boss bar: a living boss (enrage-capable enemy) that has noticed the player.
  for (const auto& e : w.enemies()) {
    if (!e.Alive() || e.def->enrageBelowPercent <= 0 || !e.aware) continue;
    const float bw = W * 0.4f, bx = (W - bw) * 0.5f, by = 4.f * u;
    Bar(fb, bx, by, bw, 3.f * u, e.hp.Fraction(), e.enraged ? Color{255, 120, 40, 255} : Color{200, 50, 90, 255},
        Color{50, 16, 30, 255});
    break;
  }

  // Player bars (top-left).
  const float bx = 6.f * u, bw = 70.f * u;
  float by = 6.f * u;
  Bar(fb, bx, by, bw, 4.f * u, p.hp.Fraction(), Color{210, 55, 70, 255}, Color{60, 20, 28, 255});
  Txt(fb, info, bx + 2.f * u, by - 0.5f * u, std::to_string(p.hp.cur) + "/" + std::to_string(p.hp.max), px * 3 / 4,
      Color{255, 255, 255, 255});
  by += 6.f * u;
  Bar(fb, bx, by, bw, 3.f * u, p.mana.Fraction(), Color{70, 120, 235, 255}, Color{20, 30, 64, 255});
  by += 5.f * u;
  Bar(fb, bx, by, bw, 2.f * u,
      info.xpToNext > 0 ? static_cast<float>(info.xp) / static_cast<float>(info.xpToNext) : 0.f,
      Color{240, 200, 70, 255}, Color{56, 48, 20, 255});
  by += 3.f * u;
  const float lw = Txt(fb, info, bx, by, info.levelText, px, Color{255, 244, 210, 255});
  Txt(fb, info, bx + lw + 4.f * u, by, info.goldText, px, Color{255, 220, 120, 255});
  if (!info.objective.empty()) {
    by += static_cast<float>(px) * 1.25f;
    Txt(fb, info, bx, by, info.objective, px, Color{210, 225, 255, 255});
  }

  // Joystick (appears where the thumb touched down).
  Vec2 jb{}, jk{};
  if (router && router->JoystickVisual(jb, jk)) {
    fb.FillRing(jb.x, jb.y, layout.joystickRadius, layout.joystickRadius - u, Color{255, 255, 255, 120});
    fb.FillCircle(jk.x, jk.y, layout.joystickRadius * 0.45f, Color{255, 255, 255, 150});
  } else {
    const float hx = layout.joystickRadius * 1.3f, hy = H - layout.joystickRadius * 1.3f;
    fb.FillRing(hx, hy, layout.joystickRadius, layout.joystickRadius - u * 0.5f, Color{255, 255, 255, 50});
    fb.FillCircle(hx, hy, layout.joystickRadius * 0.4f, Color{255, 255, 255, 40});
  }

  // Buttons.
  for (const auto& b : layout.buttons) {
    float cdFrac = 0.f;
    bool dim = false;
    std::string label, sub;
    switch (b.action) {
      case ButtonAction::Attack:
        label = info.attackLabel;
        break;
      case ButtonAction::Heavy:
        label = info.heavyLabel;
        break;
      case ButtonAction::Dodge:
        label = info.dodgeLabel;
        cdFrac = p.dodgeCd.Fraction();
        break;
      case ButtonAction::Skill1:
      case ButtonAction::Skill2:
      case ButtonAction::Skill3: {
        const std::size_t i = static_cast<std::size_t>(b.action) - static_cast<std::size_t>(ButtonAction::Skill1);
        const SkillDef* s = w.loadout().skills[i];
        label = std::to_string(i + 1);
        cdFrac = p.skillCd[i].Fraction();
        if (!s) {
          dim = true;
          label = "-";
        } else if (p.level < s->unlockLevel) {
          dim = true;
          sub = "Lv" + std::to_string(s->unlockLevel);
        } else {
          if (p.mana.cur < s->manaCost) dim = true;
          if (s->manaCost > 0) sub = std::to_string(s->manaCost);
        }
        break;
      }
      case ButtonAction::Pause:
        label = "II";
        break;
      case ButtonAction::Potion:
        label = "+";
        sub = "x" + std::to_string(info.potions);
        dim = info.potions <= 0 || p.hp.cur >= p.hp.max;
        break;
    }
    fb.FillCircle(b.cx, b.cy, b.radius, dim ? Color{20, 22, 36, 150} : Color{30, 34, 60, 170});
    fb.FillRing(b.cx, b.cy, b.radius, b.radius - u * 0.6f,
                Color{200, 210, 255, static_cast<std::uint8_t>(dim ? 80 : 200)});
    if (cdFrac > 0.f) fb.FillPie(b.cx, b.cy, b.radius, cdFrac, Color{0, 0, 0, 150});
    const int lpx = static_cast<int>(std::min(static_cast<float>(px), b.radius * 0.9f));
    const bool hasSub = !sub.empty();
    const float ly = b.cy - static_cast<float>(lpx) * (hasSub ? 0.85f : 0.6f);
    Txt(fb, info, b.cx, ly, label, lpx, dim ? Color{140, 145, 170, 255} : Color{255, 255, 255, 255}, TextAlign::Center);
    if (hasSub)
      Txt(fb, info, b.cx, b.cy + static_cast<float>(lpx) * 0.05f, sub, lpx * 3 / 4, Color{140, 190, 255, 255},
          TextAlign::Center);
  }

  // Dialogue box.
  if (!info.dialogue.empty()) {
    const float bh = H * 0.30f;
    fb.FillRect(0.f, H - bh, W, bh, Color{8, 8, 20, 215});
    fb.FillRect(0.f, H - bh, W, 2.f, Color{200, 180, 120, 255});
    const bool rtl = info.text && ContainsRtl(info.dialogue);
    const float margin = W * 0.06f;
    std::vector<std::string> lines =
        info.text ? info.text->Wrap(info.dialogue, px + 2, W - 2.f * margin) : std::vector<std::string>{info.dialogue};
    float ly = H - bh + static_cast<float>(px) * 0.8f;
    for (const auto& l : lines) {
      Txt(fb, info, rtl ? W - margin : margin, ly, l, px + 2, Color{245, 240, 225, 255},
          rtl ? TextAlign::Right : TextAlign::Left);
      ly += static_cast<float>(px) * 1.5f;
    }
    Txt(fb, info, W - margin, H - static_cast<float>(px) * 1.8f, info.dialogueHint, px * 3 / 4,
        Color{180, 190, 220, 255}, TextAlign::Right);
  }

  // Banners and pause overlay.
  if (info.paused) {
    fb.FillRect(0.f, 0.f, W, H, Color{0, 0, 0, 150});
    Txt(fb, info, W * 0.5f, H * 0.34f, info.pausedText, px * 2, Color{255, 255, 255, 255}, TextAlign::Center);
    Txt(fb, info, W * 0.5f, H * 0.34f + static_cast<float>(px) * 2.6f, info.resumeText, px, Color{200, 210, 240, 255},
        TextAlign::Center);
  } else if (!info.banner.empty()) {
    fb.FillRect(0.f, H * 0.30f, W, H * 0.24f, Color{0, 0, 0, 150});
    Txt(fb, info, W * 0.5f, H * 0.33f, info.banner, px * 2, Color{255, 230, 140, 255}, TextAlign::Center);
    if (!info.bannerSub.empty())
      Txt(fb, info, W * 0.5f, H * 0.33f + static_cast<float>(px) * 2.7f, info.bannerSub, px, Color{225, 230, 250, 255},
          TextAlign::Center);
  }

  // Debug overlay (off by default). Numbers are measured; nothing here is estimated.
  if (opt.showDebug) {
    char l1[96], l2[96], l3[96];
    std::snprintf(l1, sizeof l1, "FPS %.0f  frame %.1f ms", static_cast<double>(dbg.fps),
                  static_cast<double>(dbg.frameMs));
    if (dbg.rssKb >= 0)
      std::snprintf(l2, sizeof l2, "MEM %ld MB", dbg.rssKb / 1024);
    else
      std::snprintf(l2, sizeof l2, "MEM n/a");
    std::snprintf(l3, sizeof l3, "TRI %d  FX %d  EN %d", dbg.triangles, dbg.effects, w.AliveEnemyCount());
    const int dp = std::max(10, px * 3 / 4);
    const float dw = std::max({Width(info, l1, dp), Width(info, l2, dp), Width(info, l3, dp)}) + 8.f * u;
    const float dx = W - dw - 2.f * u, dy = 2.f * u;
    fb.FillRect(dx, dy, dw, static_cast<float>(dp) * 4.2f, Color{0, 0, 0, 150});
    Txt(fb, info, dx + 4.f * u, dy + 2.f, l1, dp, Color{150, 255, 150, 255});
    Txt(fb, info, dx + 4.f * u, dy + 2.f + static_cast<float>(dp) * 1.3f, l2, dp, Color{150, 255, 150, 255});
    Txt(fb, info, dx + 4.f * u, dy + 2.f + static_cast<float>(dp) * 2.6f, l3, dp, Color{150, 255, 150, 255});
  }
}

}  // namespace ascend
