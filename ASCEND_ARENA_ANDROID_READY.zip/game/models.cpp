#include "models.h"

#include <cmath>

namespace ascend {
namespace {

Mesh BoxAt(Vec3 center, Vec3 size, Color c) {
  Mesh m = MakeBox(size, c);
  Mesh out;
  out.Append(m, Mat4::Translation(center));
  return out;
}
Mesh SphereAt(Vec3 center, float r, Color c, int rings = 8, int segs = 12) {
  Mesh m = MakeSphere(r, rings, segs, c);
  Mesh out;
  out.Append(m, Mat4::Translation(center));
  return out;
}
Mesh CylAt(Vec3 base, float r, float h, Color c, int segs = 12) {
  Mesh m = MakeCylinder(r, h, segs, c);
  Mesh out;
  out.Append(m, Mat4::Translation(base));
  return out;
}
void Add(Mesh& dst, const Mesh& src) { dst.Append(src, Mat4::Identity()); }
Color Shade(Color c, float f) {
  auto s = [&](std::uint8_t v) { return static_cast<std::uint8_t>(Clamp(static_cast<float>(v) * f, 0.f, 255.f)); };
  return {s(c.r), s(c.g), s(c.b), c.a};
}

}  // namespace

HumanoidModel BuildHumanoid(const HumanoidPalette& p) {
  HumanoidModel h;
  // Legs hang from the hip pivot (y = 0.8); built in absolute character space.
  h.legL = BoxAt({-0.14f, 0.4f, 0.f}, {0.18f, 0.8f, 0.22f}, p.coat);
  Add(h.legL, BoxAt({-0.14f, 0.07f, 0.04f}, {0.2f, 0.14f, 0.3f}, p.boots));
  h.legR = BoxAt({0.14f, 0.4f, 0.f}, {0.18f, 0.8f, 0.22f}, p.coat);
  Add(h.legR, BoxAt({0.14f, 0.07f, 0.04f}, {0.2f, 0.14f, 0.3f}, p.boots));
  // Torso with belt and a chest sash.
  h.torso = BoxAt({0.f, 1.1f, 0.f}, {0.5f, 0.6f, 0.3f}, p.coat);
  Add(h.torso, BoxAt({0.f, 0.82f, 0.f}, {0.52f, 0.08f, 0.32f}, p.accent));
  Add(h.torso, BoxAt({0.f, 1.15f, 0.155f}, {0.12f, 0.5f, 0.02f}, p.accent));
  // Head: skin face, silver hair cap and swept spikes.
  h.head = SphereAt({0.f, 1.62f, 0.f}, 0.19f, p.skin);
  Add(h.head, SphereAt({0.f, 1.68f, -0.03f}, 0.215f, p.hair));
  Add(h.head, BoxAt({0.f, 1.60f, 0.17f}, {0.26f, 0.05f, 0.03f}, p.hair));  // fringe
  Add(h.head, BoxAt({-0.07f, 1.62f, 0.185f}, {0.05f, 0.05f, 0.02f}, Color{20, 20, 30, 255}));
  Add(h.head, BoxAt({0.07f, 1.62f, 0.185f}, {0.05f, 0.05f, 0.02f}, Color{20, 20, 30, 255}));
  Add(h.head, BoxAt({0.f, 1.78f, -0.18f}, {0.08f, 0.22f, 0.08f}, p.hair));
  Add(h.head, BoxAt({0.1f, 1.76f, -0.14f}, {0.07f, 0.2f, 0.07f}, Color{200, 205, 225, 255}));
  // Arms hang from the shoulders (y = 1.4).
  h.armL = BoxAt({-0.36f, 1.12f, 0.f}, {0.14f, 0.56f, 0.16f}, Shade(p.coat, 1.15f));
  h.armR = BoxAt({0.36f, 1.12f, 0.f}, {0.14f, 0.56f, 0.16f}, Shade(p.coat, 1.15f));
  // Weapon: a long blade held in the right hand, pointing forward when the arm is raised.
  h.weapon = BoxAt({0.36f, 0.85f, 0.f}, {0.07f, 0.14f, 0.07f}, p.boots);      // grip
  Add(h.weapon, BoxAt({0.36f, 0.93f, 0.f}, {0.2f, 0.05f, 0.07f}, p.accent));  // guard
  Add(h.weapon, BoxAt({0.36f, 1.45f, 0.f}, {0.05f, 1.0f, 0.025f}, p.blade));  // blade
  h.cape = BoxAt({0.f, 1.05f, -0.2f}, {0.46f, 0.8f, 0.04f}, Shade(p.accent, 0.75f));
  return h;
}

EnemyModel BuildEnemyModel(const std::string& id) {
  EnemyModel m;
  if (id == "wisp_grunt") {
    const Color body{120, 70, 175, 255}, glow{255, 245, 170, 255}, dark{70, 40, 110, 255};
    m.body = SphereAt({0.f, 0.65f, 0.f}, 0.42f, body);
    Add(m.body, SphereAt({-0.15f, 0.72f, 0.34f}, 0.09f, glow, 6, 8));
    Add(m.body, SphereAt({0.15f, 0.72f, 0.34f}, 0.09f, glow, 6, 8));
    Add(m.body, SphereAt({0.f, 0.28f, -0.1f}, 0.24f, dark, 6, 8));
    Add(m.body, SphereAt({0.f, 0.08f, -0.2f}, 0.13f, dark, 6, 8));
    // Claws as the "weapon".
    m.weapon = BoxAt({0.38f, 0.55f, 0.28f}, {0.08f, 0.08f, 0.45f}, Color{235, 230, 255, 255});
    Add(m.weapon, BoxAt({-0.38f, 0.55f, 0.28f}, {0.08f, 0.08f, 0.45f}, Color{235, 230, 255, 255}));
    m.weaponPivot = {0.f, 0.6f, 0.f};
    m.hasWeapon = true;
    m.height = 1.25f;
  } else if (id == "bone_brute") {
    const Color bone{196, 190, 170, 255}, dark{90, 84, 80, 255};
    m.body = BoxAt({-0.28f, 0.45f, 0.f}, {0.3f, 0.9f, 0.34f}, dark);
    Add(m.body, BoxAt({0.28f, 0.45f, 0.f}, {0.3f, 0.9f, 0.34f}, dark));
    Add(m.body, BoxAt({0.f, 1.3f, 0.f}, {1.0f, 0.95f, 0.6f}, bone));
    Add(m.body, BoxAt({0.f, 1.35f, 0.31f}, {0.8f, 0.12f, 0.04f}, dark));  // rib
    Add(m.body, BoxAt({0.f, 1.15f, 0.31f}, {0.7f, 0.1f, 0.04f}, dark));
    Add(m.body, BoxAt({0.f, 2.0f, 0.05f}, {0.5f, 0.45f, 0.46f}, bone));
    Add(m.body, BoxAt({-0.12f, 2.02f, 0.28f}, {0.1f, 0.1f, 0.03f}, Color{255, 80, 50, 255}));
    Add(m.body, BoxAt({0.12f, 2.02f, 0.28f}, {0.1f, 0.1f, 0.03f}, Color{255, 80, 50, 255}));
    Add(m.body, BoxAt({-0.62f, 1.3f, 0.f}, {0.26f, 0.8f, 0.3f}, bone));
    m.weapon = BoxAt({0.62f, 0.9f, 0.05f}, {0.22f, 1.5f, 0.22f}, Color{110, 80, 60, 255});
    Add(m.weapon, BoxAt({0.62f, 1.7f, 0.05f}, {0.45f, 0.4f, 0.45f}, Color{130, 95, 70, 255}));
    m.weaponPivot = {0.62f, 1.6f, 0.f};
    m.hasWeapon = true;
    m.height = 2.5f;
  } else if (id == "hollow_archer") {
    const Color robe{36, 78, 92, 255}, hood{24, 52, 64, 255};
    m.body = CylAt({0.f, 0.f, 0.f}, 0.3f, 1.25f, robe);
    Add(m.body, SphereAt({0.f, 1.5f, 0.f}, 0.22f, hood));
    Add(m.body, CylAt({0.f, 1.55f, 0.f}, 0.2f, 0.4f, hood, 8));
    Add(m.body, SphereAt({0.f, 1.48f, 0.17f}, 0.07f, Color{140, 255, 230, 255}, 6, 8));
    m.weapon = BoxAt({0.f, 1.1f, 0.5f}, {0.05f, 1.2f, 0.05f}, Color{150, 120, 80, 255});
    Add(m.weapon, BoxAt({0.f, 1.1f, 0.35f}, {0.02f, 1.1f, 0.02f}, Color{230, 230, 230, 255}));
    m.weaponPivot = {0.f, 1.1f, 0.f};
    m.hasWeapon = true;
    m.height = 2.0f;
    m.telegraph = {120, 255, 230, 255};
  } else if (id == "gate_warden") {
    const Color armor{42, 36, 64, 255}, trim{120, 60, 150, 255}, core{255, 70, 90, 255};
    m.body = BoxAt({-0.4f, 0.7f, 0.f}, {0.5f, 1.4f, 0.55f}, armor);
    Add(m.body, BoxAt({0.4f, 0.7f, 0.f}, {0.5f, 1.4f, 0.55f}, armor));
    Add(m.body, BoxAt({0.f, 2.0f, 0.f}, {1.6f, 1.5f, 0.95f}, armor));
    Add(m.body, BoxAt({0.f, 2.0f, 0.5f}, {1.2f, 1.0f, 0.06f}, trim));
    Add(m.body, SphereAt({0.f, 2.05f, 0.56f}, 0.2f, core, 6, 10));
    Add(m.body, BoxAt({0.f, 3.05f, 0.f}, {0.8f, 0.7f, 0.75f}, armor));
    Add(m.body, BoxAt({-0.22f, 3.08f, 0.38f}, {0.18f, 0.1f, 0.03f}, core));
    Add(m.body, BoxAt({0.22f, 3.08f, 0.38f}, {0.18f, 0.1f, 0.03f}, core));
    Add(m.body, CylAt({-0.4f, 3.3f, 0.f}, 0.1f, 0.9f, trim, 6));
    Add(m.body, CylAt({0.4f, 3.3f, 0.f}, 0.1f, 0.9f, trim, 6));
    Add(m.body, BoxAt({-1.05f, 2.2f, 0.f}, {0.5f, 0.9f, 0.5f}, trim));  // pauldron
    m.weapon = BoxAt({1.05f, 1.6f, 0.2f}, {0.25f, 0.25f, 0.25f}, Color{30, 28, 36, 255});
    Add(m.weapon, BoxAt({1.05f, 0.6f, 0.2f}, {0.2f, 2.2f, 0.12f}, Color{120, 110, 150, 255}));
    m.weaponPivot = {1.05f, 2.4f, 0.f};
    m.hasWeapon = true;
    m.height = 4.2f;
    m.telegraph = {255, 60, 90, 255};
  } else if (id == "training_dummy") {
    const Color straw{200, 170, 100, 255}, wood{110, 80, 55, 255};
    m.body = CylAt({0.f, 0.f, 0.f}, 0.45f, 0.12f, wood);
    Add(m.body, CylAt({0.f, 0.f, 0.f}, 0.1f, 1.5f, wood, 8));
    Add(m.body, CylAt({0.f, 0.7f, 0.f}, 0.3f, 0.7f, straw));
    Add(m.body, BoxAt({0.f, 1.1f, 0.f}, {1.0f, 0.12f, 0.12f}, wood));
    Add(m.body, SphereAt({0.f, 1.65f, 0.f}, 0.22f, straw));
    Add(m.body, BoxAt({0.f, 0.95f, 0.31f}, {0.35f, 0.35f, 0.02f}, Color{190, 50, 50, 255}));  // target mark
    m.height = 2.0f;
  } else {
    // Unknown enemy id: loud magenta cube so a content mistake is visible, never a crash.
    m.body = BoxAt({0.f, 0.5f, 0.f}, {1.f, 1.f, 1.f}, Color{255, 0, 255, 255});
    m.height = 1.5f;
  }
  return m;
}

Mesh MakeArcSector(float radius, float arcDegrees, int segments, Color c) {
  Mesh m;
  if (segments < 2) segments = 2;
  const float arc = arcDegrees * kPi / 180.f;
  m.vertices.push_back({{0.f, 0.f, 0.f}, c});
  for (int i = 0; i <= segments; ++i) {
    const float a = -arc * 0.5f + arc * static_cast<float>(i) / static_cast<float>(segments);
    m.vertices.push_back({{std::sin(a) * radius, 0.f, std::cos(a) * radius}, c});
  }
  for (int i = 0; i < segments; ++i)
    m.indices.insert(m.indices.end(), {0u, static_cast<std::uint32_t>(i + 2), static_cast<std::uint32_t>(i + 1)});
  return m;
}

Mesh MakeRing(float outer, float inner, int segments, Color c) {
  Mesh m;
  if (segments < 3) segments = 3;
  for (int i = 0; i < segments; ++i) {
    const float a = 2.f * kPi * static_cast<float>(i) / static_cast<float>(segments);
    m.vertices.push_back({{std::sin(a) * outer, 0.f, std::cos(a) * outer}, c});
    m.vertices.push_back({{std::sin(a) * inner, 0.f, std::cos(a) * inner}, c});
  }
  for (int i = 0; i < segments; ++i) {
    const auto o0 = static_cast<std::uint32_t>(i * 2), i0 = o0 + 1;
    const auto o1 = static_cast<std::uint32_t>(((i + 1) % segments) * 2), i1 = o1 + 1;
    m.indices.insert(m.indices.end(), {o0, o1, i0, i0, o1, i1});
  }
  return m;
}

}  // namespace ascend
