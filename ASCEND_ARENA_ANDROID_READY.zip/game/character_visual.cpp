#include "character_visual.h"

#include <algorithm>
#include <filesystem>

#include "../engine/assets/ini.h"
#ifdef ASCEND_WITH_GLTF
#include "../engine/assets/glb_loader.h"
#endif

namespace ascend {
namespace {

bool ParseRgb(const std::string& s, Color& out) {
  int v[3] = {0, 0, 0};
  std::size_t pos = 0;
  for (int i = 0; i < 3; ++i) {
    try {
      std::size_t n = 0;
      v[i] = std::stoi(s.substr(pos), &n);
      pos += n;
    } catch (...) {
      return false;
    }
    if (v[i] < 0 || v[i] > 255) return false;
    if (i < 2) {
      while (pos < s.size() && (s[pos] == ' ' || s[pos] == ',')) ++pos;
    }
  }
  out = {static_cast<std::uint8_t>(v[0]), static_cast<std::uint8_t>(v[1]), static_cast<std::uint8_t>(v[2]), 255};
  return true;
}

void Fallback(CharacterVisual& v, const std::string& why) {
  v.usedFallback = true;
  v.error = why;
}

}  // namespace

std::string ClipFor(const CharacterDef& def, const std::string& key) {
  auto it = def.animMap.find(key);
  return it == def.animMap.end() ? key : it->second;
}

std::unique_ptr<CharacterVisual> LoadCharacterVisual(const CharacterDef& def, const std::string& outfitId,
                                                     const std::string& root) {
  auto v = std::make_unique<CharacterVisual>();
  v->characterId = def.id;
  v->outfitId = outfitId;
  if (def.modelPath.rfind("builtin:", 0) == 0) {
    v->usedFallback = true;
    v->placeholderByDesign = true;
    return v;
  }
#ifndef ASCEND_WITH_GLTF
  Fallback(*v, "this build has no glTF importer (ASCEND_WITH_GLTF=OFF)");
  return v;
#else
  namespace fs = std::filesystem;
  auto base = LoadGlbFile((fs::path(root) / def.modelPath).string());
  if (!base) {
    Fallback(*v, base.status.message);
    return v;
  }
  v->model = std::move(base.value);

  const OutfitDef* outfit = nullptr;
  if (!outfitId.empty()) {
    for (const auto& o : def.outfits)
      if (o.id == outfitId) outfit = &o;
    if (!outfit) v->warnings.push_back("unknown outfit '" + outfitId + "'; using the default outfit");
  }
  if (outfit) {
    if (!outfit->meshPath.empty()) {  // real geometry swap: a different mesh on the same skeleton
      auto om = LoadGlbFile((fs::path(root) / outfit->meshPath).string());
      if (!om) {
        v->warnings.push_back("outfit mesh failed: " + om.status.message + " (default outfit used)");
      } else if (!SameSkeleton(v->model, om.value)) {
        v->warnings.push_back("outfit mesh '" + outfit->meshPath + "' has a different skeleton (default outfit used)");
      } else {
        om.value.clips = std::move(v->model.clips);  // animations stay with the character
        v->model = std::move(om.value);
      }
    }
    if (!outfit->materialPath.empty()) {  // material swap: recolor named materials
      auto doc = LoadIniFile((fs::path(root) / outfit->materialPath).string());
      if (!doc) {
        v->warnings.push_back("outfit materials failed: " + doc.status.message);
      } else if (const IniSection* s = doc.value.Find("colors")) {
        for (const auto& [name, val] : s->values) {
          Color c;
          const int mi = v->model.FindMaterial(name);
          if (mi < 0)
            v->warnings.push_back("outfit recolors unknown material '" + name + "'");
          else if (!ParseRgb(val, c))
            v->warnings.push_back("outfit color '" + name + "' is not r,g,b");
          else
            v->model.materials[static_cast<std::size_t>(mi)].color = c;
        }
      } else {
        v->warnings.push_back("outfit materials file has no [colors] section");
      }
    }
  }
  for (const char* key : {"idle", "run", "attack", "hit", "dodge", "defeat"})
    if (v->model.FindClip(ClipFor(def, key)) < 0)
      v->warnings.push_back(std::string("missing animation clip '") + ClipFor(def, key) + "' for " + key);
  v->anim.SetModel(&v->model);
  v->anim.Play(ClipFor(def, "idle"), true, 0.f);
  v->anim.Update(0.f);
  return v;
#endif
}

void CharacterVisual::Tick(const Player& p, const CharacterDef& def, float moveMag, float dt) {
  if (usedFallback) return;
  const bool newAction = p.actionSerial != lastSerial;
  lastSerial = p.actionSerial;
  std::string key = "idle";
  bool loop = true;
  float speed = 1.f;
  switch (p.state) {
    case PlayerState::Idle:
      key = "idle";
      break;
    case PlayerState::Run:
      key = moveMag < 0.55f ? "walk" : "run";
      break;
    case PlayerState::Attack:
      key = "attack";
      loop = false;
      break;
    case PlayerState::Dodge:
      key = "dodge";
      loop = false;
      break;
    case PlayerState::Hurt:
      key = "hit";
      loop = false;
      break;
    case PlayerState::Dead:
      key = "defeat";
      loop = false;
      break;
  }
  if (!loop && p.stateDuration > 0.05f && p.state != PlayerState::Dead) {
    const int ci = model.FindClip(ClipFor(def, key));
    if (ci >= 0) speed = Clamp(model.clips[static_cast<std::size_t>(ci)].duration / p.stateDuration, 0.8f, 3.f);
  }
  std::string clip = ClipFor(def, key);
  if (model.FindClip(clip) < 0) clip = ClipFor(def, "idle");  // missing clip: stay on idle rather than T-pose
  anim.Play(clip, loop, 0.1f, !loop && newAction, speed);
  anim.Update(dt);
  SkinToMesh(model, SkinMatrices(model, anim.pose()), skinned);
}

void CharacterVisual::TickPreview(const CharacterDef& def, float dt) {
  if (usedFallback) return;
  anim.Play(ClipFor(def, "idle"), true, 0.1f);
  anim.Update(dt);
  SkinToMesh(model, SkinMatrices(model, anim.pose()), skinned);
}

}  // namespace ascend
