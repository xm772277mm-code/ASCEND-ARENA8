#include "scene_renderer.h"

#include <algorithm>
#include <cmath>

namespace ascend {
namespace {

constexpr std::size_t kMaxSparks = 160;
constexpr std::size_t kMaxTexts = 24;
constexpr std::size_t kMaxSlashes = 12;

Color DamageColor(DamageType t) {
  switch (t) {
    case DamageType::Physical:
      return {235, 240, 255, 255};
    case DamageType::Fire:
      return {255, 150, 60, 255};
    case DamageType::Shadow:
      return {170, 90, 255, 255};
    case DamageType::Holy:
      return {255, 235, 140, 255};
  }
  return {255, 255, 255, 255};
}

Mat4 Base(Vec3 pos, float yaw, float scale = 1.f) {
  return Mat4::Translation(pos) * Mat4::RotationY(yaw) * Mat4::Scale({scale, scale, scale});
}
// Rotates around `pivot` (model space) about X by `angle`, then applies `base`.
Mat4 Pivoted(const Mat4& base, Vec3 pivot, float angle) {
  return base * Mat4::Translation(pivot) * Mat4::RotationX(angle) * Mat4::Translation(pivot * -1.f);
}

}  // namespace

SceneRenderer::SceneRenderer() {
  player_ = BuildHumanoid({});
  shadow_ = MakeDisc(1.f, 16, Color{0, 0, 0, 110});
  projectile_ = MakeSphere(0.22f, 6, 8, Color{190, 120, 255, 255});
  spark_ = MakeBox({0.1f, 0.1f, 0.1f}, Color{255, 255, 255, 255});
  wallBox_ = MakeBox({1.f, 1.f, 1.f}, Color{46, 48, 70, 255});
  pillar_ = MakeBox({1.f, 1.f, 1.f}, Color{92, 96, 128, 255});
}

const EnemyModel& SceneRenderer::ModelFor(const std::string& id) {
  for (const auto& p : enemyModels_)
    if (p.first == id) return p.second;
  enemyModels_.emplace_back(id, BuildEnemyModel(id));
  return enemyModels_.back().second;
}

void SceneRenderer::ClearEffects() {
  texts_.clear();
  sparks_.clear();
  slashes_.clear();
}

void SceneRenderer::OnEvents(const std::vector<GameEvent>& events, const World& w, const ContentDb& db) {
  for (const auto& ev : events) {
    switch (ev.type) {
      case EventType::EnemyHit: {
        if (texts_.size() < kMaxTexts) {
          FloatingText t;
          t.pos = ev.pos;
          t.pos.y = 2.0f;
          t.text = std::to_string(ev.amount) + (ev.crit ? "!" : "");
          t.color = ev.crit ? Color{255, 220, 60, 255} : Color{255, 255, 255, 255};
          t.scale = ev.crit ? 3 : 2;
          texts_.push_back(t);
        }
        const SkillDef* s = db.Skill(ev.refId);
        const Color c = DamageColor(s ? s->type : DamageType::Physical);
        const int n = quality_ == Quality::Low ? 3 : (quality_ == Quality::Medium ? 6 : 10);
        for (int i = 0; i < n && sparks_.size() < kMaxSparks; ++i) {
          const float a = static_cast<float>(i) * 2.399963f;  // golden angle: deterministic spread
          Spark sp;
          sp.pos = {ev.pos.x, 1.1f, ev.pos.z};
          sp.vel = {std::sin(a) * 2.5f, 2.f + static_cast<float>(i % 3), std::cos(a) * 2.5f};
          sp.color = c;
          sparks_.push_back(sp);
        }
        break;
      }
      case EventType::PlayerHit: {
        if (texts_.size() < kMaxTexts) {
          FloatingText t;
          t.pos = ev.pos;
          t.pos.y = 2.2f;
          t.text = "-" + std::to_string(ev.amount);
          t.color = {255, 90, 90, 255};
          t.scale = 3;
          texts_.push_back(t);
        }
        break;
      }
      case EventType::SkillCast: {
        const SkillDef* s = db.Skill(ev.refId);
        if (!s || slashes_.size() >= kMaxSlashes) break;
        SlashFx fx;
        fx.pos = w.player().pos;
        fx.yaw = w.player().yaw;
        fx.range = s->range;
        fx.arc = s->arcDegrees;
        fx.circle = s->kind == SkillKind::Circle;
        if (s->kind == SkillKind::Dash) fx.arc = 24.f;
        fx.color = DamageColor(s->type);
        fx.color.a = 140;
        fx.life = s->kind == SkillKind::Circle ? 0.3f : 0.2f;
        slashes_.push_back(fx);
        break;
      }
      case EventType::EnemyDefeated: {
        const int n = quality_ == Quality::Low ? 6 : 16;
        for (int i = 0; i < n && sparks_.size() < kMaxSparks; ++i) {
          const float a = static_cast<float>(i) * 2.399963f;
          Spark sp;
          sp.pos = {ev.pos.x, 0.8f, ev.pos.z};
          sp.vel = {std::sin(a) * 3.f, 3.f + static_cast<float>(i % 4), std::cos(a) * 3.f};
          sp.color = {180, 120, 255, 255};
          sp.life = 0.8f;
          sparks_.push_back(sp);
        }
        break;
      }
      default:
        break;
    }
  }
}

void SceneRenderer::Update(float dt) {
  for (auto& s : sparks_) {
    s.age += dt;
    s.vel.y -= 9.f * dt;
    s.pos += s.vel * dt;
  }
  sparks_.erase(std::remove_if(sparks_.begin(), sparks_.end(), [](const Spark& s) { return s.age >= s.life; }),
                sparks_.end());
  for (auto& t : texts_) t.age += dt;
  texts_.erase(std::remove_if(texts_.begin(), texts_.end(), [](const FloatingText& t) { return t.age >= t.life; }),
               texts_.end());
  for (auto& s : slashes_) s.age += dt;
  slashes_.erase(std::remove_if(slashes_.begin(), slashes_.end(), [](const SlashFx& s) { return s.age >= s.life; }),
                 slashes_.end());
}

void SceneRenderer::DrawArena(Rasterizer& r, const ArenaDef& a) {
  if (floorHalf_ != a.half) {
    floor_ = MakeCheckerFloor(a.half, 2.f, Color{74, 78, 104, 255}, Color{62, 66, 92, 255});
    floorHalf_ = a.half;
  }
  DrawParams dp;
  r.Draw(floor_, dp);
  // Border walls just outside the playable square.
  const float h = a.half, t = 1.5f, wallH = 3.f;
  const struct {
    Vec3 c, s;
  } walls[4] = {{{0.f, wallH * 0.5f, h + t * 0.5f}, {2.f * h + 2.f * t, wallH, t}},
                {{0.f, wallH * 0.5f, -h - t * 0.5f}, {2.f * h + 2.f * t, wallH, t}},
                {{h + t * 0.5f, wallH * 0.5f, 0.f}, {t, wallH, 2.f * h}},
                {{-h - t * 0.5f, wallH * 0.5f, 0.f}, {t, wallH, 2.f * h}}};
  for (const auto& w : walls) {
    DrawParams p;
    p.model = Mat4::Translation(w.c) * Mat4::Scale(w.s);
    r.Draw(wallBox_, p);
  }
  for (const auto& o : a.obstacles) {
    const float hgt = 3.2f;
    DrawParams p;
    p.model = Mat4::Translation({(o.minX + o.maxX) * 0.5f, hgt * 0.5f, (o.minZ + o.maxZ) * 0.5f}) *
              Mat4::Scale({o.maxX - o.minX, hgt, o.maxZ - o.minZ});
    r.Draw(pillar_, p);
  }
}

void SceneRenderer::DrawPlayer(Rasterizer& r, const World& w) {
  const Player& p = w.player();
  // Shadow blob.
  {
    DrawParams sp;
    sp.model = Mat4::Translation({p.pos.x, 0.02f, p.pos.z}) * Mat4::Scale({0.6f, 1.f, 0.6f});
    sp.unlit = true;
    sp.cull = false;
    r.Draw(shadow_, sp);
  }
  if (visual_ && !visual_->usedFallback) {
    DrawParams dp;
    dp.flash = p.flash;
    dp.tint = (p.invuln > 0.f && p.state != PlayerState::Hurt && p.state != PlayerState::Dead)
                  ? Color{190, 220, 255, 255}
                  : Color{255, 255, 255, 255};
    dp.model = Base({p.pos.x, 0.f, p.pos.z}, p.yaw);
    r.Draw(visual_->skinned, dp);
    return;
  }
  const float t = p.animTime;
  const bool running = p.state == PlayerState::Run;
  const float swing = running ? std::sin(t * 12.f) * 0.7f : 0.f;
  float bob = running ? std::fabs(std::sin(t * 12.f)) * 0.06f : std::sin(t * 2.f) * 0.01f;
  float lean = 0.f, armR = 0.35f, armL = -swing * 0.8f;
  float progress = 0.f;
  if ((p.state == PlayerState::Attack || p.state == PlayerState::Dodge || p.state == PlayerState::Hurt) &&
      p.stateDuration > 0.f)
    progress = Clamp(1.f - p.stateTimer / p.stateDuration, 0.f, 1.f);
  if (p.state == PlayerState::Attack) {
    // Raise the sword back, then whip it forward and down.
    armR = progress < 0.3f ? Lerp(0.35f, -0.9f, progress / 0.3f) : Lerp(-0.9f, 2.3f, (progress - 0.3f) / 0.7f);
    lean = 0.12f * std::sin(progress * kPi);
  } else if (p.state == PlayerState::Dodge) {
    lean = 0.5f;
    armR = 0.9f;
  } else if (p.state == PlayerState::Hurt) {
    lean = -0.35f;
    armR = 0.9f;
  } else if (running) {
    armR = 0.35f + swing * 0.6f;
  }
  Mat4 base = Base({p.pos.x, bob, p.pos.z}, p.yaw);
  if (p.state == PlayerState::Dead) {
    base = Mat4::Translation({p.pos.x, 0.25f, p.pos.z}) * Mat4::RotationY(p.yaw) * Mat4::RotationX(-1.5f);
  } else if (std::fabs(lean) > 1e-4f) {
    base = base * Mat4::RotationX(lean);
  }
  DrawParams dp;
  dp.flash = p.flash;
  dp.tint = (p.invuln > 0.f && p.state != PlayerState::Hurt && p.state != PlayerState::Dead)
                ? Color{190, 220, 255, 255}
                : Color{255, 255, 255, 255};
  dp.model = base;
  r.Draw(player_.torso, dp);
  r.Draw(player_.head, dp);
  r.Draw(player_.cape, dp);
  dp.model = Pivoted(base, player_.hipPivot, swing);
  r.Draw(player_.legL, dp);
  dp.model = Pivoted(base, player_.hipPivot, -swing);
  r.Draw(player_.legR, dp);
  dp.model = Pivoted(base, player_.shoulderL, armL);
  r.Draw(player_.armL, dp);
  dp.model = Pivoted(base, player_.shoulderR, armR);
  r.Draw(player_.armR, dp);
  r.Draw(player_.weapon, dp);
}

void SceneRenderer::DrawEnemy(Rasterizer& r, const Enemy& e) {
  const EnemyModel& m = ModelFor(e.def->id);
  const float alphaF = e.state == EnemyState::Defeated ? Clamp(e.timer / 1.2f, 0.f, 1.f) : 1.f;
  {
    DrawParams sp;
    sp.model =
        Mat4::Translation({e.pos.x, 0.02f, e.pos.z}) * Mat4::Scale({e.def->radius * 1.3f, 1.f, e.def->radius * 1.3f});
    sp.unlit = true;
    sp.cull = false;
    sp.tint.a = static_cast<std::uint8_t>(255.f * alphaF);
    r.Draw(shadow_, sp);
  }
  float bob = 0.f, lean = 0.f, weaponAngle = 0.2f;
  const bool wisp = e.def->id == "wisp_grunt";
  if (wisp) bob = 0.12f + std::sin(e.animTime * 4.f + static_cast<float>(e.uid)) * 0.08f;
  const float windup = e.def->windup * (e.enraged ? 0.75f : 1.f);
  bool telegraph = false;
  if (e.state == EnemyState::Attack) {
    const float p = Clamp(1.f - e.timer / windup, 0.f, 1.f);
    weaponAngle = Lerp(0.2f, -2.4f, p);
    lean = -0.15f * p;
    telegraph = true;
  } else if (e.state == EnemyState::Recover) {
    const float p = Clamp(1.f - e.timer / e.def->recover, 0.f, 1.f);
    weaponAngle = Lerp(1.4f, 0.2f, p);
    lean = 0.2f * (1.f - p);
  } else if (e.state == EnemyState::Stagger) {
    lean = -0.3f;
  } else if (e.state == EnemyState::Approach || e.state == EnemyState::Patrol) {
    bob += std::fabs(std::sin(e.animTime * 7.f)) * 0.05f;
  }
  Mat4 base = Base({e.pos.x, bob, e.pos.z}, e.yaw);
  if (e.state == EnemyState::Defeated) {
    const float fall = Clamp((1.2f - e.timer) / 0.4f, 0.f, 1.f);
    base = Mat4::Translation({e.pos.x, 0.f, e.pos.z}) * Mat4::RotationY(e.yaw) * Mat4::RotationX(-1.4f * fall);
  } else if (std::fabs(lean) > 1e-4f) {
    base = base * Mat4::RotationX(lean);
  }
  DrawParams dp;
  dp.model = base;
  dp.flash = e.flash;
  dp.tint.a = static_cast<std::uint8_t>(255.f * alphaF);
  if (telegraph) {
    const float pulse = 0.5f + 0.5f * std::sin(e.animTime * 24.f);
    dp.flash = std::max(dp.flash, 0.25f + 0.35f * pulse);
    dp.flashColor = m.telegraph;
  }
  if (e.enraged) dp.tint = {255, 170, 170, dp.tint.a};
  r.Draw(m.body, dp);
  if (m.hasWeapon) {
    dp.model = Pivoted(base, m.weaponPivot, weaponAngle);
    r.Draw(m.weapon, dp);
  }
  // Ground telegraph for melee windups: the strike reach, so players can read and dodge it.
  if (telegraph && !e.def->ranged) {
    DrawParams tp;
    tp.model = Mat4::Translation({e.pos.x, 0.04f, e.pos.z}) * Mat4::RotationY(e.yaw);
    tp.unlit = true;
    tp.cull = false;
    tp.tint = m.telegraph;
    tp.tint.a = 110;
    static const Mesh sector = MakeArcSector(1.f, 100.f, 12, Color{255, 255, 255, 255});
    tp.model = tp.model * Mat4::Scale({e.def->attackRange, 1.f, e.def->attackRange});
    r.Draw(sector, tp);
  }
}

void SceneRenderer::DrawEffects(Rasterizer& r) {
  static const Mesh arc = MakeArcSector(1.f, 360.f, 24, Color{255, 255, 255, 255});
  for (const auto& s : slashes_) {
    const float k = s.age / s.life;
    DrawParams p;
    p.unlit = true;
    p.cull = false;
    p.tint = s.color;
    p.tint.a = static_cast<std::uint8_t>(static_cast<float>(s.color.a) * (1.f - k));
    const Mesh sector = s.circle ? arc : MakeArcSector(1.f, s.arc, 14, Color{255, 255, 255, 255});
    const float grow = 0.6f + 0.4f * k;
    p.model = Mat4::Translation({s.pos.x, 0.12f, s.pos.z}) * Mat4::RotationY(s.yaw) *
              Mat4::Scale({s.range * grow, 1.f, s.range * grow});
    r.Draw(sector, p);
  }
  for (const auto& s : sparks_) {
    DrawParams p;
    p.unlit = true;
    p.tint = s.color;
    p.tint.a = static_cast<std::uint8_t>(255.f * (1.f - s.age / s.life));
    p.model = Mat4::Translation(s.pos);
    r.Draw(spark_, p);
  }
}

void SceneRenderer::Draw(Framebuffer& fb, Rasterizer& rast, const World& w, const Camera& cam) {
  fb.ClearGradient(Color{22, 24, 58, 255}, Color{132, 112, 156, 255});
  Lighting light;
  light.fog = Color{132, 112, 156, 255};
  rast.Begin(&fb, cam, light);
  DrawArena(rast, w.arena());
  // Far-to-near order keeps alpha-blended shadows and effects sorted well enough for this camera.
  DrawPlayer(rast, w);
  std::vector<const Enemy*> order;
  order.reserve(w.enemies().size());
  for (const auto& e : w.enemies()) order.push_back(&e);
  std::sort(order.begin(), order.end(),
            [&](const Enemy* a, const Enemy* b) { return DistanceXZ(a->pos, cam.eye) > DistanceXZ(b->pos, cam.eye); });
  for (const Enemy* e : order) DrawEnemy(rast, *e);
  for (const auto& pr : w.projectiles()) {
    DrawParams p;
    p.unlit = true;
    p.model = Mat4::Translation(pr.pos);
    rast.Draw(projectile_, p);
  }
  DrawEffects(rast);
}

void SceneRenderer::DrawTexts(Framebuffer& fb, const Rasterizer& rast) const {
  for (const auto& t : texts_) {
    float sx = 0.f, sy = 0.f;
    Vec3 p = t.pos;
    p.y += t.age * 1.2f;
    if (!rast.Project(p, sx, sy)) continue;
    const float w = Framebuffer::TextWidth(t.text, t.scale);
    Color c = t.color;
    c.a = static_cast<std::uint8_t>(255.f * (1.f - t.age / t.life));
    fb.DrawText(sx - w * 0.5f + static_cast<float>(t.scale), sy + static_cast<float>(t.scale), t.text, t.scale,
                Color{0, 0, 0, c.a});
    fb.DrawText(sx - w * 0.5f, sy, t.text, t.scale, c);
  }
}

}  // namespace ascend
