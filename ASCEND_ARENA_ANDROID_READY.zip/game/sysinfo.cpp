#include "sysinfo.h"

#include <cstdio>
#include <cstring>

namespace ascend {

long ReadRssKb() {
  std::FILE* f = std::fopen("/proc/self/status", "r");
  if (!f) return -1;
  char line[256];
  long kb = -1;
  while (std::fgets(line, sizeof line, f)) {
    if (std::strncmp(line, "VmRSS:", 6) == 0) {
      long v = 0;
      if (std::sscanf(line + 6, "%ld", &v) == 1) kb = v;
      break;
    }
  }
  std::fclose(f);
  return kb;
}

}  // namespace ascend
