#pragma once
// Runtime visual of a character: imported GLB model + outfit + animator. Falls back loudly (never silently)
// to the procedural placeholder when the asset is missing or invalid.
#include <memory>
#include <string>
#include <vector>

#include "../engine/render/animation.h"
#include "../gameplay/world.h"

namespace ascend {

struct CharacterVisual {
  std::string characterId, outfitId;
  SkinnedModel model;
  Animator anim;
  Mesh skinned;                       // refreshed by Tick()
  bool usedFallback = false;          // true: draw the procedural placeholder instead
  bool placeholderByDesign = false;   // model = "builtin:..." (not an error)
  std::string error;                  // why the fallback is used (empty when fine)
  std::vector<std::string> warnings;  // non-fatal problems (missing clips, outfit issues)
  int lastSerial = -1;

  // Chooses and advances the animation for the player's state, then re-skins the mesh.
  // moveMag (0..1) picks walk vs run.
  void Tick(const Player& p, const CharacterDef& def, float moveMag, float dt);
  // Turntable pose for the lobby preview: idle loop.
  void TickPreview(const CharacterDef& def, float dt);
};

// Loads `def.modelPath` (relative to contentRoot) and applies the outfit. Never returns null.
std::unique_ptr<CharacterVisual> LoadCharacterVisual(const CharacterDef& def, const std::string& outfitId,
                                                     const std::string& contentRoot);

// Name of the clip used for a logical animation key.
std::string ClipFor(const CharacterDef& def, const std::string& key);

}  // namespace ascend
