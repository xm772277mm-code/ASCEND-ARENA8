#pragma once
// Mobile HUD drawn on the CPU framebuffer: bars, joystick, buttons with cooldowns, enemy bars,
// banners and the debug overlay. Reads game state only; input is handled by TouchRouter.
// All visible text arrives pre-localized in HudInfo and is drawn through the TrueType TextRenderer
// (Arabic shaping and right-to-left order included). Without a TextRenderer it falls back to the 5x7 font.
#include <string>

#include "../engine/input/input.h"
#include "../engine/render/rasterizer.h"
#include "../engine/text/text_renderer.h"
#include "../gameplay/world.h"

namespace ascend {

struct HudInfo {
  int level = 1;
  int xp = 0, xpToNext = 100;
  int gold = 0;
  int potions = 0;
  std::string levelText = "Lv 1";
  std::string goldText = "Gold 0";
  std::string objective;  // one line shown under the bars
  std::string banner;     // big centered text (victory, defeated...)
  std::string bannerSub;
  bool paused = false;
  std::string pausedText = "PAUSED";
  std::string resumeText = "TAP TO RESUME";
  std::string attackLabel = "ATK", heavyLabel = "HVY", dodgeLabel = "DGE";
  // Dialogue box (story). Empty = hidden.
  std::string dialogue;
  std::string dialogueHint;
  TextRenderer* text = nullptr;  // non-owning
  float textScale = 1.f;         // accessibility scale (0.8 .. 1.6)
};

struct DebugStats {
  float fps = 0.f, frameMs = 0.f;
  long rssKb = -1;
  int triangles = 0;
  int effects = 0;
};

struct HudOptions {
  bool showDebug = false;
};

// Pixel height of normal HUD text for a framebuffer height and accessibility scale.
int HudTextPx(int fbHeight, float textScale);

void DrawHud(Framebuffer& fb, const Rasterizer& rast, const World& w, const ContentDb& db, const TouchRouter* router,
             const TouchLayout& layout, const HudInfo& info, const HudOptions& opt, const DebugStats& dbg);

}  // namespace ascend
