#pragma once
// Tiny platform probes for the debug overlay.
namespace ascend {
// Resident set size in KiB from /proc/self/status (Linux and Android). Returns -1 where unavailable.
long ReadRssKb();
}  // namespace ascend
