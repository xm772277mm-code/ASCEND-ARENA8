#pragma once
// Scripted player used for headless integration tests and demo captures. It only produces the
// same InputFrame a touch player would, so it exercises the real gameplay path.
#include "../gameplay/world.h"

namespace ascend {

class ScriptedBot {
 public:
  // cameraYaw: the yaw the host camera currently has (movement is camera relative).
  InputFrame Next(const World& w, float cameraYaw);

 private:
  int tick_ = 0;
  int attackCooldownTicks_ = 0;
};

}  // namespace ascend
