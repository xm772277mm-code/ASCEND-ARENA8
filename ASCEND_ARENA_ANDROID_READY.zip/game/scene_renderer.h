#pragma once
// Draws a World into a CPU Framebuffer with the software rasterizer. Purely visual: it never
// changes simulation state. Visual-only effects (sparks, slash arcs, damage numbers) live here.
#include <string>
#include <vector>

#include "../engine/render/rasterizer.h"
#include "../gameplay/camera.h"
#include "../gameplay/world.h"
#include "character_visual.h"
#include "models.h"

namespace ascend {

struct FloatingText {
  Vec3 pos;
  std::string text;
  Color color;
  float life = 0.9f, age = 0.f;
  int scale = 2;
};

struct Spark {
  Vec3 pos, vel;
  Color color;
  float life = 0.4f, age = 0.f;
};

struct SlashFx {
  Vec3 pos;
  float yaw = 0.f;
  float range = 2.f, arc = 90.f;
  bool circle = false;
  Color color;
  float life = 0.18f, age = 0.f;
};

enum class Quality { Low, Medium, High };

class SceneRenderer {
 public:
  SceneRenderer();

  // Non-owning. When set and not a fallback, the player is drawn from the skinned GLB model.
  void SetPlayerVisual(const CharacterVisual* v) { visual_ = v; }
  void SetQuality(Quality q) { quality_ = q; }
  Quality quality() const { return quality_; }

  // Feed the events returned by World::TakeEvents() so visuals can react (hit sparks, numbers, slashes).
  void OnEvents(const std::vector<GameEvent>& events, const World& w, const ContentDb& db);
  void Update(float dt);  // ages effects with real (render) time
  void Draw(Framebuffer& fb, Rasterizer& rast, const World& w, const Camera& cam);
  void ClearEffects();

  const std::vector<FloatingText>& texts() const { return texts_; }
  std::size_t effectCount() const { return sparks_.size() + slashes_.size() + texts_.size(); }
  // Draws floating damage numbers (needs projection from the rasterizer).
  void DrawTexts(Framebuffer& fb, const Rasterizer& rast) const;

 private:
  void DrawArena(Rasterizer& r, const ArenaDef& a);
  void DrawPlayer(Rasterizer& r, const World& w);
  void DrawEnemy(Rasterizer& r, const Enemy& e);
  void DrawEffects(Rasterizer& r);
  const EnemyModel& ModelFor(const std::string& id);

  Quality quality_ = Quality::Medium;
  HumanoidModel player_;
  Mesh floor_, wallBox_, pillar_, shadow_, projectile_, spark_;
  std::vector<std::pair<std::string, EnemyModel>> enemyModels_;
  std::vector<FloatingText> texts_;
  std::vector<Spark> sparks_;
  std::vector<SlashFx> slashes_;
  float floorHalf_ = -1.f;
  const CharacterVisual* visual_ = nullptr;
};

}  // namespace ascend
