#include "mesh_loader.h"

#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>

namespace ascend {
namespace {

bool ParseFloat(const std::string& s, float& out) {
  if (s.empty()) return false;
  errno = 0;
  char* end = nullptr;
  const double v = std::strtod(s.c_str(), &end);
  if (errno != 0 || end == s.c_str() || *end != '\0' || !std::isfinite(v) || std::fabs(v) > 1e7) return false;
  out = static_cast<float>(v);
  return true;
}

bool ParseIndex(const std::string& tok, long& out) {
  const std::string head = tok.substr(0, tok.find('/'));
  if (head.empty()) return false;
  errno = 0;
  char* end = nullptr;
  const long v = std::strtol(head.c_str(), &end, 10);
  if (errno != 0 || end == head.c_str() || *end != '\0' || v == 0) return false;
  out = v;
  return true;
}

Mesh MagentaCube() { return MakeBox({1.f, 1.f, 1.f}, Color{255, 0, 255, 255}); }

}  // namespace

Result<Mesh> ParseObj(const std::string& text, const std::string& source, const MeshLoadLimits& limits) {
  if (text.size() > limits.maxFileBytes) return Result<Mesh>::Error(source + ": file too large");
  Mesh m;
  std::istringstream in(text);
  std::string line;
  int lineNo = 0;
  auto fail = [&](const std::string& msg) {
    return Result<Mesh>::Error(source + ":" + std::to_string(lineNo) + ": " + msg);
  };
  while (std::getline(in, line)) {
    ++lineNo;
    std::istringstream ls(line);
    std::string tag;
    if (!(ls >> tag) || tag[0] == '#') continue;
    std::vector<std::string> tok;
    std::string t;
    while (ls >> t) tok.push_back(t);
    if (tag == "v") {
      if (tok.size() != 3 && tok.size() != 6) return fail("vertex needs 3 coords (+ optional 3 color components)");
      float f[6] = {0, 0, 0, 1, 1, 1};
      for (std::size_t i = 0; i < tok.size(); ++i)
        if (!ParseFloat(tok[i], f[i])) return fail("invalid number '" + tok[i] + "'");
      if (m.vertices.size() >= limits.maxVertices) return fail("too many vertices");
      auto c8 = [](float v) { return static_cast<std::uint8_t>(std::lround(Clamp(v, 0.f, 1.f) * 255.f)); };
      m.vertices.push_back({{f[0], f[1], f[2]}, Color{c8(f[3]), c8(f[4]), c8(f[5]), 255}});
    } else if (tag == "f") {
      if (tok.size() < 3) return fail("face needs at least 3 vertices");
      std::vector<std::uint32_t> idx;
      for (const auto& s : tok) {
        long v = 0;
        if (!ParseIndex(s, v)) return fail("invalid face index '" + s + "'");
        const long count = static_cast<long>(m.vertices.size());
        const long resolved = v > 0 ? v - 1 : count + v;
        if (resolved < 0 || resolved >= count) return fail("face index " + s + " out of range");
        idx.push_back(static_cast<std::uint32_t>(resolved));
      }
      for (std::size_t k = 1; k + 1 < idx.size(); ++k) {
        if (m.TriangleCount() >= limits.maxTriangles) return fail("too many triangles");
        if (limits.flipWinding)
          m.indices.insert(m.indices.end(), {idx[0], idx[k + 1], idx[k]});
        else
          m.indices.insert(m.indices.end(), {idx[0], idx[k], idx[k + 1]});
      }
    }
    // vn, vt, usemtl, o, g, s, mtllib ... are intentionally ignored.
  }
  if (m.vertices.empty() || m.indices.empty()) return Result<Mesh>::Error(source + ": no geometry found");
  return Result<Mesh>::Ok(std::move(m));
}

Result<Mesh> LoadObjFile(const std::string& path, const MeshLoadLimits& limits) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return Result<Mesh>::Error(path + ": cannot open file");
  std::stringstream ss;
  ss << f.rdbuf();
  return ParseObj(ss.str(), path, limits);
}

MeshLoadOutcome LoadMeshOrFallback(const std::string& path, const MeshLoadLimits& limits) {
  MeshLoadOutcome o;
  auto r = LoadObjFile(path, limits);
  if (r) {
    o.mesh = std::move(r.value);
    return o;
  }
  o.mesh = MagentaCube();
  o.usedFallback = true;
  o.error = r.status.message;
  return o;
}

}  // namespace ascend
