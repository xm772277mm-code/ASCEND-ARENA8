#pragma once
// Validated Wavefront OBJ loader (positions, optional per-vertex colors "v x y z r g b", faces).
// Everything else (normals, UVs, materials) is ignored; lighting is computed by the renderer.
#include <string>

#include "../core/result.h"
#include "../render/mesh.h"

namespace ascend {

struct MeshLoadLimits {
  std::size_t maxFileBytes = 16u * 1024u * 1024u;
  std::size_t maxVertices = 200000;
  std::size_t maxTriangles = 400000;
  bool flipWinding = false;  // set for files authored with the opposite winding convention
};

// Errors carry "source:line:" context. Never throws and never returns a partially valid mesh.
Result<Mesh> ParseObj(const std::string& text, const std::string& source, const MeshLoadLimits& limits = {});
Result<Mesh> LoadObjFile(const std::string& path, const MeshLoadLimits& limits = {});

struct MeshLoadOutcome {
  Mesh mesh;
  bool usedFallback = false;
  std::string error;  // empty unless usedFallback
};
// Loads `path`; on any failure returns a clearly visible magenta 1 m cube and the error text.
MeshLoadOutcome LoadMeshOrFallback(const std::string& path, const MeshLoadLimits& limits = {});

}  // namespace ascend
