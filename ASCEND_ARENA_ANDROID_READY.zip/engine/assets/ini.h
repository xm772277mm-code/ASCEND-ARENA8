#pragma once
// Tiny INI-style data format for game content (characters, skills, enemies, strings).
//   [section_id]
//   key = value
//   # full-line comment (line starting with '#' or ';'). Inline comments are NOT supported
//   so that text values such as "Level #5" are preserved.
// Chosen so content can be loaded and validated with zero third-party dependencies.
#include <map>
#include <optional>
#include <string>
#include <vector>

#include "../core/result.h"

namespace ascend {

struct IniSection {
  std::string name;
  int line = 0;
  std::map<std::string, std::string> values;

  bool Has(const std::string& k) const { return values.count(k) > 0; }
  std::string Str(const std::string& k, const std::string& def = "") const;
  // Numeric getters return nullopt if missing or malformed (callers decide how to report).
  std::optional<float> Float(const std::string& k) const;
  std::optional<int> Int(const std::string& k) const;
  float FloatOr(const std::string& k, float def) const { return Float(k).value_or(def); }
  int IntOr(const std::string& k, int def) const { return Int(k).value_or(def); }
  std::vector<std::string> List(const std::string& k) const;  // comma separated
};

struct IniDocument {
  std::vector<IniSection> sections;
  const IniSection* Find(const std::string& name) const;
};

// Parses text. Fails with a message containing the line number on malformed input
// or duplicate section names / duplicate keys inside a section.
Result<IniDocument> ParseIni(const std::string& text, const std::string& sourceName = "<memory>");
Result<IniDocument> LoadIniFile(const std::string& path);

}  // namespace ascend
