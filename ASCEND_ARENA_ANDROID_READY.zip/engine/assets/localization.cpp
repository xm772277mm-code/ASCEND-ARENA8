#include "localization.h"

#include <set>

namespace ascend {

Status Localization::AddCatalog(const std::string& lang, const IniDocument& doc, bool rtl) {
  if (lang.empty()) return Status::Error("language code is empty");
  const IniSection* s = doc.Find("strings");
  if (!s) return Status::Error("catalog '" + lang + "' has no [strings] section");
  Catalog c;
  c.rtl = rtl;
  c.strings = s->values;
  catalogs_[lang] = std::move(c);
  return Status::Ok();
}

bool Localization::SetLanguage(const std::string& lang) {
  if (!catalogs_.count(lang)) return false;
  current_ = lang;
  return true;
}

bool Localization::IsRtl() const {
  auto it = catalogs_.find(current_);
  return it != catalogs_.end() && it->second.rtl;
}

std::string Localization::Get(const std::string& key) const {
  auto c = catalogs_.find(current_);
  if (c != catalogs_.end()) {
    auto s = c->second.strings.find(key);
    if (s != c->second.strings.end()) return s->second;
  }
  auto en = catalogs_.find("en");
  if (en != catalogs_.end()) {
    auto s = en->second.strings.find(key);
    if (s != en->second.strings.end()) return s->second;
  }
  return "!" + key + "!";
}

std::string Localization::Format(const std::string& key, const std::vector<std::string>& args) const {
  std::string t = Get(key);
  for (std::size_t i = 0; i < args.size(); ++i) {
    const std::string ph = "{" + std::to_string(i) + "}";
    for (std::size_t p = t.find(ph); p != std::string::npos; p = t.find(ph, p + args[i].size()))
      t.replace(p, ph.size(), args[i]);
  }
  return t;
}

std::vector<std::string> Localization::Languages() const {
  std::vector<std::string> out;
  for (const auto& [k, v] : catalogs_) out.push_back(k);
  return out;
}

std::vector<std::string> Localization::MissingKeys(const std::string& lang, const std::string& base) const {
  std::vector<std::string> out;
  auto b = catalogs_.find(base);
  if (b == catalogs_.end()) return out;
  auto l = catalogs_.find(lang);
  for (const auto& [k, v] : b->second.strings)
    if (l == catalogs_.end() || !l->second.strings.count(k)) out.push_back(k);
  return out;
}

bool Localization::HasKey(const std::string& lang, const std::string& key) const {
  auto l = catalogs_.find(lang);
  return l != catalogs_.end() && l->second.strings.count(key) > 0;
}

std::size_t Localization::KeyCount(const std::string& lang) const {
  auto it = catalogs_.find(lang);
  return it == catalogs_.end() ? 0 : it->second.strings.size();
}

}  // namespace ascend
