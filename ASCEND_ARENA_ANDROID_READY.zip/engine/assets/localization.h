#pragma once
// Localization catalogs loaded from INI files: [strings] key = text.
// English and Arabic are required to be complete; other languages fall back to English
// per key, and the fallback is reported (never silently claimed as translated).
#include <map>
#include <string>
#include <vector>

#include "ini.h"

namespace ascend {

struct LanguageInfo {
  std::string code;  // "en", "ar"
  bool rtl = false;
};

class Localization {
 public:
  Status AddCatalog(const std::string& langCode, const IniDocument& doc, bool rtl);
  bool SetLanguage(const std::string& langCode);  // false if unknown language
  const std::string& language() const { return current_; }
  bool IsRtl() const;

  // Returns translated text; falls back to English; finally returns "!key!" so a
  // missing string is visible instead of blank.
  std::string Get(const std::string& key) const;
  // Replace {0},{1}.. placeholders.
  std::string Format(const std::string& key, const std::vector<std::string>& args) const;

  std::vector<std::string> Languages() const;
  // Keys present in `base` ("en") but missing in `lang`.
  std::vector<std::string> MissingKeys(const std::string& lang, const std::string& base = "en") const;
  bool HasKey(const std::string& lang, const std::string& key) const;
  std::size_t KeyCount(const std::string& lang) const;  // number of strings in a catalog (0 if unknown)

 private:
  struct Catalog {
    std::map<std::string, std::string> strings;
    bool rtl = false;
  };
  std::map<std::string, Catalog> catalogs_;
  std::string current_ = "en";
};

}  // namespace ascend
