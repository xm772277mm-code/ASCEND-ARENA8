#pragma once
// Imports glTF 2.0 binary (.glb) models into SkinnedModel using cgltf (MIT, pinned).
// Supported: one skin (rigid or weighted, up to 4 influences), triangle meshes, base-color factors,
// translation/rotation/scale animations (LINEAR and STEP). Not supported (reported, never silently
// ignored): CUBICSPLINE animation, morph targets, textures (colors only), node matrices on joints.
// Coordinates are converted from glTF (right-handed) to the engine (left-handed) by mirroring X.
#include <string>

#include "../core/result.h"
#include "../render/skinned_model.h"

namespace ascend {

struct GlbLimits {
  std::size_t maxFileBytes = 32u * 1024u * 1024u;
  std::size_t maxVertices = 100000;
  std::size_t maxJoints = 128;
};

Result<SkinnedModel> LoadGlbFile(const std::string& path, const GlbLimits& limits = {});
Result<SkinnedModel> ParseGlb(const unsigned char* data, std::size_t size, const std::string& sourceName,
                              const GlbLimits& limits = {});

}  // namespace ascend
