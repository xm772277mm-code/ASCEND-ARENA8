#include "ini.h"

#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace ascend {
namespace {

std::string Trim(const std::string& s) {
  std::size_t a = 0, b = s.size();
  while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r')) ++a;
  while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r')) --b;
  return s.substr(a, b - a);
}

}  // namespace

std::string IniSection::Str(const std::string& k, const std::string& def) const {
  auto it = values.find(k);
  return it == values.end() ? def : it->second;
}

std::optional<float> IniSection::Float(const std::string& k) const {
  auto it = values.find(k);
  if (it == values.end() || it->second.empty()) return std::nullopt;
  errno = 0;
  char* end = nullptr;
  const double v = std::strtod(it->second.c_str(), &end);
  if (errno != 0 || end == it->second.c_str() || *end != '\0' || !std::isfinite(v)) return std::nullopt;
  return static_cast<float>(v);
}

std::optional<int> IniSection::Int(const std::string& k) const {
  auto it = values.find(k);
  if (it == values.end() || it->second.empty()) return std::nullopt;
  errno = 0;
  char* end = nullptr;
  const long v = std::strtol(it->second.c_str(), &end, 10);
  if (errno != 0 || end == it->second.c_str() || *end != '\0' || v < -2147483647L || v > 2147483647L)
    return std::nullopt;
  return static_cast<int>(v);
}

std::vector<std::string> IniSection::List(const std::string& k) const {
  std::vector<std::string> out;
  auto it = values.find(k);
  if (it == values.end()) return out;
  std::string cur;
  std::stringstream ss(it->second);
  while (std::getline(ss, cur, ',')) {
    cur = Trim(cur);
    if (!cur.empty()) out.push_back(cur);
  }
  return out;
}

const IniSection* IniDocument::Find(const std::string& name) const {
  for (const auto& s : sections)
    if (s.name == name) return &s;
  return nullptr;
}

Result<IniDocument> ParseIni(const std::string& text, const std::string& source) {
  IniDocument doc;
  IniSection* cur = nullptr;
  std::istringstream in(text);
  std::string raw;
  int lineNo = 0;
  auto fail = [&](const std::string& msg) {
    return Result<IniDocument>::Error(source + ":" + std::to_string(lineNo) + ": " + msg);
  };
  while (std::getline(in, raw)) {
    ++lineNo;
    const std::string line = Trim(raw);
    if (line.empty() || line[0] == '#' || line[0] == ';') continue;
    if (line[0] == '[') {
      if (line.back() != ']' || line.size() < 3) return fail("malformed section header '" + line + "'");
      const std::string name = Trim(line.substr(1, line.size() - 2));
      if (name.empty()) return fail("empty section name");
      if (doc.Find(name)) return fail("duplicate section [" + name + "]");
      IniSection s;
      s.name = name;
      s.line = lineNo;
      doc.sections.push_back(std::move(s));
      cur = &doc.sections.back();
      continue;
    }
    const auto eq = line.find('=');
    if (eq == std::string::npos) return fail("expected 'key = value', got '" + line + "'");
    if (!cur) return fail("key outside of any [section]");
    const std::string key = Trim(line.substr(0, eq));
    if (key.empty()) return fail("empty key");
    if (cur->values.count(key)) return fail("duplicate key '" + key + "' in [" + cur->name + "]");
    cur->values[key] = Trim(line.substr(eq + 1));
  }
  return Result<IniDocument>::Ok(std::move(doc));
}

Result<IniDocument> LoadIniFile(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return Result<IniDocument>::Error(path + ": cannot open file");
  std::stringstream ss;
  ss << f.rdbuf();
  return ParseIni(ss.str(), path);
}

}  // namespace ascend
