#define CGLTF_IMPLEMENTATION
#include "glb_loader.h"

#include <cmath>
#include <cstdint>
#include <fstream>
#include <iterator>
#include <map>

#include "../render/animation.h"

// cgltf is third-party code (MIT); keep its warnings out of our -Werror build.
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#pragma GCC diagnostic ignored "-Wshadow"
#pragma GCC diagnostic ignored "-Wpedantic"
#pragma GCC diagnostic ignored "-Wsign-conversion"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wcast-qual"
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
#include <cgltf.h>
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

namespace ascend {
namespace {

std::uint8_t ToByte(float f) { return static_cast<std::uint8_t>(Clamp(f, 0.f, 1.f) * 255.f + 0.5f); }

// cgltf reads components through typed pointers, so a malformed file with misaligned accessor data would be
// undefined behavior. The glTF spec requires component-size alignment; reject anything else up front.
bool AccessorsAreAligned(const cgltf_data& d) {
  for (cgltf_size i = 0; i < d.accessors_count; ++i) {
    const cgltf_accessor& a = d.accessors[i];
    if (!a.buffer_view || !a.buffer_view->buffer || !a.buffer_view->buffer->data) continue;
    std::size_t comp = 0;
    switch (a.component_type) {
      case cgltf_component_type_r_8:
      case cgltf_component_type_r_8u:
        comp = 1;
        break;
      case cgltf_component_type_r_16:
      case cgltf_component_type_r_16u:
        comp = 2;
        break;
      case cgltf_component_type_r_32u:
      case cgltf_component_type_r_32f:
        comp = 4;
        break;
      default:
        return false;
    }
    const auto base = reinterpret_cast<std::uintptr_t>(a.buffer_view->buffer->data);
    const std::uintptr_t addr = base + a.buffer_view->offset + a.offset;
    if (addr % comp != 0) return false;
    if (a.buffer_view->stride != 0 && a.buffer_view->stride % comp != 0) return false;
  }
  return true;
}

struct DataGuard {
  cgltf_data* d = nullptr;
  ~DataGuard() {
    if (d) cgltf_free(d);
  }
};

}  // namespace

Result<SkinnedModel> ParseGlb(const unsigned char* data, std::size_t size, const std::string& src,
                              const GlbLimits& lim) {
  using R = Result<SkinnedModel>;
  if (!data || size < 20) return R::Error(src + ": file too small to be a GLB");
  if (size > lim.maxFileBytes)
    return R::Error(src + ": file larger than the allowed " + std::to_string(lim.maxFileBytes) + " bytes");
  if (!(data[0] == 'g' && data[1] == 'l' && data[2] == 'T' && data[3] == 'F'))
    return R::Error(src + ": not a GLB file (bad magic)");

  cgltf_options opt{};
  DataGuard g;
  const cgltf_result pr = cgltf_parse(&opt, data, size, &g.d);
  if (pr != cgltf_result_success)
    return R::Error(src + ": glTF parse failed (cgltf code " + std::to_string(static_cast<int>(pr)) + ")");
  const cgltf_result lr = cgltf_load_buffers(&opt, g.d, nullptr);
  if (lr != cgltf_result_success)
    return R::Error(src + ": could not load binary buffers (cgltf code " + std::to_string(static_cast<int>(lr)) + ")");
  if (cgltf_validate(g.d) != cgltf_result_success)
    return R::Error(src + ": glTF validation failed (inconsistent accessors/buffers)");
  const cgltf_data* d = g.d;
  if (!AccessorsAreAligned(*d)) return R::Error(src + ": glTF accessor data is not aligned to its component size");

  SkinnedModel m;
  m.source = src;

  // --- skeleton -----------------------------------------------------------------------------
  const cgltf_skin* skin = d->skins_count > 0 ? &d->skins[0] : nullptr;
  std::map<const cgltf_node*, int> jointOf;
  if (skin) {
    if (skin->joints_count > lim.maxJoints)
      return R::Error(src + ": too many joints (" + std::to_string(skin->joints_count) + ")");
    for (cgltf_size i = 0; i < skin->joints_count; ++i) jointOf[skin->joints[i]] = static_cast<int>(i);
    for (cgltf_size i = 0; i < skin->joints_count; ++i) {
      const cgltf_node* n = skin->joints[i];
      Joint j;
      j.name = n->name ? n->name : "joint" + std::to_string(i);
      j.parent = -1;
      if (n->parent) {
        auto it = jointOf.find(n->parent);
        if (it != jointOf.end()) j.parent = it->second;
      }
      if (n->has_matrix) return R::Error(src + ": joint '" + j.name + "' uses a node matrix (unsupported; use TRS)");
      if (j.parent >= static_cast<int>(i)) return R::Error(src + ": joint '" + j.name + "' appears before its parent");
      const float* t = n->has_translation ? n->translation : nullptr;
      j.rest.t = t ? Vec3{-t[0], t[1], t[2]} : Vec3{};
      if (n->has_rotation) j.rest.r = {n->rotation[0], -n->rotation[1], -n->rotation[2], n->rotation[3]};
      if (n->has_scale) j.rest.s = {n->scale[0], n->scale[1], n->scale[2]};
      // Inverse bind matrix: column-major in the file; conjugate by the X mirror.
      float ibm[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
      if (skin->inverse_bind_matrices) cgltf_accessor_read_float(skin->inverse_bind_matrices, i, ibm, 16);
      const float sgn[4] = {-1.f, 1.f, 1.f, 1.f};
      for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c) j.inverseBind.m[r][c] = ibm[c * 4 + r] * sgn[r] * sgn[c];
      m.joints.push_back(std::move(j));
    }
  } else {
    Joint root;
    root.name = "root";
    m.joints.push_back(root);  // static model: one identity joint
  }

  // --- materials ----------------------------------------------------------------------------
  for (cgltf_size i = 0; i < d->materials_count; ++i) {
    const cgltf_material& mat = d->materials[i];
    ModelMaterial mm;
    mm.name = mat.name ? mat.name : "material" + std::to_string(i);
    mm.color = {255, 255, 255, 255};
    if (mat.has_pbr_metallic_roughness) {
      const float* c = mat.pbr_metallic_roughness.base_color_factor;
      mm.color = {ToByte(c[0]), ToByte(c[1]), ToByte(c[2]), 255};
    }
    m.materials.push_back(mm);
  }
  if (m.materials.empty()) m.materials.push_back({"default", Color{200, 200, 200, 255}});

  // --- geometry -----------------------------------------------------------------------------
  bool anyMesh = false;
  for (cgltf_size ni = 0; ni < d->nodes_count; ++ni) {
    const cgltf_node& node = d->nodes[ni];
    if (!node.mesh) continue;
    if (skin && node.skin != skin) continue;  // only the primary skinned mesh(es)
    float world[16];
    cgltf_node_transform_world(&node, world);
    for (cgltf_size pi = 0; pi < node.mesh->primitives_count; ++pi) {
      const cgltf_primitive& prim = node.mesh->primitives[pi];
      if (prim.type != cgltf_primitive_type_triangles)
        return R::Error(src + ": only triangle primitives are supported");
      if (prim.targets_count > 0) return R::Error(src + ": morph targets are not supported");
      const cgltf_accessor *pos = nullptr, *jnt = nullptr, *wgt = nullptr;
      for (cgltf_size ai = 0; ai < prim.attributes_count; ++ai) {
        const auto& a = prim.attributes[ai];
        if (a.type == cgltf_attribute_type_position && a.index == 0) pos = a.data;
        if (a.type == cgltf_attribute_type_joints && a.index == 0) jnt = a.data;
        if (a.type == cgltf_attribute_type_weights && a.index == 0) wgt = a.data;
      }
      if (!pos) return R::Error(src + ": primitive without POSITION");
      if (skin && (!jnt || !wgt)) return R::Error(src + ": skinned primitive missing JOINTS_0/WEIGHTS_0");
      if (m.vertices.size() + pos->count > lim.maxVertices)
        return R::Error(src + ": too many vertices (limit " + std::to_string(lim.maxVertices) + ")");
      const int matIdx = prim.material ? static_cast<int>(prim.material - d->materials) : 0;
      const auto base = static_cast<std::uint32_t>(m.vertices.size());
      for (cgltf_size v = 0; v < pos->count; ++v) {
        float p[3] = {0, 0, 0};
        cgltf_accessor_read_float(pos, v, p, 3);
        SkinVertex sv;
        if (!skin) {  // apply the node transform for static models
          const float x = world[0] * p[0] + world[4] * p[1] + world[8] * p[2] + world[12];
          const float y = world[1] * p[0] + world[5] * p[1] + world[9] * p[2] + world[13];
          const float z = world[2] * p[0] + world[6] * p[1] + world[10] * p[2] + world[14];
          sv.pos = {-x, y, z};
        } else {
          sv.pos = {-p[0], p[1], p[2]};
          cgltf_uint ji[4] = {0, 0, 0, 0};
          float wv[4] = {1, 0, 0, 0};
          cgltf_accessor_read_uint(jnt, v, ji, 4);
          cgltf_accessor_read_float(wgt, v, wv, 4);
          float sum = wv[0] + wv[1] + wv[2] + wv[3];
          for (int k = 0; k < 4; ++k) {
            if (ji[k] >= m.joints.size()) return R::Error(src + ": vertex joint index out of range");
            sv.joint[k] = static_cast<std::uint8_t>(ji[k]);
            sv.weight[k] = sum > 1e-6f ? wv[k] / sum : (k == 0 ? 1.f : 0.f);
          }
        }
        sv.material = matIdx;
        m.vertices.push_back(sv);
      }
      if (prim.indices) {
        for (cgltf_size k = 0; k < prim.indices->count; ++k)
          m.indices.push_back(base + static_cast<std::uint32_t>(cgltf_accessor_read_index(prim.indices, k)));
      } else {
        for (cgltf_size k = 0; k < pos->count; ++k) m.indices.push_back(base + static_cast<std::uint32_t>(k));
      }
      anyMesh = true;
    }
  }
  if (!anyMesh) return R::Error(src + ": no mesh found (for skinned files the mesh node must reference the skin)");

  // --- animations ---------------------------------------------------------------------------
  for (cgltf_size ai = 0; ai < d->animations_count; ++ai) {
    const cgltf_animation& a = d->animations[ai];
    AnimClip clip;
    clip.name = a.name ? a.name : "clip" + std::to_string(ai);
    for (cgltf_size ci = 0; ci < a.channels_count; ++ci) {
      const cgltf_animation_channel& ch = a.channels[ci];
      if (!ch.target_node || !ch.sampler) continue;
      auto it = jointOf.find(ch.target_node);
      if (it == jointOf.end()) continue;  // animates a non-joint node: not used by skinning
      if (ch.target_path != cgltf_animation_path_type_translation &&
          ch.target_path != cgltf_animation_path_type_rotation && ch.target_path != cgltf_animation_path_type_scale)
        return R::Error(src + ": clip '" + clip.name + "' animates unsupported property (morph weights)");
      if (ch.sampler->interpolation == cgltf_interpolation_type_cubic_spline)
        return R::Error(src + ": clip '" + clip.name +
                        "' uses CUBICSPLINE interpolation (unsupported; export as LINEAR)");
      AnimChannel c;
      c.joint = it->second;
      c.step = ch.sampler->interpolation == cgltf_interpolation_type_step;
      c.path = ch.target_path == cgltf_animation_path_type_translation ? ChannelPath::Translation
               : ch.target_path == cgltf_animation_path_type_rotation  ? ChannelPath::Rotation
                                                                       : ChannelPath::Scale;
      const cgltf_accessor* in = ch.sampler->input;
      const cgltf_accessor* out = ch.sampler->output;
      const cgltf_size stride = c.path == ChannelPath::Rotation ? 4 : 3;
      if (!in || !out || out->count != in->count)
        return R::Error(src + ": clip '" + clip.name + "' has mismatched sampler data");
      for (cgltf_size k = 0; k < in->count; ++k) {
        float t = 0.f;
        cgltf_accessor_read_float(in, k, &t, 1);
        if (!c.times.empty() && t <= c.times.back())
          return R::Error(src + ": clip '" + clip.name + "' has non-increasing key times");
        c.times.push_back(t);
        float v[4] = {0, 0, 0, 1};
        cgltf_accessor_read_float(out, k, v, stride);
        if (c.path == ChannelPath::Translation) v[0] = -v[0];
        if (c.path == ChannelPath::Rotation) {
          v[1] = -v[1];
          v[2] = -v[2];
        }
        for (cgltf_size q = 0; q < stride; ++q) c.values.push_back(v[q]);
      }
      if (!c.times.empty()) clip.duration = std::max(clip.duration, c.times.back());
      clip.channels.push_back(std::move(c));
    }
    m.clips.push_back(std::move(clip));
  }

  const auto problems = ValidateModel(m);
  if (!problems.empty()) return R::Error(src + ": invalid model: " + problems.front());
  return R::Ok(std::move(m));
}

Result<SkinnedModel> LoadGlbFile(const std::string& path, const GlbLimits& limits) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return Result<SkinnedModel>::Error(path + ": cannot open file");
  std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  return ParseGlb(bytes.data(), bytes.size(), path, limits);
}

}  // namespace ascend
