#pragma once
// Fixed timestep accumulator. Rendering runs at variable rate; simulation at fixed dt.
#include "amath.h"

namespace ascend {

class FixedStepper {
 public:
  explicit FixedStepper(float stepSeconds = 1.f / 60.f, int maxStepsPerFrame = 5)
      : step_(stepSeconds), maxSteps_(maxStepsPerFrame) {}

  // Feed real elapsed seconds; returns how many fixed steps to run this frame.
  // Large hitches (backgrounding, breakpoints) are clamped so the game never
  // tries to catch up with hundreds of steps ("spiral of death").
  int Advance(float realDt) {
    if (paused_) return 0;
    if (realDt < 0.f) realDt = 0.f;
    acc_ += realDt;
    int n = 0;
    while (acc_ >= step_ && n < maxSteps_) {
      acc_ -= step_;
      ++n;
    }
    if (n == maxSteps_ && acc_ >= step_) acc_ = 0.f;  // drop the backlog
    return n;
  }

  // Interpolation factor for rendering between the last two sim states.
  float Alpha() const { return Clamp(acc_ / step_, 0.f, 1.f); }
  float step() const { return step_; }

  void SetPaused(bool p) {
    paused_ = p;
    if (p) acc_ = 0.f;  // do not carry time across a pause
  }
  bool paused() const { return paused_; }

 private:
  float step_;
  int maxSteps_;
  float acc_ = 0.f;
  bool paused_ = false;
};

}  // namespace ascend
