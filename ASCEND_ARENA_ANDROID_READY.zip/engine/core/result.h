#pragma once
// Minimal error-carrying result types (no exceptions needed across the engine API).
#include <string>
#include <utility>

namespace ascend {

struct Status {
  bool ok = true;
  std::string message;

  static Status Ok() { return {}; }
  static Status Error(std::string msg) { return {false, std::move(msg)}; }
  explicit operator bool() const { return ok; }
};

template <typename T>
struct Result {
  Status status;
  T value{};

  static Result Ok(T v) { return {Status::Ok(), std::move(v)}; }
  static Result Error(std::string msg) { return {Status::Error(std::move(msg)), T{}}; }
  bool ok() const { return status.ok; }
  explicit operator bool() const { return status.ok; }
};

}  // namespace ascend
