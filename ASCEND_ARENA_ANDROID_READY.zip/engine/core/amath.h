#pragma once
// ASCEND ENGINE core math. Dependency-free, header-only.
#include <algorithm>
#include <cmath>

namespace ascend {

constexpr float kPi = 3.14159265358979323846f;

struct Vec2 {
  float x = 0.f, y = 0.f;
};

struct Vec3 {
  float x = 0.f, y = 0.f, z = 0.f;
};

constexpr Vec2 operator+(Vec2 a, Vec2 b) { return {a.x + b.x, a.y + b.y}; }
constexpr Vec2 operator-(Vec2 a, Vec2 b) { return {a.x - b.x, a.y - b.y}; }
constexpr Vec2 operator*(Vec2 a, float s) { return {a.x * s, a.y * s}; }

constexpr Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
constexpr Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
constexpr Vec3 operator*(Vec3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline Vec3& operator+=(Vec3& a, Vec3 b) {
  a = a + b;
  return a;
}

constexpr float Dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline float Length(Vec3 a) { return std::sqrt(Dot(a, a)); }
inline float Length(Vec2 a) { return std::sqrt(a.x * a.x + a.y * a.y); }

// Distance on the ground plane (x,z). The game is a flat-arena game; y is height only.
inline float DistanceXZ(Vec3 a, Vec3 b) {
  const float dx = a.x - b.x, dz = a.z - b.z;
  return std::sqrt(dx * dx + dz * dz);
}

inline Vec3 NormalizeXZ(Vec3 v) {
  const float len = std::sqrt(v.x * v.x + v.z * v.z);
  if (len < 1e-6f) return {0.f, 0.f, 0.f};
  return {v.x / len, 0.f, v.z / len};
}

constexpr float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
constexpr int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
constexpr float Lerp(float a, float b, float t) { return a + (b - a) * t; }

// Wrap an angle in radians into (-pi, pi].
inline float WrapAngle(float a) {
  while (a > kPi) a -= 2.f * kPi;
  while (a <= -kPi) a += 2.f * kPi;
  return a;
}

// Forward direction on the ground plane for a yaw angle. yaw=0 faces +z.
inline Vec3 ForwardFromYaw(float yaw) { return {std::sin(yaw), 0.f, std::cos(yaw)}; }

inline float YawFromDirection(Vec3 d) { return std::atan2(d.x, d.z); }

// Smallest signed angle from yaw a to yaw b.
inline float AngleDelta(float a, float b) { return WrapAngle(b - a); }

struct Aabb2 {  // axis-aligned box on the ground plane
  float minX = 0.f, minZ = 0.f, maxX = 0.f, maxZ = 0.f;
};

// Push a circle (center p, radius r) out of a box. Returns the corrected position.
inline Vec3 ResolveCircleVsBox(Vec3 p, float r, const Aabb2& b) {
  const float cx = Clamp(p.x, b.minX, b.maxX);
  const float cz = Clamp(p.z, b.minZ, b.maxZ);
  float dx = p.x - cx, dz = p.z - cz;
  const float d2 = dx * dx + dz * dz;
  if (d2 >= r * r) return p;
  if (d2 > 1e-8f) {
    const float d = std::sqrt(d2);
    const float push = r - d;
    p.x += dx / d * push;
    p.z += dz / d * push;
    return p;
  }
  // Center is inside the box: push out through the nearest face.
  const float left = p.x - b.minX, right = b.maxX - p.x;
  const float back = p.z - b.minZ, front = b.maxZ - p.z;
  const float m = std::min(std::min(left, right), std::min(back, front));
  if (m == left)
    p.x = b.minX - r;
  else if (m == right)
    p.x = b.maxX + r;
  else if (m == back)
    p.z = b.minZ - r;
  else
    p.z = b.maxZ + r;
  return p;
}

// True if the segment a->b crosses the box (slab test, ground plane).
inline bool SegmentHitsBox(Vec3 a, Vec3 b, const Aabb2& box) {
  float t0 = 0.f, t1 = 1.f;
  const float d[2] = {b.x - a.x, b.z - a.z};
  const float o[2] = {a.x, a.z};
  const float lo[2] = {box.minX, box.minZ};
  const float hi[2] = {box.maxX, box.maxZ};
  for (int i = 0; i < 2; ++i) {
    if (std::fabs(d[i]) < 1e-8f) {
      if (o[i] < lo[i] || o[i] > hi[i]) return false;
    } else {
      float ta = (lo[i] - o[i]) / d[i];
      float tb = (hi[i] - o[i]) / d[i];
      if (ta > tb) std::swap(ta, tb);
      t0 = std::max(t0, ta);
      t1 = std::min(t1, tb);
      if (t0 > t1) return false;
    }
  }
  return true;
}

}  // namespace ascend
