#pragma once
// Deterministic RNG (xorshift64*). Same seed => same sequence on every platform.
#include <cstdint>

namespace ascend {

class Rng {
 public:
  explicit Rng(std::uint64_t seed = 0x9E3779B97F4A7C15ull) : s_(seed ? seed : 0x9E3779B97F4A7C15ull) {}

  std::uint64_t NextU64() {
    s_ ^= s_ >> 12;
    s_ ^= s_ << 25;
    s_ ^= s_ >> 27;
    return s_ * 0x2545F4914F6CDD1Dull;
  }
  // Uniform float in [0,1).
  float NextFloat() { return static_cast<float>(NextU64() >> 40) / 16777216.0f; }
  // Uniform integer in [lo, hi] inclusive.
  int NextInt(int lo, int hi) {
    if (hi <= lo) return lo;
    const auto span = static_cast<std::uint64_t>(hi - lo) + 1u;
    return lo + static_cast<int>(NextU64() % span);
  }
  std::uint64_t state() const { return s_; }

 private:
  std::uint64_t s_;
};

}  // namespace ascend
