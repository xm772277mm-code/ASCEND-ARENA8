#include "rasterizer.h"

#include <algorithm>
#include <cmath>

namespace ascend {
namespace {

struct ViewVert {
  Vec3 p;         // view space
  Vec3 w;         // world space
  float r, g, b;  // vertex color 0..1 (tint applied)
};

ViewVert Lerp(const ViewVert& a, const ViewVert& b, float t) {
  return {a.p + (b.p - a.p) * t, a.w + (b.w - a.w) * t, a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t,
          a.b + (b.b - a.b) * t};
}

}  // namespace

void Rasterizer::Begin(Framebuffer* fb, const Camera& cam, const Lighting& light) {
  fb_ = fb;
  cam_ = cam;
  light_ = light;
  view_ = cam.View();
  tanHalf_ = std::tan(cam.fovY * 0.5f);
  aspect_ = fb && fb->height() > 0 ? static_cast<float>(fb->width()) / static_cast<float>(fb->height()) : 1.f;
  stats_ = {};
}

bool Rasterizer::Project(Vec3 world, float& sx, float& sy) const {
  if (!fb_) return false;
  const Vec3 v = TransformPoint(view_, world);
  if (v.z <= cam_.nearZ) return false;
  const float nx = v.x / (v.z * tanHalf_ * aspect_);
  const float ny = v.y / (v.z * tanHalf_);
  sx = (nx * 0.5f + 0.5f) * static_cast<float>(fb_->width());
  sy = (1.f - (ny * 0.5f + 0.5f)) * static_cast<float>(fb_->height());
  return true;
}

void Rasterizer::Draw(const Mesh& mesh, const DrawParams& params) {
  if (!fb_) return;
  const Mat4 modelView = view_ * params.model;
  const float tr = static_cast<float>(params.tint.r) / 255.f;
  const float tg = static_cast<float>(params.tint.g) / 255.f;
  const float tb = static_cast<float>(params.tint.b) / 255.f;
  const Vec3 sun = Normalize(light_.sunDir) * -1.f;  // direction toward the light

  std::vector<ViewVert> vv(mesh.vertices.size());
  for (std::size_t i = 0; i < vv.size(); ++i) {
    const auto& v = mesh.vertices[i];
    vv[i].w = TransformPoint(params.model, v.pos);
    vv[i].p = TransformPoint(modelView, v.pos);
    vv[i].r = static_cast<float>(v.color.r) / 255.f * tr;
    vv[i].g = static_cast<float>(v.color.g) / 255.f * tg;
    vv[i].b = static_cast<float>(v.color.b) / 255.f * tb;
  }

  for (std::size_t t = 0; t + 2 < mesh.indices.size(); t += 3) {
    const auto i0 = mesh.indices[t], i1 = mesh.indices[t + 1], i2 = mesh.indices[t + 2];
    if (i0 >= vv.size() || i1 >= vv.size() || i2 >= vv.size()) continue;  // malformed index: skip, never crash
    ++stats_.trianglesSubmitted;

    // World-space normal. Front faces are clockwise from outside, so the outward normal is cross(c-a, b-a).
    const Vec3 n = Normalize(Cross(vv[i2].w - vv[i0].w, vv[i1].w - vv[i0].w));
    float lit = 1.f;
    if (!params.unlit) {
      const float ndl = std::max(0.f, Dot(n, sun));
      const float hemi = 0.85f + 0.15f * n.y;
      lit = Clamp(light_.ambient * hemi + (1.f - light_.ambient) * ndl, 0.f, 1.f);
    }

    // Clip against the near plane (z > nearZ) -> polygon of up to 4 vertices.
    ViewVert in[3] = {vv[i0], vv[i1], vv[i2]};
    ViewVert poly[4];
    int count = 0;
    for (int e = 0; e < 3; ++e) {
      const ViewVert& cur = in[e];
      const ViewVert& nxt = in[(e + 1) % 3];
      const bool curIn = cur.p.z > cam_.nearZ, nxtIn = nxt.p.z > cam_.nearZ;
      if (curIn && count < 4) poly[count++] = cur;
      if (curIn != nxtIn && count < 4) {
        const float s = (cam_.nearZ - cur.p.z) / (nxt.p.z - cur.p.z);
        poly[count++] = Lerp(cur, nxt, s);
      }
    }
    if (count < 3) continue;

    ScreenVert sv[4];
    float avgZ = 0.f;
    for (int k = 0; k < count; ++k) {
      const float z = poly[k].p.z;
      avgZ += z;
      sv[k].x = (poly[k].p.x / (z * tanHalf_ * aspect_) * 0.5f + 0.5f) * static_cast<float>(fb_->width());
      sv[k].y = (1.f - (poly[k].p.y / (z * tanHalf_) * 0.5f + 0.5f)) * static_cast<float>(fb_->height());
      sv[k].invW = 1.f / z;
      sv[k].r = poly[k].r;
      sv[k].g = poly[k].g;
      sv[k].b = poly[k].b;
    }
    avgZ /= static_cast<float>(count);
    const float fog = Clamp((avgZ - light_.fogNear) / std::max(1e-3f, light_.fogFar - light_.fogNear), 0.f, 1.f);
    for (int k = 1; k + 1 < count; ++k) DrawTriangle(sv[0], sv[k], sv[k + 1], lit, fog, params);
  }
}

void Rasterizer::DrawTriangle(const ScreenVert& a, const ScreenVert& b, const ScreenVert& c, float light, float fog,
                              const DrawParams& p) {
  // Screen y points down, so front (clockwise-from-outside) triangles have positive area here.
  const float area = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
  if (p.cull && area <= 0.f) return;
  if (!p.cull && std::fabs(area) < 1e-6f) return;
  if (std::fabs(area) < 1e-6f) return;
  const float invArea = 1.f / area;

  const int w = fb_->width(), h = fb_->height();
  const float minXf = std::min({a.x, b.x, c.x}), maxXf = std::max({a.x, b.x, c.x});
  const float minYf = std::min({a.y, b.y, c.y}), maxYf = std::max({a.y, b.y, c.y});
  if (maxXf < 0.f || maxYf < 0.f || minXf > static_cast<float>(w) || minYf > static_cast<float>(h)) return;
  const int x0 = std::max(0, static_cast<int>(std::floor(minXf)));
  const int x1 = std::min(w - 1, static_cast<int>(std::ceil(maxXf)));
  const int y0 = std::max(0, static_cast<int>(std::floor(minYf)));
  const int y1 = std::min(h - 1, static_cast<int>(std::ceil(maxYf)));

  const bool blend = p.tint.a < 255;
  const float alpha = static_cast<float>(p.tint.a) / 255.f;
  const float fr = static_cast<float>(light_.fog.r) / 255.f, fg = static_cast<float>(light_.fog.g) / 255.f,
              fbl = static_cast<float>(light_.fog.b) / 255.f;
  const float flr = static_cast<float>(p.flashColor.r) / 255.f, flg = static_cast<float>(p.flashColor.g) / 255.f,
              flb = static_cast<float>(p.flashColor.b) / 255.f;
  float* depth = fb_->depth();
  std::uint32_t* pix = fb_->pixels();
  bool drew = false;

  for (int y = y0; y <= y1; ++y) {
    for (int x = x0; x <= x1; ++x) {
      const float px = static_cast<float>(x) + 0.5f, py = static_cast<float>(y) + 0.5f;
      // Barycentric weights (signed area / total signed area works for both windings).
      const float w0 = ((b.x - px) * (c.y - py) - (c.x - px) * (b.y - py)) * invArea;
      const float w1 = ((c.x - px) * (a.y - py) - (a.x - px) * (c.y - py)) * invArea;
      const float w2 = 1.f - w0 - w1;
      if (w0 < 0.f || w1 < 0.f || w2 < 0.f) continue;
      const float invW = w0 * a.invW + w1 * b.invW + w2 * c.invW;
      if (invW <= 0.f) continue;
      const float z = 1.f / invW;
      const std::size_t idx = static_cast<std::size_t>(y) * static_cast<std::size_t>(w) + static_cast<std::size_t>(x);
      if (z >= depth[idx]) continue;
      // Perspective-correct color.
      float r = (w0 * a.r * a.invW + w1 * b.r * b.invW + w2 * c.r * c.invW) * z;
      float g = (w0 * a.g * a.invW + w1 * b.g * b.invW + w2 * c.g * c.invW) * z;
      float bl = (w0 * a.b * a.invW + w1 * b.b * b.invW + w2 * c.b * c.invW) * z;
      r *= light;
      g *= light;
      bl *= light;
      if (p.flash > 0.f) {
        r += (flr - r) * p.flash;
        g += (flg - g) * p.flash;
        bl += (flb - bl) * p.flash;
      }
      if (fog > 0.f) {
        r += (fr - r) * fog;
        g += (fg - g) * fog;
        bl += (fbl - bl) * fog;
      }
      const auto to8 = [](float v) { return static_cast<std::uint8_t>(std::lround(Clamp(v, 0.f, 1.f) * 255.f)); };
      if (blend) {
        fb_->Blend(x, y, Color{to8(r), to8(g), to8(bl), p.tint.a});
        (void)alpha;
      } else {
        pix[idx] = Color{to8(r), to8(g), to8(bl), 255}.Pack();
        depth[idx] = z;
      }
      drew = true;
    }
  }
  if (drew) ++stats_.trianglesDrawn;
}

}  // namespace ascend
