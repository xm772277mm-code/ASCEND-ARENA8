#pragma once
// CPU-side mesh data and primitive builders (used for the placeholder arena and characters).
#include <cstdint>
#include <vector>

#include "math3d.h"

namespace ascend {

struct Color {
  std::uint8_t r = 255, g = 255, b = 255, a = 255;
  constexpr std::uint32_t Pack() const {  // RGBA32 memory order (R lowest byte)
    return static_cast<std::uint32_t>(r) | (static_cast<std::uint32_t>(g) << 8) |
           (static_cast<std::uint32_t>(b) << 16) | (static_cast<std::uint32_t>(a) << 24);
  }
};

struct Vertex {
  Vec3 pos;
  Color color;
};

struct Mesh {
  std::vector<Vertex> vertices;
  std::vector<std::uint32_t> indices;  // triangles, 3 per face

  std::size_t TriangleCount() const { return indices.size() / 3; }
  void Append(const Mesh& other, const Mat4& transform);
};

// All builders return meshes whose triangles face outward under the renderer's culling convention.
Mesh MakeBox(Vec3 size, Color c);  // centered at origin
Mesh MakeBoxMinMax(Vec3 mn, Vec3 mx, Color c);
Mesh MakeCylinder(float radius, float height, int segments, Color c);  // y from 0 to height
Mesh MakeSphere(float radius, int rings, int segments, Color c);
Mesh MakeQuadXZ(float halfX, float halfZ, Color c);  // facing up, at y=0
Mesh MakeDisc(float radius, int segments, Color c);  // flat disc facing up at y=0
// Checkerboard floor of tile x tile quads covering [-half, half] in x and z.
Mesh MakeCheckerFloor(float half, float tile, Color a, Color b);

}  // namespace ascend
