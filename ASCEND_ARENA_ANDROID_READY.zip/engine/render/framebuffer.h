#pragma once
// CPU framebuffer (RGBA8, little-endian R,G,B,A byte order) with a depth buffer and 2D drawing helpers.
#include <cstdint>
#include <string>
#include <vector>

#include "mesh.h"

namespace ascend {

class Framebuffer {
 public:
  Framebuffer() = default;
  Framebuffer(int w, int h) { Resize(w, h); }

  // Returns false (and leaves the buffer unchanged) for non-positive or absurd sizes.
  bool Resize(int w, int h);
  int width() const { return w_; }
  int height() const { return h_; }
  const std::uint32_t* pixels() const { return color_.data(); }
  std::uint32_t* pixels() { return color_.data(); }
  float* depth() { return depth_.data(); }

  void ClearGradient(Color top, Color bottom);  // also resets depth
  void ClearDepth();

  std::uint32_t Get(int x, int y) const;
  void Blend(int x, int y, Color c);  // source-over using c.a

  void FillRect(float x, float y, float w, float h, Color c);
  void FillCircle(float cx, float cy, float r, Color c);
  void FillRing(float cx, float cy, float rOuter, float rInner, Color c);
  // Fills the clockwise-from-top fraction (0..1) of a circle; used for cooldown overlays.
  void FillPie(float cx, float cy, float r, float fraction, Color c);
  // Draws ASCII text with a built-in 5x7 font (lowercase is drawn as uppercase). Returns the width drawn.
  float DrawText(float x, float y, const std::string& text, int scale, Color c);
  static float TextWidth(const std::string& text, int scale);

  // Writes a binary PPM (P6). Returns false on I/O error.
  bool SavePpm(const std::string& path) const;

 private:
  int w_ = 0, h_ = 0;
  std::vector<std::uint32_t> color_;
  std::vector<float> depth_;
};

}  // namespace ascend
