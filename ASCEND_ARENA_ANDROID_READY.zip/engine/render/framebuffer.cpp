#include "framebuffer.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

#include "font5x7.inc"

namespace ascend {
namespace {
constexpr int kMaxDim = 8192;
}

bool Framebuffer::Resize(int w, int h) {
  if (w <= 0 || h <= 0 || w > kMaxDim || h > kMaxDim) return false;
  w_ = w;
  h_ = h;
  color_.assign(static_cast<std::size_t>(w) * static_cast<std::size_t>(h), 0xFF000000u);
  depth_.assign(color_.size(), 1e30f);
  return true;
}

void Framebuffer::ClearDepth() { std::fill(depth_.begin(), depth_.end(), 1e30f); }

void Framebuffer::ClearGradient(Color top, Color bottom) {
  for (int y = 0; y < h_; ++y) {
    const float t = h_ > 1 ? static_cast<float>(y) / static_cast<float>(h_ - 1) : 0.f;
    auto mix = [&](std::uint8_t a, std::uint8_t b) {
      return static_cast<std::uint8_t>(
          std::lround(static_cast<float>(a) + (static_cast<float>(b) - static_cast<float>(a)) * t));
    };
    const Color c{mix(top.r, bottom.r), mix(top.g, bottom.g), mix(top.b, bottom.b), 255};
    std::fill_n(color_.begin() + static_cast<std::ptrdiff_t>(y) * w_, w_, c.Pack());
  }
  ClearDepth();
}

std::uint32_t Framebuffer::Get(int x, int y) const {
  if (x < 0 || y < 0 || x >= w_ || y >= h_) return 0;
  return color_[static_cast<std::size_t>(y) * static_cast<std::size_t>(w_) + static_cast<std::size_t>(x)];
}

void Framebuffer::Blend(int x, int y, Color c) {
  if (x < 0 || y < 0 || x >= w_ || y >= h_ || c.a == 0) return;
  std::uint32_t& dst = color_[static_cast<std::size_t>(y) * static_cast<std::size_t>(w_) + static_cast<std::size_t>(x)];
  if (c.a == 255) {
    dst = c.Pack();
    return;
  }
  const int a = c.a;
  const int dr = static_cast<int>(dst & 0xFFu), dg = static_cast<int>((dst >> 8) & 0xFFu),
            db = static_cast<int>((dst >> 16) & 0xFFu);
  const auto mix = [&](int s, int d) { return static_cast<std::uint8_t>((s * a + d * (255 - a)) / 255); };
  dst = Color{mix(c.r, dr), mix(c.g, dg), mix(c.b, db), 255}.Pack();
}

void Framebuffer::FillRect(float x, float y, float w, float h, Color c) {
  const int x0 = std::max(0, static_cast<int>(std::floor(x))), x1 = std::min(w_, static_cast<int>(std::ceil(x + w)));
  const int y0 = std::max(0, static_cast<int>(std::floor(y))), y1 = std::min(h_, static_cast<int>(std::ceil(y + h)));
  for (int j = y0; j < y1; ++j)
    for (int i = x0; i < x1; ++i) Blend(i, j, c);
}

void Framebuffer::FillCircle(float cx, float cy, float r, Color c) { FillRing(cx, cy, r, 0.f, c); }

void Framebuffer::FillRing(float cx, float cy, float ro, float ri, Color c) {
  if (ro <= 0.f) return;
  const int x0 = std::max(0, static_cast<int>(std::floor(cx - ro))),
            x1 = std::min(w_ - 1, static_cast<int>(std::ceil(cx + ro)));
  const int y0 = std::max(0, static_cast<int>(std::floor(cy - ro))),
            y1 = std::min(h_ - 1, static_cast<int>(std::ceil(cy + ro)));
  const float ro2 = ro * ro, ri2 = ri > 0.f ? ri * ri : -1.f;
  for (int j = y0; j <= y1; ++j)
    for (int i = x0; i <= x1; ++i) {
      const float dx = static_cast<float>(i) + 0.5f - cx, dy = static_cast<float>(j) + 0.5f - cy;
      const float d2 = dx * dx + dy * dy;
      if (d2 <= ro2 && d2 >= ri2) Blend(i, j, c);
    }
}

void Framebuffer::FillPie(float cx, float cy, float r, float fraction, Color c) {
  fraction = std::min(1.f, std::max(0.f, fraction));
  if (fraction <= 0.f || r <= 0.f) return;
  const int x0 = std::max(0, static_cast<int>(std::floor(cx - r))),
            x1 = std::min(w_ - 1, static_cast<int>(std::ceil(cx + r)));
  const int y0 = std::max(0, static_cast<int>(std::floor(cy - r))),
            y1 = std::min(h_ - 1, static_cast<int>(std::ceil(cy + r)));
  constexpr float kTwoPi = 6.28318530717958647692f;
  for (int j = y0; j <= y1; ++j)
    for (int i = x0; i <= x1; ++i) {
      const float dx = static_cast<float>(i) + 0.5f - cx, dy = static_cast<float>(j) + 0.5f - cy;
      if (dx * dx + dy * dy > r * r) continue;
      // Angle measured clockwise from straight up.
      float a = std::atan2(dx, -dy);
      if (a < 0.f) a += kTwoPi;
      if (a / kTwoPi <= fraction) Blend(i, j, c);
    }
}

float Framebuffer::TextWidth(const std::string& text, int scale) {
  return static_cast<float>(text.size()) * 6.f * static_cast<float>(std::max(1, scale));
}

float Framebuffer::DrawText(float x, float y, const std::string& text, int scale, Color c) {
  scale = std::max(1, scale);
  float px = x;
  for (char ch : text) {
    int code = static_cast<unsigned char>(ch);
    if (code >= 'a' && code <= 'z') code -= 32;
    const unsigned char* g = (code >= 32 && code <= 95) ? kFont5x7[code - 32] : nullptr;
    static const unsigned char kBox[7] = {0x1F, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1F};
    if (!g) g = kBox;
    for (int row = 0; row < 7; ++row)
      for (int col = 0; col < 5; ++col)
        if (g[row] & (1u << (4 - col)))
          FillRect(px + static_cast<float>(col * scale), y + static_cast<float>(row * scale), static_cast<float>(scale),
                   static_cast<float>(scale), c);
    px += 6.f * static_cast<float>(scale);
  }
  return px - x;
}

bool Framebuffer::SavePpm(const std::string& path) const {
  if (w_ <= 0 || h_ <= 0) return false;
  std::FILE* f = std::fopen(path.c_str(), "wb");
  if (!f) return false;
  std::fprintf(f, "P6\n%d %d\n255\n", w_, h_);
  std::vector<unsigned char> row(static_cast<std::size_t>(w_) * 3);
  bool ok = true;
  for (int y = 0; y < h_ && ok; ++y) {
    for (int x = 0; x < w_; ++x) {
      const std::uint32_t p =
          color_[static_cast<std::size_t>(y) * static_cast<std::size_t>(w_) + static_cast<std::size_t>(x)];
      row[static_cast<std::size_t>(x) * 3] = static_cast<unsigned char>(p & 0xFFu);
      row[static_cast<std::size_t>(x) * 3 + 1] = static_cast<unsigned char>((p >> 8) & 0xFFu);
      row[static_cast<std::size_t>(x) * 3 + 2] = static_cast<unsigned char>((p >> 16) & 0xFFu);
    }
    ok = std::fwrite(row.data(), 1, row.size(), f) == row.size();
  }
  return std::fclose(f) == 0 && ok;
}

}  // namespace ascend
