#include "animation.h"

#include <algorithm>
#include <cmath>

namespace ascend {

Quat Normalize(Quat q) {
  const float l = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
  if (l < 1e-8f) return Quat{};
  return {q.x / l, q.y / l, q.z / l, q.w / l};
}

Quat Slerp(Quat a, Quat b, float t) {
  float d = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
  if (d < 0.f) {  // take the short way around
    b = {-b.x, -b.y, -b.z, -b.w};
    d = -d;
  }
  if (d > 0.9995f) {
    return Normalize({a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t});
  }
  const float th = std::acos(Clamp(d, -1.f, 1.f));
  const float s = std::sin(th);
  const float wa = std::sin((1.f - t) * th) / s, wb = std::sin(t * th) / s;
  return {a.x * wa + b.x * wb, a.y * wa + b.y * wb, a.z * wa + b.z * wb, a.w * wa + b.w * wb};
}

Mat4 ToMat4(const Quat& qIn) {
  const Quat q = Normalize(qIn);
  Mat4 m;
  const float xx = q.x * q.x, yy = q.y * q.y, zz = q.z * q.z;
  const float xy = q.x * q.y, xz = q.x * q.z, yz = q.y * q.z;
  const float wx = q.w * q.x, wy = q.w * q.y, wz = q.w * q.z;
  m.m[0][0] = 1.f - 2.f * (yy + zz);
  m.m[0][1] = 2.f * (xy - wz);
  m.m[0][2] = 2.f * (xz + wy);
  m.m[1][0] = 2.f * (xy + wz);
  m.m[1][1] = 1.f - 2.f * (xx + zz);
  m.m[1][2] = 2.f * (yz - wx);
  m.m[2][0] = 2.f * (xz - wy);
  m.m[2][1] = 2.f * (yz + wx);
  m.m[2][2] = 1.f - 2.f * (xx + yy);
  return m;
}

Mat4 ToMat4(const JointTRS& j) {
  Mat4 r = ToMat4(j.r);
  for (int row = 0; row < 3; ++row) {
    r.m[row][0] *= j.s.x;
    r.m[row][1] *= j.s.y;
    r.m[row][2] *= j.s.z;
  }
  r.m[0][3] = j.t.x;
  r.m[1][3] = j.t.y;
  r.m[2][3] = j.t.z;
  return r;
}

Pose RestPose(const SkinnedModel& m) {
  Pose p(m.joints.size());
  for (std::size_t i = 0; i < p.size(); ++i) p[i] = m.joints[i].rest;
  return p;
}

namespace {

// Finds the key interval for `t`; returns index i with times[i] <= t < times[i+1] and the blend factor.
void FindKey(const std::vector<float>& times, float t, std::size_t& i, float& f) {
  if (t <= times.front()) {
    i = 0;
    f = 0.f;
    return;
  }
  if (t >= times.back()) {
    i = times.size() - 1;
    f = 0.f;
    return;
  }
  const auto it = std::upper_bound(times.begin(), times.end(), t);
  i = static_cast<std::size_t>(it - times.begin()) - 1;
  const float span = times[i + 1] - times[i];
  f = span > 1e-8f ? (t - times[i]) / span : 0.f;
}

}  // namespace

void SampleClip(const SkinnedModel& m, const AnimClip& clip, float time, bool loop, Pose& out) {
  out = RestPose(m);
  float t = time;
  if (clip.duration > 1e-6f) {
    if (loop)
      t = std::fmod(std::max(0.f, t), clip.duration);
    else
      t = Clamp(t, 0.f, clip.duration);
  } else {
    t = 0.f;
  }
  for (const auto& ch : clip.channels) {
    if (ch.joint < 0 || ch.joint >= static_cast<int>(out.size()) || ch.times.empty()) continue;
    const std::size_t stride = ch.path == ChannelPath::Rotation ? 4u : 3u;
    if (ch.values.size() < ch.times.size() * stride) continue;  // malformed channel: ignore
    std::size_t i = 0;
    float f = 0.f;
    FindKey(ch.times, t, i, f);
    const std::size_t j = std::min(i + 1, ch.times.size() - 1);
    if (ch.step) f = 0.f;
    JointTRS& dst = out[static_cast<std::size_t>(ch.joint)];
    const float* a = &ch.values[i * stride];
    const float* b = &ch.values[j * stride];
    if (ch.path == ChannelPath::Rotation) {
      dst.r = Slerp({a[0], a[1], a[2], a[3]}, {b[0], b[1], b[2], b[3]}, f);
    } else {
      const Vec3 v{Lerp(a[0], b[0], f), Lerp(a[1], b[1], f), Lerp(a[2], b[2], f)};
      if (ch.path == ChannelPath::Translation)
        dst.t = v;
      else
        dst.s = v;
    }
  }
}

Pose BlendPoses(const Pose& a, const Pose& b, float t) {
  Pose out(a.size());
  const std::size_t n = std::min(a.size(), b.size());
  for (std::size_t i = 0; i < n; ++i) {
    out[i].t = {Lerp(a[i].t.x, b[i].t.x, t), Lerp(a[i].t.y, b[i].t.y, t), Lerp(a[i].t.z, b[i].t.z, t)};
    out[i].s = {Lerp(a[i].s.x, b[i].s.x, t), Lerp(a[i].s.y, b[i].s.y, t), Lerp(a[i].s.z, b[i].s.z, t)};
    out[i].r = Slerp(a[i].r, b[i].r, t);
  }
  for (std::size_t i = n; i < a.size(); ++i) out[i] = a[i];
  return out;
}

std::vector<Mat4> WorldMatrices(const SkinnedModel& m, const Pose& pose) {
  std::vector<Mat4> w(m.joints.size());
  for (std::size_t i = 0; i < m.joints.size(); ++i) {
    const Mat4 local = ToMat4(i < pose.size() ? pose[i] : m.joints[i].rest);
    const int p = m.joints[i].parent;
    w[i] = (p >= 0 && static_cast<std::size_t>(p) < i) ? w[static_cast<std::size_t>(p)] * local : local;
  }
  return w;
}

std::vector<Mat4> SkinMatrices(const SkinnedModel& m, const Pose& pose) {
  std::vector<Mat4> s = WorldMatrices(m, pose);
  for (std::size_t i = 0; i < s.size(); ++i) s[i] = s[i] * m.joints[i].inverseBind;
  return s;
}

void SkinToMesh(const SkinnedModel& m, const std::vector<Mat4>& skin, Mesh& out) {
  out.vertices.resize(m.vertices.size());
  for (std::size_t i = 0; i < m.vertices.size(); ++i) {
    const SkinVertex& v = m.vertices[i];
    Vec3 p{0.f, 0.f, 0.f};
    float wsum = 0.f;
    for (int k = 0; k < 4; ++k) {
      const float w = v.weight[k];
      if (w <= 0.f || v.joint[k] >= skin.size()) continue;
      p += TransformPoint(skin[v.joint[k]], v.pos) * w;
      wsum += w;
    }
    if (wsum < 1e-6f) p = v.pos;
    const std::size_t mi = static_cast<std::size_t>(std::max(0, v.material));
    out.vertices[i].pos = p;
    out.vertices[i].color = mi < m.materials.size() ? m.materials[mi].color : Color{255, 0, 255, 255};
  }
  out.indices = m.indices;
}

void Animator::SetModel(const SkinnedModel* m) {
  model_ = m;
  clip_ = -1;
  currentName_.clear();
  finished_ = false;
  time_ = 0.f;
  pose_ = m ? RestPose(*m) : Pose{};
  from_ = pose_;
}

bool Animator::Play(const std::string& clip, bool loop, float fade, bool restart, float speed) {
  if (!model_) return false;
  const int idx = model_->FindClip(clip);
  if (idx < 0) return false;
  speed_ = speed;
  if (idx == clip_ && !restart) return true;
  from_ = pose_;  // cross-fade from whatever is on screen now
  fadeTotal_ = fade;
  fade_ = fade;
  clip_ = idx;
  currentName_ = clip;
  loop_ = loop;
  finished_ = false;
  time_ = 0.f;
  return true;
}

void Animator::Update(float dt) {
  if (!model_ || clip_ < 0) return;
  const AnimClip& c = model_->clips[static_cast<std::size_t>(clip_)];
  time_ += dt * speed_;
  if (!loop_ && time_ >= c.duration) {
    time_ = c.duration;
    finished_ = true;
  }
  Pose target;
  SampleClip(*model_, c, time_, loop_, target);
  if (fade_ > 0.f && fadeTotal_ > 0.f) {
    fade_ = std::max(0.f, fade_ - dt);
    const float t = 1.f - fade_ / fadeTotal_;
    pose_ = BlendPoses(from_, target, t);
  } else {
    pose_ = std::move(target);
  }
}

std::vector<std::string> ValidateModel(const SkinnedModel& m) {
  std::vector<std::string> e;
  if (m.joints.empty()) e.push_back("model has no joints");
  if (m.joints.size() > 128) e.push_back("too many joints (" + std::to_string(m.joints.size()) + " > 128)");
  for (std::size_t i = 0; i < m.joints.size(); ++i)
    if (m.joints[i].parent >= static_cast<int>(i))
      e.push_back("joint '" + m.joints[i].name + "' parent must precede it");
  if (m.vertices.empty()) e.push_back("model has no vertices");
  if (m.indices.size() % 3 != 0) e.push_back("index count is not a multiple of 3");
  for (auto i : m.indices)
    if (i >= m.vertices.size()) {
      e.push_back("index out of range");
      break;
    }
  for (const auto& v : m.vertices) {
    float sum = 0.f;
    for (int k = 0; k < 4; ++k) {
      sum += v.weight[k];
      if (v.weight[k] > 0.f && v.joint[k] >= m.joints.size()) {
        e.push_back("vertex references missing joint");
        return e;
      }
    }
    if (sum < 0.5f || sum > 1.5f) {
      e.push_back("vertex weights do not sum to ~1");
      break;
    }
  }
  for (const auto& c : m.clips) {
    if (c.duration < 0.f) e.push_back("clip '" + c.name + "' has negative duration");
    for (const auto& ch : c.channels) {
      if (ch.joint < 0 || ch.joint >= static_cast<int>(m.joints.size()))
        e.push_back("clip '" + c.name + "' targets a missing joint");
      const std::size_t stride = ch.path == ChannelPath::Rotation ? 4u : 3u;
      if (ch.values.size() != ch.times.size() * stride) e.push_back("clip '" + c.name + "' channel data size mismatch");
      if (ch.times.empty()) e.push_back("clip '" + c.name + "' has an empty channel");
      for (std::size_t k = 0; k < ch.times.size(); ++k) {
        if (!std::isfinite(ch.times[k]) || (k > 0 && !(ch.times[k] > ch.times[k - 1]))) {
          e.push_back("clip '" + c.name + "' keyframe times are not finite and strictly increasing");
          break;
        }
      }
      for (const float v : ch.values) {
        if (!std::isfinite(v)) {
          e.push_back("clip '" + c.name + "' has a non-finite keyframe value");
          break;
        }
      }
    }
  }
  return e;
}

bool SameSkeleton(const SkinnedModel& a, const SkinnedModel& b) {
  if (a.joints.size() != b.joints.size()) return false;
  for (std::size_t i = 0; i < a.joints.size(); ++i)
    if (a.joints[i].name != b.joints[i].name || a.joints[i].parent != b.joints[i].parent) return false;
  return true;
}

}  // namespace ascend
