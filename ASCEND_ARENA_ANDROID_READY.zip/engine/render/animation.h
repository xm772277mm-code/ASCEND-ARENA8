#pragma once
// Pose sampling, blending, CPU skinning and a small animation state driver.
#include <string>
#include <vector>

#include "skinned_model.h"

namespace ascend {

using Pose = std::vector<JointTRS>;

Quat Normalize(Quat q);
Quat Slerp(Quat a, Quat b, float t);
Mat4 ToMat4(const Quat& q);
Mat4 ToMat4(const JointTRS& trs);

Pose RestPose(const SkinnedModel& m);
// Samples `clip` at `time` (looped or clamped) on top of the rest pose.
void SampleClip(const SkinnedModel& m, const AnimClip& clip, float time, bool loop, Pose& out);
// Linear blend of two poses (slerp for rotations); t = 0 -> a, t = 1 -> b.
Pose BlendPoses(const Pose& a, const Pose& b, float t);
// World matrix of every joint for a pose.
std::vector<Mat4> WorldMatrices(const SkinnedModel& m, const Pose& pose);
// skin[i] = world[i] * inverseBind[i]
std::vector<Mat4> SkinMatrices(const SkinnedModel& m, const Pose& pose);
// Skins all vertices into `out` (reusing its storage). Colors come from the model's materials.
void SkinToMesh(const SkinnedModel& m, const std::vector<Mat4>& skin, Mesh& out);

// Drives one model: plays a clip and cross-fades when the clip changes.
class Animator {
 public:
  void SetModel(const SkinnedModel* m);
  // Starts `clip` (by name). If it is already playing and `restart` is false, nothing changes.
  // Returns false (and keeps the current animation) if the clip does not exist.
  bool Play(const std::string& clip, bool loop, float fadeSeconds = 0.12f, bool restart = false, float speed = 1.f);
  void Update(float dt);
  const Pose& pose() const { return pose_; }
  bool finished() const { return finished_; }  // one-shot clip reached its end (pose holds the last frame)
  const std::string& current() const { return currentName_; }
  float time() const { return time_; }

 private:
  const SkinnedModel* model_ = nullptr;
  int clip_ = -1;
  std::string currentName_;
  bool loop_ = true, finished_ = false;
  float time_ = 0.f, speed_ = 1.f;
  float fade_ = 0.f, fadeTotal_ = 0.f;
  Pose from_, pose_;
};

}  // namespace ascend
