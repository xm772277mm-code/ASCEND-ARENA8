#pragma once
// CPU triangle rasterizer: near-plane clipping, back-face culling, depth test, flat lighting, fog, alpha blend.
#include "framebuffer.h"
#include "mesh.h"

namespace ascend {

struct Lighting {
  Vec3 sunDir{-0.4f, -1.f, 0.3f};  // direction the light travels
  float ambient = 0.45f;
  Color fog{150, 170, 205, 255};
  float fogNear = 25.f, fogFar = 70.f;
};

struct DrawParams {
  Mat4 model;
  Color tint{255, 255, 255, 255};  // multiplied with vertex colors; alpha < 255 blends (no depth write)
  Color flashColor{255, 60, 60, 255};
  float flash = 0.f;  // 0..1 blend toward flashColor (hit feedback)
  bool unlit = false;
  bool cull = true;
};

struct RasterStats {
  int trianglesSubmitted = 0;
  int trianglesDrawn = 0;
};

class Rasterizer {
 public:
  void Begin(Framebuffer* fb, const Camera& cam, const Lighting& light);
  void Draw(const Mesh& mesh, const DrawParams& params);
  // Projects a world point to framebuffer pixels. Returns false if behind the camera.
  bool Project(Vec3 world, float& sx, float& sy) const;
  const RasterStats& stats() const { return stats_; }

 private:
  struct ScreenVert {
    float x, y, invW;
    float r, g, b;
  };
  void DrawTriangle(const ScreenVert& a, const ScreenVert& b, const ScreenVert& c, float light, float fog,
                    const DrawParams& p);

  Framebuffer* fb_ = nullptr;
  Camera cam_;
  Lighting light_;
  Mat4 view_;
  float tanHalf_ = 1.f, aspect_ = 1.f;
  RasterStats stats_;
};

}  // namespace ascend
