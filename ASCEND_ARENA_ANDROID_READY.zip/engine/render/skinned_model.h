#pragma once
// Data for skeletal (skinned) models and animation clips. Pure data; see animation.h for behavior
// and engine/assets/glb_loader.h for importing from glTF binary files.
#include <cstdint>
#include <string>
#include <vector>

#include "mesh.h"

namespace ascend {

struct Quat {
  float x = 0.f, y = 0.f, z = 0.f, w = 1.f;
};

struct JointTRS {
  Vec3 t;
  Quat r;
  Vec3 s{1.f, 1.f, 1.f};
};

struct Joint {
  std::string name;
  int parent = -1;  // index into SkinnedModel::joints, -1 for roots; parents always precede children
  JointTRS rest;
  Mat4 inverseBind;
};

struct SkinVertex {
  Vec3 pos;
  std::uint8_t joint[4] = {0, 0, 0, 0};
  float weight[4] = {1.f, 0.f, 0.f, 0.f};
  int material = 0;
};

struct ModelMaterial {
  std::string name;
  Color color;
};

enum class ChannelPath { Translation, Rotation, Scale };

struct AnimChannel {
  int joint = 0;
  ChannelPath path = ChannelPath::Translation;
  bool step = false;          // STEP interpolation (otherwise LINEAR)
  std::vector<float> times;   // strictly increasing
  std::vector<float> values;  // 3 floats per key (T/S) or 4 (R: x,y,z,w)
};

struct AnimClip {
  std::string name;
  float duration = 0.f;
  std::vector<AnimChannel> channels;
};

struct SkinnedModel {
  std::string source;  // file path or "<generated>"
  std::vector<Joint> joints;
  std::vector<SkinVertex> vertices;
  std::vector<std::uint32_t> indices;
  std::vector<ModelMaterial> materials;
  std::vector<AnimClip> clips;

  int FindClip(const std::string& name) const {
    for (std::size_t i = 0; i < clips.size(); ++i)
      if (clips[i].name == name) return static_cast<int>(i);
    return -1;
  }
  int FindJoint(const std::string& name) const {
    for (std::size_t i = 0; i < joints.size(); ++i)
      if (joints[i].name == name) return static_cast<int>(i);
    return -1;
  }
  int FindMaterial(const std::string& name) const {
    for (std::size_t i = 0; i < materials.size(); ++i)
      if (materials[i].name == name) return static_cast<int>(i);
    return -1;
  }
};

// Structural validation (indices in range, parent order, weights, channel data). Empty == valid.
std::vector<std::string> ValidateModel(const SkinnedModel& m);
// True when both models have the same joint names and parents in the same order (outfit meshes must match).
bool SameSkeleton(const SkinnedModel& a, const SkinnedModel& b);

}  // namespace ascend
