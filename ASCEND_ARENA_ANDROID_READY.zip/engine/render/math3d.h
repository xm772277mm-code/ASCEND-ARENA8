#pragma once
// 3D math for the renderer. Left-handed, y up, +z forward at yaw 0 (matches engine/core/amath.h).
#include <cmath>

#include "../core/amath.h"

namespace ascend {

constexpr Vec3 Cross(Vec3 a, Vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline Vec3 Normalize(Vec3 v) {
  const float l = Length(v);
  return l < 1e-8f ? Vec3{0.f, 0.f, 0.f} : v * (1.f / l);
}

struct Vec4 {
  float x = 0.f, y = 0.f, z = 0.f, w = 0.f;
};

// Row-major 4x4, column-vector convention: v' = M * v.
struct Mat4 {
  float m[4][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};

  static Mat4 Identity() { return {}; }
  static Mat4 Translation(Vec3 t) {
    Mat4 r;
    r.m[0][3] = t.x;
    r.m[1][3] = t.y;
    r.m[2][3] = t.z;
    return r;
  }
  static Mat4 Scale(Vec3 s) {
    Mat4 r;
    r.m[0][0] = s.x;
    r.m[1][1] = s.y;
    r.m[2][2] = s.z;
    return r;
  }
  static Mat4 RotationY(float a) {  // positive angle turns +z toward +x (same as yaw)
    Mat4 r;
    const float c = std::cos(a), s = std::sin(a);
    r.m[0][0] = c;
    r.m[0][2] = s;
    r.m[2][0] = -s;
    r.m[2][2] = c;
    return r;
  }
  static Mat4 RotationX(float a) {  // positive angle pitches +y toward +z
    Mat4 r;
    const float c = std::cos(a), s = std::sin(a);
    r.m[1][1] = c;
    r.m[1][2] = -s;
    r.m[2][1] = s;
    r.m[2][2] = c;
    return r;
  }
  static Mat4 RotationZ(float a) {
    Mat4 r;
    const float c = std::cos(a), s = std::sin(a);
    r.m[0][0] = c;
    r.m[0][1] = -s;
    r.m[1][0] = s;
    r.m[1][1] = c;
    return r;
  }
};

inline Mat4 operator*(const Mat4& a, const Mat4& b) {
  Mat4 r;
  for (int i = 0; i < 4; ++i)
    for (int j = 0; j < 4; ++j) {
      float s = 0.f;
      for (int k = 0; k < 4; ++k) s += a.m[i][k] * b.m[k][j];
      r.m[i][j] = s;
    }
  return r;
}

inline Vec4 operator*(const Mat4& a, Vec4 v) {
  return {a.m[0][0] * v.x + a.m[0][1] * v.y + a.m[0][2] * v.z + a.m[0][3] * v.w,
          a.m[1][0] * v.x + a.m[1][1] * v.y + a.m[1][2] * v.z + a.m[1][3] * v.w,
          a.m[2][0] * v.x + a.m[2][1] * v.y + a.m[2][2] * v.z + a.m[2][3] * v.w,
          a.m[3][0] * v.x + a.m[3][1] * v.y + a.m[3][2] * v.z + a.m[3][3] * v.w};
}

inline Vec3 TransformPoint(const Mat4& a, Vec3 p) {
  const Vec4 r = a * Vec4{p.x, p.y, p.z, 1.f};
  return {r.x, r.y, r.z};
}
inline Vec3 TransformDir(const Mat4& a, Vec3 d) {
  const Vec4 r = a * Vec4{d.x, d.y, d.z, 0.f};
  return {r.x, r.y, r.z};
}

// Left-handed look-at view matrix: view space has +z forward, +x right, +y up.
inline Mat4 LookAt(Vec3 eye, Vec3 target, Vec3 up = {0.f, 1.f, 0.f}) {
  const Vec3 f = Normalize(target - eye);
  const Vec3 r = Normalize(Cross(up, f));
  const Vec3 u = Cross(f, r);
  Mat4 v;
  v.m[0][0] = r.x;
  v.m[0][1] = r.y;
  v.m[0][2] = r.z;
  v.m[0][3] = -Dot(r, eye);
  v.m[1][0] = u.x;
  v.m[1][1] = u.y;
  v.m[1][2] = u.z;
  v.m[1][3] = -Dot(u, eye);
  v.m[2][0] = f.x;
  v.m[2][1] = f.y;
  v.m[2][2] = f.z;
  v.m[2][3] = -Dot(f, eye);
  return v;
}

struct Camera {
  Vec3 eye{0.f, 5.f, -8.f};
  Vec3 target{0.f, 1.f, 0.f};
  float fovY = 60.f * kPi / 180.f;
  float nearZ = 0.1f;
  float farZ = 100.f;
  Mat4 View() const { return LookAt(eye, target); }
};

}  // namespace ascend
