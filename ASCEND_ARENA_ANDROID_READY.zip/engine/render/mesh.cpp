#include "mesh.h"

#include <cmath>

namespace ascend {

void Mesh::Append(const Mesh& other, const Mat4& t) {
  const auto base = static_cast<std::uint32_t>(vertices.size());
  for (const auto& v : other.vertices) vertices.push_back({TransformPoint(t, v.pos), v.color});
  for (const auto i : other.indices) indices.push_back(base + i);
}

namespace {
// Adds a quad (a,b,c,d) in the order that is front-facing when viewed from outside.
void AddQuad(Mesh& m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, Color col) {
  const auto base = static_cast<std::uint32_t>(m.vertices.size());
  m.vertices.push_back({a, col});
  m.vertices.push_back({b, col});
  m.vertices.push_back({c, col});
  m.vertices.push_back({d, col});
  m.indices.insert(m.indices.end(), {base, base + 1, base + 2, base, base + 2, base + 3});
}
}  // namespace

Mesh MakeBoxMinMax(Vec3 mn, Vec3 mx, Color c) {
  Mesh m;
  // Winding: clockwise when seen from outside in this left-handed system (verified by render tests).
  const Vec3 p000{mn.x, mn.y, mn.z}, p100{mx.x, mn.y, mn.z}, p110{mx.x, mx.y, mn.z}, p010{mn.x, mx.y, mn.z};
  const Vec3 p001{mn.x, mn.y, mx.z}, p101{mx.x, mn.y, mx.z}, p111{mx.x, mx.y, mx.z}, p011{mn.x, mx.y, mx.z};
  AddQuad(m, p000, p010, p110, p100, c);  // -z face
  AddQuad(m, p101, p111, p011, p001, c);  // +z face
  AddQuad(m, p001, p011, p010, p000, c);  // -x face
  AddQuad(m, p100, p110, p111, p101, c);  // +x face
  AddQuad(m, p010, p011, p111, p110, c);  // +y face
  AddQuad(m, p000, p100, p101, p001, c);  // -y face
  return m;
}

Mesh MakeBox(Vec3 size, Color c) {
  const Vec3 h = size * 0.5f;
  return MakeBoxMinMax({-h.x, -h.y, -h.z}, h, c);
}

Mesh MakeQuadXZ(float hx, float hz, Color c) {
  Mesh m;
  AddQuad(m, {-hx, 0.f, -hz}, {-hx, 0.f, hz}, {hx, 0.f, hz}, {hx, 0.f, -hz}, c);
  return m;
}

Mesh MakeDisc(float radius, int segments, Color c) {
  Mesh m;
  if (segments < 3) segments = 3;
  m.vertices.push_back({{0.f, 0.f, 0.f}, c});
  for (int i = 0; i < segments; ++i) {
    const float a = 2.f * kPi * static_cast<float>(i) / static_cast<float>(segments);
    m.vertices.push_back({{std::sin(a) * radius, 0.f, std::cos(a) * radius}, c});
  }
  for (int i = 0; i < segments; ++i) {
    const auto a = static_cast<std::uint32_t>(1 + i);
    const auto b = static_cast<std::uint32_t>(1 + (i + 1) % segments);
    m.indices.insert(m.indices.end(), {0u, b, a});
  }
  return m;
}

Mesh MakeCylinder(float r, float h, int seg, Color c) {
  Mesh m;
  if (seg < 3) seg = 3;
  for (int i = 0; i < seg; ++i) {
    const float a0 = 2.f * kPi * static_cast<float>(i) / static_cast<float>(seg);
    const float a1 = 2.f * kPi * static_cast<float>(i + 1) / static_cast<float>(seg);
    const Vec3 b0{std::sin(a0) * r, 0.f, std::cos(a0) * r}, b1{std::sin(a1) * r, 0.f, std::cos(a1) * r};
    const Vec3 t0{b0.x, h, b0.z}, t1{b1.x, h, b1.z};
    AddQuad(m, b1, t1, t0, b0, c);  // side
    const auto base = static_cast<std::uint32_t>(m.vertices.size());
    m.vertices.push_back({{0.f, h, 0.f}, c});
    m.vertices.push_back({t0, c});
    m.vertices.push_back({t1, c});
    m.indices.insert(m.indices.end(), {base, base + 1, base + 2});  // top cap
    m.vertices.push_back({{0.f, 0.f, 0.f}, c});
    m.vertices.push_back({b0, c});
    m.vertices.push_back({b1, c});
    m.indices.insert(m.indices.end(), {base + 3, base + 5, base + 4});  // bottom cap
  }
  return m;
}

Mesh MakeSphere(float radius, int rings, int segments, Color c) {
  Mesh m;
  if (rings < 2) rings = 2;
  if (segments < 3) segments = 3;
  for (int r = 0; r <= rings; ++r) {
    const float v = kPi * static_cast<float>(r) / static_cast<float>(rings);  // 0 = top pole
    for (int s = 0; s <= segments; ++s) {
      const float a = 2.f * kPi * static_cast<float>(s) / static_cast<float>(segments);
      m.vertices.push_back(
          {{std::sin(v) * std::sin(a) * radius, std::cos(v) * radius, std::sin(v) * std::cos(a) * radius}, c});
    }
  }
  const auto stride = static_cast<std::uint32_t>(segments + 1);
  for (int r = 0; r < rings; ++r)
    for (int s = 0; s < segments; ++s) {
      const auto i0 = static_cast<std::uint32_t>(r) * stride + static_cast<std::uint32_t>(s);
      const std::uint32_t i1 = i0 + 1, i2 = i0 + stride, i3 = i2 + 1;
      if (r != 0) m.indices.insert(m.indices.end(), {i0, i2, i1});
      if (r != rings - 1) m.indices.insert(m.indices.end(), {i1, i2, i3});
    }
  return m;
}

Mesh MakeCheckerFloor(float half, float tile, Color a, Color b) {
  Mesh m;
  if (tile <= 0.f || half <= 0.f) return m;
  const int n = static_cast<int>(std::ceil(2.f * half / tile));
  const float step = 2.f * half / static_cast<float>(n);
  for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j) {
      const float x0 = -half + static_cast<float>(i) * step, x1 = x0 + step;
      const float z0 = -half + static_cast<float>(j) * step, z1 = z0 + step;
      AddQuad(m, {x0, 0.f, z0}, {x0, 0.f, z1}, {x1, 0.f, z1}, {x1, 0.f, z0}, ((i + j) & 1) ? b : a);
    }
  return m;
}

}  // namespace ascend
