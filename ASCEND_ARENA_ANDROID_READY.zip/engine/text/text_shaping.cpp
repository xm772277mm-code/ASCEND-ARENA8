#include "text_shaping.h"

#include <algorithm>

namespace ascend {
namespace {

struct Joining {
  std::uint32_t base, isolated, final_, initial, medial;  // 0 = form does not exist
};

// Arabic letters -> Presentation Forms-B. Right-joining letters have no initial/medial form.
constexpr Joining kTable[] = {
    {0x0621, 0xFE80, 0, 0, 0},
    {0x0622, 0xFE81, 0xFE82, 0, 0},
    {0x0623, 0xFE83, 0xFE84, 0, 0},
    {0x0624, 0xFE85, 0xFE86, 0, 0},
    {0x0625, 0xFE87, 0xFE88, 0, 0},
    {0x0626, 0xFE89, 0xFE8A, 0xFE8B, 0xFE8C},
    {0x0627, 0xFE8D, 0xFE8E, 0, 0},
    {0x0628, 0xFE8F, 0xFE90, 0xFE91, 0xFE92},
    {0x0629, 0xFE93, 0xFE94, 0, 0},
    {0x062A, 0xFE95, 0xFE96, 0xFE97, 0xFE98},
    {0x062B, 0xFE99, 0xFE9A, 0xFE9B, 0xFE9C},
    {0x062C, 0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0},
    {0x062D, 0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4},
    {0x062E, 0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8},
    {0x062F, 0xFEA9, 0xFEAA, 0, 0},
    {0x0630, 0xFEAB, 0xFEAC, 0, 0},
    {0x0631, 0xFEAD, 0xFEAE, 0, 0},
    {0x0632, 0xFEAF, 0xFEB0, 0, 0},
    {0x0633, 0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4},
    {0x0634, 0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8},
    {0x0635, 0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC},
    {0x0636, 0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0},
    {0x0637, 0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4},
    {0x0638, 0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8},
    {0x0639, 0xFEC9, 0xFECA, 0xFECB, 0xFECC},
    {0x063A, 0xFECD, 0xFECE, 0xFECF, 0xFED0},
    {0x0641, 0xFED1, 0xFED2, 0xFED3, 0xFED4},
    {0x0642, 0xFED5, 0xFED6, 0xFED7, 0xFED8},
    {0x0643, 0xFED9, 0xFEDA, 0xFEDB, 0xFEDC},
    {0x0644, 0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0},
    {0x0645, 0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4},
    {0x0646, 0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8},
    {0x0647, 0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC},
    {0x0648, 0xFEED, 0xFEEE, 0, 0},
    {0x0649, 0xFEEF, 0xFEF0, 0, 0},
    {0x064A, 0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4},
};

const Joining* Find(std::uint32_t c) {
  for (const auto& j : kTable)
    if (j.base == c) return &j;
  return nullptr;
}

bool IsTransparent(std::uint32_t c) { return (c >= 0x064B && c <= 0x065F) || c == 0x0670; }  // harakat
bool IsTatweel(std::uint32_t c) { return c == 0x0640; }
// Can this letter connect to the letter that follows it (in logical order)?
bool JoinsForward(std::uint32_t c) {
  if (IsTatweel(c)) return true;
  const Joining* j = Find(c);
  return j && j->initial != 0;
}
// Can this letter connect to the letter before it?
bool JoinsBackward(std::uint32_t c) {
  if (IsTatweel(c)) return true;
  const Joining* j = Find(c);
  return j && j->final_ != 0;
}

enum class Dir { L, R, N };  // strong left, strong right, neutral

Dir Classify(std::uint32_t c) {
  if ((c >= 0x0590 && c <= 0x08FF) || (c >= 0xFB1D && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF)) {
    if (c >= 0x0660 && c <= 0x0669) return Dir::L;  // Arabic-Indic digits are drawn left-to-right as numbers
    return Dir::R;
  }
  if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= 0x00C0 && c <= 0x024F))
    return Dir::L;
  return Dir::N;
}

std::uint32_t Mirror(std::uint32_t c) {
  switch (c) {
    case '(':
      return ')';
    case ')':
      return '(';
    case '[':
      return ']';
    case ']':
      return '[';
    case '{':
      return '}';
    case '}':
      return '{';
    case '<':
      return '>';
    case '>':
      return '<';
    default:
      return c;
  }
}

}  // namespace

CodePoints DecodeUtf8(const std::string& s) {
  CodePoints out;
  out.reserve(s.size());
  std::size_t i = 0;
  const auto n = s.size();
  auto cont = [&](std::size_t k) { return k < n && (static_cast<unsigned char>(s[k]) & 0xC0) == 0x80; };
  while (i < n) {
    const unsigned char b = static_cast<unsigned char>(s[i]);
    std::uint32_t cp = 0xFFFD;
    std::size_t len = 1;
    if (b < 0x80) {
      cp = b;
    } else if ((b & 0xE0) == 0xC0 && cont(i + 1)) {
      cp = (static_cast<std::uint32_t>(b & 0x1F) << 6) | (static_cast<unsigned char>(s[i + 1]) & 0x3F);
      len = 2;
      if (cp < 0x80) cp = 0xFFFD;  // overlong
    } else if ((b & 0xF0) == 0xE0 && cont(i + 1) && cont(i + 2)) {
      cp = (static_cast<std::uint32_t>(b & 0x0F) << 12) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 1]) & 0x3F) << 6) |
           (static_cast<unsigned char>(s[i + 2]) & 0x3F);
      len = 3;
      if (cp < 0x800 || (cp >= 0xD800 && cp <= 0xDFFF)) cp = 0xFFFD;
    } else if ((b & 0xF8) == 0xF0 && cont(i + 1) && cont(i + 2) && cont(i + 3)) {
      cp = (static_cast<std::uint32_t>(b & 0x07) << 18) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 1]) & 0x3F) << 12) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(s[i + 2]) & 0x3F) << 6) |
           (static_cast<unsigned char>(s[i + 3]) & 0x3F);
      len = 4;
      if (cp < 0x10000 || cp > 0x10FFFF) cp = 0xFFFD;
    }
    out.push_back(cp);
    i += len;
  }
  return out;
}

std::string EncodeUtf8(const CodePoints& cps) {
  std::string o;
  for (std::uint32_t c : cps) {
    if (c < 0x80)
      o += static_cast<char>(c);
    else if (c < 0x800) {
      o += static_cast<char>(0xC0 | (c >> 6));
      o += static_cast<char>(0x80 | (c & 0x3F));
    } else if (c < 0x10000) {
      o += static_cast<char>(0xE0 | (c >> 12));
      o += static_cast<char>(0x80 | ((c >> 6) & 0x3F));
      o += static_cast<char>(0x80 | (c & 0x3F));
    } else {
      o += static_cast<char>(0xF0 | (c >> 18));
      o += static_cast<char>(0x80 | ((c >> 12) & 0x3F));
      o += static_cast<char>(0x80 | ((c >> 6) & 0x3F));
      o += static_cast<char>(0x80 | (c & 0x3F));
    }
  }
  return o;
}

bool IsArabicLetter(std::uint32_t c) { return IsTatweel(c) || Find(c) != nullptr; }
bool IsArabicCodepoint(std::uint32_t c) { return (c >= 0x0600 && c <= 0x06FF) || (c >= 0xFE70 && c <= 0xFEFF); }

CodePoints ShapeArabic(const CodePoints& in) {
  // 1. Lam + alef ligatures.
  CodePoints t;
  t.reserve(in.size());
  struct LamAlef {
    std::uint32_t alef, iso, fin;
  };
  static constexpr LamAlef kLig[] = {
      {0x0622, 0xFEF5, 0xFEF6}, {0x0623, 0xFEF7, 0xFEF8}, {0x0625, 0xFEF9, 0xFEFA}, {0x0627, 0xFEFB, 0xFEFC}};
  // Marker values (> 0x10FFFF) carry "this slot is a ligature" through the joining pass.
  constexpr std::uint32_t kLigBase = 0x110000;
  for (std::size_t i = 0; i < in.size(); ++i) {
    bool done = false;
    if (in[i] == 0x0644) {
      std::size_t k = i + 1;
      while (k < in.size() && IsTransparent(in[k])) ++k;
      if (k < in.size()) {
        for (std::size_t li = 0; li < 4; ++li)
          if (in[k] == kLig[li].alef) {
            t.push_back(kLigBase + static_cast<std::uint32_t>(li));
            for (std::size_t m = i + 1; m < k; ++m) t.push_back(in[m]);  // keep harakat
            i = k;
            done = true;
            break;
          }
      }
    }
    if (!done) t.push_back(in[i]);
  }

  // 2. Joining.
  auto prevJoins = [&](std::size_t i) {  // does the previous non-transparent char join forward into position i?
    for (std::size_t k = i; k > 0; --k) {
      const std::uint32_t c = t[k - 1];
      if (IsTransparent(c)) continue;
      return c < kLigBase && JoinsForward(c);  // a lam-alef ligature (alef end) never joins forward
    }
    return false;
  };
  auto nextJoins = [&](std::size_t i) {  // does the next non-transparent char accept a join from the left?
    for (std::size_t k = i + 1; k < t.size(); ++k) {
      const std::uint32_t c = t[k];
      if (IsTransparent(c)) continue;
      if (c >= kLigBase) return true;  // ligature starts with lam, which has a final form
      return JoinsBackward(c);
    }
    return false;
  };
  CodePoints out;
  out.reserve(t.size());
  for (std::size_t i = 0; i < t.size(); ++i) {
    const std::uint32_t c = t[i];
    if (c >= kLigBase) {
      const LamAlef& L = kLig[c - kLigBase];
      out.push_back(prevJoins(i) ? L.fin : L.iso);
      continue;
    }
    const Joining* j = Find(c);
    if (!j) {
      out.push_back(c);
      continue;
    }
    const bool before = prevJoins(i) && j->final_ != 0;
    const bool after = j->initial != 0 && nextJoins(i);
    std::uint32_t form = j->isolated;
    if (before && after)
      form = j->medial;
    else if (before)
      form = j->final_;
    else if (after)
      form = j->initial;
    out.push_back(form);
  }
  return out;
}

CodePoints ReorderBidi(const CodePoints& s, int rtlParagraph) {
  if (s.empty()) return s;
  bool rtl = rtlParagraph == 1;
  if (rtlParagraph < 0) {
    for (std::uint32_t c : s) {
      const Dir d = Classify(c);
      if (d != Dir::N) {
        rtl = d == Dir::R;
        break;
      }
    }
  }
  // Resolve neutrals: between two runs of the same direction they take it, otherwise the paragraph direction.
  const Dir para = rtl ? Dir::R : Dir::L;
  std::vector<Dir> dir(s.size());
  for (std::size_t i = 0; i < s.size(); ++i) dir[i] = Classify(s[i]);
  for (std::size_t i = 0; i < s.size();) {
    if (dir[i] != Dir::N) {
      ++i;
      continue;
    }
    std::size_t j = i;
    while (j < s.size() && dir[j] == Dir::N) ++j;
    const Dir left = i > 0 ? dir[i - 1] : para;
    const Dir right = j < s.size() ? dir[j] : para;
    const Dir r = left == right ? left : para;
    for (std::size_t k = i; k < j; ++k) dir[k] = r;
    i = j;
  }
  // Split into runs of equal direction.
  struct Run {
    std::size_t b, e;
    Dir d;
  };
  std::vector<Run> runs;
  for (std::size_t i = 0; i < s.size();) {
    std::size_t j = i;
    while (j < s.size() && dir[j] == dir[i]) ++j;
    runs.push_back({i, j, dir[i]});
    i = j;
  }
  CodePoints out;
  out.reserve(s.size());
  auto emit = [&](const Run& r) {
    if (r.d == Dir::R) {
      // Reverse by cluster so a diacritic stays after (visually on) the letter it belongs to.
      std::size_t k = r.e;
      while (k > r.b) {
        std::size_t start = k - 1;
        while (start > r.b && IsTransparent(s[start])) --start;
        out.push_back(Mirror(s[start]));
        for (std::size_t m = start + 1; m < k; ++m) out.push_back(s[m]);
        k = start;
      }
    } else {
      for (std::size_t k = r.b; k < r.e; ++k) out.push_back(s[k]);
    }
  };
  if (rtl) {
    for (std::size_t k = runs.size(); k > 0; --k) emit(runs[k - 1]);
  } else {
    for (const auto& r : runs) emit(r);
  }
  return out;
}

CodePoints PrepareForDisplay(const std::string& utf8, int rtlParagraph) {
  return ReorderBidi(ShapeArabic(DecodeUtf8(utf8)), rtlParagraph);
}

bool ContainsRtl(const std::string& utf8) {
  for (std::uint32_t c : DecodeUtf8(utf8))
    if (Classify(c) == Dir::R) return true;
  return false;
}

}  // namespace ascend
