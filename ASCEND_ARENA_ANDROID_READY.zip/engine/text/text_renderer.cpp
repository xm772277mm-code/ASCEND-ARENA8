#include "text_renderer.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iterator>

#define STB_TRUETYPE_IMPLEMENTATION
#define STBTT_STATIC
#include "../../third_party/stb/stb_truetype.h"

namespace ascend {

struct TextRenderer::Impl {
  stbtt_fontinfo info{};
};

TextRenderer::TextRenderer() : impl_(new Impl) {}
TextRenderer::~TextRenderer() { delete impl_; }

Status TextRenderer::LoadFont(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return Status::Error("cannot open font file: " + path);
  std::vector<std::uint8_t> data((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if (data.size() < 64 || data.size() > 32u * 1024u * 1024u)
    return Status::Error("font file has an invalid size: " + path);
  const int offset = stbtt_GetFontOffsetForIndex(data.data(), 0);
  if (offset < 0) return Status::Error("not a TrueType font: " + path);
  stbtt_fontinfo info;
  if (!stbtt_InitFont(&info, data.data(), offset)) return Status::Error("font parse failed: " + path);
  fontData_ = std::move(data);
  // The font info must point at our stored buffer (it holds the pointer).
  if (!stbtt_InitFont(&impl_->info, fontData_.data(), offset)) return Status::Error("font parse failed: " + path);
  cache_.clear();
  loaded_ = true;
  return Status::Ok();
}

const TextRenderer::Glyph& TextRenderer::GetGlyph(std::uint32_t cp, int px) {
  const std::uint64_t key = (static_cast<std::uint64_t>(px) << 32) | cp;
  auto it = cache_.find(key);
  if (it != cache_.end()) return it->second;
  Glyph g;
  if (loaded_) {
    const float scale = stbtt_ScaleForPixelHeight(&impl_->info, static_cast<float>(px));
    int idx = stbtt_FindGlyphIndex(&impl_->info, static_cast<int>(cp));
    if (idx == 0 && cp != 0x20) idx = 0;  // .notdef: a visible box, never a crash
    int adv = 0, lsb = 0;
    stbtt_GetGlyphHMetrics(&impl_->info, idx, &adv, &lsb);
    g.advance = static_cast<float>(adv) * scale;
    int x0, y0, x1, y1;
    stbtt_GetGlyphBitmapBox(&impl_->info, idx, scale, scale, &x0, &y0, &x1, &y1);
    g.w = std::max(0, x1 - x0);
    g.h = std::max(0, y1 - y0);
    g.xoff = x0;
    g.yoff = y0;
    if (g.w > 0 && g.h > 0 && g.w < 512 && g.h < 512) {
      g.alpha.assign(static_cast<std::size_t>(g.w) * static_cast<std::size_t>(g.h), 0);
      stbtt_MakeGlyphBitmap(&impl_->info, g.alpha.data(), g.w, g.h, g.w, scale, scale, idx);
    } else {
      g.w = g.h = 0;
    }
  } else {
    g.advance = static_cast<float>(px) * 0.6f;
  }
  return cache_.emplace(key, std::move(g)).first->second;
}

float TextRenderer::LineHeight(int px) const {
  if (!loaded_) return static_cast<float>(px) * 1.2f;
  const float scale = stbtt_ScaleForPixelHeight(&impl_->info, static_cast<float>(px));
  int asc, desc, gap;
  stbtt_GetFontVMetrics(&impl_->info, &asc, &desc, &gap);
  return static_cast<float>(asc - desc + gap) * scale;
}

float TextRenderer::Measure(const std::string& utf8, int px, int rtl) {
  float w = 0.f;
  for (std::uint32_t c : PrepareForDisplay(utf8, rtl)) w += GetGlyph(c, px).advance;
  return w;
}

float TextRenderer::Draw(Framebuffer& fb, float x, float y, const std::string& utf8, int px, Color color,
                         TextAlign align, int rtl) {
  if (px < 4) px = 4;
  if (px > 200) px = 200;
  const CodePoints cps = PrepareForDisplay(utf8, rtl);
  float width = 0.f;
  for (std::uint32_t c : cps) width += GetGlyph(c, px).advance;
  float pen = x;
  if (align == TextAlign::Center)
    pen = x - width * 0.5f;
  else if (align == TextAlign::Right)
    pen = x - width;
  float baseline = y;
  if (loaded_) {
    const float scale = stbtt_ScaleForPixelHeight(&impl_->info, static_cast<float>(px));
    int asc, desc, gap;
    stbtt_GetFontVMetrics(&impl_->info, &asc, &desc, &gap);
    baseline = y + static_cast<float>(asc) * scale;
  }
  if (!loaded_) {  // fallback: ASCII only through the built-in font
    std::string ascii;
    for (std::uint32_t c : cps) ascii += c < 128 ? static_cast<char>(c) : '?';
    fb.DrawText(pen, y, ascii, std::max(1, px / 8), color);
    return width;
  }
  for (std::uint32_t c : cps) {
    const Glyph& g = GetGlyph(c, px);
    if (g.w > 0) {
      const int gx = static_cast<int>(std::lround(pen)) + g.xoff;
      const int gy = static_cast<int>(std::lround(baseline)) + g.yoff;
      for (int j = 0; j < g.h; ++j) {
        const int py = gy + j;
        if (py < 0 || py >= fb.height()) continue;
        for (int i = 0; i < g.w; ++i) {
          const int pxl = gx + i;
          if (pxl < 0 || pxl >= fb.width()) continue;
          const std::uint8_t a =
              g.alpha[static_cast<std::size_t>(j) * static_cast<std::size_t>(g.w) + static_cast<std::size_t>(i)];
          if (a == 0) continue;
          Color cc = color;
          cc.a = static_cast<std::uint8_t>(static_cast<int>(a) * static_cast<int>(color.a) / 255);
          fb.Blend(pxl, py, cc);
        }
      }
    }
    pen += g.advance;
  }
  return width;
}

std::vector<std::string> TextRenderer::Wrap(const std::string& utf8, int px, float maxWidth) {
  std::vector<std::string> lines;
  std::string line;
  std::size_t i = 0;
  const std::size_t n = utf8.size();
  while (i < n) {
    std::size_t j = utf8.find(' ', i);
    if (j == std::string::npos) j = n;
    const std::string word = utf8.substr(i, j - i);
    const std::string trial = line.empty() ? word : line + " " + word;
    if (!line.empty() && Measure(trial, px) > maxWidth) {
      lines.push_back(line);
      line = word;
    } else {
      line = trial;
    }
    i = j + 1;
  }
  if (!line.empty() || lines.empty()) lines.push_back(line);
  return lines;
}

bool TextRenderer::CoversText(const std::string& utf8) const {
  if (!loaded_) return false;
  for (std::uint32_t c : PrepareForDisplay(utf8)) {
    if (c == ' ' || c == '\n') continue;
    if (stbtt_FindGlyphIndex(&impl_->info, static_cast<int>(c)) == 0) return false;
  }
  return true;
}

}  // namespace ascend
