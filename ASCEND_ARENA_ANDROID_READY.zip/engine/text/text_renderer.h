#pragma once
// TrueType text drawing on the CPU framebuffer (stb_truetype). Handles Arabic via text_shaping.
#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "../core/result.h"
#include "../render/framebuffer.h"
#include "text_shaping.h"

namespace ascend {

enum class TextAlign { Left, Center, Right };

class TextRenderer {
 public:
  TextRenderer();
  ~TextRenderer();
  TextRenderer(const TextRenderer&) = delete;
  TextRenderer& operator=(const TextRenderer&) = delete;

  // Loads a .ttf file. On failure returns an error and the renderer stays usable through the 5x7 fallback font.
  Status LoadFont(const std::string& path);
  bool HasFont() const { return loaded_; }

  // Width in pixels of the text at the given pixel height (after shaping and bidi).
  float Measure(const std::string& utf8, int pixelHeight, int rtlParagraph = -1);
  float LineHeight(int pixelHeight) const;

  // Draws text. `x` is the left edge for Left, the center for Center and the right edge for Right.
  // `y` is the top of the line box. Returns the drawn width.
  float Draw(Framebuffer& fb, float x, float y, const std::string& utf8, int pixelHeight, Color color,
             TextAlign align = TextAlign::Left, int rtlParagraph = -1);

  // Greedy word wrap on logical text; each returned line fits `maxWidth` (a single longer word is kept whole).
  std::vector<std::string> Wrap(const std::string& utf8, int pixelHeight, float maxWidth);

  // True if every glyph of the string exists in the font (used by the validator/tests).
  bool CoversText(const std::string& utf8) const;

 private:
  struct Glyph {
    int w = 0, h = 0, xoff = 0, yoff = 0;
    float advance = 0.f;
    std::vector<std::uint8_t> alpha;
  };
  const Glyph& GetGlyph(std::uint32_t cp, int px);

  struct Impl;
  Impl* impl_;
  bool loaded_ = false;
  std::map<std::uint64_t, Glyph> cache_;
  std::vector<std::uint8_t> fontData_;
};

}  // namespace ascend
