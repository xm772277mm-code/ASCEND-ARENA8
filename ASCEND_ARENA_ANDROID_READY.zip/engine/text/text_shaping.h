#pragma once
// Unicode text preparation for the UI: UTF-8 decoding, Arabic joining/shaping (Presentation Forms-B)
// and a simplified bidirectional reorder, so a font without OpenType shaping can still draw correct
// Arabic. This is NOT a full Unicode Bidi / HarfBuzz implementation; limits are listed in the .cpp.
#include <cstdint>
#include <string>
#include <vector>

namespace ascend {

using CodePoints = std::vector<std::uint32_t>;

// Decodes UTF-8. Invalid bytes become U+FFFD (never throws, never reads out of bounds).
CodePoints DecodeUtf8(const std::string& s);
std::string EncodeUtf8(const CodePoints& cps);

bool IsArabicLetter(std::uint32_t c);     // letters that take part in joining (U+0621..U+064A, U+0640)
bool IsArabicCodepoint(std::uint32_t c);  // any codepoint in the Arabic blocks used by the shaper

// Replaces Arabic base letters with the isolated/initial/medial/final presentation forms and joins
// lam+alef into ligatures. Input and output are in LOGICAL order.
CodePoints ShapeArabic(const CodePoints& logical);

// Converts logical order to visual (left-to-right drawing) order. `rtlParagraph` selects the
// paragraph direction; pass -1 to detect it from the first strong character.
CodePoints ReorderBidi(const CodePoints& logical, int rtlParagraph = -1);

// Full pipeline for drawing: shape then reorder.
CodePoints PrepareForDisplay(const std::string& utf8, int rtlParagraph = -1);

// True if the text contains at least one right-to-left character.
bool ContainsRtl(const std::string& utf8);

}  // namespace ascend
