#pragma once
// Platform-independent input model. The platform host (SDL) converts OS events into
// TouchEvent; tests and the headless sim feed TouchEvent or InputFrame directly.
#include <array>
#include <vector>

#include "../core/amath.h"

namespace ascend {

constexpr int kMaxSkills = 3;

// What gameplay consumes each simulation step.
struct InputFrame {
  Vec2 move;            // -1..1, x = right, y = forward (up on screen)
  Vec2 lookDelta;       // radians of camera yaw/pitch change this frame
  bool attack = false;  // light attack (edge: true only on the step it was pressed)
  bool heavy = false;   // heavy attack
  bool dodge = false;
  std::array<bool, kMaxSkills> skill{};
  bool potion = false;  // use one healing potion (the host/app applies it)
  bool pause = false;
};

enum class TouchPhase { Down, Move, Up, Cancel };

struct TouchEvent {
  int id = 0;
  TouchPhase phase = TouchPhase::Down;
  float x = 0.f, y = 0.f;  // screen pixels, origin top-left
};

enum class ButtonAction { Attack, Heavy, Dodge, Skill1, Skill2, Skill3, Pause, Potion };

struct TouchButton {
  ButtonAction action;
  float cx, cy, radius;  // pixels
};

// Builds a HUD layout for a screen. Touch targets must be at least `minDiameterMm`
// physical size (Android guideline is ~9 mm / 48 dp); `pixelsPerMm` converts.
struct TouchLayout {
  float screenW = 0.f, screenH = 0.f;
  float joystickRadius = 0.f;    // max drag distance in pixels
  float joystickZoneMaxX = 0.f;  // touches starting left of this x control movement
  std::vector<TouchButton> buttons;

  static TouchLayout ForScreen(float w, float h, float pixelsPerMm);
  // Smallest button diameter in mm for the given pixelsPerMm.
  float MinButtonDiameterMm(float pixelsPerMm) const;
};

class TouchRouter {
 public:
  explicit TouchRouter(TouchLayout layout, float deadzone = 0.12f, float lookRadiansPerPixel = 0.005f)
      : layout_(std::move(layout)), deadzone_(deadzone), lookScale_(lookRadiansPerPixel) {}

  void OnTouch(const TouchEvent& e);
  // Produces the frame for this simulation step and clears one-shot presses/look delta.
  InputFrame Consume();
  // Releases everything (call on pause/background so no control stays stuck).
  void ReleaseAll();

  const TouchLayout& layout() const { return layout_; }
  // Where to draw the on-screen joystick (base = where the thumb went down, knob = current thumb, clamped).
  bool JoystickVisual(Vec2& base, Vec2& knob) const;

 private:
  enum class Role { None, Joystick, Look, Button };
  struct Active {
    int id = -1;
    Role role = Role::None;
    float startX = 0, startY = 0, lastX = 0, lastY = 0;
    int buttonIndex = -1;
  };

  Active* Find(int id);
  void Release(int id);

  TouchLayout layout_;
  float deadzone_, lookScale_;
  std::vector<Active> active_;
  Vec2 move_{};
  Vec2 look_{};
  InputFrame pending_{};
};

}  // namespace ascend
