#include "input.h"

#include <algorithm>
#include <cmath>

namespace ascend {

TouchLayout TouchLayout::ForScreen(float w, float h, float pixelsPerMm) {
  TouchLayout l;
  l.screenW = w;
  l.screenH = h;
  const float mm = pixelsPerMm;
  // Diameters in mm: primary buttons 14 mm, secondary 11 mm, pause 10 mm (all >= 9 mm).
  const float big = 7.f * mm, mid = 5.5f * mm, small = 5.f * mm;
  const float margin = 12.f * mm;
  l.joystickRadius = 11.f * mm;
  l.joystickZoneMaxX = w * 0.4f;

  // Thumb arc around the Attack button (all distances in mm, designed so no two buttons touch: gaps >= 1 mm;
  // tests/test_ui.cpp checks this for several screen sizes). Inner ring: Heavy, Dodge, Skill1. Outer ring: Skill2/3.
  const float ax = w - margin - big;  // Attack center
  const float ay = h - margin - big;
  l.buttons.push_back({ButtonAction::Attack, ax, ay, big});
  const float r1 = big + mid + 2.f * mm, r2 = 2.f * r1;
  const struct {
    ButtonAction action;
    float ring;
    float degrees;
  } arc[] = {{ButtonAction::Heavy, r1, 180.f},
             {ButtonAction::Dodge, r1, 125.f},
             {ButtonAction::Skill1, r1, 70.f},
             {ButtonAction::Skill2, r2, 152.f},
             {ButtonAction::Skill3, r2, 112.f}};
  for (const auto& b : arc) {
    const float rad = b.degrees * 3.14159265f / 180.f;
    l.buttons.push_back({b.action, ax + b.ring * std::cos(rad), ay - b.ring * std::sin(rad), mid});
  }
  l.buttons.push_back({ButtonAction::Pause, w - margin, margin, small});
  l.buttons.push_back({ButtonAction::Potion, w - margin, margin + 2.f * small + 4.f * mm, small});
  return l;
}

float TouchLayout::MinButtonDiameterMm(float pixelsPerMm) const {
  float m = 1e9f;
  for (const auto& b : buttons) m = std::min(m, b.radius * 2.f / pixelsPerMm);
  return buttons.empty() ? 0.f : m;
}

TouchRouter::Active* TouchRouter::Find(int id) {
  for (auto& a : active_)
    if (a.id == id) return &a;
  return nullptr;
}

void TouchRouter::Release(int id) {
  for (std::size_t i = 0; i < active_.size(); ++i) {
    if (active_[i].id != id) continue;
    if (active_[i].role == Role::Joystick) move_ = {};
    active_.erase(active_.begin() + static_cast<std::ptrdiff_t>(i));
    return;
  }
}

void TouchRouter::OnTouch(const TouchEvent& e) {
  if (e.phase == TouchPhase::Up || e.phase == TouchPhase::Cancel) {
    Release(e.id);
    return;
  }
  if (e.phase == TouchPhase::Down) {
    if (Find(e.id)) return;  // duplicate down
    Active a;
    a.id = e.id;
    a.startX = a.lastX = e.x;
    a.startY = a.lastY = e.y;
    // Buttons take priority.
    for (std::size_t i = 0; i < layout_.buttons.size(); ++i) {
      const auto& b = layout_.buttons[i];
      const float dx = e.x - b.cx, dy = e.y - b.cy;
      if (dx * dx + dy * dy <= b.radius * b.radius) {
        a.role = Role::Button;
        a.buttonIndex = static_cast<int>(i);
        switch (b.action) {
          case ButtonAction::Attack:
            pending_.attack = true;
            break;
          case ButtonAction::Heavy:
            pending_.heavy = true;
            break;
          case ButtonAction::Dodge:
            pending_.dodge = true;
            break;
          case ButtonAction::Skill1:
            pending_.skill[0] = true;
            break;
          case ButtonAction::Skill2:
            pending_.skill[1] = true;
            break;
          case ButtonAction::Skill3:
            pending_.skill[2] = true;
            break;
          case ButtonAction::Pause:
            pending_.pause = true;
            break;
          case ButtonAction::Potion:
            pending_.potion = true;
            break;
        }
        active_.push_back(a);
        return;
      }
    }
    bool joyTaken = false;
    for (const auto& o : active_) joyTaken |= (o.role == Role::Joystick);
    if (e.x < layout_.joystickZoneMaxX && !joyTaken)
      a.role = Role::Joystick;
    else
      a.role = Role::Look;
    active_.push_back(a);
    return;
  }
  // Move
  Active* a = Find(e.id);
  if (!a) return;
  if (a->role == Role::Joystick) {
    float dx = e.x - a->startX, dy = e.y - a->startY;
    const float len = std::sqrt(dx * dx + dy * dy);
    const float r = layout_.joystickRadius;
    const float mag = std::min(len / r, 1.f);
    if (mag < deadzone_ || len < 1e-4f) {
      move_ = {};
    } else {
      // Rescale so output ramps from 0 at the deadzone edge to 1 at full drag.
      const float scaled = (mag - deadzone_) / (1.f - deadzone_);
      move_ = {dx / len * scaled, -dy / len * scaled};  // screen up => forward (+y)
    }
  } else if (a->role == Role::Look) {
    look_.x += (e.x - a->lastX) * lookScale_;
    look_.y += (e.y - a->lastY) * lookScale_;
  }
  a->lastX = e.x;
  a->lastY = e.y;
}

InputFrame TouchRouter::Consume() {
  InputFrame f = pending_;
  f.move = move_;
  f.lookDelta = look_;
  pending_ = InputFrame{};
  look_ = {};
  return f;
}

bool TouchRouter::JoystickVisual(Vec2& base, Vec2& knob) const {
  for (const auto& a : active_) {
    if (a.role != Role::Joystick) continue;
    base = {a.startX, a.startY};
    float dx = a.lastX - a.startX, dy = a.lastY - a.startY;
    const float len = std::sqrt(dx * dx + dy * dy);
    if (len > layout_.joystickRadius && len > 1e-4f) {
      dx *= layout_.joystickRadius / len;
      dy *= layout_.joystickRadius / len;
    }
    knob = {a.startX + dx, a.startY + dy};
    return true;
  }
  return false;
}

void TouchRouter::ReleaseAll() {
  active_.clear();
  move_ = {};
  look_ = {};
  pending_ = InputFrame{};
}

}  // namespace ascend
