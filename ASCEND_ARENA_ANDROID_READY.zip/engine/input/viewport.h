#pragma once
// Maps between the OS window and the internal CPU framebuffer: safe-area (notch / rounded corners),
// render-resolution choice per quality tier, touch coordinate conversion and physical size (px per mm).
// Pure functions so they are unit-tested without SDL.
#include <string>

namespace ascend {

struct RectI {
  int x = 0, y = 0, w = 0, h = 0;
};

struct Viewport {
  RectI dst;  // where the framebuffer is drawn inside the window (the safe area)
  int fbW = 0, fbH = 0;
};

// Target framebuffer height for a quality tier ("low" 360, "medium" 540, "high" 720; unknown -> medium).
int FbHeightForQuality(const std::string& quality);

// `safe` may be empty/invalid (w or h <= 0): the whole window is used. It is clamped into the window.
// The framebuffer keeps the safe area's aspect ratio; width is even and within [320, 2048].
Viewport ComputeViewport(int winW, int winH, RectI safe, int targetFbHeight);

// Converts window pixel coordinates to framebuffer coordinates (clamped to the framebuffer).
// Returns true when the point was inside the destination rectangle.
bool WindowToFb(const Viewport& vp, float wx, float wy, float& fx, float& fy);

// Physical size of one framebuffer pixel. displayScale: 1.0 = 160 dpi (Android density / 160).
// Result is clamped to [3, 30] so a wrong density report cannot make buttons microscopic or huge.
float FbPixelsPerMm(const Viewport& vp, float displayScale);

}  // namespace ascend
