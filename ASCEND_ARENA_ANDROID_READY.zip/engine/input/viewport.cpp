#include "viewport.h"

#include <algorithm>
#include <cmath>

namespace ascend {

int FbHeightForQuality(const std::string& q) {
  if (q == "low") return 360;
  if (q == "high") return 720;
  return 540;
}

Viewport ComputeViewport(int winW, int winH, RectI safe, int targetH) {
  Viewport vp;
  winW = std::max(winW, 1);
  winH = std::max(winH, 1);
  RectI r = safe;
  if (r.w <= 0 || r.h <= 0) r = {0, 0, winW, winH};
  r.x = std::clamp(r.x, 0, winW - 1);
  r.y = std::clamp(r.y, 0, winH - 1);
  r.w = std::clamp(r.w, 1, winW - r.x);
  r.h = std::clamp(r.h, 1, winH - r.y);
  vp.dst = r;
  const int h = std::clamp(std::min(targetH, r.h), 180, 1080);
  const double aspect = static_cast<double>(r.w) / static_cast<double>(r.h);
  int w = static_cast<int>(std::lround(static_cast<double>(h) * aspect));
  w = std::clamp(w, 320, 2048);
  w &= ~1;
  vp.fbW = w;
  vp.fbH = h;
  return vp;
}

bool WindowToFb(const Viewport& vp, float wx, float wy, float& fx, float& fy) {
  const float u = (wx - static_cast<float>(vp.dst.x)) / static_cast<float>(vp.dst.w);
  const float v = (wy - static_cast<float>(vp.dst.y)) / static_cast<float>(vp.dst.h);
  const bool inside = u >= 0.f && u <= 1.f && v >= 0.f && v <= 1.f;
  fx = std::clamp(u, 0.f, 1.f) * static_cast<float>(vp.fbW);
  fy = std::clamp(v, 0.f, 1.f) * static_cast<float>(vp.fbH);
  return inside;
}

float FbPixelsPerMm(const Viewport& vp, float displayScale) {
  if (!(displayScale > 0.2f) || !std::isfinite(displayScale)) displayScale = 2.0f;  // unknown: assume a ~320 dpi phone
  const float windowPxPerMm = 160.f * displayScale / 25.4f;
  const float k = static_cast<float>(vp.fbW) / static_cast<float>(std::max(vp.dst.w, 1));
  return std::clamp(windowPxPerMm * k, 3.f, 30.f);
}

}  // namespace ascend
