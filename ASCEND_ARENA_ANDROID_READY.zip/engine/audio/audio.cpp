#include "audio.h"

#include <algorithm>
#include <cmath>

namespace ascend {
namespace {

constexpr float kTwoPi = 6.28318530717958647692f;
constexpr float kRate = static_cast<float>(kAudioRate);

// Deterministic white noise (xorshift32), reset per clip so output never depends on call order.
struct Noise {
  std::uint32_t s = 0x1234ABCDu;
  float Next() {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return static_cast<float>(s & 0xFFFFFFu) / 8388608.f - 1.f;  // [-1, 1)
  }
};

std::int16_t ToPcm(float v) {
  v = std::clamp(v, -1.f, 1.f);
  return static_cast<std::int16_t>(std::lround(v * 32000.f));
}

// Attack/decay envelope with a hard guarantee of zero at both ends (no clicks).
float Env(float t, float dur, float attack = 0.004f, float release = 0.02f) {
  if (t < 0.f || t > dur) return 0.f;
  float e = 1.f;
  if (t < attack) e = t / attack;
  if (dur - t < release) e = std::min(e, (dur - t) / release);
  return e;
}

// Fills `dur` seconds by calling f(t, i) and applies a final safety fade-out of 3 ms.
template <typename F>
PcmClip Make(float dur, F f) {
  PcmClip c;
  const int n = static_cast<int>(dur * kRate);
  c.samples.resize(static_cast<std::size_t>(n));
  for (int i = 0; i < n; ++i) {
    const float t = static_cast<float>(i) / kRate;
    c.samples[static_cast<std::size_t>(i)] = ToPcm(f(t, i));
  }
  const int fade = std::min(n, static_cast<int>(0.003f * kRate));
  for (int i = 0; i < fade; ++i) {
    const float k = static_cast<float>(i) / static_cast<float>(fade);
    auto& s = c.samples[static_cast<std::size_t>(n - 1 - i)];
    s = static_cast<std::int16_t>(static_cast<float>(s) * k);
  }
  if (n > 0) c.samples[0] = 0;
  return c;
}

float Sine(float phase) { return std::sin(kTwoPi * phase); }

// Sine with a frequency sweep from f0 to f1 over `dur` (phase integrated analytically).
float Sweep(float t, float dur, float f0, float f1) {
  const float k = (f1 - f0) / dur;
  return Sine(f0 * t + 0.5f * k * t * t);
}

PcmClip Arp(const float* notes, int count, float noteDur, float amp) {
  const float total = noteDur * static_cast<float>(count) + 0.12f;
  return Make(total, [=](float t, int) {
    float v = 0.f;
    for (int k = 0; k < count; ++k) {
      const float st = static_cast<float>(k) * noteDur;
      const float lt = t - st;
      if (lt < 0.f) continue;
      const float f = notes[k];
      const float e = Env(lt, noteDur + 0.12f, 0.004f, 0.08f) * std::exp(-lt * 6.f);
      v += e * (Sine(f * lt) + 0.35f * Sine(2.f * f * lt));
    }
    return v * amp;
  });
}

PcmClip Synth(Sfx s) {
  Noise nz;
  switch (s) {
    case Sfx::UiClick:
      return Make(0.06f, [&](float t, int) { return 0.45f * Env(t, 0.06f) * Sweep(t, 0.06f, 1300.f, 900.f); });
    case Sfx::UiBack:
      return Make(0.07f, [&](float t, int) { return 0.4f * Env(t, 0.07f) * Sweep(t, 0.07f, 800.f, 520.f); });
    case Sfx::Swing: {
      float lp = 0.f;
      return Make(0.14f, [&](float t, int) {
        const float cutoff = 0.05f + 0.35f * std::sin(3.14159f * t / 0.14f);  // rises then falls
        lp += cutoff * (nz.Next() - lp);
        return 0.9f * Env(t, 0.14f, 0.02f, 0.05f) * lp;
      });
    }
    case Sfx::Heavy: {
      float lp = 0.f;
      return Make(0.26f, [&](float t, int) {
        lp += 0.12f * (nz.Next() - lp);
        const float thump = Sweep(t, 0.26f, 140.f, 55.f) * std::exp(-t * 9.f);
        return Env(t, 0.26f, 0.006f, 0.08f) * (0.9f * lp + 0.8f * thump);
      });
    }
    case Sfx::Hit:
      return Make(0.12f, [&](float t, int) {
        return Env(t, 0.12f, 0.002f, 0.04f) *
               (0.5f * nz.Next() * std::exp(-t * 40.f) + 0.7f * Sweep(t, 0.12f, 220.f, 110.f) * std::exp(-t * 18.f));
      });
    case Sfx::Crit:
      return Make(0.20f, [&](float t, int) {
        return Env(t, 0.20f, 0.002f, 0.06f) *
               (0.45f * nz.Next() * std::exp(-t * 35.f) + 0.6f * Sweep(t, 0.2f, 260.f, 120.f) * std::exp(-t * 14.f) +
                0.35f * Sine(1450.f * t) * std::exp(-t * 16.f));
      });
    case Sfx::Skill:
      return Make(0.28f, [&](float t, int) {
        const float vib = 1.f + 0.02f * Sine(9.f * t);
        return 0.55f * Env(t, 0.28f, 0.01f, 0.1f) *
               (Sweep(t, 0.28f, 300.f * vib, 950.f) + 0.4f * Sweep(t, 0.28f, 600.f, 1900.f));
      });
    case Sfx::Dash: {
      float lp = 0.f;
      return Make(0.18f, [&](float t, int) {
        lp += (0.4f - 1.8f * t) * 0.3f * (nz.Next() - lp);
        return 1.1f * Env(t, 0.18f, 0.015f, 0.08f) * lp;
      });
    }
    case Sfx::Dodge: {
      float lp = 0.f;
      return Make(0.15f, [&](float t, int) {
        lp += 0.2f * (nz.Next() - lp);
        return 0.9f * Env(t, 0.15f, 0.01f, 0.07f) * lp + 0.2f * Env(t, 0.15f) * Sweep(t, 0.15f, 500.f, 200.f);
      });
    }
    case Sfx::PlayerHurt:
      return Make(0.2f, [&](float t, int) {
        const float f = 220.f - 110.f * t / 0.2f;
        const float ph = f * t;
        const float saw = 2.f * (ph - std::floor(ph + 0.5f));
        return 0.45f * Env(t, 0.2f, 0.004f, 0.08f) * saw + 0.2f * Env(t, 0.2f) * nz.Next() * std::exp(-t * 25.f);
      });
    case Sfx::EnemyDefeat: {
      float lp = 0.f;
      return Make(0.34f, [&](float t, int) {
        lp += 0.25f * (nz.Next() - lp);
        return Env(t, 0.34f, 0.004f, 0.12f) *
               (0.55f * Sweep(t, 0.34f, 520.f, 90.f) * std::exp(-t * 4.f) + 0.5f * lp * std::exp(-t * 8.f));
      });
    }
    case Sfx::EnemyWindup:
      return Make(0.28f, [&](float t, int) {
        const float trem = 0.6f + 0.4f * Sine(18.f * t);
        return 0.5f * Env(t, 0.28f, 0.02f, 0.06f) * trem * Sweep(t, 0.28f, 110.f, 240.f);
      });
    case Sfx::LevelUp: {
      static const float n[] = {523.25f, 659.25f, 783.99f, 1046.5f};
      return Arp(n, 4, 0.09f, 0.28f);
    }
    case Sfx::Pickup: {
      static const float n[] = {880.f, 1318.5f};
      return Arp(n, 2, 0.07f, 0.3f);
    }
    case Sfx::Victory: {
      static const float n[] = {392.f, 523.25f, 659.25f, 783.99f, 1046.5f};
      return Arp(n, 5, 0.12f, 0.26f);
    }
    case Sfx::Defeat: {
      static const float n[] = {392.f, 349.23f, 311.13f, 261.63f};
      return Arp(n, 4, 0.16f, 0.28f);
    }
    case Sfx::Count:
      break;
  }
  return {};
}

// ---- music ------------------------------------------------------------------------------------------

struct Chord {
  float root;  // bass frequency
  float third, fifth;
};

float NoteHz(int semitonesFromA4) { return 440.f * std::pow(2.f, static_cast<float>(semitonesFromA4) / 12.f); }

// Generates `bars` bars at `bpm`; each bar plays one chord from `prog` (cyclic). `arpRate` = notes per beat.
PcmClip Compose(float bpm, int bars, const std::vector<Chord>& prog, float arpRate, float padAmp, float bassAmp,
                float arpAmp, bool pulse) {
  const float beat = 60.f / bpm, bar = beat * 4.f;
  const float total = bar * static_cast<float>(bars);
  const int n = static_cast<int>(total * kRate);
  PcmClip c;
  c.samples.resize(static_cast<std::size_t>(n));
  for (int i = 0; i < n; ++i) {
    const float t = static_cast<float>(i) / kRate;
    const int b = static_cast<int>(t / bar);
    const Chord& ch = prog[static_cast<std::size_t>(b) % prog.size()];
    const float tb = t - static_cast<float>(b) * bar;  // time in bar
    // Pad: three detuned sines per chord tone with a bar-long swell (zero at bar boundaries -> loop safe).
    const float swell = std::sin(3.14159265f * tb / bar);
    float pad = 0.f;
    for (float f : {ch.root * 2.f, ch.third * 2.f, ch.fifth * 2.f})
      pad += Sine(f * t) + 0.5f * Sine(f * 1.004f * t) + 0.25f * Sine(f * 2.f * t);
    pad *= padAmp * swell * swell / 3.f;
    // Bass: on every beat (pulse) or half-bar, decaying.
    const float bt = std::fmod(tb, pulse ? beat * 0.5f : beat * 2.f);
    const float bassEnv =
        std::exp(-bt * (pulse ? 7.f : 2.5f)) * std::min(1.f, bt / 0.01f) * std::min(1.f, (bar - tb) / 0.02f);
    const float bass = bassAmp * bassEnv * (Sine(ch.root * t) + 0.3f * Sine(ch.root * 2.f * t));
    // Arp: chord tones in a rising pattern.
    const float step = beat / arpRate;
    const int k = static_cast<int>(tb / step);
    const float at = tb - static_cast<float>(k) * step;
    const float tones[4] = {ch.root * 4.f, ch.third * 4.f, ch.fifth * 4.f, ch.third * 4.f};
    const float f = tones[k % 4];
    const float arpEnv = std::exp(-at * 14.f) * std::min(1.f, at / 0.003f) * std::min(1.f, (bar - tb) / 0.02f);
    const float arp = arpAmp * arpEnv * (Sine(f * t) + 0.2f * Sine(f * 3.f * t));
    c.samples[static_cast<std::size_t>(i)] = ToPcm(pad + bass + arp);
  }
  // Loop seam: all components are zero at bar boundaries by construction; force the edges anyway.
  if (n > 0) {
    c.samples[0] = 0;
    c.samples[static_cast<std::size_t>(n - 1)] = 0;
  }
  return c;
}

PcmClip SynthMusic(Music m) {
  auto hz = [](int semis) { return NoteHz(semis); };
  switch (m) {
    case Music::Menu: {  // A minor, slow, airy
      const std::vector<Chord> prog = {{hz(-24), hz(-21), hz(-17)},
                                       {hz(-28), hz(-24), hz(-21)},
                                       {hz(-31), hz(-27), hz(-24)},
                                       {hz(-29), hz(-25), hz(-22)}};
      return Compose(60.f, 8, prog, 2.f, 0.16f, 0.12f, 0.06f, false);
    }
    case Music::Battle: {  // D minor, driving
      const std::vector<Chord> prog = {{hz(-31), hz(-28), hz(-24)},
                                       {hz(-35), hz(-32), hz(-28)},
                                       {hz(-33), hz(-29), hz(-26)},
                                       {hz(-36), hz(-32), hz(-29)}};
      return Compose(124.f, 8, prog, 2.f, 0.1f, 0.2f, 0.09f, true);
    }
    case Music::Boss: {  // tritone colour, faster
      const std::vector<Chord> prog = {{hz(-33), hz(-30), hz(-26)},
                                       {hz(-39), hz(-36), hz(-32)},
                                       {hz(-34), hz(-31), hz(-27)},
                                       {hz(-40), hz(-37), hz(-33)}};
      return Compose(144.f, 8, prog, 4.f, 0.1f, 0.22f, 0.08f, true);
    }
    default:
      break;
  }
  return {};
}

}  // namespace

const PcmClip& SfxClip(Sfx s) {
  static std::vector<PcmClip> cache(static_cast<std::size_t>(Sfx::Count));
  static std::vector<bool> done(static_cast<std::size_t>(Sfx::Count), false);
  const auto i = static_cast<std::size_t>(s);
  static const PcmClip empty;
  if (i >= cache.size()) return empty;
  if (!done[i]) {
    cache[i] = Synth(s);
    done[i] = true;
  }
  return cache[i];
}

const PcmClip& MusicClip(Music m) {
  static std::vector<PcmClip> cache(static_cast<std::size_t>(Music::Count));
  static std::vector<bool> done(static_cast<std::size_t>(Music::Count), false);
  const auto i = static_cast<std::size_t>(m);
  static const PcmClip empty;
  if (i >= cache.size() || m == Music::None) return empty;
  if (!done[i]) {
    cache[i] = SynthMusic(m);
    done[i] = true;
  }
  return cache[i];
}

const char* SfxName(Sfx s) {
  static const char* names[] = {"ui_click", "ui_back", "swing",   "heavy",       "hit",          "crit",
                                "skill",    "dash",    "dodge",   "player_hurt", "enemy_defeat", "enemy_windup",
                                "level_up", "pickup",  "victory", "defeat"};
  const auto i = static_cast<std::size_t>(s);
  return i < sizeof(names) / sizeof(names[0]) ? names[i] : "?";
}

// ------------------------------------------------------------------------------------------- mixer

namespace {
// Per-sound concurrency caps and the minimum spacing between two plays of the same sound (in frames).
int MaxConcurrent(Sfx s) {
  switch (s) {
    case Sfx::Hit:
    case Sfx::Crit:
    case Sfx::Swing:
    case Sfx::EnemyDefeat:
      return 3;
    case Sfx::UiClick:
    case Sfx::UiBack:
      return 2;
    default:
      return 2;
  }
}
std::int64_t MinSpacing(Sfx s) {
  switch (s) {
    case Sfx::Hit:
    case Sfx::Crit:
      return kAudioRate / 33;  // 30 ms: an area hit on 10 enemies is one sound
    case Sfx::EnemyDefeat:
      return kAudioRate / 20;
    default:
      return kAudioRate / 50;  // 20 ms
  }
}
int Priority(Sfx s) {  // higher survives voice stealing
  switch (s) {
    case Sfx::LevelUp:
    case Sfx::Victory:
    case Sfx::Defeat:
      return 3;
    case Sfx::PlayerHurt:
    case Sfx::EnemyWindup:
    case Sfx::Dodge:
      return 2;
    default:
      return 1;
  }
}
}  // namespace

Mixer::Mixer(int maxVoices) : maxVoices_(std::clamp(maxVoices, 1, 64)) {
  voices_.resize(static_cast<std::size_t>(maxVoices_));
  for (auto& l : lastPlay_) l = -1000000000LL;
}

void Mixer::SetVolumes(int music, int sfx) {
  musicVol_ = static_cast<float>(std::clamp(music, 0, 100)) / 100.f;
  sfxVol_ = static_cast<float>(std::clamp(sfx, 0, 100)) / 100.f;
}

void Mixer::StopAll() {
  for (auto& v : voices_) v.active = false;
  layers_[0] = {};
  layers_[1] = {};
  wanted_ = Music::None;
}

bool Mixer::Play(Sfx s, float gain, float pitch) {
  const auto si = static_cast<std::size_t>(s);
  if (si >= static_cast<std::size_t>(Sfx::Count)) return false;
  if (!std::isfinite(gain) || !std::isfinite(pitch)) return false;
  gain = std::clamp(gain, 0.f, 2.f);
  pitch = std::clamp(pitch, 0.5f, 2.f);
  const PcmClip& clip = SfxClip(s);
  if (clip.samples.empty()) return false;
  if (clock_ - lastPlay_[si] < MinSpacing(s)) {
    ++stats_.droppedPlays;
    return false;
  }
  int same = 0;
  for (const auto& v : voices_) same += (v.active && v.sfx == s) ? 1 : 0;
  if (same >= MaxConcurrent(s)) {
    ++stats_.droppedPlays;
    return false;
  }
  Voice* slot = nullptr;
  for (auto& v : voices_)
    if (!v.active) {
      slot = &v;
      break;
    }
  if (!slot) {  // steal the oldest voice of the lowest priority, unless the new sound is less important
    Voice* victim = nullptr;
    for (auto& v : voices_) {
      if (!victim || Priority(v.sfx) < Priority(victim->sfx) ||
          (Priority(v.sfx) == Priority(victim->sfx) && v.startedAt < victim->startedAt))
        victim = &v;
    }
    if (!victim || Priority(victim->sfx) > Priority(s)) {
      ++stats_.droppedPlays;
      return false;
    }
    slot = victim;
    ++stats_.stolenVoices;
  }
  slot->clip = &clip;
  slot->pos = 0.0;
  slot->gain = gain;
  slot->pitch = pitch;
  slot->sfx = s;
  slot->startedAt = clock_;
  slot->active = true;
  lastPlay_[si] = clock_;
  return true;
}

void Mixer::SetMusic(Music m) {
  if (m == wanted_) return;
  wanted_ = m;
  layers_[1] = layers_[0];  // current fades out
  layers_[0] = {};
  layers_[0].id = m;
  layers_[0].clip = m == Music::None ? nullptr : &MusicClip(m);
  layers_[0].level = 0.f;
  if (layers_[0].clip && layers_[0].clip->samples.empty()) layers_[0].clip = nullptr;
}

void Mixer::Mix(std::int16_t* out, int frames) {
  if (!out || frames <= 0) return;
  if (paused_) {
    std::fill(out, out + static_cast<std::size_t>(frames) * 2, static_cast<std::int16_t>(0));
    return;
  }
  const float fadeStep = 1.f / (0.6f * kRate);  // 0.6 s crossfade
  for (int i = 0; i < frames; ++i) {
    float acc = 0.f;
    // Music layers.
    for (int li = 0; li < 2; ++li) {
      MusicLayer& L = layers_[li];
      if (!L.clip) continue;
      const auto& s = L.clip->samples;
      acc += static_cast<float>(s[L.pos]) / 32768.f * L.level * musicVol_ * 0.8f;
      L.pos = (L.pos + 1) % s.size();
      if (li == 0)
        L.level = std::min(1.f, L.level + fadeStep);
      else {
        L.level -= fadeStep;
        if (L.level <= 0.f) L = {};
      }
    }
    // Voices.
    for (auto& v : voices_) {
      if (!v.active) continue;
      const auto& s = v.clip->samples;
      const std::size_t p = static_cast<std::size_t>(v.pos);
      if (p + 1 >= s.size()) {
        v.active = false;
        continue;
      }
      const float frac = static_cast<float>(v.pos - static_cast<double>(p));
      const float smp = (static_cast<float>(s[p]) * (1.f - frac) + static_cast<float>(s[p + 1]) * frac) / 32768.f;
      acc += smp * v.gain * sfxVol_;
      v.pos += static_cast<double>(v.pitch);
    }
    // Soft limiter keeps many simultaneous loud voices from wrapping around.
    const float lim = std::tanh(acc);
    const auto o = static_cast<std::int16_t>(std::lround(std::clamp(lim, -1.f, 1.f) * 32767.f));
    out[static_cast<std::size_t>(i) * 2] = o;
    out[static_cast<std::size_t>(i) * 2 + 1] = o;
  }
  clock_ += frames;
  int active = 0;
  for (const auto& v : voices_) active += v.active ? 1 : 0;
  stats_.activeVoices = active;
}

}  // namespace ascend
