#pragma once
// ASCEND ENGINE audio: procedurally synthesized original sound effects and music loops plus a small
// deterministic software mixer. No audio files are bundled (nothing to license); the platform host only
// pushes the mixed PCM to the OS. Everything here is pure CPU code, so it is unit-tested without a device.
#include <cstdint>
#include <vector>

namespace ascend {

constexpr int kAudioRate = 22050;  // mono clips and mixer output (stereo interleaved) are at this rate

enum class Sfx {
  UiClick,
  UiBack,
  Swing,
  Heavy,
  Hit,
  Crit,
  Skill,
  Dash,
  Dodge,
  PlayerHurt,
  EnemyDefeat,
  EnemyWindup,
  LevelUp,
  Pickup,
  Victory,
  Defeat,
  Count
};
enum class Music { None, Menu, Battle, Boss, Count };

struct PcmClip {
  std::vector<std::int16_t> samples;  // mono
};

// Clips are synthesized on first use and cached. Synthesis is deterministic (fixed noise seed).
const PcmClip& SfxClip(Sfx s);
const PcmClip& MusicClip(Music m);  // seamless loop; Music::None returns an empty clip
const char* SfxName(Sfx s);

struct MixerStats {
  int activeVoices = 0;
  int droppedPlays = 0;  // rejected by the rate limit or per-sound cap
  int stolenVoices = 0;  // oldest voice replaced because the voice cap was reached
};

class Mixer {
 public:
  explicit Mixer(int maxVoices = 16);

  // Volumes 0..100 (values outside are clamped). Applied immediately.
  void SetVolumes(int music, int sfx);
  // Starts a sound effect. gain 0..2, pitch 0.5..2. Returns false if it was dropped.
  bool Play(Sfx s, float gain = 1.f, float pitch = 1.f);
  // Crossfades to a music loop (Music::None fades out).
  void SetMusic(Music m);
  Music music() const { return wanted_; }
  // Freezes everything (app in background): output is silence and no voice advances.
  void SetPaused(bool p) { paused_ = p; }
  bool paused() const { return paused_; }
  void StopAll();

  // Writes `frames` stereo frames (interleaved L,R int16) to out, overwriting it. Safe for frames <= 0.
  void Mix(std::int16_t* out, int frames);

  const MixerStats& stats() const { return stats_; }
  std::int64_t clock() const { return clock_; }  // frames mixed so far (unpaused)

 private:
  struct Voice {
    const PcmClip* clip = nullptr;
    double pos = 0.0;
    float gain = 1.f, pitch = 1.f;
    Sfx sfx = Sfx::UiClick;
    std::int64_t startedAt = 0;
    bool active = false;
  };
  struct MusicLayer {
    const PcmClip* clip = nullptr;
    Music id = Music::None;
    std::size_t pos = 0;
    float level = 0.f;  // 0..1 crossfade level
  };

  int maxVoices_;
  std::vector<Voice> voices_;
  MusicLayer layers_[2];  // [0] = current, [1] = fading out
  Music wanted_ = Music::None;
  float musicVol_ = 0.7f, sfxVol_ = 0.8f;
  bool paused_ = false;
  std::int64_t clock_ = 0;
  std::int64_t lastPlay_[static_cast<int>(Sfx::Count)];
  MixerStats stats_;
};

}  // namespace ascend
